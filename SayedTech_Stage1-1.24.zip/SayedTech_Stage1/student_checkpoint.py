"""Local, transactional recovery of completed read-only student scans.

Only completed student results are stored beside the chosen Excel destination.
No login secret, browser profile, cookie or raw record URL is persisted.
"""
from collections import Counter
import copy
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import threading
from uuid import uuid4

from student_scan import (ScanError, row_key, TABS, collect_students,
                          export_students, missing_fields)
from student_excel import BY_ID, ADDRESS_HEADERS,shift_for_username


def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()


def fingerprint(item):
    return digest(row_key(item))


def valid_result(row):
    """Bound and validate locally saved JSON before it can reach the exporter."""
    scalar=lambda v:isinstance(v,(str,bool)) and len(str(v))<=8192
    if not isinstance(row,dict) or not isinstance(row.get('item'),dict):return False
    if any(not isinstance(row['item'].get(k,''),str) or len(row['item'].get(k,''))>1024
           for k in ('uid','first','middle','last','grade','language','section','status','branch','school')):return False
    if not isinstance(row.get('values'),dict) or not set(row['values'])<=BY_ID.keys():return False
    if not all(scalar(v) for v in row['values'].values()):return False
    if not isinstance(row.get('read_ids'),list) or len(row['read_ids'])>len(BY_ID):return False
    if any(not isinstance(k,str) or k not in BY_ID for k in row['read_ids']):return False
    if not isinstance(row.get('address'),dict) or not set(row['address'])<=set(ADDRESS_HEADERS):return False
    if not all(scalar(v) for v in row['address'].values()):return False
    for key in ('unread_tabs','empty_tabs'):
        if not isinstance(row.get(key),list) or len(row[key])>len(TABS) or any(t not in TABS for t in row[key]):return False
    if not isinstance(row.get('fields'),list) or len(row['fields'])>5000:return False
    for field in row['fields']:
        if not isinstance(field,dict) or not scalar(field.get('value')) or type(field.get('required')) is not bool:return False
        if any(not isinstance(field.get(k),str) or len(field[k])>1024 for k in ('section','label','kind')):return False
    if row.get('skipped','') not in ('','deleted','duplicate_record'):return False
    if 'record_ref' in row and (not isinstance(row['record_ref'],str) or not re.fullmatch('[a-f0-9]{64}',row['record_ref'])):return False
    return True


class ScanCheckpoint:
    def __init__(self,path,username,limit,grade=None):
        self.target=Path(path)
        self.path=self.target.with_suffix('.sayedtech-progress.sqlite3')
        self.owner=digest(username.strip().casefold())
        self.limit=limit
        self.grade=grade
        self.db=None
        self.bound=False
        self.cache={}
        self.total=0

    def bind(self,records):
        if self.target.suffix.lower()!='.xlsx':raise ScanError('scan_failed','checkpoint_write')
        expected={'version':1,'account':self.owner,'roster':digest(sorted(row_key(r) for r in records)),
                  'limit':self.limit,'inventory':len(records)}
        if self.grade is not None:expected['grade']=self.grade
        self.counts=Counter(fingerprint(r) for r in records)
        self.total=len(records)
        existed=self.path.exists()
        try:
            if existed and self.path.stat().st_size>512*1024*1024:raise ValueError()
            self.db=sqlite3.connect(str(self.path),timeout=10)
            self.db.execute('PRAGMA trusted_schema=OFF')
            self.db.execute('PRAGMA synchronous=FULL')
            if not existed:
                with self.db:
                    self.db.execute('CREATE TABLE metadata (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL)')
                    self.db.execute('CREATE TABLE students (token TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, position INTEGER NOT NULL, payload TEXT NOT NULL)')
                    self.db.execute('INSERT INTO metadata VALUES(1,?)',(json.dumps(expected),))
            else:
                saved=self.db.execute('SELECT payload FROM metadata WHERE id=1').fetchone()
                if not saved or len(saved[0])>4096:raise ValueError()
                metadata=json.loads(saved[0])
                if not isinstance(metadata,dict):raise ValueError()
                if metadata.get('complete') and metadata.get('account')==self.owner:
                    # A successful final export starts fresh even if Windows
                    # temporarily prevented removal of its checkpoint file.
                    with self.db:
                        self.db.execute('DELETE FROM students')
                        self.db.execute('UPDATE metadata SET payload=? WHERE id=1',(json.dumps(expected),))
                elif metadata!=expected:raise ScanError('scan_changed','checkpoint_mismatch')
            saved_rows=self.db.execute('SELECT token,fingerprint,position,payload FROM students LIMIT 5001').fetchall()
            if len(saved_rows)>len(records):raise ValueError()
            for token,key,position,payload in saved_rows:
                if not isinstance(payload,str) or len(payload)>64*1024*1024:raise ValueError()
                row=json.loads(payload)
                if not valid_result(row) or fingerprint(row['item'])!=key or key not in self.counts:raise ValueError()
                if not isinstance(position,int) or not 1<=position<=len(records):raise ValueError()
                if not isinstance(token,str) or not token.startswith(key+':'):raise ValueError()
                suffix=token[len(key)+1:]
                if not suffix.isdigit() or not 1<=int(suffix)<=self.counts[key]:raise ValueError()
                if self.counts[key]==1:self.cache[key]=row
            # Identical full table rows cannot be distinguished reliably after
            # a reload. Re-read those rows instead of matching them by UID.
            with self.db:
                for key,count in self.counts.items():
                    if count>1:self.db.execute('DELETE FROM students WHERE fingerprint=?',(key,))
            self.bound=True
        except ScanError:
            self.close();raise
        except (sqlite3.Error,OSError,ValueError,TypeError,KeyError):
            self.close();raise ScanError('scan_failed','checkpoint_invalid' if existed else 'checkpoint_write') from None

    def take(self,item):
        row=self.cache.get(fingerprint(item))
        if row is None:return None
        row=copy.deepcopy(row);row['item']=item
        return row

    def save(self,row,occurrence,position):
        if not self.bound or not valid_result(row):raise ScanError('scan_failed','checkpoint_write')
        key=fingerprint(row['item'])
        if key not in self.counts or not 1<=occurrence<=self.counts[key]:raise ScanError('scan_changed','checkpoint_mismatch')
        try:
            payload=json.dumps(row,ensure_ascii=False,separators=(',',':'))
            with self.db:
                self.db.execute('INSERT OR REPLACE INTO students VALUES(?,?,?,?)',
                    (key+':'+str(occurrence),key,position,payload))
        except (sqlite3.Error,OSError):raise ScanError('scan_failed','checkpoint_write') from None

    def data(self):
        if not self.bound:return None
        rows=[json.loads(r[0]) for r in self.db.execute('SELECT payload FROM students ORDER BY position,token')]
        return {'records':rows,'inventory':self.total,'limit':self.limit,'interrupted':True}

    def complete(self):
        try:
            with self.db:
                payload=json.loads(self.db.execute('SELECT payload FROM metadata WHERE id=1').fetchone()[0])
                payload['complete']=True
                self.db.execute('UPDATE metadata SET payload=? WHERE id=1',(json.dumps(payload),))
            self.close()
            self.path.unlink()
        except (sqlite3.Error,OSError,TypeError,ValueError):self.close()

    def close(self):
        if self.db is not None:
            try:self.db.close()
            except sqlite3.Error:pass
            self.db=None


def run_student_scan(page,username,cancelled,path,limit,progress=lambda *_:None,account_session=None,grade=None):
    """Return only an event, counts and safe diagnostics to the helper process."""
    checkpoint=ScanCheckpoint(path,username,limit,grade)
    try:
        data=collect_students(page,username,cancelled,limit,progress,
                              account_session=account_session,checkpoint=checkpoint,grade=grade)
        data['shift']=shift_for_username(username)
        progress(len(data['records']),len(data['records']),{'stage':'export'})
        export_students(data,path,cancelled)
        unread=sum(bool(missing_fields(r)[1] or r['unread_tabs']) for r in data['records'])
        missing=sum(bool(missing_fields(r)[0]) for r in data['records'])
        skipped=sum(bool(r.get('skipped')) for r in data['records'])
        checkpoint.complete()
        return ('scan_saved_partial' if unread else 'scan_saved',len(data['records']),data['inventory'],
                {'unread':unread,'missing':missing,'read':len(data['records'])-skipped,'skipped':skipped})
    except Exception as exc:
        code=exc.code if isinstance(exc,ScanError) else 'scan_failed'
        reason=exc.reason if isinstance(exc,ScanError) and exc.reason else ('cancelled_by_user' if code=='scan_cancelled' else 'account_session_changed' if code=='scan_account_required' else 'unexpected_error')
        try:data=checkpoint.data()
        except Exception:data=None
        if not data or not data['records']:return code,0,0,{'reason':reason}
        data['shift']=shift_for_username(username)
        detail={'reason':reason,'cause':code}
        # Cancellation stops browser work. It does not discard already committed
        # records; write a separate, clearly interrupted workbook without touching
        # a previous final Excel destination.
        name='SayedTech_Recovery_'+uuid4().hex+'.xlsx'
        try:
            export_students(data,Path(path).parent/name,threading.Event())
            detail['recovery_file']=name
            event='scan_paused'
        except Exception:event='scan_paused_checkpoint'
        return event,len(data['records']),data['inventory'],detail
    finally:checkpoint.close()
