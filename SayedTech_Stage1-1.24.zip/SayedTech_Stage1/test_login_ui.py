"""Offline saved-login UI lifecycle using a synthetic, isolated native store."""
import unittest
from pathlib import Path
import tempfile
from unittest.mock import patch
try:
    from PySide6.QtWidgets import QApplication,QLineEdit
    from PySide6.QtCore import QCoreApplication,QEvent
    import app
    from credential_store import CredentialStore
    from test_credentials import Native
    QT=True
except ImportError:
    QT=False


@unittest.skipUnless(QT,'Qt is not installed in this Python environment')
class SavedLoginUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])

    def setUp(self):
        self.native=Native()
        self.store=CredentialStore(self.native)
        self.windows=[]
        self.patches=[patch('app.CredentialStore',return_value=self.store),patch('app.core.read_school',return_value={})]
        for p in self.patches:p.start()

    def tearDown(self):
        for w in self.windows:w.close();w.deleteLater()
        QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
        self.qt.processEvents()
        self.windows.clear()
        for p in reversed(self.patches):p.stop()

    def window(self):
        w=app.Window();self.windows.append(w);return w

    def fill(self,w):
        w.select_shift('morning');w.username.setText('test@te.mehe.school');w.password.setText('TEST_ONLY_SECRET')

    def test_local_nsldb_worker_clears_password_and_finishes_without_browser_calls(self):
        import time
        from nsldb_dialog import NSLDBDialog
        w=self.window();dialog=NSLDBDialog(w)
        self.assertFalse(dialog.advanced_toggle.isChecked())
        self.assertTrue(dialog.advanced.isHidden())
        dialog.advanced_toggle.setChecked(True)
        dialog.source.setText('TEST.sdf');dialog.password.setText('TEST_ONLY_DB_SECRET')
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'reference.xlsx'
            with patch('nsldb_dialog.QFileDialog.getSaveFileName',return_value=(str(path),'')), \
                 patch('nsldb_dialog.export_database',return_value={'records':4,'people':1,'selected':0}) as export:
                dialog.start()
                self.assertEqual(dialog.password.text(),'')
                deadline=time.monotonic()+3
                while dialog.worker.isRunning() and time.monotonic()<deadline:
                    self.qt.processEvents();time.sleep(.005)
                self.qt.processEvents()
                self.assertFalse(dialog.worker.isRunning())
                self.assertEqual(dialog.worker.password,'')
                self.assertTrue(dialog.export_button.isEnabled())
                self.assertTrue(dialog.open_button.isEnabled())
                self.assertIn('لا يوجد أي طالب مختار',dialog.status.text())
                export.assert_called_once()
                self.assertEqual(export.call_args.args[2],'TEST_ONLY_DB_SECRET')
                self.assertEqual(export.call_args.kwargs['mode'],'detailed')
                self.assertEqual(export.call_args.kwargs['academic_year'],'20252026')
                self.assertTrue(dialog.convert_button.isEnabled())
                dialog.advanced_toggle.setChecked(False)
                self.assertTrue(dialog.advanced.isHidden())
                self.assertEqual(dialog.program.text(),'')
                self.assertEqual(dialog.password.text(),'')
        dialog.close()

    def test_full_year_export_button_routes_mode_and_names_file(self):
        import time
        from nsldb_dialog import NSLDBDialog
        w=self.window();dialog=NSLDBDialog(w);dialog.source.setText('TEST.sdf')
        with tempfile.TemporaryDirectory() as tmp:
            with patch('nsldb_dialog.QFileDialog.getSaveFileName',return_value=(str(Path(tmp)/'detailed.xlsx'),'')) as save, \
                 patch('nsldb_dialog.export_database',return_value={'records':4,'people':1,'selected':0}) as export:
                dialog.export_button.click()
                deadline=time.monotonic()+3
                while dialog.worker.isRunning() and time.monotonic()<deadline:
                    self.qt.processEvents();time.sleep(.005)
                self.qt.processEvents()
                self.assertEqual(export.call_args.kwargs['mode'],'detailed')
                self.assertIn('2025-2026',save.call_args.args[2])
                self.assertEqual(export.call_args.kwargs['academic_year'],'20252026')
                self.assertIn('تجهيز ملف موحّد',dialog.status.text())
                self.assertTrue(dialog.export_button.isEnabled())
        dialog.close()

    def test_selected_queue_waits_for_user_verification_and_stops_on_session_loss(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        w=self.window();w.connected=True
        rows=[{'excel_row':i+2,'values':record(),'errors':[],'address':{},'workflow':True} for i in range(3)]
        dialog=StudentImportDialog(rows,w.login_controller,w)
        dialog.grade_combo.setCurrentIndex(1);dialog.select_all_button.click()
        with patch.object(w.login_controller,'fill_student',return_value=True) as send:
            dialog.batch_button.click()
            self.assertEqual(send.call_count,1)
            self.assertTrue(send.call_args.kwargs['save'])
            request=dialog.pending[0]
            dialog.on_result(request,'student_save_requested','')
            self.assertEqual(send.call_count,1)
            self.assertTrue(dialog.continue_button.isEnabled())
            dialog.continue_button.click();self.assertEqual(send.call_count,2)
            dialog.continue_button.click();self.assertEqual(send.call_count,2)
            dialog.on_result(dialog.pending[0],'student_save_unverified','')
            self.assertEqual(send.call_count,2)
            dialog.on_session_event('disconnected')
            self.assertFalse(dialog.continue_button.isEnabled())
            dialog.confirm_and_continue();self.assertEqual(send.call_count,2)
        dialog.close()

    def test_grade_filter_and_name_checkboxes_limit_registration_queue(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        from PySide6.QtCore import Qt
        w=self.window();w.connected=True
        rows=[]
        for i,grade in enumerate(('الأول أساسي','الأول أساسي','الثاني أساسي')):
            values=record();values['field-enrollment-promoted-class']=grade
            rows.append({'excel_row':i+2,'values':values,'errors':[],'address':{},'workflow':True})
        dialog=StudentImportDialog(rows,w.login_controller,w)
        self.assertFalse(dialog.batch_button.isEnabled())
        dialog.grade_combo.setCurrentIndex(1)
        self.assertTrue(dialog.table.isRowHidden(2))
        self.assertEqual(dialog.table.item(0,1).checkState(),Qt.Unchecked)
        dialog.table.item(1,1).setCheckState(Qt.Checked)
        with patch.object(w.login_controller,'fill_student',return_value=True) as send:
            dialog.start_batch()
            self.assertEqual(dialog.pending[1],1)
            self.assertEqual(send.call_count,1)
            dialog.on_result(dialog.pending[0],'student_saved','')
            self.qt.processEvents()
            self.assertEqual(send.call_count,1)
        dialog.close()

    def test_verified_success_advances_without_user_click_and_stop_cancels_queue(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        w=self.window();w.connected=True
        rows=[{'excel_row':i+2,'values':record(),'errors':[],'address':{},'workflow':True} for i in range(3)]
        dialog=StudentImportDialog(rows,w.login_controller,w)
        dialog.grade_combo.setCurrentIndex(1);dialog.select_all_button.click()
        with patch.object(w.login_controller,'fill_student',return_value=True) as send:
            dialog.start_batch()
            self.assertEqual(send.call_count,1)
            dialog.on_result(dialog.pending[0],'student_saved','')
            self.assertIn(0,dialog.filled)
            self.assertIsNone(dialog.awaiting_review)
            self.qt.processEvents()
            self.assertEqual(send.call_count,2)
            dialog.on_result(dialog.pending[0],'student_saved','')
            dialog.stop_batch()
            self.qt.processEvents()
            self.assertEqual(send.call_count,2)
            self.assertIn(1,dialog.filled)
        dialog.close()

    def test_existing_registration_is_skipped_and_batch_moves_to_next_row(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        w=self.window();w.connected=True
        rows=[{'excel_row':i+2,'values':record(),'errors':[],'address':{},'workflow':True} for i in range(2)]
        dialog=StudentImportDialog(rows,w.login_controller,w)
        dialog.grade_combo.setCurrentIndex(1);dialog.select_all_button.click()
        with patch.object(w.login_controller,'fill_student',return_value=True) as send:
            dialog.start_batch()
            first=dialog.pending[0]
            dialog.on_result(first,'student_already_registered','')
            self.qt.processEvents()
            self.assertEqual(send.call_count,2)
            self.assertIn(0,dialog.filled)
            self.assertIn('مسجّل مسبقاً',dialog.table.item(0,5).text())
            self.assertEqual(send.call_args.kwargs['batch_id'],send.call_args_list[0].kwargs['batch_id'])
            dialog.on_result(dialog.pending[0],'student_duplicate_review','')
            self.assertFalse(dialog.batch_active)
            self.assertEqual(send.call_count,2)
        dialog.close()

    def test_selected_queue_sends_nothing_until_missing_data_is_corrected(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        w=self.window();w.connected=True
        rows=[{'excel_row':2,'values':record(),'errors':['مطلوب'],'address':{},'workflow':True}]
        dialog=StudentImportDialog(rows,w.login_controller,w)
        dialog.grade_combo.setCurrentIndex(1)
        from PySide6.QtCore import Qt
        dialog.table.item(0,1).setCheckState(Qt.Checked)
        with patch.object(w.login_controller,'fill_student') as send:
            dialog.start_batch();send.assert_not_called()
            self.assertIn('بحاجة تصحيح',dialog.status.text())
        dialog.close()

    def test_workflow_conversion_and_registration_route_selected_rows(self):
        from nsldb_dialog import NSLDBDialog
        from test_students import record
        w=self.window();w.connected=True;dialog=NSLDBDialog(w)
        rows=[{'excel_row':2,'values':record(),'errors':[],'address':{},'workflow':True}]
        with patch('nsldb_dialog.QFileDialog.getOpenFileName',return_value=('FULL.xlsx','')), \
             patch('nsldb_dialog.QFileDialog.getSaveFileName',return_value=('SIMPLE.xlsx','')), \
             patch('student_unified.convert_to_unified',return_value=286) as convert:
            dialog.convert();convert.assert_called_once_with('FULL.xlsx','SIMPLE.xlsx')
            self.assertEqual(dialog.simple_output,'SIMPLE.xlsx')
            self.assertEqual(dialog.detailed_output,'SIMPLE.xlsx')
        with patch('nsldb_dialog.QFileDialog.getOpenFileName',return_value=('SIMPLE.xlsx','')), \
             patch('student_excel.read_students',return_value=rows), \
             patch('student_dialog.StudentImportDialog') as imported:
            dialog.register()
            imported.assert_called_once_with(rows,w.login_controller,w)
            imported.return_value.exec.assert_called_once()
        dialog.close()

    def test_explicit_simple_save_button_and_ambiguous_outcome_lock_the_row(self):
        from student_dialog import StudentImportDialog
        from test_students import record
        w=self.window();w.connected=True
        rows=[{'excel_row':2,'values':record(),'errors':[],'address':{}}]
        dialog=StudentImportDialog(rows,w.login_controller,w)
        dialog.table.setCurrentCell(0,0);dialog.selection_changed()
        with patch.object(w.login_controller,'fill_student',return_value=True) as send:
            dialog.save_button.click()
            self.assertTrue(send.call_args.kwargs['save'])
            request=dialog.pending[0]
            self.assertFalse(dialog.fill_button.isEnabled())
            self.assertFalse(dialog.save_button.isEnabled())
            dialog.on_result(request,'student_save_requested','')
            self.assertIn('تحقّق',dialog.status.text())
            self.assertIn(0,dialog.filled)
            self.assertFalse(dialog.save_button.isEnabled())
            dialog.fill_selected(save=True)
            self.assertEqual(send.call_count,1)
        dialog.close()

    def test_scan_recovery_keeps_progress_and_paths_after_session_ends(self):
        from student_scan_dialog import StudentScanDialog
        w=self.window();dialog=StudentScanDialog(w.login_controller,w)
        dialog.path='C:/TEST/students.xlsx';dialog.request_id='DEMO';dialog.set_pending(True)
        recovery='SayedTech_Recovery_'+'1'*32+'.xlsx'
        dialog.result('DEMO','scan_paused',2,6,{'reason':'tab_timeout','recovery_file':recovery})
        self.assertEqual(dialog.progress.value(),2)
        self.assertEqual(dialog.progress.maximum(),6)
        self.assertIn(recovery,dialog.status.text())
        self.assertIn(dialog.path,dialog.status.text())
        dialog.session_event('disconnected')
        self.assertIn(recovery,dialog.status.text())
        self.assertIn('سجّل الدخول',dialog.status.text())
        dialog.close()

    def test_both_shifts_receive_same_menus_tools_and_excel_template(self):
        snapshots=[]
        for shift,domain in app.SHIFT_DOMAINS.items():
            with self.subTest(shift=shift):
                w=self.window();w.select_shift(shift)
                w.school.setText('TEST SCHOOL');w.center.setText('01234')
                w.show_done('TEST SCHOOL','01234')
                self.assertIn(w.shift_label.text(),w.login_school_label.text())
                self.assertEqual(w.username.placeholderText(),f'name@{domain}')
                username=f'test@{domain}'
                w.username.setText(username);w.password.setText('TEST_ONLY_SECRET')
                with patch.object(w.login_controller,'start',return_value=True) as start:
                    w.start_login()
                start.assert_called_once_with(username,'TEST_ONLY_SECRET','edge',shift)
                self.assertEqual(self.store.load(shift)['username'],username)
                w.on_login_event('authenticated')
                self.assertIn(w.shift_label.text(),w.menu_summary.text())
                for section in app.SECTIONS:
                    w.show_section(section)
                    self.assertEqual(w.current_section,section)
                snapshots.append({key:b.isEnabled() for key,b in w.operation_buttons.items()})
                with patch('student_scan_dialog.StudentScanDialog') as scan:
                    w.open_student_scan();scan.return_value.exec.assert_called_once()
                with patch('catalog_dialog.CatalogDialog') as catalog:
                    w.open_catalog();catalog.return_value.exec.assert_called_once()
                with patch('nsldb_dialog.NSLDBDialog') as database:
                    w.nsldb_button.click();database.return_value.exec.assert_called_once()
                with tempfile.TemporaryDirectory() as tmp:
                    path=Path(tmp)/'template.xlsx'
                    with patch('app.QFileDialog.getSaveFileName',return_value=(str(path),'Excel (*.xlsx)')):
                        w.student_operation('استخراج')
                    self.assertEqual(path.read_bytes(),(app.core.ASSET_BASE/'assets/student_with_addresses.xlsx').read_bytes())
        self.assertEqual(snapshots[0],snapshots[1])

    def test_save_on_attempt_timeout_and_new_launch_autofill_masked(self):
        w=self.window();self.fill(w)
        with patch.object(w.login_controller,'start',return_value=True) as start:
            w.start_login();self.assertEqual(start.call_count,1)
        self.assertEqual(w.password.text(),'')
        self.assertFalse(w.remember_login.isEnabled())
        w.on_login_event('timeout')
        self.assertEqual(w.password.text(),'TEST_ONLY_SECRET')
        self.assertEqual(w.password.echoMode(),QLineEdit.Password)
        self.assertFalse(w.show_password.isChecked())
        w2=self.window();w2.select_shift('morning');w2.show_done('TEST','001')
        self.assertEqual(w2.username.text(),'test@te.mehe.school')
        self.assertEqual(w2.password.text(),'TEST_ONLY_SECRET')
        self.assertTrue(w2.remember_login.isChecked())

    def test_shift_switch_and_username_edit_do_not_mix_passwords(self):
        self.store.save('morning','am@te.mehe.school','TEST_ONLY_AM')
        self.store.save('afternoon','pm@te.pm.mehe.school','TEST_ONLY_PM')
        w=self.window();w.select_shift('morning')
        self.assertEqual(w.password.text(),'TEST_ONLY_AM')
        w.select_shift('afternoon');self.assertEqual(w.username.text(),'pm@te.pm.mehe.school')
        self.assertEqual(w.password.text(),'TEST_ONLY_PM')
        w.username.setText('another@te.pm.mehe.school');w.username.textEdited.emit(w.username.text())
        self.assertEqual(w.password.text(),'')
        w.select_shift('morning');self.assertEqual(w.password.text(),'TEST_ONLY_AM')

    def test_forget_and_opt_out_delete_only_selected_shift(self):
        self.store.save('morning','am@te.mehe.school','TEST_ONLY_AM')
        self.store.save('afternoon','pm@te.pm.mehe.school','TEST_ONLY_PM')
        w=self.window();w.select_shift('morning');w.forget_login_button.click()
        self.assertIsNone(self.store.load('morning'))
        self.assertIsNotNone(self.store.load('afternoon'))
        self.assertEqual(w.password.text(),'');self.assertFalse(w.remember_login.isChecked())
        w.password.setText('TEST_ONLY_NO_SAVE')
        with patch.object(w.login_controller,'start',return_value=True):w.start_login()
        self.assertIsNone(self.store.load('morning'))
        w.on_login_event('cancelled')
        w.remember_login.setChecked(True);w.select_shift('afternoon');w.remember_login.setChecked(False)
        self.assertIsNone(self.store.load('afternoon'))

    def test_invalid_input_never_saves_and_vault_failures_are_visible(self):
        w=self.window();self.fill(w);w.username.setText('test@te.pm.mehe.school')
        with patch.object(w.login_controller,'start') as start:w.start_login();start.assert_not_called()
        self.assertEqual(self.native.entries,{})
        w.username.setText('test@te.mehe.school');self.native.fail_write=True
        with patch.object(w.login_controller,'start',return_value=True) as start:w.start_login();start.assert_called_once()
        self.assertIn('تعذّر حفظ',w.credential_note.text());self.assertEqual(self.native.entries,{})
        w.on_login_event('failed');self.native.fail_write=False
        self.store.save('morning','test@te.mehe.school','TEST_ONLY_SAVED');w.restore_saved_login()
        self.native.fail_delete=True;w.remember_login.setChecked(False)
        self.assertTrue(w.remember_login.isChecked());self.assertIn('تعذّر حذف',w.credential_note.text())
        self.assertIsNotNone(self.store.load('morning'))


if __name__=='__main__':unittest.main()
