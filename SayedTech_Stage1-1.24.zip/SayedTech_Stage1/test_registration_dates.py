"""Month/day/year text dates from the user's NSLDB/Excel workflow."""
from datetime import date,timedelta
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from student_excel import normalize_date,validate_record,read_students
from nsldb_reference import _source_date,map_records
from test_students import record
import test_students
from test_nsldb import tables


class RegistrationDateTests(unittest.TestCase):
    def test_month_day_year_is_accepted_without_swapping_ambiguous_components(self):
        for raw,expected in (('09/15/2025','2025-09-15'),('04/05/2025','2025-04-05'),
                             ('2/29/2024','2024-02-29'),('2025-09-15','2025-09-15')):
            with self.subTest(raw=raw):self.assertEqual(normalize_date(raw),expected)

    def test_registration_validation_for_both_shifts_keeps_source_value(self):
        for shift in ('morning','afternoon'):
            row=record();row['field-enrollment-registration-date']='04/05/2025'
            clean,errors=validate_record(row,shift)
            self.assertEqual(errors,[])
            self.assertEqual(clean['field-enrollment-registration-date'],'2025-04-05')
            self.assertEqual(row['field-enrollment-registration-date'],'04/05/2025')

    def test_excel_reader_accepts_existing_text_dates_without_rescanning_database(self):
        row=record();row['field-birthDate']='02/13/2015';row['field-enrollment-registration-date']='09/15/2025'
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'dates.xlsx'
            with patch('test_students.record',return_value=row):test_students.StudentTests().fixture(path)
            for shift in ('morning','afternoon'):
                loaded=read_students(path,shift)[0]
                self.assertEqual(loaded['errors'],[])
                self.assertEqual(loaded['values']['field-birthDate'],'2015-02-13')
                self.assertEqual(loaded['values']['field-enrollment-registration-date'],'2025-09-15')

    def test_source_registration_dates_use_declared_month_first_order(self):
        self.assertEqual(_source_date('04/05/2025'),'2025-04-05')
        self.assertEqual(_source_date('13/02/2025'),'2025-02-13')
        source=tables()
        for row in source['StudentSchool']:row['RegistrationDate']='04/05/2025'
        for mapped in map_records(source):
            self.assertEqual(mapped['values']['field-enrollment-registration-date'],'2025-04-05')

    def test_invalid_future_dates_and_bad_excel_serials_stay_rejected(self):
        future=(date.today()+timedelta(days=1)).strftime('%m/%d/%Y')
        for raw in ('02/29/2025','04/31/2025','13/02/2025',future,60,True):
            with self.subTest(raw=raw),self.assertRaises((ValueError,TypeError)):normalize_date(raw)
        self.assertEqual(normalize_date(45672),'2025-01-15')


if __name__=='__main__':unittest.main()
