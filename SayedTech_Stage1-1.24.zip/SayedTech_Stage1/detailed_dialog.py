import uuid
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,
    QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView,QComboBox,
    QWidget,QScrollArea,QFrame,QGroupBox,QToolButton,QSizePolicy,QLayout,QHeaderView,QStyledItemDelegate)
from detailed_batch import DetailedImportBatch
from detail_scope import grade_choices,in_grade,scoped_record

DIALOG_STYLE='''
QDialog#detailedImport { background: #f3f6fa; }
QDialog#detailedImport QWidget { font-size: 13px; }
QDialog#detailedImport QWidget#detailBody, QDialog#detailedImport QScrollArea { background: transparent; }
QDialog#detailedImport QLabel#detailTitle { font-size: 18px; font-weight: 700; }
QDialog#detailedImport QLabel#detailStatus { color: #496178; padding: 4px 2px; }
QDialog#detailedImport QGroupBox { background: white; border: 1px solid #d7e1ec; border-radius: 8px; margin-top: 8px; font-weight: 600; }
QDialog#detailedImport QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top right; right: 12px; padding: 0 4px; }
QDialog#detailedImport QComboBox { background: #f9fbfd; color: #1a2a43; border: 1px solid #d7e1ec; padding: 5px 10px; min-height: 22px; border-radius: 6px; }
QDialog#detailedImport QPushButton { color: white; background: #138d79; font-weight: 600; border: none; padding: 6px 10px; min-height: 22px; border-radius: 6px; }
QDialog#detailedImport QPushButton:hover { background: #0f7b69; }
QDialog#detailedImport QPushButton:disabled { color: #eef4f3; background: #a4bcb8; }
QDialog#detailedImport QPushButton#detailSecondary { color: #24466c; background: #e8eef5; }
QDialog#detailedImport QPushButton#detailSecondary:hover { background: #dce6f1; }
QDialog#detailedImport QPushButton#detailSecondary:disabled { color: #8291a1; background: #eef1f5; }
QDialog#detailedImport QPushButton#detailStop { background: #b3562c; }
QDialog#detailedImport QPushButton#detailStop:disabled { background: #c6b7b0; }
QDialog#detailedImport QToolButton { color: #246b97; background: transparent; padding: 4px; border: none; }
QDialog#detailedImport QTableWidget { background: white; alternate-background-color: #f6f9fc; border: 1px solid #d7e1ec; gridline-color: #e4eaf1; selection-background-color: #def2ec; selection-color: #173e35; }
QDialog#detailedImport QHeaderView::section { background: #eaf0f6; color: #24466c; padding: 6px; border: none; border-bottom: 1px solid #d7e1ec; font-weight: 600; }
'''


class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.batch=DetailedImportBatch(rows);self.single_pending=None
        self._fitted=False;self._action_columns=None
        self.setObjectName('detailedImport')
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setStyleSheet(DIALOG_STYLE)
        outer=QVBoxLayout(self);outer.setContentsMargins(12,12,12,10);outer.setSpacing(8)
        # The scrollable body can exceed a small/high-DPI screen without
        # forcing the native window beyond its available work area.
        outer.setSizeConstraint(QLayout.SetNoConstraint)
        self.body_scroll=QScrollArea();self.body_scroll.setWidgetResizable(True)
        self.body_scroll.setFrameShape(QFrame.NoFrame)
        self.body_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.body_scroll.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        self.body=QWidget();self.body.setObjectName('detailBody')
        self.body_scroll.setWidget(self.body);outer.addWidget(self.body_scroll,1)
        layout=QVBoxLayout(self.body);layout.setContentsMargins(0,0,0,0);layout.setSpacing(8)
        header=QHBoxLayout()
        title=QLabel('استرداد المعلومات المفصّلة');title.setObjectName('detailTitle')
        header.addWidget(title,1)
        self.help_button=QToolButton();self.help_button.setText('إرشادات الاستخدام')
        self.help_button.setCheckable(True);self.help_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.help_button.setArrowType(Qt.LeftArrow);header.addWidget(self.help_button)
        layout.addLayout(header)
        note=QLabel('تُستورد بيانات كل التلاميذ المعلّمين بـ1 أو نعم في أول عمود في Excel، لمدارس قبل الظهر وبعد الظهر. '
            'يتحقق البرنامج من هوية كل طالب، ثم يعبّئ ويحفظ الأقسام التي فيها بيانات: عناوين السكن والهواتف والبريد الإلكتروني وشهرة الأم وبطاقات التعريف والمستندات. '
            'الخانات الفارغة لا تمسح بيانات الموقع، ولا يلزم مرفق لبطاقات التعريف والمستندات. '
            'لتعبئة قسم واحد، اختر الطالب من الجدول والقسم من القائمة واضغط تعبئة وحفظ القسم المحدد. '
            'اختر الصف، وأزل إشارة استرداد عن الطلاب الذين تريد تخطّيهم؛ الاستيراد المجمع يعمل على المؤشّر عليهم ضمن الصف فقط. الإرسال بعد تأكيد حفظ الأقسام. '
            'إذا تعثّرت التعبئة أو الحفظ، تتوقف العملية عند الطالب لمراجعته قبل المتابعة. احفظ أي مسودة مفتوحة في المتصفح قبل البدء.')
        note.setWordWrap(True);note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Minimum)
        self.help_scroll=QScrollArea();self.help_scroll.setWidgetResizable(True)
        self.help_scroll.setFrameShape(QFrame.NoFrame);self.help_scroll.setWidget(note)
        self.help_scroll.setFixedHeight(100);self.help_scroll.hide();layout.addWidget(self.help_scroll)
        self.help_button.toggled.connect(self.show_help)
        scope_line=QHBoxLayout();scope_line.addWidget(QLabel('صف الاسترداد والبحث:'))
        self.grade_combo=QComboBox()
        self.grade_combo.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        self.grade_combo.setMinimumContentsLength(12)
        self.grade_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.grade_combo.addItem('كل الصفوف',None)
        for grade in grade_choices(rows):self.grade_combo.addItem(grade,grade)
        scope_line.addWidget(self.grade_combo,1);layout.addLayout(scope_line)
        from manual_sections import IMPORT_SECTIONS,section_summary
        self.manual_mode=all('manual' in r for r in rows)
        headings=(['صف Excel','الطالب']+list(IMPORT_SECTIONS) if self.manual_mode else
                  ['صف Excel','الطالب','شهرة الأم','البلد','العنوان','الهاتف','نوع المستند','رقم الوثيقة','تاريخ الانتهاء'])
        headings.insert(0,'استرداد');self.select_column=0
        headings.append('نتيجة الاستيراد')
        self.result_column=len(headings)-1
        self.table=QTableWidget(len(rows),len(headings))
        self.table.setLayoutDirection(Qt.RightToLeft)
        self.table.setHorizontalHeaderLabels(headings)
        self.table.horizontalHeader().setLayoutDirection(Qt.RightToLeft)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
        self.table.horizontalHeaderItem(self.select_column).setToolTip('أزل الإشارة لتخطّي هذا الطالب في التعبئة والحفظ والمراجعة. الاختيار محلي لهذه النافذة.')
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True);self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideRight)
        self.table.setMinimumHeight(210)
        self.table.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Expanding)
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setMinimumSectionSize(60)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[str(row['excel_row']),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                   str(row.get('mother_surname','')),address.get('البلد',''),
                   ' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            card=row.get('identity_card',{})
            texts.extend(str(card.get(k,'') or '') for k in ('type','number','expiry'))
            if self.manual_mode:texts=texts[:2]+[section_summary(row,title) for title in IMPORT_SECTIONS]
            texts.append('بانتظار الاستيراد')
            texts.insert(0,'')
            for j,text in enumerate(texts):
                item=QTableWidgetItem(text);item.setToolTip(text)
                item.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
                if j==self.select_column:
                    item.setFlags(Qt.ItemIsUserCheckable|Qt.ItemIsEnabled|Qt.ItemIsSelectable)
                    item.setCheckState(Qt.Checked)
                    item.setToolTip('مؤشّر عليه: يُسترد. أزل الإشارة لتخطّيه في هذه النافذة.')
                self.table.setItem(i,j,item)
        for column in range(len(headings)):
            self.table.setColumnWidth(column,64 if column==0 else 74 if column==1 else 220 if column==2 else 190)
        self.table.setColumnWidth(self.result_column,300)
        self.table.horizontalHeader().moveSection(self.result_column,3)
        self.table.verticalHeader().setDefaultSectionSize(max(34,self.table.fontMetrics().height()+12))
        layout.addWidget(self.table,1)
        instruction='أزل إشارة استرداد عمّن تريد تخطّيه، ثم اختر إجراء الاستيراد.'
        self.status=QLabel(f'جاهز لاستيراد {len(rows)} طالباً من Excel. '+instruction)
        self.status.setTextFormat(Qt.PlainText);self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.status.setObjectName('detailStatus');layout.addWidget(self.status)
        self.buttons=[self.grade_combo]
        if self.manual_mode:
            self.single_group=QGroupBox('الطالب المحدّد في الجدول')
            self.single_grid=QGridLayout(self.single_group)
            self.single_grid.setContentsMargins(10,20,10,10);self.single_grid.setSpacing(8)
            self.manual_sections=QComboBox()
            self.manual_sections.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            self.manual_sections.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            self.manual_sections.setMinimumContentsLength(12)
            for title in IMPORT_SECTIONS:self.manual_sections.addItem(title,'manual_save:'+title)
            self.manual_sections.setToolTip('اختر القسم للطالب المحدّد. حالة التسجيل للقراءة؛ الإرسال له زر مستقل.')
            self.manual_save_button=QPushButton('تعبئة وحفظ القسم المحدد')
            self.manual_save_button.clicked.connect(self.start_section)
            self.manual_save_button.setObjectName('detailSecondary')
            self.buttons.extend([self.manual_sections,self.manual_save_button])
            self.manual_sections.currentIndexChanged.connect(self.section_changed)
            self.review_button=QPushButton('إرسال الطالب المحدد للمراجعة')
            self.review_button.clicked.connect(lambda:self.start_selected('review_send'))
            self.review_button.setObjectName('detailSecondary')
            self.buttons.append(self.review_button);layout.addWidget(self.single_group)
        self.batch_group=QGroupBox('استيراد الطلاب المؤشّر عليهم ضمن الصف المختار')
        self.batch_grid=QGridLayout(self.batch_group)
        self.batch_grid.setContentsMargins(10,20,10,10);self.batch_grid.setSpacing(8)
        self.import_review_button=QPushButton('استيراد الداتا المفصّلة مع إرسال الطالب للمراجعة')
        self.import_review_button.clicked.connect(lambda:self.start_batch(True))
        self.import_button=QPushButton('استيراد الداتا المفصّلة بدون إرسال الطالب للمراجعة')
        self.import_button.clicked.connect(lambda:self.start_batch(False))
        self.buttons.extend([self.import_review_button,self.import_button])
        layout.addWidget(self.batch_group)
        for button in self.buttons:
            if isinstance(button,QPushButton):
                button.setAutoDefault(False)
                button.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
                button.setToolTip(button.text())
        footer=QHBoxLayout()
        self.stop_button=QPushButton('إيقاف بعد الطالب الحالي')
        self.stop_button.setObjectName('detailStop');self.stop_button.setAutoDefault(False)
        self.stop_button.clicked.connect(self.stop_batch);self.stop_button.hide();footer.addWidget(self.stop_button)
        footer.addStretch()
        self.close_button=QPushButton('إغلاق');self.close_button.setObjectName('detailSecondary')
        self.close_button.setAutoDefault(False);self.close_button.setMinimumWidth(90)
        self.close_button.clicked.connect(self.reject);footer.addWidget(self.close_button);outer.addLayout(footer)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        self.finished.connect(self.detach)
        # Explicit direction/alignment also covers native Windows combo labels,
        # whose noneditable text may otherwise ignore the inherited RTL state.
        for widget in (self.body,self.body_scroll,self.table.viewport()):widget.setLayoutDirection(Qt.RightToLeft)
        for combo in [self.grade_combo]+([self.manual_sections] if self.manual_mode else []):
            combo.setLayoutDirection(Qt.RightToLeft);combo.view().setLayoutDirection(Qt.RightToLeft)
            combo.setItemDelegate(QStyledItemDelegate(combo))
            for index in range(combo.count()):combo.setItemData(index,Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute,Qt.TextAlignmentRole)
            if hasattr(combo,'setLabelDrawingMode'):combo.setLabelDrawingMode(QComboBox.LabelDrawingMode.UseDelegate)
        self.table.itemChanged.connect(self.selection_changed)
        self.grade_combo.currentIndexChanged.connect(self.grade_changed)
        if rows:self.table.setCurrentCell(0,0)
        self.reflow_actions(1100)
        self.resize(1180,780)
        self.section_changed()

    def show_help(self,visible):
        self.help_scroll.setVisible(visible)
        self.help_button.setArrowType(Qt.DownArrow if visible else Qt.LeftArrow)

    def reflow_actions(self,width):
        columns=3 if width>=980 else 2 if width>=700 else 1
        if columns==self._action_columns:return
        self._action_columns=columns
        grids=[self.batch_grid]+([self.single_grid] if self.manual_mode else [])
        for grid in grids:
            while grid.count():grid.takeAt(0)
            for column in range(3):grid.setColumnStretch(column,0)
        if self.manual_mode:
            if columns==3:
                for column,widget in enumerate((self.manual_sections,self.manual_save_button,self.review_button)):
                    self.single_grid.addWidget(widget,0,column);self.single_grid.setColumnStretch(column,1)
            elif columns==2:
                self.single_grid.addWidget(self.manual_sections,0,0,1,2)
                self.single_grid.addWidget(self.manual_save_button,1,0)
                self.single_grid.addWidget(self.review_button,1,1)
                for column in range(2):self.single_grid.setColumnStretch(column,1)
            else:
                for row,widget in enumerate((self.manual_sections,self.manual_save_button,self.review_button)):
                    self.single_grid.addWidget(widget,row,0)
                self.single_grid.setColumnStretch(0,1)
        for index,button in enumerate((self.import_button,self.import_review_button)):
            # Compact labels keep both explicit choices readable side by side
            # on smaller screens; the full action remains in the tooltip.
            button.setText(('استيراد وحفظ بدون إرسال للمراجعة' if index==0 else 'استيراد وحفظ وإرسال للمراجعة')
                           if columns==2 else button.toolTip())
            self.batch_grid.addWidget(button,0 if columns>=2 else index,index if columns>=2 else 0)
            self.batch_grid.setColumnStretch(index if columns>=2 else 0,1)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'batch_grid'):self.reflow_actions(self.width()-48)

    def showEvent(self,event):
        super().showEvent(event)
        if not self._fitted:
            self._fitted=True
            QTimer.singleShot(0,self.fit_screen)
            if self.windowHandle():self.windowHandle().screenChanged.connect(self.fit_screen)

    def fit_screen(self,*args):
        screen=self.screen()
        if screen is None:return
        area=screen.availableGeometry()
        frame=self.frameGeometry()
        frame_width=frame.width()-self.width();frame_height=frame.height()-self.height()
        self.resize(min(1180,max(1,area.width()-24-frame_width)),
                    min(780,max(1,area.height()-24-frame_height)))
        frame=self.frameGeometry()
        frame.moveCenter(area.center());self.move(frame.topLeft())

    def grade_changed(self,*args):
        if self.single_pending or self.batch.active or self.batch.pending:return
        grade=self.grade_combo.currentData()
        visible=[]
        for i,row in enumerate(self.rows):
            show=in_grade(row,grade);self.table.setRowHidden(i,not show)
            if show:visible.append(i)
        self.table.clearSelection();self.table.setCurrentCell(visible[0] if visible else -1,0)
        scope=grade or 'كل الصفوف'
        self.status.setText(f'نطاق البحث: {scope} — مؤشّر عليهم {len(self.checked_indices())}/{len(visible)}. أزل إشارة استرداد عن الطلاب المطلوب تخطّيهم.')

    def checked_indices(self):
        return [i for i in range(len(self.rows)) if not self.table.isRowHidden(i) and
                self.table.item(i,self.select_column).checkState()==Qt.Checked]

    def selection_changed(self,item):
        if item.column()!=self.select_column or self.single_pending or self.batch.active or self.batch.pending:return
        self.status.setText(f'مؤشّر عليهم للاسترداد: {len(self.checked_indices())} طالباً ضمن الصف المختار. الطلاب غير المؤشّر عليهم يُتخطّون.')

    def section_changed(self,*args):
        if self.manual_mode and not self.batch.active and not self.single_pending:
            self.manual_save_button.setEnabled(self.manual_sections.currentData()!='manual_save:حالة التسجيل')

    def start_section(self):
        if self.manual_mode:self.start_selected(self.manual_sections.currentData())

    def start_selected(self,section):
        if self.single_pending or self.batch.active or self.batch.pending:return
        index=self.table.currentRow()
        if index<0 or not self.manual_mode or self.table.isRowHidden(index):return
        if self.table.item(index,self.select_column).checkState()!=Qt.Checked:
            self.status.setText('هذا الطالب غير مؤشّر عليه للاسترداد. فعّل خانة استرداد بجانبه قبل تعبئته أو إرساله للمراجعة.');return
        if section=='manual_save:حالة التسجيل':return
        request=uuid.uuid4().hex
        self.single_pending=(request,index)
        self.set_running(True)
        action='إرسال الطالب المحدد للمراجعة' if section=='review_send' else 'تعبئة وحفظ '+self.manual_sections.currentText()
        self.status.setText(f'جارٍ {action} — صف Excel {self.rows[index]["excel_row"]}…')
        row=scoped_record(self.rows[index],self.grade_combo.currentData())
        if not self.controller.fill_details(row,section,request):
            self.result(request,'detail_account','')

    def start_batch(self,with_review):
        if self.single_pending or self.batch.active or self.batch.pending:return
        selected=self.checked_indices()
        if not selected:
            self.status.setText('لم يبدأ الاستيراد. فعّل خانة استرداد لطالب واحد على الأقل ضمن الصف المختار.');return
        if not self.batch.start(with_review,self.grade_combo.currentData(),selected):return
        self.set_running(self.batch.active)
        if self.batch.active:self.dispatch_next()
        else:self.status.setText(f'سبق إنجاز كل طلاب النطاق لهذا الخيار في هذه النافذة: {self.batch.done}/{self.batch.total}.')

    def set_running(self,running):
        for button in self.buttons+[self.close_button]:button.setEnabled(not running)
        self.table.setEnabled(not running)
        self.stop_button.setVisible(running and self.batch.active);self.stop_button.setEnabled(running and self.batch.active)
        if not running:self.section_changed()

    def row_result(self,index,text):
        item=QTableWidgetItem(text);item.setToolTip(text)
        item.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
        self.table.setItem(index,self.result_column,item)

    def dispatch_next(self):
        if not self.batch.active:return
        request=self.batch.request()
        if request is None:return
        row,mode,request_id=request
        self.table.setCurrentCell(self.batch.index,0)
        self.row_result(self.batch.index,'جارٍ الاستيراد والحفظ…')
        action='مع الإرسال للمراجعة' if mode=='details_import_review' else 'بدون إرسال للمراجعة'
        scope=self.batch.grade or 'كل الصفوف'
        self.status.setText(f'جارٍ استيراد الطالب {self.batch.position}/{self.batch.total} — {scope} — صف Excel {row["excel_row"]} — {action}…')
        if not self.controller.fill_details(row,mode,request_id):
            self.result(request_id,'detail_account','')

    def stop_batch(self):
        self.batch.stop_after_current();self.stop_button.setEnabled(False)
        self.status.setText('سيكتمل الطالب الحالي حسب الخيار المختار ثم تتوقف العملية.')
        if not self.batch.pending:
            self.set_running(False);self.status.setText(f'توقفت العملية حسب طلبك. اكتمل {self.batch.done}/{self.batch.total}.')

    def result(self,request,event,field):
        if self.single_pending and request==self.single_pending[0]:
            index=self.single_pending[1];self.single_pending=None
            self.set_running(False)
            text=self.result_text(event,field)
            if event=='detail_no_data':text='القسم المحدد فارغ في Excel؛ لم تُضف بيانات ولم يُحفظ.'
            self.row_result(index,text);self.status.setText(text)
            return
        index=self.batch.index
        if not self.batch.result(request,event,field):return
        text=self.result_text(event,field)
        self.row_result(index,text)
        if self.batch.active:
            QTimer.singleShot(0,self.dispatch_next)
        else:
            self.set_running(False)
            prefix=f'اكتمل {self.batch.done}/{self.batch.total}. '
            if self.batch.stopping:prefix+='توقفت العملية حسب طلبك. '
            self.status.setText(prefix+text+(' يمكنك المتابعة بنفس الخيار؛ تُتخطّى الصفوف التي نجحت في هذه النافذة.' if self.batch.index<len(self.rows) else ''))

    def result_text(self,event,field):
        text={
            'detail_import_saved':'تم استيراد الداتا المفصّلة وحفظها بدون إرسال للمراجعة.',
            'detail_import_review_sent':'تم استيراد الداتا المفصّلة وحفظها وإرسال الطالب للمراجعة.',
            'detail_import_review_already':'حُفظت الداتا المفصّلة؛ الطالب مقدّم للمراجعة مسبقاً.',

            'detail_save_blocked':'زر الحفظ ما زال معطلاً. راجع الحقول المطلوبة في القسم؛ لم يُضغط الحفظ.',
            'detail_no_data':'لا توجد بيانات تفصيلية قابلة للاستيراد في هذا الصف؛ لم يُرسل الطالب للمراجعة.',
            'detail_review_sent':'تم الإرسال للمراجعة، وتأكد ظهور «مقدّم للمراجعة» في الموقع.',
            'detail_review_already':'الطالب مقدّم للمراجعة بالفعل؛ لم يُرسل مرة ثانية.',
            'detail_card_input':'اختر نوع المستند من أعمدة بطاقة التعريف في Excel، وأكمل رقم الوثيقة (أو رقم السجل السابق). تاريخ الانتهاء اختياري ويجب أن يكون تاريخاً صالحاً عند إدخاله.',
            'detail_card_disabled':'زر حفظ بطاقة التعريف ما زال معطلاً في الموقع. راجع الحقول أو رسالة التحقق الظاهرة؛ لم يتم الضغط على الحفظ.',
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_saved':'حُفظ القسم المحدد بنجاح.',
            'detail_all_saved':'حُفظت الأقسام المتاحة من ملف Excel بالتتابع بنجاح.',
            'detail_all_partial':'اكتملت الأقسام التي أمكن تعبئتها. بعض الأقسام موجودة سلفاً أو ناقصة في Excel وتُخطّيت دون استبدالها. راجع عمود شهرة الأم ونتيجة الموقع.',
            'detail_mother_missing':'شهرة الأم فارغة في صف Excel المحدد. عبّئ عمود «شهرة الأم (للمفصّل)» واحفظ الملف ثم أعد استيراده.',
            'detail_mother_field':'شهرة الأم وصلت من Excel، لكن لم أستطع تحديد خانة الشهرة وحدها داخل «الأقارب #2» الخاصة بالأم. ابعث HTML لهذا القسم مع عنوانه والخانة لضبطه.',
            'detail_save_unknown':'تم الضغط على حفظ القسم، لكن لم يصل تأكيد نجاح. راجع القسم المفتوح وما سبقه قبل إعادة المحاولة.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على سجل مطابق للاسم الكامل وتاريخ الولادة ضمن نطاق الصف المختار. لم تُدخل بيانات ولم يُوسّع البحث إلى باقي المدرسة.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'تعذّرت قراءة قائمة الطلاب ضمن النطاق المختار. راجع خيار الصف وامسح البحث وأعد باقي المرشحات إلى «الجميع»، ثم أعد المحاولة.',
            'detail_existing':'توجد بيانات مختلفة في الموقع أو أكثر من سجل. توقّف الاستيراد عند الطالب؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار أو مربع التأكيد بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_input':'أكمل بيانات القسم المختار في Excel: العنوان أو الهاتف أو شهرة الأم، ثم احفظ الملف وأعد استرداده.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.')
        from manual_sections import HEADERS
        if field in HEADERS:text+='\nالخانة: '+field
        return text

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.single_pending=None;self.batch.disconnect();self.set_running(False)
            for button in self.buttons:button.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.batch.rows=[];self.table.clearContents()

    def reject(self):
        if self.single_pending or self.batch.active or self.batch.pending:return
        super().reject()
