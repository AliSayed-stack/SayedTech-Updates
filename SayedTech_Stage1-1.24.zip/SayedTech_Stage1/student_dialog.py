"""Explicit per-student draft filling, with a separate opt-in save request."""
import uuid
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTableWidget,
    QTableWidgetItem,QPushButton,QPlainTextEdit,QAbstractItemView,QHeaderView,QComboBox)
from student_excel import FIELDS, BY_ID

class StudentImportDialog(QDialog):
    def __init__(self, rows, controller, parent, auto_start=False):
        super().__init__(parent)
        self.rows, self.controller = rows, controller
        self.pending = None
        self.filled = set()
        self.batch_active = False
        self.batch_queue = []
        self.batch_phase = None
        self.batch_id = None
        self.awaiting_review = None
        self.workflow = bool(rows) and all(row.get('workflow') for row in rows)
        self.session_active = parent.connected
        self.setWindowTitle('Sayed tech | استرداد إضافة التلاميذ')
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(1100,730)
        layout=QVBoxLayout(self)
        valid=sum(not r['errors'] for r in rows)
        layout.addWidget(QLabel(f'{len(rows)} طالب — {valid} صف صالح للفحص الأولي — {len(rows)-valid} صف بحاجة تصحيح'))
        note=QLabel('الاسترداد حالياً للخانات الأصلية فقط؛ الصف الذي يحتوي عنواناً يتوقف دون إرسال. اختر طالباً صالحاً ثم «تعبئة الطالب المحدد»، وراجعه واحفظ القسم بنفسك في المتصفح. «تعبئة وحفظ المبسّط» يضغط حفظ القسم وتأكيد مرة واحدة؛ النتيجة تحتاج تحققاً بالموقع. لا يضغط إرسال للمراجعة.')
        note.setWordWrap(True)
        layout.addWidget(note)
        if self.workflow:
            note.setText('يعرض فقط الطلاب الذين قيمتهم 1 أو نعم في Excel. اختر الصف أولاً، ثم علّم المربعات بجانب أسماء الطلاب المطلوب تدقيقهم وتسجيلهم. المسجّل مسبقاً يُتخطّى، والنتيجة الملتبسة توقف القائمة. لا يُرسل للمراجعة.')
        grade_line=QHBoxLayout()
        grade_line.addWidget(QLabel('الصف المطلوب استرداده وتسجيله:'))
        self.grade_combo=QComboBox()
        self.grade_combo.addItem('اختر الصف', None)
        grades=list(dict.fromkeys(row['values'].get('field-enrollment-promoted-class','') or 'غير محدد' for row in rows))
        for grade in grades:self.grade_combo.addItem(grade,grade)
        grade_line.addWidget(self.grade_combo,1)
        layout.addLayout(grade_line)
        self.table=QTableWidget(len(rows),9)
        self.table.setHorizontalHeaderLabels(['صف Excel','اسم الطالب','الصف','لغة التعليم','الشعبة','الحالة','الملاحظات','السنة في القاعدة','الحالة في القاعدة'])
        reference = any('reference' in row for row in rows)
        if reference:
            note.setText('هذه الصفوف محددة صراحة في Excel بـ«نعم» في مسجّل بمدرستي؟ وإدخال مبسّط؟. راجع السنة والحالة الأصلية والخانات المطلوبة. وجود الطالب في القاعدة أو انتسابه للمدرسة لا يثبت وجوده في SIMS. لا يجري أي تسجيل تلقائي بمجرد استرداد الملف؛ أزرار التعبئة والحفظ تعمل على الطالب المحدد وحده.')
        else:
            self.table.setColumnHidden(7, True)
            self.table.setColumnHidden(8, True)
        if any(row.get('unified') for row in rows):
            note.setText('تسجيل مبسّط من الملف الموحد: تُستخدم خانات المبسّط فقط للطلاب المحددين في أول عمود. العناوين والهواتف لا تؤثر على فحص المبسّط. لا تختَر طالباً موجوداً في SIMS لإنشائه مجدداً. عند إشعار نجاح الحفظ يرجع لإدارة الطلاب ويتابع التالي تلقائياً؛ وإلا يتوقف للمراجعة.')
        if self.workflow:
            note.setText('يعرض فقط الطلاب الذين قيمتهم 1 أو نعم في Excel. اختر الصف أولاً، ثم علّم مربّع الاختيار بجانب اسم كل طالب تريد تدقيقه وتسجيله. قبل حفظ كل طالب يفحص سجلات إدارة الطلاب؛ المسجّل يُتخطّى، والالتباس يوقف القائمة. لا يُغيّر Excel ولا يُرسل للمراجعة.')
        note.setText(note.text() + ' صفوف القاعدة تبدأ من طالب موجود؛ الصف اليدوي يمكن تسجيله كطالب جديد أو كطالب موجود بمدرسة أخرى حسب الخيار في Excel. فحص التكرار يسبق الحفظ.')
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(6,QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        for i,row in enumerate(rows):
            values=row['values']
            name=' '.join(values.get(k,'') for k in ('field-firstName','field-middleName','field-lastName'))
            texts=[str(row['excel_row']),name,values.get('field-enrollment-promoted-class',''),
                values.get('field-enrollment-teaching-language',''),values.get('field-enrollment-grade-section',''),
                'بحاجة تصحيح' if row['errors'] else 'جاهز للتعبئة','؛ '.join(row['errors']+row.get('warnings',[])),
                row.get('reference', {}).get('السنة في القاعدة', ''),
                row.get('reference', {}).get('الحالة في القاعدة', '')]
            for j,text in enumerate(texts):
                item=QTableWidgetItem(text)
                item.setToolTip(text)
                if j == 1 and self.workflow:
                    item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
                    item.setCheckState(Qt.Unchecked)
                self.table.setItem(i,j,item)
            self.table.setRowHidden(i,True)
        layout.addWidget(self.table,1)
        self.details=QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumHeight(155)
        layout.addWidget(self.details)
        self.status=QLabel('')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions=QHBoxLayout()
        self.fill_button=QPushButton('تعبئة الطالب المحدد')
        self.fill_button.clicked.connect(self.fill_selected)
        actions.addWidget(self.fill_button)
        self.save_button=QPushButton('تعبئة وحفظ المبسّط')
        self.save_button.clicked.connect(lambda:self.fill_selected(save=True))
        actions.addWidget(self.save_button)
        self.close_button=QPushButton('إغلاق')
        self.close_button.clicked.connect(self.reject)
        actions.addWidget(self.close_button)
        layout.addLayout(actions)
        batch_actions = QHBoxLayout()
        self.select_all_button = QPushButton('تحديد جاهزي هذا الصف')
        self.select_all_button.clicked.connect(self.select_all_ready)
        self.clear_button = QPushButton('إلغاء التحديد')
        self.clear_button.clicked.connect(self.clear_selection)
        self.batch_button = QPushButton('تدقيق وتسجيل المحددين')
        self.batch_button.clicked.connect(self.start_batch)
        self.continue_button = QPushButton('تحقّقت من الحفظ — تابع التالي')
        self.continue_button.clicked.connect(self.confirm_and_continue)
        self.stop_button = QPushButton('إيقاف التسجيل')
        self.stop_button.clicked.connect(self.stop_batch)
        for button in (self.select_all_button, self.clear_button, self.batch_button, self.continue_button, self.stop_button):
            button.setVisible(self.workflow)
            batch_actions.addWidget(button)
        layout.addLayout(batch_actions)
        self.table.itemSelectionChanged.connect(self.selection_changed)
        self.table.itemChanged.connect(lambda *_args:self.selection_changed())
        self.grade_combo.currentIndexChanged.connect(self.grade_changed)
        self.table.currentCellChanged.connect(lambda *_args:self.selection_changed())
        controller.student_result.connect(self.on_result)
        controller.event.connect(self.on_session_event)
        self.finished.connect(self.detach)
        self.table.setCurrentCell(0,0)
        self.selection_changed()
        # Even from the conversion window, require an explicit grade and student choice.

    def detach(self,*_args):
        self.controller.student_result.disconnect(self.on_result)
        self.controller.event.disconnect(self.on_session_event)
        # Do not write imported student data or messages to disk.
        self.rows=[]
        self.batch_queue=[]
        self.batch_active=False
        self.batch_phase=None
        self.awaiting_review=None
        self.table.clearContents()
        self.details.clear()

    def selection_changed(self):
        index=self.table.currentRow()
        if index<0 or not self.rows:
            self.fill_button.setEnabled(False); self.save_button.setEnabled(False)
            self.batch_button.setEnabled(False);return
        row=self.rows[index]
        lines=[]
        for f in FIELDS:
            value=row['values'].get(f['id'],'')
            if isinstance(value,bool): value='نعم' if value else 'لا'
            lines.append(f"{f['label']}: {value}")
        for label, value in row.get('address', {}).items():
            lines.append(f'{label}: {value}')
        for label, value in row.get('reference', {}).items():
            lines.append(f'{label}: {value}')
        self.details.setPlainText('\n'.join(lines + row['errors'] + row.get('warnings',[])))
        enabled=self.session_active and self.pending is None and not row['errors'] and index not in self.filled and not self.batch_active and not self.table.isRowHidden(index)
        self.fill_button.setEnabled(enabled);self.save_button.setEnabled(enabled)
        chosen=self.checked_indices()
        self.batch_button.setEnabled(self.workflow and self.session_active and self.pending is None and not self.batch_active and bool(chosen))
        self.grade_combo.setEnabled(self.pending is None and not self.batch_active)
        self.select_all_button.setEnabled(self.workflow and self.grade_combo.currentData() is not None and self.pending is None and not self.batch_active)
        self.clear_button.setEnabled(self.workflow and self.grade_combo.currentData() is not None and self.pending is None and not self.batch_active)
        self.continue_button.setEnabled(self.session_active and self.batch_active and self.batch_phase=='save' and self.pending is None and self.awaiting_review is not None)
        self.stop_button.setEnabled(self.batch_active)

    def fill_selected(self,checked=False,save=False,_batch=False):
        if self.batch_active and not _batch: return
        index=self.table.currentRow()
        if index<0 or self.pending or not self.session_active or self.table.isRowHidden(index) or self.rows[index]['errors'] or index in self.filled: return
        request=uuid.uuid4().hex
        self.pending=(request,index)
        token=self.batch_id if _batch else uuid.uuid4().hex
        if not self.controller.fill_student(self.rows[index]['values'],request,save=save,batch_id=token,
                                            entry_kind=self.rows[index].get('entry_kind','طالب موجود')):
            self.pending=None
            self.status.setText('تعذّر إرسال طلب التعبئة. تأكد من بقاء جلسة المتصفح مفتوحة.')
        else:
            self.status.setText('جارٍ تدقيق إدارة الطلاب قبل تعبئة الطالب وحفظه…' if save else 'جارٍ تدقيق إدارة الطلاب قبل تعبئة الطالب المحدد…')
            self.table.item(index,5).setText('جارٍ التعبئة')
        self.close_button.setEnabled(self.pending is None)
        self.selection_changed()

    def checked_indices(self):
        return [i for i in range(len(self.rows)) if not self.table.isRowHidden(i) and self.table.item(i,1).checkState()==Qt.Checked and i not in self.filled]

    def grade_changed(self):
        grade=self.grade_combo.currentData()
        for i,row in enumerate(self.rows):
            row_grade=row['values'].get('field-enrollment-promoted-class','') or 'غير محدد'
            self.table.setRowHidden(i, grade is None or row_grade != grade)
        self.table.clearSelection()
        visible=next((i for i in range(len(self.rows)) if not self.table.isRowHidden(i)),None)
        if visible is not None:self.table.setCurrentCell(visible,1)
        self.selection_changed()

    def select_all_ready(self):
        if self.pending or self.batch_active:return
        for i,row in enumerate(self.rows):
            if not self.table.isRowHidden(i):
                self.table.item(i,1).setCheckState(Qt.Checked if not row['errors'] and i not in self.filled else Qt.Unchecked)
        self.selection_changed()

    def clear_selection(self):
        if self.pending or self.batch_active:return
        for i in range(len(self.rows)):
            if not self.table.isRowHidden(i):self.table.item(i,1).setCheckState(Qt.Unchecked)
        self.selection_changed()

    def start_batch(self):
        if not self.workflow or self.pending or self.batch_active or not self.session_active: return
        chosen=self.checked_indices()
        if not chosen:
            self.status.setText('حدّد طالباً واحداً على الأقل من مربعات الاختيار.');return
        if any(self.rows[i]['errors'] for i in chosen):
            self.status.setText('لم يبدأ التسجيل. يوجد طالب محدد بحاجة تصحيح؛ ألغِ تحديده أو صحّح بياناته في Excel وأعد استرداده.'); return
        self.batch_queue = chosen
        self.batch_phase='save'
        self.batch_id = uuid.uuid4().hex
        self.awaiting_review = None
        self.batch_active = True
        self.advance_batch()

    def advance_batch(self):
        if not self.batch_active or self.pending or not self.session_active: return
        if not self.batch_queue:
            self.batch_active = False
            self.batch_phase=None
            self.status.setText('انتهت قائمة الطلاب المختارين. راجع نتائج التسجيل في الموقع.')
            self.selection_changed(); return
        index = self.batch_queue.pop(0)
        self.table.setCurrentCell(index,1)
        self.fill_selected(save=True,_batch=True)
        if self.pending is None:
            self.batch_active=False
            self.batch_queue=[]
            self.batch_phase=None
            self.selection_changed()

    def confirm_and_continue(self):
        if not self.batch_active or self.awaiting_review is None or self.pending or not self.session_active: return
        index = self.awaiting_review
        self.awaiting_review = None
        self.table.item(index,5).setText('تأكّد المستخدم من الحفظ')
        self.advance_batch()

    def stop_batch(self):
        self.batch_active=False
        self.batch_queue=[]
        self.batch_phase=None
        self.awaiting_review=None
        self.status.setText('سيتوقف بعد انتهاء الطلب الحالي. لن يبدأ الطالب التالي.' if self.pending else 'توقف التسجيل. لم يبدأ أي طالب إضافي.')
        self.selection_changed()

    def on_result(self,request,event,field):
        if self.pending is None or self.pending[0]!=request: return
        index=self.pending[1]
        self.pending=None
        messages={
            'student_preflight_clear':'لا يظهر تسجيل مطابق ضمن سجلات المدرسة؛ اجتاز الطالب مراجعة ما قبل الحفظ.',
            'student_already_registered':'الطالب موجود ضمن السجلات الحالية للمدرسة؛ تم تخطيه دون فتح نموذج التسجيل أو حفظه.',
            'student_duplicate_review':'توجد سجلات قد تكون للتلميذ نفسه لكن الهوية غير مؤكّدة. توقف التسجيل لمراجعتها، ولم يُضغط حفظ.',
            'student_duplicate_check_failed':'تعذّر جرد جميع سجلات إدارة الطلاب والتحقق منها. لم يبدأ تسجيل التلميذ؛ أعد المحاولة بعد فتح إدارة الطلاب وإظهار كل الصفوف.',
            'student_create_unavailable':'توقف قبل فتح إنشاء: زر إنشاء غير متاح أو محجوب بنافذة أخرى. افتح إدارة الطلاب وأغلق أي نافذة منبثقة ثم أعد المحاولة.',
            'student_existing_unavailable':'انفتح إنشاء لكن تعذّر الضغط على طالب موجود. راجع نافذة اختيار نوع الطالب.',
            'student_search_unavailable':'توقف عند نافذة طالب موجود: تعذّر إظهار خانة البحث أو الكتابة فيها. لم يبدأ تعبئة السجل.',
            'student_result_unavailable':'ظهرت نتيجة مطابقة لكن تعذّر اختيارها. لم يبدأ تعبئة السجل.',
            'student_form_unavailable':'تم اختيار نتيجة البحث لكن نموذج معلومات الطالب لم يظهر خلال المهلة. راجع المتصفح قبل إعادة المحاولة.',
            'student_field_failed':'توقف أثناء تعبئة الحقل المذكور. لم يُطلب الحفظ؛ راجع المسودة في المتصفح.',
            'student_saved':'أكد الموقع حفظ السجل الأساسي بنجاح، وعاد البرنامج إلى إدارة الطلاب.',
            'student_saved_return_failed':'أكد الموقع نجاح الحفظ، لكن تعذّر الرجوع إلى إدارة الطلاب. لا تعِد تسجيل هذا التلميذ؛ راجع المتصفح.',
            'student_save_requested':'تم الضغط على حفظ القسم وتأكيد مرة واحدة. نتيجة الحفظ غير مؤكّدة؛ تحقّق منها في الموقع قبل الانتقال أو إعادة التسجيل. لم يُضغط إرسال للمراجعة.',
            'student_save_unverified':'تعذّر تأكيد نتيجة محاولة الحفظ. قد يكون الطلب وصل؛ لن يكرره البرنامج لهذا الصف في هذه النافذة. راجع الموقع قبل أي إعادة تسجيل.',
            'student_save_blocked':'لم يُضغط حفظ القسم: تعذّر التحقق من الخانات أو زر الحفظ أو وُجدت نافذة مفتوحة. راجع المسودة في الموقع.',
            'student_draft_filled':'تمت تعبئة النموذج فقط. راجعه واحفظ القسم يدوياً في المتصفح قبل الانتقال إلى الطالب التالي.',
            'student_form_not_empty':'النموذج يحوي بيانات مسبقاً. راجعه ثم ارجع إلى إدارة الطلاب.',
            'student_existing_not_found':'لم يُعثر على طالب موجود يطابق الاسم الكامل وتاريخ الولادة والرقم الموحد إن توفر. راجع بيانات البحث؛ لم يُنشأ طالب جديد.',
            'student_existing_ambiguous':'ظهر أكثر من طالب مطابق. توقّف التسجيل لتراجع السجلات؛ لم يُختر طالب عشوائياً.',
            'student_search_changed':'تغيّرت نتائج البحث أو لم يُعرف شكلها. راجع نافذة طالب موجود وأعد المحاولة.',
            'student_existing_mismatch':'بيانات النموذج المفتوح لا تطابق التلميذ المختار من Excel. لم يبدأ تعديل معلوماته أو حفظها.',
            'student_options_changed':'قيمة غير متاحة أو غير مميزة في نموذج المدرسة. راجع خيارات الحقل والصف ولغة التعليم.',
            'student_open_management':'راجع أي مسودة مفتوحة ثم ارجع إلى إدارة الطلاب. يبدأ التسجيل من إنشاء ← طالب موجود.',
            'student_account_required':'تعذّر التحقق من حساب المدرسة الحالي. راجع جلسة تسجيل الدخول.',
            'student_invalid':'توقفت التعبئة بسبب قيمة غير صالحة في هذا الصف. راجع الحقل المذكور في Excel واحفظ الملف ثم أعد استيراده.',
            'student_cancelled':'أُلغيت التعبئة.',
            'student_busy':'هناك طلب تعبئة آخر قيد التنفيذ.',
            'student_failed':'لم تكتمل التعبئة. راجع ما ظهر في المتصفح قبل إعادة المحاولة؛ قد يكون النموذج معبأً جزئياً.',
        }
        message=messages.get(event,'تعذّرت التعبئة.')
        if field in BY_ID: message+=' الحقل: '+BY_ID[field]['label']
        if event=='student_invalid' and self.rows[index]['errors']:
            message+=' السبب: '+self.rows[index]['errors'][0]
        elif event=='student_invalid' and field=='field-existingUniqueId' and self.rows[index].get('entry_kind')=='طالب جديد':
            message+=' الطالب الجديد يجب أن يبقى رقمه الموحد فارغاً.'
        self.status.setText(message)
        if event=='student_already_registered':
            self.filled.add(index)
            self.table.item(index,5).setText('مسجّل مسبقاً — تم التخطي')
        elif event in {'student_saved','student_saved_return_failed'}:
            self.filled.add(index)
            self.table.item(index,5).setText('تم حفظ المبسّط' if event=='student_saved' else 'تم الحفظ — تعذّر الرجوع')
        elif event in {'student_save_requested','student_save_unverified','student_save_blocked'}:
            self.filled.add(index)
            self.table.item(index,5).setText('طلب حفظ — تحقّق من الموقع' if event=='student_save_requested' else 'الحفظ غير مؤكّد — راجع الموقع' if event=='student_save_unverified' else 'راجع المسودة — لم يُطلب الحفظ')
        elif event=='student_draft_filled':
            self.filled.add(index)
            self.table.item(index,5).setText('تمت التعبئة — غير محفوظ')
        else:
            self.table.item(index,5).setText('راجع المتصفح')
        self.table.item(index,6).setText(message)
        if self.batch_active:
            if event in {'student_saved','student_already_registered'}:
                self.awaiting_review=None
                QTimer.singleShot(0,self.advance_batch)
            elif event in {'student_save_requested','student_save_unverified'}:
                self.awaiting_review=index
                self.status.setText(message + ' بعد التحقق من نجاح الحفظ، اضغط «تحقّقت من الحفظ — تابع التالي».')
            else:
                self.batch_active=False
                self.batch_queue=[]
                self.batch_phase=None
                self.awaiting_review=None
                self.status.setText(message + ' توقفت قائمة التسجيل؛ راجع الموقع قبل استئنافها.')
        self.close_button.setEnabled(True)
        self.selection_changed()

    def on_session_event(self,event):
        if event in ('browser_closed','cancelled','disconnected','failed','timeout'):
            self.session_active=False
            self.batch_active=False
            self.batch_queue=[]
            self.batch_phase=None
            self.awaiting_review=None
            self.pending=None
            self.close_button.setEnabled(True)
            self.status.setText('أُغلقت جلسة المتصفح. أغلق هذه النافذة وسجّل الدخول مجدداً.')
            self.selection_changed()

    def reject(self):
        if self.pending:
            self.status.setText('انتظر انتهاء التعبئة؛ يمكنك إلغاء جلسة المتصفح بإغلاق نافذته.')
            return
        super().reject()

    def closeEvent(self,event):
        if self.pending: event.ignore()
        else: super().closeEvent(event)
