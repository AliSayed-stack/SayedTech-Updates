"""Shared student-attendance input contract for both school shifts."""
from datetime import date,datetime,timedelta
import hashlib
import re

HEADERS=['اختيار للاسترداد','الرقم الموحد للطالب','الاسم الأول','اسم الأب','الشهرة','صف الطالب',
         'من تاريخ','إلى تاريخ','سبب الغياب','تخطّي أيام العطلة الأسبوعية','ملاحظات']
REASONS=dict([
 ('medical_report_illness','تقرير طبي بسبب المرض'),('travel','سفر'),
 ('family_reasons','أسباب عائلية (زواج، وفاة)'),('without_permission_or_excuse','بدون إذن / من دون عذر'),
 ('administrative_leave','إذن إداري'),('maternity_leave','إجازة أمومة'),('unpaid_leave','إجازة من دون راتب'),
 ('no_attendance_day','لا يحضر هذا اليوم / يوم فراغ / حصر دوام'),('training_courses','دورات تدريبية'),
 ('resignation_or_contract_end','ترك / انقطاع / استقالة / انتهاء العقد'),('strike','إضراب'),
 ('weather_official_decision','أحوال الطقس بموجب قرار رسمي'),('justified_security_situation_or_war','وضع أمني مبرر / حرب'),
 ('temporary_suspension','فصل مؤقت'),('unjustified_reasons','أسباب غير مبررة'),('standby','الاستيداع'),
 ('refused_to_teach','امتنع عن التدريس / العمل'),('transferred_to_another_school','انتقل إلى ثانوية / مدرسة أخرى'),
 ('end_of_service_or_retirement','نهاية الخدمة / تقاعد'),
 ('severe_illness_or_injury_by_minister','أمراض مستعصية وحوادث جسدية جسيمة معللة بقرار وزير'),
 ('accepted_excuse_by_principal','عذر مقبول من قبل المدير'),('other','أسباب أخرى')])
EVENTS=frozenset({'attendance_template_saved','attendance_exported','attendance_saved','attendance_already',
 'attendance_account','attendance_input','attendance_identity','attendance_ambiguous','attendance_options',
 'attendance_date','attendance_existing','attendance_save_unknown','attendance_failed','attendance_busy','attendance_uncertain'})
SUCCESS_TEXT=re.compile(r'^\s*تم\s+تسجيل\s+الغياب\s*[—–-]\s*([0-9٠-٩]+)\s+أيام\s+دراسية[.\s]*$')


class AttendanceError(Exception):
    def __init__(self,code):self.code=code;super().__init__(code)


def account_key(username):return hashlib.sha256(username.strip().casefold().encode()).hexdigest()


def absence_date(value):
    if isinstance(value,bool):raise ValueError('date')
    if isinstance(value,(int,float)):
        if int(value)!=value or not 1<=value<=73050 or value==60:raise ValueError('date')
        return (date(1899,12,31)+timedelta(days=int(value)-(value>60))).isoformat()
    if isinstance(value,str):
        value=value.strip()
        for fmt in ('%Y-%m-%d','%m/%d/%Y'):
            try:return datetime.strptime(value,fmt).date().isoformat()
            except ValueError:pass
    raise ValueError('date')


def validate_absence(raw):
    from student_workflow import selection_value
    if not isinstance(raw,dict):raise AttendanceError('attendance_input')
    out={k:raw.get(k,'') for k in ('uid','first','middle','last','grade','start','end','reason','skip','notes','account')}
    if any(not isinstance(out[k],str) or len(out[k])>256 for k in ('uid','first','middle','last','grade')):
        raise AttendanceError('attendance_input')
    if not all(out[k].strip() for k in ('first','middle','last')):raise AttendanceError('attendance_identity')
    try:
        out['start']=absence_date(out['start'])
        out['end']=absence_date(out['end']) if out['end'] not in ('',None) else ''
        if out['end'] and out['end']<out['start']:raise ValueError('range')
        out['skip']=True if out['skip'] in ('',None) else out['skip'] if isinstance(out['skip'],bool) else selection_value(out['skip'])
    except (ValueError,TypeError,OverflowError):raise AttendanceError('attendance_date') from None
    if out['reason'] not in REASONS:
        codes=[k for k,v in REASONS.items() if v==out['reason']]
        if len(codes)!=1:raise AttendanceError('attendance_input')
        out['reason']=codes[0]
    if not isinstance(out['notes'],str) or len(out['notes'])>2000:raise AttendanceError('attendance_input')
    if not isinstance(out['account'],str) or not re.fullmatch('[a-f0-9]{64}',out['account']):raise AttendanceError('attendance_account')
    return out


def resolve_pupil(roster,record):
    from student_scan import normalized,is_deleted,canonical_uid
    expected=tuple(normalized(record[k]) for k in ('first','middle','last'))
    all_matches=[r for r in roster if tuple(normalized(r[k]) for k in ('first','middle','last'))==expected]
    if any(not str(r.get('status','')).strip() for r in all_matches):raise AttendanceError('attendance_options')
    live=[r for r in all_matches if not is_deleted(r)]
    pending=[r for r in live if normalized(r.get('status',''))==normalized('قيد الانتظار')]
    candidates=pending if pending else live
    uid=canonical_uid(record['uid'])
    if len(candidates)>1 and uid:candidates=[r for r in candidates if canonical_uid(r['uid'])==uid]
    if not candidates:raise AttendanceError('attendance_identity')
    if len(candidates)!=1:raise AttendanceError('attendance_ambiguous')
    chosen=candidates[0]
    if uid and canonical_uid(chosen['uid'])!=uid:
        # An old deleted row may carry the Excel UID. The user explicitly
        # requested the unique pending namesake instead of that deleted row.
        if not (len(pending)==1 and any(is_deleted(r) and canonical_uid(r['uid'])==uid for r in all_matches)):
            raise AttendanceError('attendance_identity')
    return chosen


def pupil_option(labels,pupil):
    from student_scan import normalized,canonical_uid
    uid=canonical_uid(pupil['uid'])
    names={normalized(' '.join(pupil[k] for k in keys)) for keys in (('first','last'),('first','middle','last'))}
    matches=[]
    for label in labels:
        parts=re.split(r'\s+[—–]\s+',label.strip(),maxsplit=1)
        if normalized(parts[0]) not in names:continue
        if uid and (len(parts)!=2 or canonical_uid(parts[1])!=uid):continue
        if not uid and len(parts)!=1:continue
        matches.append(label)
    if len(matches)!=1:raise AttendanceError('attendance_ambiguous' if matches else 'attendance_identity')
    return matches[0]
