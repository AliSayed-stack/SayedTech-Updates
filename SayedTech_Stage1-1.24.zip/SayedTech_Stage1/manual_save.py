"""Explicit per-section save and a separately requested review submission."""
from detailed_import import DetailError
from detail_dom import SAVE_SUCCESS_TEXT


def scope_for(page,title):
    scope=page.locator('section').filter(has=page.get_by_role('heading',name=title,exact=True))
    scope.wait_for(state='visible',timeout=5000)
    if scope.count()!=1:raise DetailError('detail_options')
    return scope


def confirm_once(page,scope,button_name,confirmation_name,guard):
    guard()
    button=scope.get_by_role('button',name=button_name,exact=True)
    if button.count()!=1:raise DetailError('detail_options')
    button.wait_for(state='visible',timeout=5000)
    # Reactive validation can enable the button on the next frame.
    try:button.evaluate('(e)=>new Promise((resolve,reject)=>{const end=Date.now()+3000;const tick=()=>{if(!e.disabled)return resolve(true);if(Date.now()>end)return reject(new Error("disabled"));setTimeout(tick,40)};tick()})')
    except Exception:raise DetailError('detail_save_blocked') from None
    if not button.is_enabled():raise DetailError('detail_options')
    guard();button.click(timeout=5000)
    dialog=page.locator('.swal2-popup[role="dialog"]')
    try:dialog.wait_for(state='visible',timeout=8000)
    except Exception:raise DetailError('detail_save_unknown') from None
    guard()
    confirm=dialog.get_by_role('button',name=confirmation_name,exact=True)
    if dialog.count()!=1 or confirm.count()!=1 or not confirm.is_enabled():raise DetailError('detail_save_unknown')
    confirm.click(timeout=5000)
    try:dialog.wait_for(state='hidden',timeout=8000)
    except Exception:raise DetailError('detail_save_unknown') from None
    guard()


def save_manual(page,title,guard):
    if title=='حالة التسجيل':return 'detail_filled'
    scope=scope_for(page,title)
    success=page.get_by_role('alert').filter(has_text=SAVE_SUCCESS_TEXT)
    try:success.wait_for(state='hidden',timeout=4000)
    except Exception:raise DetailError('detail_save_unknown') from None
    confirm_once(page,scope,'حفظ' if title in ('بطاقات التعريف','المستندات') else 'حفظ القسم','تأكيد',guard)
    try:success.wait_for(state='visible',timeout=8000)
    except Exception:raise DetailError('detail_save_unknown') from None
    return 'detail_saved'


def send_review(page,record,guard):
    guard()
    mode=page.get_by_role('radio',name='مفصّل',exact=True)
    if mode.count()!=1 or not mode.is_enabled():raise DetailError('detail_options')
    mode.click(timeout=3000)
    from detail_dom import tab_locator
    tab_locator(page,'حالة التسجيل').click(timeout=5000)
    guard();scope=scope_for(page,'حالة التسجيل')
    sent=scope.get_by_text('مقدّم للمراجعة',exact=True)
    if sent.count()==1 and sent.is_visible():return 'detail_review_already'
    terminate=scope.locator('#terminate-registration')
    if terminate.count()!=1 or terminate.is_checked():raise DetailError('detail_input')
    note=record.get('manual',{}).get('حالة التسجيل / ملاحظة (اختياري)','')
    if note:
        field=scope.get_by_label('ملاحظة (اختياري)',exact=True)
        if field.count()!=1 or not field.is_enabled():raise DetailError('detail_options')
        if field.input_value() and field.input_value()!=note:raise DetailError('detail_existing')
        guard();field.fill(note,timeout=3000)
    confirm_once(page,scope,'إرسال للمراجعة','إرسال للمراجعة',guard)
    try:sent.wait_for(state='visible',timeout=10000)
    except Exception:raise DetailError('detail_save_unknown') from None
    return 'detail_review_sent'
