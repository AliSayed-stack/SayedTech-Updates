"""Local grade scope shared by the detail preview, queue and roster lookup."""
import re


def grade_text(value):
    if not isinstance(value,str):return ''
    return re.sub(r'\s+',' ',re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',value)).strip()


def row_grade(row):
    return grade_text(row.get('values',{}).get('field-enrollment-promoted-class',''))


def in_grade(row,grade):
    return grade is None or row_grade(row)==grade


def scoped_record(row,grade):
    # Request metadata only; never change the source Excel values.
    return dict(row,search_grade=grade) if grade is not None else row


def grade_choices(rows):
    return list(dict.fromkeys(row_grade(row) for row in rows if row_grade(row)))
