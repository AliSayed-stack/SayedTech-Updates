"""A selected grade exports without reading other grades or school-wide pages."""
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
import zipfile
from test_scan import Page,Clock
from student_scan import collect_students,ScanError,clean_detail,list_scan_grades
from student_checkpoint import run_student_scan
from student_checkpoint import ScanCheckpoint

USERNAME='test@te.mehe.school'

class SelectedGradeScanTests(unittest.TestCase):
    def test_single_grade_scans_only_its_students_and_exports_a_complete_workbook(self):
        page=Page(105)
        grade='الثالث ثانوي'
        with tempfile.TemporaryDirectory() as tmp,patch('student_scan.time.monotonic',Clock()):
            target=Path(tmp)/'grade.xlsx'
            event,count,total,details=run_student_scan(page,USERNAME,threading.Event(),target,0,grade=grade)
            self.assertIn(event,('scan_saved','scan_saved_partial'))
            self.assertEqual((count,total),(35,35))
            self.assertEqual(sum(action[0]=='opened' for action in page.actions),35)
            self.assertFalse(any(action==('grade','الأول أساسي') for action in page.actions))
            self.assertFalse(any(action==('grade','الروضة الأولى') for action in page.actions))
            self.assertTrue(target.is_file())
            with zipfile.ZipFile(target) as workbook:self.assertIsNone(workbook.testzip())

    def test_chosen_grade_must_exist_on_site(self):
        page=Page(10)
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as error:
            collect_students(page,USERNAME,threading.Event(),0,grade='الثاني ثانوي')
        self.assertEqual(error.exception.reason,'grade_options')
        self.assertFalse(any(action[0]=='opened' for action in page.actions))

    def test_live_grade_options_are_returned_as_bounded_metadata(self):
        page=Page(15)
        with patch('student_scan.time.monotonic',Clock()):
            grades=list_scan_grades(page,USERNAME,threading.Event())
        self.assertEqual(set(clean_detail({'grades':grades})['grades']),set(page.grade_options()))
        self.assertFalse(any(action[0]=='opened' for action in page.actions))

    def test_grade_checkpoint_does_not_resume_another_grade(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'selected.xlsx'
            page=Page(15)
            subset=[r for r in page.records if r['grade']=='الثالث ثانوي']
            checkpoint=ScanCheckpoint(path,USERNAME,0,'الثالث ثانوي')
            checkpoint.bind(subset)
            checkpoint.close()
            other=ScanCheckpoint(path,USERNAME,0,'الأول أساسي')
            with self.assertRaises(ScanError) as error:other.bind(subset)
            self.assertEqual(error.exception.reason,'checkpoint_mismatch')

if __name__=='__main__':unittest.main()
