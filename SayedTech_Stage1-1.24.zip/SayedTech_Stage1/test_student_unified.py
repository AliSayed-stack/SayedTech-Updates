import copy
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import zipfile
import xml.etree.ElementTree as ET
from student_unified import convert_to_unified, translate_manual_names, add_mother_surname_column, UNIFIED_HEADERS, SELECTION, ENTRY_KIND, TRANSFER_KIND, LAST_UNIFIED_HEADERS, MOTHER_SURNAME, MOTHER_SURNAME_INDEX
from student_detailed import PREP_HEADERS, read_table
from student_excel import FIELDS, read_students, ExcelInputError, NS
from detailed_import import read_details
from test_students import record


def edit(path, values):
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml']);q=lambda n:'{'+NS['m']+'}'+n
    from student_workflow import column
    for header,value in values.items():
        cell=root.find('.//m:c[@r="'+column(UNIFIED_HEADERS.index(header)+1)+'2"]',NS)
        for child in list(cell):cell.remove(child)
        cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,q('is')),q('t')).text=value
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,v in parts.items():z.writestr(n,v)


def append_manual(path,kind='طالب جديد'):
    from student_workflow import column
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml']);q=lambda n:'{'+NS['m']+'}'+n
    body=root.find('m:sheetData',NS)
    row=ET.SubElement(body,q('row'),r='3')
    fields={f['label']:record().get(f['id'],'') for f in FIELDS}
    names={f['id']:f['label'] for f in FIELDS}
    fields.update({SELECTION:'1',ENTRY_KIND:kind,names['field-firstName']:'علي',
                   names['field-firstNameEn']:'',names['field-lastName']:'السيد',
                   names['field-lastNameEn']:'',names['field-middleName']:'حسن',
                   names['field-middleNameEn']:'',names['field-motherName']:'مريم',
                   names['field-motherNameEn']:'',names['field-existingUniqueId']:'',
                   'السنة في القاعدة':''})
    for key in ('field-nationality','field-motherNationality','isFatherDeceased','isMotherDeceased'):
        fields[names[key]]=''
    for j,label in enumerate(UNIFIED_HEADERS,1):
        value=fields.get(label,'')
        if isinstance(value,bool):value='نعم' if value else 'لا'
        c=ET.SubElement(row,q('c'),r=column(j)+'3',t='inlineStr')
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=str(value)
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in parts.items():z.writestr(name,data)


def add_ignorable_excel_namespaces(path):
    from student_workflow import column
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    main=NS['m'];mc='http://schemas.openxmlformats.org/markup-compatibility/2006'
    x14ac='http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac'
    ET.register_namespace('',main);ET.register_namespace('mc',mc);ET.register_namespace('x14ac',x14ac)
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    root.set('{%s}Ignorable'%mc,'x14ac')
    row=root.find(".//m:sheetData/m:row[@r='3']",NS)
    row.set('{%s}dyDescent'%x14ac,'0.25')
    col=column(UNIFIED_HEADERS.index(ENTRY_KIND)+1)
    cell=row.find("m:c[@r='%s3']"%col,NS)
    for child in list(cell):cell.remove(child)
    cell.set('t','inlineStr')
    ET.SubElement(ET.SubElement(cell,'{%s}is'%main),'{%s}t'%main).text=''
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in parts.items():z.writestr(name,data)


class UnifiedTests(unittest.TestCase):
    def test_residence_type_is_adjacent_to_address_in_new_exports(self):
        self.assertEqual(UNIFIED_HEADERS.index('نوع السكن'),UNIFIED_HEADERS.index('تفاصيل العنوان')+1)
        self.assertEqual(PREP_HEADERS.index('نوع السكن'),PREP_HEADERS.index('تفاصيل العنوان')+1)

    def make(self, folder, explicit=False, source_note=''):
        r=record()
        r.update({'field-firstName':'أحمد','field-firstNameEn':'Ahmed' if explicit else '',
                  'isFatherDeceased':'نعم' if explicit else '', 'isMotherDeceased':'',
                  'field-motherNationality':'لبنان' if explicit else '',
                  'field-fatherSector':'عاطل عن العمل','field-fatherOccupation':''})
        raw=dict.fromkeys(PREP_HEADERS,'')
        raw.update({f['label']:r[f['id']] for f in FIELDS})
        raw.update({'السنة في القاعدة':'20252026','معرّف الشخص في القاعدة':'123',
                    'معرّف المدرسة في القاعدة':'school', 'رقم الهاتف (LivingPhone)':'03123456',
                    'محافظة السكن':'الشمال','قضاء السكن':'زغرتا','منطقة / بلدة السكن':'بلدة اختبار',
                    'ملاحظات المصدر':source_note})
        source=Path(folder)/'source.xlsx';out=Path(folder)/'unified.xlsx'
        with zipfile.ZipFile(source,'w') as z:z.writestr('source','fixture')
        before=source.read_bytes()
        with patch('student_detailed.prepared_rows',return_value=[[raw[h] for h in PREP_HEADERS]]), patch('student_promotion.source_results',return_value={}):
            self.assertEqual(convert_to_unified(source,out),1)
        self.assertEqual(source.read_bytes(),before)
        return out

    def test_shared_defaults_names_and_no_initial_selection(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            with zipfile.ZipFile(p) as z:r=read_table(z,'الطلاب')[0]
            self.assertEqual(r[SELECTION],'0')
            by_id={f['id']:r[f['label']] for f in FIELDS}
            self.assertEqual(by_id['field-firstNameEn'],'Ahmad')
            self.assertEqual(by_id['isFatherDeceased'],'لا')
            self.assertEqual(by_id['isMotherDeceased'],'لا')
            self.assertEqual(by_id['field-motherNationality'],'سوريا')
            for reader in (read_students,read_details):
                with self.assertRaises(ExcelInputError):reader(p)

    def test_converting_again_never_overwrites_edited_workbook(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);edit(p,{SELECTION:'1'})
            previous=p.read_bytes()
            with self.assertRaisesRegex(ExcelInputError,'موجود مسبقاً'):
                convert_to_unified(Path(d)/'source.xlsx',p)
            self.assertEqual(p.read_bytes(),previous)

    def test_upgrades_previous_workbook_without_losing_edits(self):
        import student_unified
        with tempfile.TemporaryDirectory() as d:
            with patch.object(student_unified,'UNIFIED_HEADERS',LAST_UNIFIED_HEADERS):
                old=self.make(d,source_note='شهرة الأم في القاعدة: الحسين')
            original=old.read_bytes()
            upgraded=Path(d)/'with_mother_surname.xlsx'
            add_mother_surname_column(old,upgraded)
            self.assertEqual(old.read_bytes(),original)
            with zipfile.ZipFile(upgraded) as z:
                rows=read_table(z,'الطلاب')
                self.assertIn(MOTHER_SURNAME,rows[0])
                self.assertEqual(rows[0][MOTHER_SURNAME],'الحسين')
                self.assertEqual(rows[0][SELECTION],'0')
                table=ET.fromstring(z.read('xl/tables/table1.xml'))
            from student_unified import UNIFIED_HEADERS_V081
            self.assertEqual(len(table.find('m:tableColumns',NS)),len(UNIFIED_HEADERS_V081))
            import openpyxl
            book=openpyxl.load_workbook(upgraded,read_only=False)
            self.assertEqual(book['الطلاب'].cell(1,MOTHER_SURNAME_INDEX+1).value,MOTHER_SURNAME)
            self.assertEqual(book['الطلاب'].cell(2,MOTHER_SURNAME_INDEX+1).value,'الحسين')
            self.assertEqual(book['الطلاب'].tables['StudentsInput'].tableColumns[MOTHER_SURNAME_INDEX].name,MOTHER_SURNAME)
            previous_book=openpyxl.load_workbook(old,read_only=True)
            self.assertEqual(book['الطلاب'].cell(2,MOTHER_SURNAME_INDEX+2).value,
                             previous_book['الطلاب'].cell(2,MOTHER_SURNAME_INDEX+1).value)
            previous_book.close()
            book.close()

    def test_mother_surname_is_adjacent_and_detailed_only(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d,source_note='غير متوفر؛ شهرة الأم في القاعدة: الحسين؛ مراجعة')
            edit(p,{SELECTION:'1'})
            with zipfile.ZipFile(p) as z:
                headings=list(z.namelist())
                rows=read_table(z,'الطلاب')
            self.assertEqual(UNIFIED_HEADERS[MOTHER_SURNAME_INDEX-1],
                             next(f['label'] for f in FIELDS if f['id']=='field-motherName'))
            self.assertEqual(rows[0][MOTHER_SURNAME],'الحسين')
            simple=read_students(p)[0]
            self.assertNotIn('mother_surname',simple['values'])
            self.assertEqual(read_details(p)[0]['mother_surname'],'الحسين')

    def test_mother_surname_falls_back_to_source_note_when_cell_has_spaces(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d,source_note='معلومة مصدر؛ شهرة الأم في القاعدة: الحسين')
            edit(p,{SELECTION:'1',MOTHER_SURNAME:'   '})
            self.assertEqual(read_details(p)[0]['mother_surname'],'الحسين')

    def test_same_edited_file_both_readers_and_independent_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            first=next(f['label'] for f in FIELDS if f['id']=='field-firstName')
            english=next(f['label'] for f in FIELDS if f['id']=='field-firstNameEn')
            edit(p,{SELECTION:'1',first:'محمود',english:'Mahmoud', 'الشارع':'شارع تجريبي'})
            simple=read_students(p)[0];detailed=read_details(p)[0]
            self.assertEqual(simple['errors'],[]) # no country/address validation in simple
            self.assertTrue(simple['workflow']);self.assertTrue(simple['unified'])
            self.assertEqual(simple['values']['field-firstName'],detailed['values']['field-firstName'])
            self.assertEqual(detailed['values']['field-firstNameEn'],'Mahmoud')
            self.assertEqual(detailed['address']['الشارع'],'شارع تجريبي')
            self.assertEqual(detailed['phone'],'03123456')
            self.assertNotIn('phone',simple)
            # Detailed identity/address import does not demand the parents' occupations.
            sector=next(f['label'] for f in FIELDS if f['id']=='field-fatherSector')
            edit(p,{sector:'قطاع خاص'})
            self.assertTrue(read_students(p)[0]['errors'])
            self.assertEqual(len(read_details(p)),1)

    def test_existing_values_remain_and_year_is_checked(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d,explicit=True);edit(p,{SELECTION:'نعم'})
            simple=read_students(p)[0]['values']
            self.assertEqual(simple['field-firstNameEn'],'Ahmed')
            self.assertTrue(simple['isFatherDeceased'])
            self.assertEqual(simple['field-motherNationality'],'لبنان')
            edit(p,{'السنة في القاعدة':'20242025'})
            for reader in (read_students,read_details):
                with self.assertRaises(ExcelInputError):reader(p)

    def test_manual_row_is_translated_in_same_file_and_uses_new_route(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            self.assertGreaterEqual(translate_manual_names(p),1)
            self.assertEqual(translate_manual_names(p),0)
            with zipfile.ZipFile(p) as z:rows=read_table(z,'الطلاب')
            english=next(f['label'] for f in FIELDS if f['id']=='field-firstNameEn')
            self.assertEqual(rows[1][english],'Ali')
            expected={'field-lastNameEn':'Al Sayed','field-middleNameEn':'Hassan','field-motherNameEn':'Mariam'}
            for field_id,value in expected.items():
                label=next(f['label'] for f in FIELDS if f['id']==field_id)
                self.assertEqual(rows[1][label],value)
            self.assertEqual(rows[1][ENTRY_KIND],'طالب جديد')
            simple=read_students(p)
            self.assertEqual(len(simple),1)
            self.assertEqual(simple[0]['entry_kind'],'طالب جديد')
            self.assertEqual(simple[0]['values']['field-firstNameEn'],'Ali')
            self.assertEqual(simple[0]['errors'],[])

    def test_manual_student_from_another_school_translates_and_uses_existing_search(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p,TRANSFER_KIND)
            self.assertEqual(translate_manual_names(p),10)
            student=read_students(p)[0]
            self.assertEqual(student['entry_kind'],'طالب موجود')
            self.assertEqual(student['errors'],[])
            self.assertEqual(student['values']['field-firstNameEn'],'Ali')
            self.assertEqual(student['values']['field-existingUniqueId'],'')
            with zipfile.ZipFile(p) as z:rows=read_table(z,'الطلاب')
            self.assertEqual(rows[1][ENTRY_KIND],TRANSFER_KIND)
            with zipfile.ZipFile(p) as z:
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            validations=[v.findtext('m:formula1','',NS) for v in sheet.findall('m:dataValidations/m:dataValidation',NS)]
            self.assertTrue(any(TRANSFER_KIND in formula for formula in validations))

    def test_manual_defaults_apply_even_without_translation_and_keep_explicit_values(self):
        for kind in ('طالب جديد',TRANSFER_KIND):
            with tempfile.TemporaryDirectory() as d:
                p=self.make(d);append_manual(p,kind)
                with zipfile.ZipFile(p) as z:
                    selected=__import__('student_unified').selected_rows(z,'detailed')[0][1]
                labels={f['id']:f['label'] for f in FIELDS}
                self.assertEqual(selected[labels['field-nationality']],'سوريا')
                self.assertEqual(selected[labels['field-motherNationality']],'سوريا')
                self.assertEqual(selected[labels['isFatherDeceased']],'لا')
                self.assertEqual(selected[labels['isMotherDeceased']],'لا')
                self.assertEqual(selected['السنة في القاعدة'],'2025/2026')
                self.assertEqual(selected['بلد السكن'],'لبنان')
                self.assertEqual(len(read_details(p)),1)
                # A typed value wins over a suggested default.
                with zipfile.ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
                root=ET.fromstring(parts['xl/worksheets/sheet1.xml']);q=lambda n:'{'+NS['m']+'}'+n
                from student_workflow import column
                col=column(UNIFIED_HEADERS.index(labels['field-nationality'])+1)
                cell=root.find(f".//m:c[@r='{col}3']",NS)
                cell.find('m:is/m:t',NS).text='لبنان'
                parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
                with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                    for n,data in parts.items():z.writestr(n,data)
                self.assertGreaterEqual(translate_manual_names(p),1)
                with zipfile.ZipFile(p) as z:row=read_table(z,'الطلاب')[1]
                self.assertEqual(row[labels['field-nationality']],'لبنان')

    def test_translation_preserves_excel_compatibility_namespaces_and_manual_blank_route(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p);add_ignorable_excel_namespaces(p)
            self.assertEqual(translate_manual_names(p),10)
            with zipfile.ZipFile(p) as z:
                xml=z.read('xl/worksheets/sheet1.xml')
                rows=read_table(z,'الطلاب')
            self.assertIn(b'mc:Ignorable="x14ac"',xml)
            self.assertIn(b'xmlns:x14ac=',xml)
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')
            self.assertEqual(rows[1]['الشهرة (بالإنكليزية)'],'Al Sayed')
            self.assertEqual(rows[1]['اسم الأب (بالإنكليزية)'],'Hassan')
            self.assertEqual(rows[1]['اسم الأم (بالإنكليزية)'],'Mariam')

    def test_translation_keeps_unrelated_xml_and_unused_ignorable_namespace(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            with zipfile.ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
            original=parts['xl/worksheets/sheet1.xml']
            # Excel may declare x14ac solely in mc:Ignorable, with no x14ac
            # element/attribute in the sheet. ElementTree silently drops it.
            import re
            opening=re.search(rb'<(?:[\w.-]+:)?worksheet(?=[\s>])',original).group()
            original=original.replace(opening, opening+b' xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac" mc:Ignorable="x14ac"',1)
            parts['xl/worksheets/sheet1.xml']=original
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                for n,v in parts.items():z.writestr(n,v)
            self.assertEqual(translate_manual_names(p),10)
            with zipfile.ZipFile(p) as z:
                updated=z.read('xl/worksheets/sheet1.xml')
                for n,v in parts.items():
                    if n!='xl/worksheets/sheet1.xml':self.assertEqual(z.read(n),v)
                rows=read_table(z,'الطلاب')
            self.assertIn(b'xmlns:x14ac=',updated)
            self.assertIn(b'mc:Ignorable="x14ac"',updated)
            body_start=re.search(rb'<(?:[\w.-]+:)?sheetData(?=[\s>])',original).start()
            self.assertIn(original[:body_start],updated)
            self.assertEqual(rows[0]['الاسم الأول (بالعربية)'],'أحمد')
            self.assertEqual(rows[1]['الاسم الأول (بالعربية)'],'علي')
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')

    def test_translation_inserts_missing_english_cells_in_column_order(self):
        from student_workflow import column
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            with zipfile.ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
            root=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
            row=root.find(".//m:sheetData/m:row[@r='3']",NS)
            for _,english_id in (('field-firstName','field-firstNameEn'),('field-lastName','field-lastNameEn'),
                                 ('field-middleName','field-middleNameEn'),('field-motherName','field-motherNameEn')):
                label=next(f['label'] for f in FIELDS if f['id']==english_id)
                row.remove(row.find("m:c[@r='%s3']"%column(UNIFIED_HEADERS.index(label)+1),NS))
            parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                for n,v in parts.items():z.writestr(n,v)
            self.assertEqual(translate_manual_names(p),10)
            with zipfile.ZipFile(p) as z:
                rows=read_table(z,'الطلاب')
                xml=z.read('xl/worksheets/sheet1.xml')
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')
            self.assertEqual(rows[1]['الشهرة (بالإنكليزية)'],'Al Sayed')
            parsed=ET.fromstring(xml)
            translated=parsed.find(".//m:sheetData/m:row[@r='3']",NS)
            letters=[c.get('r')[:-1] for c in translated.findall('m:c',NS)]
            self.assertEqual(letters,sorted(letters,key=lambda col:sum((ord(c)-64)*26**(len(col)-i-1) for i,c in enumerate(col))))

    def test_manual_row_cannot_claim_imported_identity(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            edit(p,{SELECTION:'1',ENTRY_KIND:'طالب جديد'})
            with self.assertRaisesRegex(ExcelInputError,'معرّفاً'):read_students(p)

    def test_housing_type_dropdown_and_street_remains_user_input(self):
        from student_workflow import column
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            with zipfile.ZipFile(p) as z:
                root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                menus={node.get('sqref'):node.findtext('m:formula1','',NS) for node in root.findall('m:dataValidations/m:dataValidation',NS)}
                rows=read_table(z,'الطلاب')
            letter=column(UNIFIED_HEADERS.index('نوع السكن')+1)
            self.assertEqual(menus[letter+'2:'+letter+'501'],'"دائم,صيفي,غير ذلك"')
            self.assertEqual(rows[0]['الشارع'],'')
            self.assertEqual(rows[0]['تفاصيل العنوان'],'')
            edit(p,{SELECTION:'1','نوع السكن':'دائم'})
            self.assertEqual(read_details(p)[0]['address']['النوع'],'دائم')


if __name__=='__main__':unittest.main()
