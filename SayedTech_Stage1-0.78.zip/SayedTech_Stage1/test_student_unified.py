import copy
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import zipfile
import xml.etree.ElementTree as ET
from student_unified import convert_to_unified, translate_manual_names, UNIFIED_HEADERS, SELECTION, ENTRY_KIND
from student_detailed import PREP_HEADERS, read_table
from student_excel import FIELDS, read_students, ExcelInputError, NS
from detailed_import import read_details
from test_students import record


def edit(path, values):
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml']);q=lambda n:'{'+NS['m']+'}'+n
    from student_workflow import column
    for header,value in values.items():
        cell=root.find('.//m:c[@r="'+column(UNIFIED_HEADERS.index(header)+1)+'2"]',NS)
        for child in list(cell):cell.remove(child)
        cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,q('is')),q('t')).text=value
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,v in parts.items():z.writestr(n,v)


def append_manual(path):
    from student_workflow import column
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml']);q=lambda n:'{'+NS['m']+'}'+n
    body=root.find('m:sheetData',NS)
    row=ET.SubElement(body,q('row'),r='3')
    fields={f['label']:record().get(f['id'],'') for f in FIELDS}
    names={f['id']:f['label'] for f in FIELDS}
    fields.update({SELECTION:'1',ENTRY_KIND:'طالب جديد',names['field-firstName']:'علي',
                   names['field-firstNameEn']:'',names['field-lastName']:'السيد',
                   names['field-lastNameEn']:'',names['field-middleName']:'حسن',
                   names['field-middleNameEn']:'',names['field-motherName']:'مريم',
                   names['field-motherNameEn']:'',names['field-existingUniqueId']:''})
    for j,label in enumerate(UNIFIED_HEADERS,1):
        value=fields.get(label,'')
        if isinstance(value,bool):value='نعم' if value else 'لا'
        c=ET.SubElement(row,q('c'),r=column(j)+'3',t='inlineStr')
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=str(value)
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in parts.items():z.writestr(name,data)


def add_ignorable_excel_namespaces(path):
    from student_workflow import column
    with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
    main=NS['m'];mc='http://schemas.openxmlformats.org/markup-compatibility/2006'
    x14ac='http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac'
    ET.register_namespace('',main);ET.register_namespace('mc',mc);ET.register_namespace('x14ac',x14ac)
    root=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    root.set('{%s}Ignorable'%mc,'x14ac')
    row=root.find(".//m:sheetData/m:row[@r='3']",NS)
    row.set('{%s}dyDescent'%x14ac,'0.25')
    col=column(UNIFIED_HEADERS.index(ENTRY_KIND)+1)
    cell=row.find("m:c[@r='%s3']"%col,NS)
    for child in list(cell):cell.remove(child)
    cell.set('t','inlineStr')
    ET.SubElement(ET.SubElement(cell,'{%s}is'%main),'{%s}t'%main).text=''
    parts['xl/worksheets/sheet1.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in parts.items():z.writestr(name,data)


class UnifiedTests(unittest.TestCase):
    def make(self, folder, explicit=False):
        r=record()
        r.update({'field-firstName':'أحمد','field-firstNameEn':'Ahmed' if explicit else '',
                  'isFatherDeceased':'نعم' if explicit else '', 'isMotherDeceased':'',
                  'field-motherNationality':'لبنان' if explicit else '',
                  'field-fatherSector':'عاطل عن العمل','field-fatherOccupation':''})
        raw=dict.fromkeys(PREP_HEADERS,'')
        raw.update({f['label']:r[f['id']] for f in FIELDS})
        raw.update({'السنة في القاعدة':'20252026','معرّف الشخص في القاعدة':'123',
                    'معرّف المدرسة في القاعدة':'school', 'رقم الهاتف (LivingPhone)':'03123456',
                    'محافظة السكن':'الشمال','قضاء السكن':'زغرتا','منطقة / بلدة السكن':'بلدة اختبار'})
        source=Path(folder)/'source.xlsx';out=Path(folder)/'unified.xlsx'
        with zipfile.ZipFile(source,'w') as z:z.writestr('source','fixture')
        before=source.read_bytes()
        with patch('student_detailed.prepared_rows',return_value=[[raw[h] for h in PREP_HEADERS]]), patch('student_promotion.source_results',return_value={}):
            self.assertEqual(convert_to_unified(source,out),1)
        self.assertEqual(source.read_bytes(),before)
        return out

    def test_shared_defaults_names_and_no_initial_selection(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            with zipfile.ZipFile(p) as z:r=read_table(z,'الطلاب')[0]
            self.assertEqual(r[SELECTION],'0')
            by_id={f['id']:r[f['label']] for f in FIELDS}
            self.assertEqual(by_id['field-firstNameEn'],'Ahmad')
            self.assertEqual(by_id['isFatherDeceased'],'لا')
            self.assertEqual(by_id['isMotherDeceased'],'لا')
            self.assertEqual(by_id['field-motherNationality'],'سوريا')
            for reader in (read_students,read_details):
                with self.assertRaises(ExcelInputError):reader(p)

    def test_same_edited_file_both_readers_and_independent_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            first=next(f['label'] for f in FIELDS if f['id']=='field-firstName')
            english=next(f['label'] for f in FIELDS if f['id']=='field-firstNameEn')
            edit(p,{SELECTION:'1',first:'محمود',english:'Mahmoud', 'الشارع':'شارع تجريبي'})
            simple=read_students(p)[0];detailed=read_details(p)[0]
            self.assertEqual(simple['errors'],[]) # no country/address validation in simple
            self.assertTrue(simple['workflow']);self.assertTrue(simple['unified'])
            self.assertEqual(simple['values']['field-firstName'],detailed['values']['field-firstName'])
            self.assertEqual(detailed['values']['field-firstNameEn'],'Mahmoud')
            self.assertEqual(detailed['address']['الشارع'],'شارع تجريبي')
            self.assertEqual(detailed['phone'],'03123456')
            self.assertNotIn('phone',simple)
            # Detailed identity/address import does not demand the parents' occupations.
            sector=next(f['label'] for f in FIELDS if f['id']=='field-fatherSector')
            edit(p,{sector:'قطاع خاص'})
            self.assertTrue(read_students(p)[0]['errors'])
            self.assertEqual(len(read_details(p)),1)

    def test_existing_values_remain_and_year_is_checked(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d,explicit=True);edit(p,{SELECTION:'نعم'})
            simple=read_students(p)[0]['values']
            self.assertEqual(simple['field-firstNameEn'],'Ahmed')
            self.assertTrue(simple['isFatherDeceased'])
            self.assertEqual(simple['field-motherNationality'],'لبنان')
            edit(p,{'السنة في القاعدة':'20242025'})
            for reader in (read_students,read_details):
                with self.assertRaises(ExcelInputError):reader(p)

    def test_manual_row_is_translated_in_same_file_and_uses_new_route(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            self.assertGreaterEqual(translate_manual_names(p),1)
            self.assertEqual(translate_manual_names(p),0)
            with zipfile.ZipFile(p) as z:rows=read_table(z,'الطلاب')
            english=next(f['label'] for f in FIELDS if f['id']=='field-firstNameEn')
            self.assertEqual(rows[1][english],'Ali')
            expected={'field-lastNameEn':'Al Sayed','field-middleNameEn':'Hassan','field-motherNameEn':'Mariam'}
            for field_id,value in expected.items():
                label=next(f['label'] for f in FIELDS if f['id']==field_id)
                self.assertEqual(rows[1][label],value)
            self.assertEqual(rows[1][ENTRY_KIND],'طالب جديد')
            simple=read_students(p)
            self.assertEqual(len(simple),1)
            self.assertEqual(simple[0]['entry_kind'],'طالب جديد')
            self.assertEqual(simple[0]['values']['field-firstNameEn'],'Ali')
            self.assertEqual(simple[0]['errors'],[])

    def test_translation_preserves_excel_compatibility_namespaces_and_manual_blank_route(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p);add_ignorable_excel_namespaces(p)
            self.assertEqual(translate_manual_names(p),4)
            with zipfile.ZipFile(p) as z:
                xml=z.read('xl/worksheets/sheet1.xml')
                rows=read_table(z,'الطلاب')
            self.assertIn(b'mc:Ignorable="x14ac"',xml)
            self.assertIn(b'xmlns:x14ac=',xml)
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')
            self.assertEqual(rows[1]['الشهرة (بالإنكليزية)'],'Al Sayed')
            self.assertEqual(rows[1]['اسم الأب (بالإنكليزية)'],'Hassan')
            self.assertEqual(rows[1]['اسم الأم (بالإنكليزية)'],'Mariam')

    def test_translation_keeps_unrelated_xml_and_unused_ignorable_namespace(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            with zipfile.ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
            original=parts['xl/worksheets/sheet1.xml']
            # Excel may declare x14ac solely in mc:Ignorable, with no x14ac
            # element/attribute in the sheet. ElementTree silently drops it.
            opening=b'<ns0:worksheet'
            self.assertIn(opening,original)
            original=original.replace(opening, opening+b' xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" xmlns:x14ac="http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac" mc:Ignorable="x14ac"',1)
            parts['xl/worksheets/sheet1.xml']=original
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                for n,v in parts.items():z.writestr(n,v)
            self.assertEqual(translate_manual_names(p),4)
            with zipfile.ZipFile(p) as z:
                updated=z.read('xl/worksheets/sheet1.xml')
                for n,v in parts.items():
                    if n!='xl/worksheets/sheet1.xml':self.assertEqual(z.read(n),v)
                rows=read_table(z,'الطلاب')
            self.assertIn(b'xmlns:x14ac=',updated)
            self.assertIn(b'mc:Ignorable="x14ac"',updated)
            self.assertIn(original.split(b'<ns0:sheetData')[0],updated)
            self.assertEqual(rows[0]['الاسم الأول (بالعربية)'],'أحمد')
            self.assertEqual(rows[1]['الاسم الأول (بالعربية)'],'علي')
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')

    def test_translation_inserts_missing_english_cells_in_column_order(self):
        from student_workflow import column
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            with zipfile.ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
            root=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
            row=root.find(".//m:sheetData/m:row[@r='3']",NS)
            for _,english_id in (('field-firstName','field-firstNameEn'),('field-lastName','field-lastNameEn'),
                                 ('field-middleName','field-middleNameEn'),('field-motherName','field-motherNameEn')):
                label=next(f['label'] for f in FIELDS if f['id']==english_id)
                row.remove(row.find("m:c[@r='%s3']"%column(UNIFIED_HEADERS.index(label)+1),NS))
            parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
                for n,v in parts.items():z.writestr(n,v)
            self.assertEqual(translate_manual_names(p),4)
            with zipfile.ZipFile(p) as z:
                rows=read_table(z,'الطلاب')
                xml=z.read('xl/worksheets/sheet1.xml')
            self.assertEqual(rows[1]['الاسم الأول (بالإنكليزية)'],'Ali')
            self.assertEqual(rows[1]['الشهرة (بالإنكليزية)'],'Al Sayed')
            parsed=ET.fromstring(xml)
            translated=parsed.find(".//m:sheetData/m:row[@r='3']",NS)
            letters=[c.get('r')[:-1] for c in translated.findall('m:c',NS)]
            self.assertEqual(letters,sorted(letters,key=lambda col:sum((ord(c)-64)*26**(len(col)-i-1) for i,c in enumerate(col))))

    def test_manual_row_cannot_claim_imported_identity(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d);append_manual(p)
            edit(p,{SELECTION:'1',ENTRY_KIND:'طالب جديد'})
            with self.assertRaisesRegex(ExcelInputError,'معرّفاً'):read_students(p)

    def test_housing_type_dropdown_and_street_remains_user_input(self):
        from student_workflow import column
        with tempfile.TemporaryDirectory() as d:
            p=self.make(d)
            with zipfile.ZipFile(p) as z:
                root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                menus={node.get('sqref'):node.findtext('m:formula1','',NS) for node in root.findall('m:dataValidations/m:dataValidation',NS)}
                rows=read_table(z,'الطلاب')
            letter=column(UNIFIED_HEADERS.index('نوع السكن')+1)
            self.assertEqual(menus[letter+'2:'+letter+'501'],'"دائم,صيفي,غير ذلك"')
            self.assertEqual(rows[0]['الشارع'],'')
            self.assertEqual(rows[0]['تفاصيل العنوان'],'')
            edit(p,{SELECTION:'1','نوع السكن':'دائم'})
            self.assertEqual(read_details(p)[0]['address']['النوع'],'دائم')


if __name__=='__main__':unittest.main()
