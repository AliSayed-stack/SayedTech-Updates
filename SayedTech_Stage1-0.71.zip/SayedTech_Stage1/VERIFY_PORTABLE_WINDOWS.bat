@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
set "PYTHONHOME="
set "PYTHONPATH="
set "VIRTUAL_ENV="
set "PLAYWRIGHT_BROWSERS_PATH="
set "QT_PLUGIN_PATH="
set "QT_QPA_PLATFORM_PLUGIN_PATH="
set "PATH=%SystemRoot%;%SystemRoot%\System32"
"%~dp0SayedTech.exe" --bundle-self-test
if not "%errorlevel%"=="0" goto failure
"%~dp0helpers\SayedTechLogin\SayedTechLogin.exe" --bundle-self-test
if not "%errorlevel%"=="0" goto failure
echo Offline app and bundled Firefox/Chromium checks passed. No Python command was used.
pause
exit /b 0
:failure
echo Installed application check failed. Send the error shown here for diagnosis.
pause
exit /b 1
