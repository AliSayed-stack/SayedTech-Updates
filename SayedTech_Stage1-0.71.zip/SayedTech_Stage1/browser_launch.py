"""The user's browser choice is shared by both school shifts."""
BROWSERS = ('edge', 'chrome', 'firefox', 'chromium')


def launch_browser(playwright, name, *, headless=False):
    if name == 'firefox': return playwright.firefox.launch(headless=headless)
    if name == 'chromium':
        return playwright.chromium.launch(headless=headless, args=['--start-maximized'])
    if name in ('edge', 'chrome'):
        return playwright.chromium.launch(channel='msedge' if name == 'edge' else 'chrome',
                                         headless=headless, args=['--start-maximized'])
    raise ValueError('Unsupported browser')
