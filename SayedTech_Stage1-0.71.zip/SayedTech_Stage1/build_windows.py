"""Build on Windows, test bundled runtimes, then publish one installer EXE."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from ensure_dependencies import ensure

ROOT = Path(__file__).resolve().parent
INSTALLER_NAME = 'SayedTech-Setup-Windows-x64.exe'


def find_inno_compiler():
    def candidates():
        found = shutil.which('ISCC.exe')
        if found: yield Path(found)
        for base in (os.environ.get('LOCALAPPDATA'), os.environ.get('ProgramFiles(x86)'),
                     os.environ.get('ProgramFiles')):
            if base:
                for version in ('6', '7'):
                    yield Path(base)/'Programs'/('Inno Setup '+version)/'ISCC.exe'
                    yield Path(base)/('Inno Setup '+version)/'ISCC.exe'
    for candidate in candidates():
        if candidate.is_file(): return candidate
    winget=shutil.which('winget')
    if winget:
        subprocess.run([winget, 'install', '--id', 'JRSoftware.InnoSetup', '--exact',
                        '--scope', 'user', '--silent', '--accept-source-agreements',
                        '--accept-package-agreements'], check=True, timeout=600)
        for candidate in candidates():
            if candidate.is_file(): return candidate
    raise RuntimeError('Inno Setup compiler was not found. Install Inno Setup 6 on this build PC.')


def installer_script(package, output, version):
    """Only generated paths from this build; no student data or credentials."""
    template=(ROOT/'installer.iss').read_text(encoding='utf-8')
    return (template.replace('@PACKAGE_DIR@', str(package))
                    .replace('@OUTPUT_DIR@', str(output))
                    .replace('@APP_VERSION@', version))


def clean_environment():
    env = dict(os.environ)
    for key in list(env):
        if key.upper().startswith(('PYTHON', 'VIRTUAL_ENV', 'QT_', 'PYSIDE', 'PLAYWRIGHT')):
            env.pop(key, None)
    windows = env.get('SystemRoot', r'C:\Windows')
    env['PATH'] = os.pathsep.join([windows, str(Path(windows)/'System32')])
    return env


def main():
    if sys.platform != 'win32' or sysconfig.get_platform() != 'win-amd64':
        raise RuntimeError('Build this release on Windows x64.')
    os.chdir(ROOT)
    ensure()
    subprocess.run([sys.executable, '-m', 'pip', 'install', 'pyinstaller==6.22.3'], check=True)
    env = dict(os.environ, PLAYWRIGHT_BROWSERS_PATH='0')
    subprocess.run([sys.executable, '-m', 'playwright', 'install', 'firefox', 'chromium'], env=env, check=True)
    # Unique staging protects any previous successful release when a build fails.
    with tempfile.TemporaryDirectory(prefix='SayedTech-build-') as temp:
        stage = Path(temp)
        build_assets = stage/'assets'
        shutil.copytree(ROOT/'assets', build_assets)
        for name in ('MEHENSL.exe', 'MDBL.dll'):
            if not (build_assets/'legacy'/name).is_file():
                raise RuntimeError(f'Missing bundled NSLDB reference file: {name}')
        common = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean', '--onedir',
                  '--distpath', str(stage/'dist'), '--workpath', str(stage/'work'),
                  '--specpath', str(stage), '--add-data', str(build_assets)+';assets']
        subprocess.run(common+['--windowed', '--name', 'SayedTech', '--collect-all', 'sqlce', str(ROOT/'app.py')], env=env, check=True)
        subprocess.run(common+['--console', '--name', 'SayedTechLogin', '--collect-all', 'playwright', str(ROOT/'login_worker.py')], env=env, check=True)
        package = stage/'dist/SayedTech'
        helper = package/'helpers/SayedTechLogin'
        shutil.copytree(stage/'dist/SayedTechLogin', helper)
        verify_env = clean_environment()
        for executable in (package/'SayedTech.exe', helper/'SayedTechLogin.exe'):
            subprocess.run([str(executable), '--bundle-self-test'], env=verify_env,
                           cwd=stage, check=True, timeout=120)
        shutil.copy2(ROOT/'README_PORTABLE_AR.txt', package/'README_AR.txt')
        shutil.copy2(ROOT/'VERIFY_PORTABLE_WINDOWS.bat', package/'VERIFY_PORTABLE_WINDOWS.bat')
        import core
        (package/'BUILD_INFO.json').write_text(json.dumps({'app': core.APP_VERSION,
            'python':sys.version.split()[0], 'platform':'Windows x64',
            'bundled_browsers':['Firefox','Chromium'], 'offline_smoke_checks':'passed'}, indent=2), encoding='utf-8')
        output=ROOT/'dist';output.mkdir(exist_ok=True)
        compiler=find_inno_compiler()
        installer_out=stage/'installer';installer_out.mkdir()
        script=stage/'installer.iss'
        script.write_text(installer_script(package,installer_out,core.APP_VERSION),encoding='utf-8')
        subprocess.run([str(compiler),str(script)],check=True,timeout=1800)
        installer=installer_out/INSTALLER_NAME
        if not installer.is_file() or installer.stat().st_size<2:
            raise RuntimeError('Installer was not produced by Inno Setup.')
        with installer.open('rb') as stream:
            if stream.read(2)!=b'MZ': raise RuntimeError('Installer is not a Windows executable.')
        # Replace only after both runtime checks and the installer compile succeed.
        temporary=output/(INSTALLER_NAME+'.new')
        shutil.copy2(installer, temporary)
        os.replace(temporary,output/INSTALLER_NAME)
        print('Release ready:',output/INSTALLER_NAME)


if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print('Build failed:',exc, file=sys.stderr)
        raise SystemExit(1)
