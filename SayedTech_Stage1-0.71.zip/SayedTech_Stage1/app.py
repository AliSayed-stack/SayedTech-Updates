"""Sayed tech — school registration, no application sign-in required."""
import sys
import threading
import shutil
from PySide6.QtCore import Qt, QObject, Signal
from PySide6.QtGui import QFont, QIcon
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QHBoxLayout,
    QVBoxLayout, QLabel, QFrame, QPushButton, QLineEdit, QComboBox, QStackedWidget, QCheckBox, QFileDialog)
import core
from login_controller import LoginController
from login_flow import validate_credentials, LoginInputError, SHIFT_DOMAINS
from credential_store import CredentialStore, CredentialError

SECTIONS = {
    'root': ('أقسام البرنامج', None, ('students', 'employees')),
    'students': ('الطلاب', 'root', ('student_admin', 'student_attendance', 'student_payments')),
    'student_admin': ('الإدارة', 'students', ('student_create', 'student_simple', 'student_detailed')),
    'student_create': ('إنشاء / إضافة التلاميذ', 'student_admin', ()),
    'student_simple': ('إدخال المعلومات المبسطة', 'student_admin', ()),
    'student_detailed': ('إدخال المعلومات المفصلة', 'student_admin', ()),
    'student_attendance': ('الحضور', 'students', ()),
    'student_payments': ('مدفوعات الطلاب', 'students', ()),
    'employees': ('الموظفون', 'root', ('employee_admin', 'employee_attendance', 'employee_daily', 'employee_monthly')),
    'employee_admin': ('الإدارة', 'employees', ()),
    'employee_attendance': ('الحضور', 'employees', ()),
    'employee_daily': ('الساعات اليومية', 'employees', ()),
    'employee_monthly': ('الساعات الشهرية', 'employees', ()),
}

class Events(QObject):
    finished = Signal(object)


def label(text, name=''):
    widget = QLabel(text)
    widget.setObjectName(name)
    widget.setWordWrap(True)
    return widget

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.busy = False
        self.connected = False
        self.returning_to_school = False
        self._closing = False
        self.school_shift = None
        self.credential_store = CredentialStore()
        self._saved_available = False
        self.events = Events(self)
        self.events.finished.connect(self.finished)
        self.setWindowTitle('Sayed tech | بيانات المدرسة')
        self.setWindowIcon(QIcon(str(core.ASSET_BASE / 'assets' / 'logo.svg')))
        self.resize(1040, 790)
        self.setMinimumSize(940, 760)
        self.setLayoutDirection(Qt.RightToLeft)
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(28, 22, 28, 16)
        header = QHBoxLayout()
        header.addWidget(label('إدارة بيانات المدرسة', 'eyebrow'))
        header.addStretch()
        self.update_button = QPushButton('تحديث البرنامج')
        self.update_button.setObjectName('secondary')
        self.update_button.clicked.connect(self.open_update)
        header.addWidget(self.update_button)
        header.addWidget(label('Sayed tech', 'smallBrand'))
        outer.addLayout(header)
        content = QHBoxLayout()
        content.setSpacing(22)
        panel = QFrame()
        panel.setObjectName('panel')
        pl = QVBoxLayout(panel)
        pl.setContentsMargins(32, 26, 32, 22)
        self.pages = QStackedWidget()
        self.welcome_page = self.build_welcome()
        self.shift_page = self.build_shift_choice()
        self.school_page = self.build_school()
        self.login_page = self.build_login()
        self.menu_page = self.build_menu()
        self.pages.addWidget(self.welcome_page)
        self.pages.addWidget(self.shift_page)
        self.pages.addWidget(self.school_page)
        self.pages.addWidget(self.login_page)
        self.pages.addWidget(self.menu_page)
        pl.addWidget(self.pages)
        self.status = label('', 'status')
        self.status.setMinimumHeight(48)
        pl.addWidget(self.status)
        content.addWidget(panel, 3)
        side = QFrame()
        side.setObjectName('side')
        side.setFixedWidth(285)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(27, 32, 27, 28)
        logo = QSvgWidget(str(core.ASSET_BASE / 'assets' / 'logo.svg'))
        logo.setFixedSize(90, 90)
        sl.addWidget(logo, alignment=Qt.AlignRight)
        sl.addSpacing(18)
        sl.addWidget(label('Sayed tech', 'brand'))
        sl.addSpacing(8)
        for text, style_name in (
            ('Ali El Sayed', 'contactName'),
            ('71020669', 'contactPhone'),
            ('IT Ayrouniyeh Official School', 'contactRole'),
        ):
            contact = label(text, style_name)
            contact.setLayoutDirection(Qt.LeftToRight)
            contact.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            contact.setTextInteractionFlags(Qt.TextSelectableByMouse)
            sl.addWidget(contact)
        sl.addSpacing(14)
        sl.addWidget(label('بداية منظّمة\nلشغل المدرسة.', 'tagline'))
        sl.addSpacing(12)
        for text in ('01   اختيار الدوام', '02   بيانات المدرسة', '03   الدخول إلى SIMS'):
            sl.addWidget(label(text,'sideStep'))
        sl.addStretch()
        sl.addWidget(label('إحصاء المدارس\nوتسهيل الوصول إلى النظام.', 'sideNote'))
        content.addWidget(side)
        outer.addLayout(content, 1)
        outer.addWidget(label(f'Sayed tech • نسخة أولية {core.APP_VERSION}', 'footer'))
        self.setStyleSheet(STYLE)
        self.login_controller = LoginController(self)
        self.login_controller.event.connect(self.on_login_event)
        cached = core.read_school()
        self.school.setText(cached.get('school', ''))
        self.center.setText(cached.get('center', ''))

    def build_welcome(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addStretch()
        greeting_row = QHBoxLayout()
        greeting_row.setSpacing(12)
        greeting_icon = label('👋', 'welcomeIcon')
        greeting_icon.setAlignment(Qt.AlignCenter)
        greeting_row.addWidget(greeting_icon, 0, Qt.AlignVCenter)
        self.welcome_greeting = label('أهلاً فيك', 'title')
        greeting_row.addWidget(self.welcome_greeting, 1, Qt.AlignVCenter)
        layout.addLayout(greeting_row)
        layout.addSpacing(12)
        layout.addWidget(label('اسم الموظف', 'fieldLabel'))
        self.employee_name_input = QLineEdit()
        self.employee_name_input.setObjectName('employeeName')
        self.employee_name_input.setMaxLength(60)
        self.employee_name_input.setPlaceholderText('اكتب اسمك هون')
        self.employee_name_input.setToolTip('الاسم للترحيب فقط؛ لا يُحفظ ولا يُرسل.')
        self.employee_name_input.textChanged.connect(self.update_welcome_greeting)
        layout.addWidget(self.employee_name_input)
        layout.addWidget(label('الاسم للترحيب على هذه الشاشة فقط، ولا يُحفظ أو يُرسل.', 'hint'))
        product = label('Sayed tech', 'welcomeBrand')
        product.setLayoutDirection(Qt.LeftToRight)
        product.setAlignment(Qt.AlignLeft)
        layout.addWidget(product)
        layout.addSpacing(16)
        layout.addWidget(label('اختر دوام المدرسة، ثم أدخل بياناتها للمتابعة.', 'subtitle'))
        layout.addSpacing(28)
        self.start_button = QPushButton('ابدأ')
        self.start_button.clicked.connect(lambda: self.pages.setCurrentWidget(self.shift_page))
        layout.addWidget(self.start_button)
        layout.addStretch()
        return page

    def update_welcome_greeting(self, name):
        clean_name = ' '.join(name.split())
        self.welcome_greeting.setText(f'أهلاً فيك {clean_name}' if clean_name else 'أهلاً فيك')

    def build_shift_choice(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addStretch()
        layout.addWidget(label('اختيار دوام المدرسة', 'title'))
        layout.addWidget(label('اختر أحد الخيارين للانتقال إلى بيانات المدرسة.', 'subtitle'))
        layout.addSpacing(26)
        self.morning_button = QPushButton('مدارس قبل الظهر')
        self.morning_button.setObjectName('shiftOption')
        self.morning_button.clicked.connect(lambda: self.select_shift('morning'))
        layout.addWidget(self.morning_button)
        layout.addSpacing(12)
        self.afternoon_button = QPushButton('مدارس بعد الظهر')
        self.afternoon_button.setObjectName('shiftOption')
        self.afternoon_button.clicked.connect(lambda: self.select_shift('afternoon'))
        layout.addWidget(self.afternoon_button)
        layout.addSpacing(12)
        back = QPushButton('رجوع')
        back.setObjectName('secondary')
        back.clicked.connect(lambda: self.pages.setCurrentWidget(self.welcome_page))
        layout.addWidget(back)
        layout.addStretch()
        return page

    def select_shift(self, shift):
        if self.busy or shift not in ('morning', 'afternoon'):
            return
        self.school_shift = shift
        self.shift_label.setText('مدارس قبل الظهر' if shift == 'morning' else 'مدارس بعد الظهر')
        domain = SHIFT_DOMAINS[shift]
        self.username.setPlaceholderText(f'name@{domain}')
        self.login_email_label.setText(f'إيميل الشغل — {self.shift_label.text()}')
        self.username.setToolTip(f'الإيميل المقبول ينتهي فقط بـ @{domain}')
        self.restore_saved_login()
        self.status.clear()
        self.pages.setCurrentWidget(self.school_page)

    def change_shift(self):
        if not self.busy:
            self.status.clear()
            self.pages.setCurrentWidget(self.shift_page)

    def build_school(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0,0,0,0)
        layout.addWidget(label('بيانات المدرسة','title'))
        self.shift_label = label('', 'selectedShift')
        layout.addWidget(self.shift_label)
        self.change_shift_button = QPushButton('تغيير الدوام')
        self.change_shift_button.setObjectName('changeShift')
        self.change_shift_button.clicked.connect(self.change_shift)
        layout.addWidget(self.change_shift_button)
        layout.addSpacing(12)
        for attr, title, hint, limit in (
            ('school','اسم المدرسة','أدخل اسم المدرسة',160),
            ('center','رقم المركز التربوي','مثال: 01234',12)):
            layout.addWidget(label(title,'fieldLabel'))
            field=QLineEdit()
            field.setMaxLength(limit)
            field.setPlaceholderText(hint)
            setattr(self,attr,field)
            layout.addWidget(field)
        self.center.setLayoutDirection(Qt.LeftToRight)
        self.center.setAlignment(Qt.AlignRight)
        self.submit_button=QPushButton('متابعة')
        self.submit_button.clicked.connect(self.submit)
        layout.addWidget(self.submit_button)
        layout.addWidget(label('تُرسل بيانات المدرسة إلى مسؤول البرنامج لأغراض الإحصاء والدعم.','privacyNotice'))
        layout.addStretch()
        return page

    def build_login(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(label('تسجيل الدخول إلى SIMS', 'title'))
        self.login_school_label = label('', 'subtitle')
        layout.addWidget(self.login_school_label)
        layout.addSpacing(12)
        self.login_email_label = label('اسم المستخدم / إيميل الشغل', 'fieldLabel')
        layout.addWidget(self.login_email_label)
        self.username = QLineEdit()
        self.username.setMaxLength(254)
        self.username.setLayoutDirection(Qt.LeftToRight)
        self.username.setPlaceholderText('اختر دوام المدرسة أولاً')
        layout.addWidget(self.username)
        layout.addWidget(label('كلمة السر', 'fieldLabel'))
        self.password = QLineEdit()
        self.password.setMaxLength(1024)
        self.password.setLayoutDirection(Qt.LeftToRight)
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText('Password')
        self.password.returnPressed.connect(self.start_login)
        layout.addWidget(self.password)
        self.show_password = QCheckBox('إظهار كلمة السر')
        self.show_password.toggled.connect(lambda checked: self.password.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password))
        options=QHBoxLayout()
        options.addWidget(self.show_password)
        self.remember_login=QCheckBox('تذكّر بيانات الدخول على هالجهاز')
        self.remember_login.setChecked(self.credential_store.available)
        self.remember_login.setEnabled(self.credential_store.available)
        self.remember_login.toggled.connect(self.remember_changed)
        options.addWidget(self.remember_login)
        self.forget_login_button=QPushButton('نسيان المحفوظ')
        self.forget_login_button.setObjectName('changeShift')
        self.forget_login_button.setToolTip('حذف بيانات الدخول المحفوظة للدوام المختار من Windows')
        self.forget_login_button.setEnabled(False)
        self.forget_login_button.clicked.connect(self.forget_saved_login)
        options.addWidget(self.forget_login_button)
        layout.addLayout(options)
        self.credential_note=label('تُحفظ عند الضغط على تسجيل الدخول، محلياً في مدير بيانات اعتماد Windows لهذا المستخدم.', 'hint')
        layout.addWidget(self.credential_note)
        self.username.textEdited.connect(self.login_username_edited)
        layout.addSpacing(8)
        layout.addWidget(label('المتصفح', 'fieldLabel'))
        self.browser = QComboBox()
        for text, value in [('Microsoft Edge', 'edge'), ('Google Chrome', 'chrome'), ('Firefox — نسخة البرنامج', 'firefox'), ('Chromium — نسخة البرنامج', 'chromium')]:
            self.browser.addItem(text, value)
        layout.addWidget(self.browser)
        layout.addWidget(label('تُفتح نافذة مستقلة للدخول إلى Microsoft ثم نظام الوزارة.', 'hint'))
        self.login_button = QPushButton('تسجيل الدخول')
        self.login_button.clicked.connect(self.start_login)
        layout.addWidget(self.login_button)
        self.cancel_login_button = QPushButton('إلغاء تسجيل الدخول')
        self.cancel_login_button.setObjectName('secondary')
        self.cancel_login_button.setEnabled(False)
        self.cancel_login_button.clicked.connect(self.cancel_login)
        layout.addWidget(self.cancel_login_button)
        self.login_back_button = QPushButton('العودة إلى بيانات المدرسة')
        self.login_back_button.setObjectName('secondary')
        self.login_back_button.clicked.connect(self.return_to_school)
        layout.addWidget(self.login_back_button)
        layout.addWidget(label('بيانات الدخول تُستخدم مع Microsoft فقط، ولا تُرسل إلى نموذج الإحصاء. أكمل أي تحقّق إضافي في المتصفح.', 'hint'))
        layout.addStretch()
        return page

    def build_menu(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        self.menu_title = label('أقسام البرنامج', 'title')
        layout.addWidget(self.menu_title)
        self.menu_summary = label('', 'selectedShift')
        layout.addWidget(self.menu_summary)
        self.menu_breadcrumb = label('', 'subtitle')
        layout.addWidget(self.menu_breadcrumb)
        layout.addSpacing(14)
        self.section_stack = QStackedWidget()
        self.section_pages = {}
        self.section_buttons = {}
        self.operation_buttons = {}
        self.current_section = 'root'
        for key, (title, parent, children) in SECTIONS.items():
            section = QWidget()
            section_layout = QVBoxLayout(section)
            section_layout.setContentsMargins(0, 0, 0, 0)
            section_layout.setSpacing(12)
            if children:
                if key == 'root':
                    section_layout.addWidget(label('اختر القسم للمتابعة.', 'subtitle'))
                if key == 'student_admin':
                    self.nsldb_button = QPushButton('NSLDB \u200e2025–2026\u200e — سحب كامل / ملف موحد / استيراد')
                    self.nsldb_button.setObjectName('menuOption')
                    self.nsldb_button.clicked.connect(self.open_nsldb)
                    section_layout.addWidget(self.nsldb_button)
                    self.scan_button = QPushButton('سحب بيانات الطلاب والنواقص — تجربة')
                    self.scan_button.setObjectName('menuOption')
                    self.scan_button.clicked.connect(self.open_student_scan)
                    section_layout.addWidget(self.scan_button)
                for child in children:
                    button = QPushButton(SECTIONS[child][0])
                    button.setObjectName('menuOption')
                    button.clicked.connect(lambda checked=False, target=child: self.show_section(target))
                    section_layout.addWidget(button)
                    self.section_buttons[child] = button
            else:
                actions = QHBoxLayout()
                actions.setSpacing(12)
                for operation in ('استخراج', 'استرداد'):
                    button = QPushButton(operation)
                    button.setObjectName('operationPending')
                    button.setEnabled(key == 'student_create')
                    if key == 'student_create':
                        button.clicked.connect(lambda checked=False, action=operation: self.student_operation(action))
                        button.setToolTip('تنزيل نموذج الطلاب المدمج مع قوائم العناوين' if operation == 'استخراج' else 'فحص Excel وتعبئة الطالب المحدد')
                    else:
                        button.setToolTip('ستُفعّل بعد تحديد الحقول وربط هذا القسم بالنظام.')
                    actions.addWidget(button)
                    self.operation_buttons[(key, operation)] = button
                section_layout.addLayout(actions)
                note = 'استخراج واسترداد هذا القسم قيد التجهيز؛ ستُفعّل الأزرار بعد تحديد الحقول المطلوبة.'
                if key == 'student_create':
                    note = 'استخراج: نموذج الطلاب المدمج، ٢٧ خانة أصلية و٧ خانات للعناوين مع القوائم المترابطة. الاسترداد حالياً للخانات الأصلية فقط؛ الصف الذي يحتوي عنواناً يتوقف للمراجعة حتى تفعيل استرداد العناوين. يمكن تعبئة المسودة فقط أو اختيار «تعبئة وحفظ المبسّط». نتيجة الحفظ تُراجع في الموقع؛ لا يضغط إرسال للمراجعة.'
                elif key == 'employee_admin':
                    note = 'تفاصيل إدارة الموظفين ستُضاف لاحقاً، ومعها ربط الاستخراج والاسترداد.'
                elif key in ('student_attendance', 'employee_attendance'):
                    note = 'تنظيم الحضور والاستخراج والاسترداد سيُضاف لاحقاً.'
                section_layout.addWidget(label(note, 'hint'))
                if key == 'student_detailed':
                    self.catalog_button = QPushButton('تجميع قوائم المحافظة والقضاء والمنطقة')
                    self.catalog_button.clicked.connect(self.open_catalog)
                    section_layout.addWidget(self.catalog_button)
                    section_layout.addWidget(label('أداة تجهيز قوائم Excel من عناوين تلميذ مسجّل: تبدّل الاختيارات مؤقتاً ثم ترجعها، دون حفظ الطالب أو تصدير بياناته.', 'hint'))
            section_layout.addStretch()
            self.section_pages[key] = section
            self.section_stack.addWidget(section)
        layout.addWidget(self.section_stack, 1)
        navigation = QHBoxLayout()
        self.section_back_button = QPushButton('رجوع')
        self.section_back_button.setObjectName('secondary')
        self.section_back_button.clicked.connect(lambda: self.show_section(SECTIONS[self.current_section][1] or 'root'))
        navigation.addWidget(self.section_back_button)
        self.section_home_button = QPushButton('القائمة الرئيسية')
        self.section_home_button.setObjectName('secondary')
        self.section_home_button.clicked.connect(lambda: self.show_section('root'))
        navigation.addWidget(self.section_home_button)
        layout.addLayout(navigation)
        self.section_back_button.setVisible(False)
        self.section_home_button.setVisible(False)
        close = QPushButton('إنهاء جلسة الدخول')
        close.setObjectName('secondary')
        close.clicked.connect(self.cancel_login)
        layout.addWidget(close)
        return page

    def show_section(self, key):
        if not self.connected or key not in SECTIONS:
            return
        self.current_section = key
        self.menu_title.setText(SECTIONS[key][0])
        path = []
        ancestor = key
        while ancestor != 'root':
            path.append(SECTIONS[ancestor][0])
            ancestor = SECTIONS[ancestor][1]
        self.menu_breadcrumb.setText(' / '.join(reversed(path)))
        self.menu_breadcrumb.setVisible(key != 'root')
        self.section_stack.setCurrentWidget(self.section_pages[key])
        self.section_back_button.setVisible(key != 'root')
        self.section_home_button.setVisible(key != 'root')
        self.status.clear()

    def open_catalog(self):
        if not self.connected: return
        from catalog_dialog import CatalogDialog
        dialog = CatalogDialog(self.login_controller, self)
        dialog.exec()

    def open_update(self):
        from update_dialog import UpdateDialog
        UpdateDialog(self).exec()

    def open_student_scan(self):
        if not self.connected: return
        from student_scan_dialog import StudentScanDialog
        StudentScanDialog(self.login_controller,self).exec()

    def open_nsldb(self):
        if not self.connected: return
        from nsldb_dialog import NSLDBDialog
        NSLDBDialog(self).exec()

    def student_operation(self, operation):
        if not self.connected: return
        if operation == 'استخراج':
            path,_ = QFileDialog.getSaveFileName(self,'استخراج نموذج الطلاب مع العناوين','SayedTech_Students_With_Addresses.xlsx','Excel (*.xlsx)')
            if not path: return
            if not path.lower().endswith('.xlsx'): path += '.xlsx'
            try:
                shutil.copyfile(core.ASSET_BASE / 'assets/student_with_addresses.xlsx',path)
                self.status.setText('تم استخراج نموذج الطلاب المدمج مع قوائم العناوين. استرداد العناوين إلى النظام غير مفعّل بعد.')
            except OSError:
                self.status.setText('تعذّر حفظ النموذج. اختر مجلداً متاحاً وأغلق الملف إذا كان مفتوحاً.')
        else:
            path,_ = QFileDialog.getOpenFileName(self,'استرداد نموذج إضافة التلاميذ','','Excel (*.xlsx)')
            if not path: return
            from student_excel import read_students, ExcelInputError
            from student_dialog import StudentImportDialog
            try: rows = read_students(path, shift=self.school_shift)
            except ExcelInputError as exc:
                self.status.setText(str(exc)); return
            dialog = StudentImportDialog(rows,self.login_controller,self)
            dialog.exec()

    def submit(self):
        if self.busy: return
        try:
            name,center=core.validate_school(self.school.text(),self.center.text())
        except core.AppError as exc:
            self.status.setText(str(exc)); return
        cached=core.read_school()
        if cached.get('school')==name and cached.get('center')==center:
            self.show_done(name,center)
            self.status.clear()
            try: core.save_school(name,center)
            except OSError: self.status.setText('تعذّر حفظ التعديلات محلياً.')
            return
        self.busy=True
        self.submit_button.setEnabled(False)
        self.change_shift_button.setEnabled(False)
        for field in (self.school,self.center): field.setReadOnly(True)
        self.status.clear()
        def worker():
            try: result=core.submit_school(name,center)
            except core.AppError as exc: result=exc
            except Exception: result=core.AppError('تعذّر الاتصال بالنموذج. افحص الإنترنت وإعدادات النموذج.')
            try: self.events.finished.emit(result)
            except RuntimeError: pass
        threading.Thread(target=worker,daemon=True).start()

    def finished(self,result):
        self.busy=False
        self.submit_button.setEnabled(True)
        self.change_shift_button.setEnabled(True)
        for field in (self.school,self.center): field.setReadOnly(False)
        if isinstance(result,Exception):
            self.status.setText(str(result)); return
        name,center=result
        self.show_done(name,center)
        self.status.clear()
        try: core.save_school(name,center)
        except OSError: self.status.setText('تم الإرسال، لكن تعذّر حفظ التسجيل محلياً. تجنّب إعادة الإرسال.')

    def show_done(self,name,center):
        self.login_school_label.setText(f'{name} — رقم المركز: {center} — {self.shift_label.text()}')
        self.password.clear()
        self.show_password.setChecked(False)
        self.restore_saved_login()
        self.pages.setCurrentWidget(self.login_page)

    def restore_saved_login(self,replace_username=True):
        self._saved_available=False
        self.show_password.setChecked(False)
        if replace_username:
            self.username.clear();self.password.clear()
        if not self.credential_store.available:
            self.credential_note.setText('حفظ كلمة السر المحمي متاح عند تشغيل البرنامج على Windows.')
            self.forget_login_button.setEnabled(False);return
        if self.school_shift not in SHIFT_DOMAINS:return
        try:
            saved=self.credential_store.load(self.school_shift)
        except CredentialError as exc:
            self.credential_note.setText(str(exc))
            self._saved_available=True
            self.forget_login_button.setEnabled(True);return
        self._saved_available=saved is not None
        self.forget_login_button.setEnabled(self._saved_available)
        if saved and self.remember_login.isChecked() and (replace_username or self.username.text().strip().casefold()==saved['username']):
            self.username.setText(saved['username']);self.password.setText(saved['password'])
            self.credential_note.setText('تمت تعبئة بيانات الدخول المحفوظة لهذا الدوام من Windows. اضغط تسجيل الدخول للمتابعة.')
        elif not saved:
            self.credential_note.setText('تُحفظ عند الضغط على تسجيل الدخول، محلياً في مدير بيانات اعتماد Windows لهذا المستخدم.')

    def login_username_edited(self,*_):
        self.password.clear();self.show_password.setChecked(False)

    def remember_changed(self,checked):
        if not checked and self.school_shift in SHIFT_DOMAINS:
            self.forget_saved_login()

    def forget_saved_login(self):
        if self.school_shift not in SHIFT_DOMAINS:return
        try:self.credential_store.delete(self.school_shift)
        except CredentialError as exc:
            self.credential_note.setText(str(exc))
            self.remember_login.blockSignals(True);self.remember_login.setChecked(True);self.remember_login.blockSignals(False)
            return
        self.remember_login.blockSignals(True);self.remember_login.setChecked(False);self.remember_login.blockSignals(False)
        self.password.clear();self.show_password.setChecked(False)
        self._saved_available=False
        self.forget_login_button.setEnabled(False)
        self.credential_note.setText('حُذفت بيانات الدخول المحفوظة لهذا الدوام. لن تُحفظ المحاولات التالية إلا إذا فعّلت التذكّر.')

    def set_login_busy(self, busy):
        self.login_button.setEnabled(not busy)
        self.cancel_login_button.setEnabled(busy)
        self.username.setReadOnly(busy)
        self.password.setReadOnly(busy)
        self.show_password.setEnabled(not busy)
        self.remember_login.setEnabled(not busy and self.credential_store.available)
        self.forget_login_button.setEnabled(not busy and self._saved_available)
        self.browser.setEnabled(not busy)
        self.login_back_button.setEnabled(not busy)

    def start_login(self):
        if self.login_controller.running():
            self.status.setText('نافذة الدخول ما زالت مفتوحة. أغلقها أو ألغِ الجلسة أولاً.')
            return
        try:
            username, password, browser = validate_credentials(self.username.text(), self.password.text(), self.browser.currentData(), self.school_shift)
        except LoginInputError as exc:
            self.status.setText(str(exc))
            return
        if self.remember_login.isChecked() and self.credential_store.available:
            try:
                self.credential_store.save(self.school_shift,username,password)
                self._saved_available=True
                self.credential_note.setText('حُفظت بيانات الدخول محلياً في Windows لهذا الدوام. يمكنك حذفها من «نسيان المحفوظ».')
            except CredentialError as exc:self.credential_note.setText(str(exc))
        self.returning_to_school = False
        self.connected = False
        self.set_login_busy(True)
        self.status.setText('جارٍ فتح نافذة الدخول…')
        self.login_controller.start(username, password, browser, self.school_shift)
        self.password.clear()
        self.show_password.setChecked(False)

    def on_login_event(self, event):
        if self._closing:
            return
        messages = {
            'opening': 'جارٍ فتح SIMS…',
            'microsoft_opening': 'جارٍ الانتقال إلى Microsoft…',
            'portal_retry': 'صفحة الدخول لم تستجب بعد. جارٍ إعادة المحاولة تلقائياً؛ قد تُحدّث الصفحة مرة واحدة…',
            'portal_manual_required': 'لم ينتقل الموقع إلى Microsoft. اضغط «تسجيل الدخول باستخدام Microsoft» يدوياً في نافذة المتصفح المفتوحة؛ البرنامج سيكمل بعدها.',
            'email_submitted': 'تم إدخال الإيميل. جارٍ انتظار خانة كلمة السر…',
            'password_submitted': 'جارٍ إتمام الدخول. أكمل أي تحقّق إضافي في نافذة المتصفح.',
            'manual_required': 'كمّل الخطوة الظاهرة في المتصفح: قد تكون تحقّقاً إضافياً أو اختيار حساب أو مراجعة بيانات الدخول.',
            'verify_account': 'وصل المتصفح إلى النظام. جارٍ التحقّق من الحساب والقائمة الظاهرة…',
            'invalid_input': 'بيانات الدخول غير صالحة. راجع الإيميل وكلمة السر.',
            'dependency_missing': 'مكتبة تشغيل المتصفح ناقصة. شغّل START_WINDOWS.bat لتثبيتها.',
            'browser_missing': 'تعذّر تشغيل المتصفح المختار. تأكّد من تثبيت Edge أو Chrome، أو اختر Firefox أو Chromium المرفقين بحزمة EXE. في نسخة المصدر شغّل INSTALL_BROWSERS.bat لتنزيلهما.',
            'timeout': 'انتهت مهلة الدخول. أعد المحاولة عندما تكون جاهزاً لإتمام التحقّق.',
            'failed': 'تعذّر تشغيل جلسة الدخول. راجع تثبيت المكتبات والمتصفح ثم أعد المحاولة.',
            'cancelled': 'تم إلغاء الجلسة.',
            'browser_closed': 'أُغلقت نافذة النظام. يمكنك تسجيل الدخول مجدداً.',
            'disconnected': 'انتهت جلسة النظام. سجّل الدخول مجدداً.',
        }
        if event == 'authenticated':
            self.connected = True
            self.menu_summary.setText(f'{self.school.text().strip()} — {self.shift_label.text()}')
            self.show_section('root')
            self.status.clear()
            self.pages.setCurrentWidget(self.menu_page)
        elif event in ('invalid_input', 'dependency_missing', 'browser_missing', 'timeout', 'failed', 'cancelled', 'browser_closed', 'disconnected'):
            self.connected = False
            self.set_login_busy(False)
            if not self.returning_to_school:
                self.restore_saved_login(replace_username=False)
                self.pages.setCurrentWidget(self.login_page)
                self.status.setText(messages[event])
        else:
            self.status.setText(messages.get(event, ''))

    def cancel_login(self):
        self.connected = False
        self.login_controller.cancel()
        self.password.clear()
        self.pages.setCurrentWidget(self.login_page)
        self.status.setText('جارٍ إنهاء جلسة المتصفح…')

    def return_to_school(self):
        self.returning_to_school = True
        self.connected = False
        self.login_controller.cancel()
        self.password.clear()
        self.show_password.setChecked(False)
        self.status.clear()
        self.pages.setCurrentWidget(self.school_page)

    def closeEvent(self, event):
        self._closing = True
        self.password.clear()
        self.login_controller.shutdown()
        super().closeEvent(event)

STYLE = '\nQWidget { font-family: "Segoe UI", "Noto Sans Arabic", sans-serif; font-size: 14px; color: #1a2a43; }\nQMainWindow { background: #eef3f8; }\nQFrame#panel { background: white; border: 1px solid #e0e8f0; border-radius: 22px; }\nQFrame#side { background: #12233e; border-radius: 22px; }\nQLabel#brand { font-size: 29px; font-weight: 700; color: white; }\nQLabel#smallBrand { font-size: 21px; font-weight: 700; }\nQLabel#tagline { color: #f3f7fc; font-size: 25px; font-weight: 600; }\nQLabel#sideStep { color: #d7e6f5; font-size: 15px; padding: 12px 0; border-bottom: 1px solid #2a3b56; }\nQLabel#sideNote { color: #a5bdd7; line-height: 1.5; font-size: 13px; }\nQLabel#title { font-size: 29px; font-weight: 700; }\nQLabel#subtitle { font-size: 17px; color: #63748b; }\nQLabel#verified { color: #16866b; font-size: 15px; }\nQLabel#eyebrow, QLabel#footer { color: #64778e; font-size: 12px; padding: 5px; }\nQLabel#fieldLabel { font-size: 14px; font-weight: 600; padding-bottom: 5px; }\nQLabel#domains { background: #f0f5fa; color: #24466c; border-radius: 12px; padding: 14px; font-size: 15px; }\nQLabel#hint { color: #718197; font-size: 12px; padding-top: 7px; }\nQLabel#status { color: #845b20; font-size: 13px; }\nQLineEdit, QComboBox { background: #f9fbfd; border: 1px solid #d7e1ec; border-radius: 10px; padding: 13px; min-height: 22px; }\nQLineEdit:focus, QComboBox:focus { border: 1px solid #36aa93; }\nQPushButton { color: white; background: #138d79; font-weight: 600; padding: 14px 18px; border-radius: 10px; border: none; min-height: 22px; }\nQPushButton:hover { background: #0f7b69; }\nQPushButton:disabled { background: #a4bcb8; }\nQPushButton#secondary { color: #496178; background: #f0f4f8; font-size: 13px; padding: 10px; }\nQPushButton#secondary:hover { background: #e3ebf3; }\n'

STYLE += '''
QLabel#welcomeIcon { font-size: 40px; min-width: 58px; }
QLabel#contactName { color: #f2f7fd; font-size: 18px; font-weight: 600; }
QLabel#contactPhone { color: #4edec0; font-size: 17px; font-weight: 600; }
QLabel#contactRole { color: #bed1e7; font-size: 13px; }
QLabel#welcomeBrand { color: #138d79; font-size: 38px; font-weight: 700; }
QLabel#selectedShift { color: #138d79; font-size: 17px; font-weight: 600; }
QLabel#privacyNotice { color: #52647b; font-size: 11px; padding-top: 7px; }
QPushButton#shiftOption { font-size: 19px; padding: 24px 18px; }
QPushButton#changeShift { background: #f0f4f8; color: #496178; font-size: 12px; padding: 5px 10px; min-height: 15px; }
QPushButton#menuOption { font-size: 19px; padding: 22px 18px; }
QPushButton#operationPending:disabled { background: #eff4f8; color: #64778e; font-size: 18px; padding: 24px 18px; border: 1px solid #d7e1ec; }
QCheckBox { padding: 4px; color: #64778e; font-size: 12px; }
'''

if __name__ == '__main__':
    if '--bundle-self-test' in sys.argv:
        from app_bundle_check import check_app
        check_app()
        raise SystemExit(0)
    app=QApplication(sys.argv)
    app.setFont(QFont('Segoe UI',10))
    window=Window()
    window.show()
    sys.exit(app.exec())
