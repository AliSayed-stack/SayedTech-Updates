@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if exist "helpers\SayedTechLogin\SayedTechLogin.exe" goto packaged
call "%~dp0SETUP_PYTHON_WINDOWS.bat"
if not "%errorlevel%"=="0" goto failure
if not defined SAYED_PYTHON goto failure
"%SAYED_PYTHON%" -m pip install --only-binary=sqlce -r requirements.txt
if not "%errorlevel%"=="0" goto failure
"%SAYED_PYTHON%" -m playwright install firefox
if not "%errorlevel%"=="0" goto failure
goto success
:packaged
"helpers\SayedTechLogin\SayedTechLogin.exe" --install-firefox
if not "%errorlevel%"=="0" goto failure
:success
echo Firefox for Sayed tech is ready.
pause
exit /b 0
:failure
echo Could not install the browser. Review the error above.
pause
exit /b 1
