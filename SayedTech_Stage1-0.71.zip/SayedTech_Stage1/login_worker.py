"""User-run browser helper; input is ephemeral JSON over stdin, not CLI args."""
import json
import os
import sys
import threading
import time
import queue
import re

from login_flow import LoginFlow, validate_credentials
from bundle_check import configure_browser
configure_browser()


def emit(event, request_id='', field=''):
    # Fixed event names only: never serialize pages, URLs, input, or exceptions.
    result = {'event': event}
    if request_id: result['request_id'] = request_id
    if field: result['field'] = field
    print(json.dumps(result), flush=True)


def emit_catalog(event, request_id, first=0, second=0, detail=None):
    # Only lookup labels, fixed statuses and counts cross back into the UI.
    from address_catalog import clean_detail
    print(json.dumps({'event': event, 'request_id': request_id,
                      'first': first, 'second': second, 'detail': clean_detail(detail)}), flush=True)


def emit_scan(event, request_id, first=0, second=0, detail=None):
    from student_scan import clean_detail
    print(json.dumps({'event':event,'request_id':request_id,'first':first,'second':second,
                      'detail':clean_detail(detail)}),flush=True)


def run():
    if sys.stdin is None or sys.stdout is None:
        return 2
    os.environ.pop('DEBUG', None)
    os.environ.pop('PWDEBUG', None)
    try:
        raw = sys.stdin.readline(16385)
        if len(raw) > 16384:
            raise ValueError('input limit')
        payload = json.loads(raw)
        username, password, browser_name = validate_credentials(
            payload.get('username'), payload.get('password'), payload.get('browser'), payload.get('shift'))
        payload.clear()
        del payload, raw
    except Exception:
        emit('invalid_input')
        return 2
    cancelled = threading.Event()
    pending_students = queue.Queue(maxsize=1)
    catalog_cancelled = threading.Event()
    catalog_request_id = ''
    scan_cancelled = threading.Event()
    scan_request_id = ''
    operation_lock = threading.Lock()
    from student_duplicate import DuplicateGuard
    registration_guard = DuplicateGuard()

    def commands():
        nonlocal catalog_request_id, scan_request_id
        while True:
            line = sys.stdin.readline(32769)
            if not line: break
            if len(line) > 32768:
                catalog_cancelled.set()
                scan_cancelled.set()
                cancelled.set()
                return
            if line.strip() == 'cancel':
                catalog_cancelled.set()
                scan_cancelled.set()
                cancelled.set()
                return
            try:
                command = json.loads(line)
                request_id = command.get('request_id','')
                if not isinstance(request_id, str) or not re.fullmatch(r'[a-f0-9]{32}',request_id):
                    continue
                action = command.get('action')
                if action == 'cancel_catalog' and request_id == catalog_request_id:
                    catalog_cancelled.set()
                elif action == 'cancel_scan' and request_id == scan_request_id:
                    scan_cancelled.set()
                elif action == 'scan_students':
                    path,limit=command.get('path'),command.get('limit')
                    if not isinstance(path,str) or len(path)>4096 or type(limit) is not int or limit not in (0,10):
                        emit_scan('scan_prepare',request_id);continue
                    if not operation_lock.acquire(blocking=False):
                        emit_scan('scan_busy',request_id);continue
                    scan_cancelled.clear();scan_request_id=request_id
                    try:pending_students.put_nowait(command)
                    except queue.Full:
                        scan_request_id='';operation_lock.release();emit_scan('scan_busy',request_id)
                elif action == 'collect_catalog':
                    path = command.get('path')
                    if not isinstance(path, str) or len(path) > 4096:
                        emit_catalog('catalog_failed', request_id)
                        continue
                    if not operation_lock.acquire(blocking=False):
                        emit_catalog('catalog_busy', request_id)
                        continue
                    catalog_cancelled.clear()
                    catalog_request_id = request_id
                    try: pending_students.put_nowait(command)
                    except queue.Full:
                        catalog_request_id = ''
                        operation_lock.release()
                        emit_catalog('catalog_busy', request_id)
                elif action in ('fill_student','fill_details','check_student'):
                    if action!='check_student' and type(command.get('save',False)) is not bool:
                        emit('student_invalid',request_id);continue
                    if action in ('fill_student','check_student') and not (command.get('batch_id') is None or
                        (isinstance(command.get('batch_id'),str) and
                         re.fullmatch(r'[a-f0-9]{32}',command['batch_id']))):
                        emit('student_invalid',request_id);continue
                    if not operation_lock.acquire(blocking=False):
                        emit('student_busy',request_id);continue
                    try: pending_students.put_nowait(command)
                    except queue.Full:
                        operation_lock.release();emit('student_busy',request_id)
            except (ValueError, AttributeError, TypeError):
                pass
        catalog_cancelled.set()
        scan_cancelled.set()
        cancelled.set()

    threading.Thread(target=commands, daemon=True).start()
    flow = LoginFlow(username, password, emit)
    del password
    try:
        from playwright.sync_api import sync_playwright, Error as PlaywrightError
    except ImportError:
        flow.clear_secret()
        emit('dependency_missing')
        return 2
    try:
        with sync_playwright() as playwright:
            try:
                from browser_launch import launch_browser
                browser = launch_browser(playwright, browser_name)
            except Exception:
                emit('browser_missing')
                return 2
            try:
                # Let the page follow the real window instead of emulating a
                # fixed 1280x720 viewport inside a larger desktop window.
                context = browser.new_context(accept_downloads=False, no_viewport=True)
                page = context.new_page()
                emit('opening')
                try:
                    page.goto('https://new-sims.mehe.gov.lb/login', wait_until='domcontentloaded', timeout=45000)
                except Exception:
                    # The visible page may still be usable after a navigation timeout.
                    emit('manual_required')
                deadline = time.monotonic() + 600
                while not cancelled.is_set() and browser.is_connected():
                    pages = [p for p in context.pages if not p.is_closed()]
                    if not pages:
                        break
                    if not flow.connected and time.monotonic() > deadline:
                        emit('timeout')
                        return 2
                    try:
                        flow.tick(pages)
                        try: command = pending_students.get_nowait()
                        except queue.Empty: command = None
                        if command is not None:
                            if command.get('action') == 'scan_students':
                                from student_checkpoint import run_student_scan
                                from login_flow import exact_https_host,SIMS_HOST
                                request_id=command['request_id']
                                try:
                                    candidates=[p for p in pages if exact_https_host(p.url,SIMS_HOST)]
                                    if not flow.connected or len(candidates)!=1:
                                        emit_scan('scan_account_required',request_id)
                                    else:
                                        event,first,second,detail=run_student_scan(candidates[0],username,scan_cancelled,
                                            command['path'],command['limit'],
                                            lambda first,second,detail:emit_scan('scan_progress',request_id,first,second,detail),
                                            account_session=flow.account_session)
                                        emit_scan(event,request_id,first,second,detail)
                                except Exception:emit_scan('scan_failed',request_id)
                                finally:
                                    command.clear();scan_request_id='';operation_lock.release()
                                continue
                            if command.get('action') == 'collect_catalog':
                                from address_catalog import collect_catalog, save_catalog, CatalogError
                                from login_flow import exact_https_host, SIMS_HOST
                                request_id = command['request_id']
                                try:
                                    candidates = [p for p in pages if exact_https_host(p.url, SIMS_HOST)]
                                    if not flow.connected or len(candidates) != 1:
                                        raise CatalogError('catalog_account_required')
                                    data = collect_catalog(candidates[0], username, catalog_cancelled,
                                        lambda first, second, detail: emit_catalog('catalog_progress', request_id, first, second, detail),
                                        lambda: emit_catalog('catalog_restoring', request_id))
                                    save_catalog(data, command.get('path', ''), catalog_cancelled)
                                    districts = [d for g in data['governorates'] for d in g['districts']]
                                    completed = [d for d in districts if d['status'] == 'complete']
                                    emit_catalog('catalog_saved' if data['complete'] else 'catalog_saved_partial', request_id,
                                        len(completed), sum(len(d['areas']) for d in completed), {'pending': len(data['pending'])})
                                except CatalogError as exc:
                                    emit_catalog(exc.code, request_id, detail=exc.detail)
                                except Exception:
                                    emit_catalog('catalog_failed', request_id)
                                finally:
                                    catalog_request_id = ''
                                    command.clear()
                                    operation_lock.release()
                                continue
                            if command.get('action') == 'fill_details':
                                from detailed_import import fill_details, DetailError
                                from login_flow import exact_https_host, SIMS_HOST
                                request_id=command['request_id']
                                try:
                                    candidates=[p for p in pages if exact_https_host(p.url,SIMS_HOST)]
                                    if not flow.connected or len(candidates)!=1:raise DetailError('detail_account')
                                    event=fill_details(candidates[0],command.get('record',{}),command.get('section'),username,cancelled,account_session=flow.account_session)
                                    emit(event,request_id)
                                except DetailError as exc:emit(exc.code,request_id)
                                except Exception:emit('detail_failed',request_id)
                                finally:
                                    command.clear();operation_lock.release()
                                continue
                            from student_fill import fill_student, StudentFillError
                            from login_flow import exact_https_host, SIMS_HOST
                            request_id = command['request_id']
                            result_event,result_field='student_failed',''
                            try:
                                candidates = [p for p in pages if exact_https_host(p.url,SIMS_HOST)]
                                if not flow.connected or len(candidates) != 1:
                                    raise StudentFillError('student_account_required')
                                if command.get('action')=='check_student':
                                    verdict=registration_guard.check(candidates[0],command.get('record',{}),username,
                                        cancelled,command.get('batch_id'),flow.account_session)
                                    result_event='student_already_registered' if verdict=='registered' else 'student_preflight_clear'
                                elif command.get('save',False):
                                    from student_save import fill_and_save_student
                                    event=fill_and_save_student(candidates[0],command.get('record',{}),username,cancelled,
                                        account_session=flow.account_session,duplicate_guard=registration_guard,
                                        batch_id=command.get('batch_id'),entry_kind=command.get('entry_kind','طالب موجود'))
                                    result_event=event
                                else:
                                    verdict=registration_guard.check(candidates[0],command.get('record',{}),username,
                                        cancelled,command.get('batch_id'),flow.account_session)
                                    if verdict=='registered':result_event='student_already_registered'
                                    else:
                                        fill_student(candidates[0], command.get('record',{}), username, cancelled,
                                            account_session=flow.account_session,entry_kind=command.get('entry_kind','طالب موجود'))
                                        result_event='student_draft_filled'
                            except StudentFillError as exc:
                                result_event,result_field=exc.code,exc.field
                            except Exception:
                                result_event='student_failed'
                            finally:
                                command.clear()
                                operation_lock.release()
                            # The UI may enqueue the next student immediately.
                            # Publish completion only after releasing the lock.
                            emit(result_event,request_id,result_field)
                        if flow.connected and any(
                            p.url.startswith('https://new-sims.mehe.gov.lb/login') for p in pages
                        ) and not any('/dashboard/' in p.url for p in pages):
                            emit('disconnected')
                            return 0
                    except Exception:
                        # No automatic credential resubmission after failures.
                        flow.notice('manual_required')
                    try:
                        pages[-1].wait_for_timeout(350)
                    except PlaywrightError:
                        pass
                emit('cancelled' if cancelled.is_set() else 'browser_closed')
            finally:
                flow.clear_secret()
                try:
                    browser.close()
                except Exception:
                    pass
    except Exception:
        emit('failed')
        return 2
    finally:
        flow.clear_secret()
    return 0


if __name__ == '__main__':
    if '--bundle-self-test' in sys.argv:
        from bundle_check import check_browser
        check_browser()
    elif '--install-firefox' in sys.argv or '--install-browsers' in sys.argv:
        from playwright.__main__ import main
        sys.argv = ['playwright', 'install', 'firefox', 'chromium'] if '--install-browsers' in sys.argv else ['playwright', 'install', 'firefox']
        main()
    else:
        raise SystemExit(run())
