"""Offline smoke checks for the Windows distribution, never accessing school data."""
from pathlib import Path
import os
import sys


def configure_browser():
    if getattr(sys, 'frozen', False):
        # Use only the browser shipped with this helper, not the build user's cache.
        os.environ['PLAYWRIGHT_BROWSERS_PATH'] = '0'


def check_browser():
    configure_browser()
    from playwright.sync_api import sync_playwright
    from browser_launch import launch_browser
    with sync_playwright() as playwright:
        for name in ('firefox','chromium'):
            if not Path(getattr(playwright,name).executable_path).is_file():
                raise RuntimeError('Bundled browser is missing: '+name)
            browser = launch_browser(playwright, name, headless=True)
            try:
                page = browser.new_page()
                page.set_content('<title>SayedTech offline check</title>')
                if page.title() != 'SayedTech offline check': raise RuntimeError('Browser check failed')
            finally: browser.close()

