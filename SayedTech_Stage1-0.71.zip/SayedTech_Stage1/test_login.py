"""Offline login-state tests; no real site, account, or credential is accessed."""
import re
import unittest
from login_flow import LoginFlow, LoginInputError, validate_credentials, exact_https_host


class Element:
    def __init__(self, page, kind, present):
        self.page, self.kind, self.present = page, kind, present
    def all(self):
        return [self] if self.present else []
    def is_visible(self):
        return self.present
    def is_enabled(self):
        return not getattr(self.page, 'disabled', False)
    def fill(self, value, **_kwargs):
        self.page.actions.append(('fill', self.kind, value))
    def click(self, **_kwargs):
        if getattr(self.page, 'click_failures', 0):
            self.page.click_failures -= 1
            raise RuntimeError('temporarily covered button')
        self.page.actions.append(('click', self.kind))


class Page:
    def __init__(self, url, stage, account='person@te.mehe.school'):
        self.url, self.stage, self.account = url, stage, account
        self.actions = []
    def bring_to_front(self):
        self.focused = True
    def reload(self, **kwargs):
        self.reloads = getattr(self, 'reloads', 0) + 1
    def is_closed(self):
        return False
    def get_by_placeholder(self, name, **_kwargs):
        return Element(self, 'email', self.stage == 'email' and name == 'Email or phone')
    def locator(self, selector):
        return Element(self, 'password' if 'password' in selector else 'email',
            (self.stage == 'password' and 'password' in selector) or
            (self.stage == 'email' and 'email' in selector))
    def get_by_role(self, role, name):
        text = {'email': 'Next', 'password': 'Sign in',
                'portal': getattr(self, 'button_name', 'تسجيل الدخول باستخدام Microsoft')}.get(self.stage, '')
        expected_role = getattr(self, 'portal_role', 'button') if self.stage == 'portal' else 'button'
        return Element(self, text, bool(role == expected_role and text and name.search(text)))
    def get_by_text(self, text, **_kwargs):
        if self.stage == 'portal':
            value = 'تسجيل الدخول باستخدام Microsoft'
        elif self.stage == 'dashboard':
            value = 'الطلاب' if isinstance(text, str) else self.account
        else:
            value = ''
        matched = bool(text.search(value)) if hasattr(text, 'search') else bool(value and text == value)
        return Element(self, value, matched)


class LoginTests(unittest.TestCase):
    def setUp(self):
        self.events = []
        self.clock = [0]
        self.flow = LoginFlow('person@te.mehe.school', 'TEST_ONLY_PASSWORD', self.events.append, lambda: self.clock[0])

    def test_normal_sequence_and_secret_release(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        email = Page('https://login.microsoftonline.com/common/oauth2/v2.0/authorize', 'email')
        self.flow.tick([email]); self.flow.tick([email])
        self.assertEqual(len(email.actions), 2)  # One fill, one click; no retry loop.
        password = Page('https://login.microsoftonline.com/common/login', 'password')
        self.flow.tick([password]); self.flow.tick([password])
        self.assertEqual(len(password.actions), 2)
        self.assertIsNone(self.flow._password)
        dashboard = Page('https://new-sims.mehe.gov.lb/dashboard/analytics', 'dashboard')
        self.flow.tick([dashboard])
        self.assertTrue(self.flow.connected)
        self.assertEqual(self.events[-1], 'authenticated')
        self.assertNotIn('TEST_ONLY_PASSWORD', str(self.events))

    def test_wrong_or_non_https_hosts_never_receive_credentials(self):
        for url in ('http://login.microsoftonline.com/login',
                    'https://login.microsoftonline.com.evil.test/login',
                    'https://login.microsoftonline.com@evil.test/login',
                    'https://login.microsoftonline.com:444/login',
                    'https://other-idp.test/login'):
            for stage in ('email', 'password'):
                page = Page(url, stage)
                self.flow.tick([page])
                self.assertEqual(page.actions, [], url)

    def test_mfa_waits_for_user_and_does_not_repeat_credentials(self):
        self.flow.tick([Page('https://login.microsoftonline.com/login', 'password')])
        page = Page('https://login.microsoftonline.com/mfa', 'mfa')
        self.clock[0] = 10
        self.flow.tick([page]); self.flow.tick([page])
        self.assertFalse(self.flow.connected)
        self.assertEqual(page.actions, [])
        self.assertEqual(self.events.count('manual_required'), 1)

    def test_dashboard_alone_or_wrong_account_is_not_success(self):
        for stage, account in [('dashboard', 'someoneelse@te.mehe.school'), ('empty', 'person@te.mehe.school')]:
            self.flow.tick([Page('https://new-sims.mehe.gov.lb/dashboard/analytics', stage, account)])
            self.assertFalse(self.flow.connected)
        self.flow.tick([Page('https://new-sims.mehe.gov.lb.evil.test/dashboard/analytics', 'dashboard')])
        self.assertFalse(self.flow.connected)

    def test_popup_login_and_domain_validation(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'empty')
        popup = Page('https://login.microsoftonline.com/login', 'email')
        self.flow.tick([portal, popup])
        self.assertEqual(len(popup.actions), 2)
        self.assertEqual(validate_credentials('Person@te.pm.mehe.school', ' x ', 'edge', 'afternoon'), ('person@te.pm.mehe.school', ' x ', 'edge'))
        for email in ('p@gmail.com', 'p@evilte.mehe.school', 'p@te.mehe.school.evil', '@te.mehe.school'):
            with self.assertRaises(LoginInputError):
                validate_credentials(email, 'x', 'edge', 'morning')

    def test_email_must_match_selected_shift(self):
        for shift, allowed, forbidden in (
            ('morning', 'te.mehe.school', 'te.pm.mehe.school'),
            ('afternoon', 'te.pm.mehe.school', 'te.mehe.school'),
        ):
            for browser in ('edge', 'chrome', 'firefox'):
                with self.subTest(shift=shift, browser=browser):
                    result = validate_credentials(f' Person@{allowed.upper()} ', ' x ', browser, shift)
                    self.assertEqual(result, (f'person@{allowed}', ' x ', browser))
                    for domain in (forbidden, f'sub.{allowed}', f'{allowed}.evil', f'evil{allowed}'):
                        with self.assertRaises(LoginInputError):
                            validate_credentials(f'person@{domain}', 'x', browser, shift)
        for shift in (None, '', 'unknown', [], {}):
            with self.assertRaises(LoginInputError):
                validate_credentials('person@te.mehe.school', 'x', 'edge', shift)

    def test_portal_button_with_bidi_caption_and_bounded_hydration_retries(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        portal.button_name = 'تسجيل الدخول باستخدام\u200f \u2066Microsoft\u2069'
        # Initial click may arrive before the site's JS handlers are ready.
        self.flow.tick([portal])
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        for seconds in (8, 16, 24, 32, 40, 48, 56, 100):
            self.clock[0] = seconds
            self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 6)
        self.assertEqual(portal.reloads, 1)
        self.assertEqual(self.events[-1], 'portal_manual_required')
        self.assertFalse(self.flow.email_attempted)
        self.assertFalse(self.flow.password_attempted)

    def test_portal_failed_click_recovers_and_popup_stops_portal_retries(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        portal.click_failures = 1
        self.flow.tick([portal])
        self.assertEqual(self.events[-1], 'portal_retry')
        self.assertFalse(self.flow.portal_clicked)
        self.clock[0] = 8
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        popup = Page('https://login.microsoftonline.com/login', 'email')
        self.clock[0] = 10
        self.flow.tick([portal,popup])
        self.clock[0] = 20
        self.flow.tick([portal,popup])
        self.assertEqual(len(portal.actions), 1)
        self.assertEqual(len(popup.actions), 2)  # No repeat email submissions.

    def test_localized_link_login_and_no_retry_after_credential_submission(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        portal.portal_role = 'link'
        portal.button_name = 'تسجيل الدخول باستخدام مايكروسوفت'
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        self.flow.email_attempted = True
        self.clock[0] = 100
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        self.assertEqual(getattr(portal, 'reloads', 0), 0)
        self.assertEqual(self.events[-1], 'manual_required')

    def test_slow_portal_can_recover_after_reload(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        for seconds in (0, 8, 16, 24):
            self.clock[0] = seconds; self.flow.tick([portal])
        self.assertEqual(portal.reloads, 1)
        popup = Page('https://login.microsoftonline.com/common/login', 'email')
        self.clock[0] = 32; self.flow.tick([portal, popup])
        self.clock[0] = 100; self.flow.tick([portal, popup])
        self.assertEqual(portal.reloads, 1)
        self.assertEqual(len(portal.actions), 3)
        self.assertEqual(len(popup.actions), 2)

    def test_disabled_portal_button_is_waited_for_and_unrelated_page_ignored(self):
        portal = Page('https://new-sims.mehe.gov.lb/login', 'portal')
        portal.disabled = True
        self.flow.tick([portal])
        self.assertEqual(self.flow.portal_attempts, 0)
        portal.disabled = False
        self.flow.tick([portal])
        self.assertEqual(len(portal.actions), 1)
        self.clock[0] = 10
        other = Page('https://new-sims.mehe.gov.lb/unrelated', 'portal')
        self.flow.tick([other])
        self.assertEqual(other.actions, [])


if __name__ == '__main__':
    unittest.main()
