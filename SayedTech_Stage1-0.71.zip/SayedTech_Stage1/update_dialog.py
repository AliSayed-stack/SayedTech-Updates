"""Manual update screen, available without signing into SIMS."""
import os
from pathlib import Path
import sys

from PySide6.QtCore import QObject, QThread, Signal, Slot, Qt
from PySide6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QApplication, QMessageBox

import core
import online_update


class UpdateTask(QObject):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, operation, argument):
        super().__init__()
        self.operation, self.argument = operation, argument

    @Slot()
    def run(self):
        try:
            if self.operation == 'check':
                result = online_update.check_release(self.argument, core.APP_VERSION, getattr(sys, 'frozen', False))
            else:
                result = online_update.download_release(self.argument)
            self.done.emit(result)
        except online_update.UpdateError as exc:
            self.failed.emit(str(exc))
        except Exception:
            self.failed.emit('تعذّر الاتصال بخادم التحديثات. حاول لاحقاً.')


class UpdateDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle('Sayed tech | تحديث البرنامج')
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(610, 270)
        self.release = None
        self.stage = None
        self.thread = None
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f'النسخة الحالية: {core.APP_VERSION}'))
        description = QLabel('يفحص البرنامج آخر إصدار من GitHub ويتحقق من بصمة الملف قبل تنزيله. بعد إنهاء جلسة SIMS يمكنك تثبيت التحديث من هذه النافذة.')
        description.setWordWrap(True)
        layout.addWidget(description)
        try: saved_url = online_update.source_url()
        except online_update.UpdateError: saved_url = ''
        self.url = QLineEdit(saved_url)
        self.url.setLayoutDirection(Qt.LeftToRight)
        self.url.setPlaceholderText('https://example.com/sayedtech/latest.json')
        layout.addWidget(self.url)
        self.status = QLabel('')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.check_button = QPushButton('فحص التحديثات')
        self.check_button.clicked.connect(self.check)
        actions.addWidget(self.check_button)
        self.download_button = QPushButton('تنزيل التحديث')
        self.download_button.setEnabled(False)
        self.download_button.clicked.connect(self.download)
        actions.addWidget(self.download_button)
        self.install_button = QPushButton('تثبيت التحديث')
        self.install_button.setEnabled(False)
        self.install_button.clicked.connect(self.install)
        actions.addWidget(self.install_button)
        layout.addLayout(actions)

    def set_busy(self, busy):
        self.check_button.setEnabled(not busy)
        self.download_button.setEnabled(not busy and self.release is not None and self.stage is None)
        self.install_button.setEnabled(not busy and self.stage is not None)
        self.url.setReadOnly(busy)

    def start_task(self, operation, argument):
        if self.thread is not None and self.thread.isRunning():return
        self.set_busy(True)
        self.thread = QThread(self)
        self.worker = UpdateTask(operation, argument)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.done.connect(lambda result:self.completed(operation, result))
        self.worker.failed.connect(self.failed)
        self.worker.done.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.task_finished)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def task_finished(self):
        self.set_busy(False)
        self.thread = None

    def check(self):
        try:
            url = online_update.https_url(self.url.text())
            online_update.save_source_url(url)
        except (online_update.UpdateError, OSError) as exc:
            self.status.setText(str(exc))
            return
        self.release = None
        self.stage = None
        self.status.setText('جارٍ فحص النسخة المنشورة…')
        self.start_task('check', url)

    def download(self):
        if not self.release:return
        self.status.setText('جارٍ تنزيل التحديث والتحقق منه…')
        self.start_task('download', self.release)

    def completed(self, operation, result):
        if operation == 'check':
            self.release = result
            self.status.setText('برنامجك محدّث.' if result is None else f'تتوفر نسخة {result["version"]}. اضغط تنزيل التحديث.')
        else:
            self.stage = result
            self.status.setText('اكتمل التنزيل والتحقق. اضغط تثبيت التحديث عند انتهاء عملك على النظام.')

    def failed(self, message):
        self.status.setText(message)

    def install(self):
        if self.stage is None or self.release is None:return
        parent = self.parent()
        if parent.login_controller.running():
            self.status.setText('أنهِ جلسة SIMS وأغلق المتصفح من البرنامج، ثم اضغط تثبيت التحديث.')
            return
        try:
            target = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
            online_update.begin_install(self.stage, self.release['kind'], target, os.getpid())
        except (OSError, online_update.UpdateError) as exc:
            QMessageBox.warning(self, 'تعذّر التحديث', str(exc))
            return
        self.accept()
        parent.close()
        QApplication.instance().quit()

    def reject(self):
        if self.thread is not None and self.thread.isRunning():
            self.status.setText('انتظر انتهاء التنزيل أو الفحص قبل إغلاق النافذة.')
            return
        super().reject()
