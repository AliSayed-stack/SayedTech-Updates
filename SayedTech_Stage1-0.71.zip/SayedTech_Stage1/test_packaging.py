"""Release publishing must fail closed; offline launches cannot use Python PATH."""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import build_windows
import bundle_check
from browser_launch import launch_browser, BROWSERS
from unittest.mock import Mock


class PackagingTests(unittest.TestCase):
    def test_browser_choice_is_honored_on_both_shifts(self):
        from login_flow import validate_credentials
        for shift,domain in (('morning','te.mehe.school'),('afternoon','te.pm.mehe.school')):
            for name in BROWSERS:
                self.assertEqual(validate_credentials('test@'+domain,'test',name,shift)[2],name)
                api=Mock();launch_browser(api,name)
                if name=='firefox':
                    api.firefox.launch.assert_called_once_with(headless=False)
                    api.chromium.launch.assert_not_called()
                else:
                    kwargs=api.chromium.launch.call_args.kwargs
                    self.assertEqual(kwargs.get('channel'),{'edge':'msedge','chrome':'chrome'}.get(name))
                    api.firefox.launch.assert_not_called()

    def test_browser_uses_bundled_path_only_when_frozen(self):
        with patch.dict(os.environ, {'PLAYWRIGHT_BROWSERS_PATH':'external'}), patch.object(bundle_check.sys,'frozen',True,create=True):
            bundle_check.configure_browser()
            self.assertEqual(os.environ['PLAYWRIGHT_BROWSERS_PATH'],'0')

    def test_clean_environment_removes_development_runtime(self):
        with patch.dict(os.environ,{'PYTHONPATH':'dev','PYTHONHOME':'dev','VIRTUAL_ENV':'dev',
                                 'QT_PLUGIN_PATH':'dev','PLAYWRIGHT_BROWSERS_PATH':'cache','PATH':'python-dir'}):
            env=build_windows.clean_environment()
            for key in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','QT_PLUGIN_PATH','PLAYWRIGHT_BROWSERS_PATH'):
                self.assertNotIn(key,env)
            self.assertNotIn('python-dir',env['PATH'])

    def build(self, folder, fail=False,fail_compile=False):
        root=Path(folder)
        (root/'assets').mkdir()
        legacy=root/'assets'/'legacy';legacy.mkdir()
        for name in ('MEHENSL.exe','MDBL.dll'):(legacy/name).write_bytes(b'bundled-test-fixture')
        for name in ('README_PORTABLE_AR.txt','VERIFY_PORTABLE_WINDOWS.bat'):(root/name).write_text('test')
        (root/'installer.iss').write_text('Source: "@PACKAGE_DIR@"\nOutputDir=@OUTPUT_DIR@\nAppVersion=@APP_VERSION@')
        (root/'dist').mkdir()
        output=root/'dist'/build_windows.INSTALLER_NAME;output.write_bytes(b'previous-success')
        checks=[]
        def run(args,**kwargs):
            if '-m' in args and 'PyInstaller' in args:
                asset_arg=Path(args[args.index('--add-data')+1].split(';',1)[0])
                self.assertTrue((asset_arg/'legacy'/'MEHENSL.exe').exists())
                self.assertTrue((asset_arg/'legacy'/'MDBL.dll').exists())
                name=args[args.index('--name')+1]
                target=Path(args[args.index('--distpath')+1])/name
                target.mkdir(parents=True)
                (target/(name+'.exe')).write_bytes(b'synthetic-test-only')
            if '--bundle-self-test' in args:
                checks.append(args[0])
                self.assertNotIn('PYTHONPATH',kwargs['env'])
                if fail:raise subprocess.CalledProcessError(1,args)
            if args[0]=='synthetic-iscc':
                script=Path(args[1]).read_text()
                self.assertIn('AppVersion=',script)
                self.assertNotIn('@PACKAGE_DIR@',script)
                if fail_compile:raise subprocess.CalledProcessError(1,args)
                (Path(args[1]).parent/'installer'/build_windows.INSTALLER_NAME).write_bytes(b'MZsynthetic-test-only')
        cwd=Path.cwd()
        try:
            with patch.object(build_windows,'ROOT',root), patch.object(build_windows.sys,'platform','win32'), \
                 patch.object(build_windows.sysconfig,'get_platform',return_value='win-amd64'), \
                 patch.object(build_windows,'ensure'), patch.object(build_windows,'find_inno_compiler',return_value='synthetic-iscc'), \
                 patch.object(build_windows.subprocess,'run',side_effect=run):
                if fail or fail_compile:
                    with self.assertRaises(subprocess.CalledProcessError):build_windows.main()
                    self.assertEqual(output.read_bytes(),b'previous-success')
                else:
                    build_windows.main()
                    self.assertEqual(len(checks),2)
                    self.assertEqual(output.read_bytes(),b'MZsynthetic-test-only')
        finally:os.chdir(cwd)

    def test_publishes_whole_folder_only_after_two_offline_checks(self):
        with tempfile.TemporaryDirectory() as d:self.build(d)

    def test_failed_check_keeps_previous_release(self):
        with tempfile.TemporaryDirectory() as d:self.build(d,fail=True)

    def test_failed_installer_compilation_keeps_previous_release(self):
        with tempfile.TemporaryDirectory() as d:self.build(d,fail_compile=True)

    def test_installer_contains_whole_frozen_tree_and_user_shortcut(self):
        script=(Path(__file__).parent/'installer.iss').read_text()
        for item in ('recursesubdirs','createallsubdirs','{localappdata}',
                     'SayedTech.exe','{autoprograms}','ArchitecturesAllowed=x64os'):
            self.assertIn(item,script)


if __name__=='__main__':unittest.main()
