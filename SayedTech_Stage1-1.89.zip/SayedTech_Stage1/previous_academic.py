"""Excel data and live SIMS controls for the previous school year."""
import math
import re
import time

from student_excel import BY_ID, CURRENT_GRADE_FIELD, PREVIOUS_SCHOOL_TYPE_HEADER, PREVIOUS_SCHOOL_TYPES, is_third_kindergarten


SCHOOL = 'المدرسة السابقة'
SCHOOL_ECRD = 'رقم المدرسة السابقة (ECRD)'
SCHOOL_SEARCH = 'ابحث بالاسم أو رقم ECRD أو رقم الوزارة'
DIGITS = str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789')
ECRD_LABEL = r'(?:ECRD|رقم\s+المركز\s+التربوي)'
ECRD_PREFIX = ECRD_LABEL+r'\s*[:#：-]?\s*'
GRADE = 'الصف السابق'
LIST_NUMBER = 'رقم الطالب على لائحة السنة السابقة'
RESULT = 'نتيجة السنة الدراسية السابقة'
STATE = 'وضع الطالب'
GRADE_OPTIONS = dict(zip(
    [f'kg_{n}' for n in range(1,4)]+[f'grade_{n}' for n in range(1,10)]+[f'secondary_{n}' for n in range(1,4)],
    ['الروضة الأولى','الروضة الثانية','الروضة الثالثة']+
    [f'{ordinal} أساسي' for ordinal in ('الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع')]+
    [f'{ordinal} ثانوي' for ordinal in ('الأول','الثاني','الثالث')]))
FIELDS = {
    PREVIOUS_SCHOOL_TYPE_HEADER:('previousSchoolType',PREVIOUS_SCHOOL_TYPES),
    SCHOOL_ECRD:('previousSchoolId',None),
    GRADE:('previousGradeLevel',GRADE_OPTIONS),
    LIST_NUMBER:('previousListNumber',None),
    RESULT:('previousAcademicYearResult',{'passed':'ناجح','failed':'راسب'}),
    STATE:('studentState',{'repeater':'معيد','promoted':'مترفع','from_home':'من البيت','discontinued':'منقطع'}),
}
HEADERS = (PREVIOUS_SCHOOL_TYPE_HEADER,SCHOOL,GRADE,LIST_NUMBER,RESULT,STATE,SCHOOL_ECRD)
DROPDOWNS = {label:options for label,(_,options) in FIELDS.items() if options}
CURRENT_GRADE_LABEL = BY_ID[CURRENT_GRADE_FIELD]['label']


def from_excel(row):
    return {key:row[label] for label,(key,_) in FIELDS.items() if label in row}


def has_data(record):
    values=record.get('values',{})
    return any(values.get(key) not in ('',None) for key,_ in FIELDS.values())


def grade_code(value):
    if value in GRADE_OPTIONS:return value
    from student_scan import grade_rank,ScanError
    try:return tuple(GRADE_OPTIONS)[grade_rank(value)-1]
    except (ScanError,IndexError):return ''


def prior_number(value):
    if isinstance(value,bool) or value is None:return ''
    if isinstance(value,(int,float)):
        if not math.isfinite(value) or int(value)!=value:return ''
        value=str(int(value))
    if not isinstance(value,str):return ''
    value=value.strip()
    if not re.search(r'[1-9]',value.translate(DIGITS)):
        return ''
    return value


def workbook_defaults(row):
    from nsldb_reference import TARGET_YEAR, canonical_year
    from manual_sections import norm
    current=row.get(CURRENT_GRADE_LABEL,'')
    previous_year=canonical_year(row.get('السنة في القاعدة',''))==TARGET_YEAR
    sequence=prior_number(row.get('التسلسل الدراسي (SequenceNb)')) if previous_year else ''
    has_number=bool(prior_number(row.get(LIST_NUMBER)) or sequence)
    kind='new' if is_third_kindergarten(current) and not has_number else 'public_education'
    defaults={PREVIOUS_SCHOOL_TYPE_HEADER:PREVIOUS_SCHOOL_TYPES[kind]}
    if not previous_year:
        return defaults
    grade=grade_code(row.get('الصف الأصلي في القاعدة',''))
    result={'ناجح':'ناجح','نجاح':'ناجح','راسب':'راسب','رسوب':'راسب',
            'succ':'ناجح','usuc':'راسب'}.get(norm(row.get('النتيجة النهائية في القاعدة','')).casefold(),'')
    defaults.update({SCHOOL:row.get('اسم المدرسة في القاعدة',''), GRADE:GRADE_OPTIONS.get(grade,''),
                     LIST_NUMBER:sequence, RESULT:result})
    now=grade_code(current)
    if grade and now and result:
        grades=tuple(GRADE_OPTIONS)
        advance=grades.index(now)-grades.index(grade)
        if result=='ناجح' and advance==1:defaults[STATE]='مترفع'
        if result=='راسب' and advance==0:defaults[STATE]='معيد'
    return defaults


def should_apply_default(row,label):
    current=row.get(label)
    if label==PREVIOUS_SCHOOL_TYPE_HEADER and is_third_kindergarten(row.get(CURRENT_GRADE_LABEL,'')):
        return True
    return not prior_number(current) if label==LIST_NUMBER else current in ('',None)


def planned_values(record):
    from detailed_import import DetailError
    values=record.get('values',{})
    plan=[]
    for label,(key,options) in FIELDS.items():
        value=values.get(key)
        if value in ('',None):continue
        if (key in ('previousListNumber','previousSchoolId') and isinstance(value,(int,float)) and not isinstance(value,bool)
                and math.isfinite(value) and int(value)==value and value>=0):
            value=str(int(value))
        if not isinstance(value,str) or len(value)>256 or any(ord(c)<32 for c in value):
            raise DetailError('detail_input',label)
        value=value.strip()
        if not value:continue
        if key=='previousSchoolId':
            value=value.translate(DIGITS)
            if not re.fullmatch(r'[0-9]{1,20}',value) or not value.strip('0'):
                raise DetailError('detail_input',label)
        if options:
            value={caption:code for code,caption in options.items()}.get(value,value)
            if value not in options:raise DetailError('detail_input',label)
        plan.append((label,key,value,options))
    return plan


def matches_ecrd(control, wanted):
    for attribute in ('data-ecrd','data-ecrd-code','data-ecrd-number'):
        value=control.get_attribute(attribute)
        if value and value.strip().translate(DIGITS)==wanted:
            return True
    text='\n'.join((control.inner_text(),control.get_attribute('aria-label') or '')).translate(DIGITS)
    text=re.sub(r'[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]','',text)
    numbers=re.findall(ECRD_PREFIX+r'([0-9]+)(?![0-9])',text,re.IGNORECASE)
    return bool(numbers) and set(numbers)=={wanted}


def choose_school(page,scope,wanted,guard):
    from detailed_import import DetailError,norm
    trigger=scope.locator('button#field-previousSchoolId[aria-haspopup="listbox"]')
    try:trigger.wait_for(state='visible',timeout=5000)
    except Exception:raise DetailError('detail_options',SCHOOL_ECRD) from None
    guard()
    if trigger.count()!=1:raise DetailError('detail_options',SCHOOL_ECRD)
    current=norm(trigger.inner_text())
    if matches_ecrd(trigger,wanted):return False
    if not trigger.is_enabled():raise DetailError('detail_options',SCHOOL_ECRD)
    if trigger.get_attribute('aria-expanded')!='true':trigger.click(timeout=5000)
    search=page.get_by_label(SCHOOL_SEARCH,exact=True)
    try:search.wait_for(state='visible',timeout=4000)
    except Exception:raise DetailError('detail_options',SCHOOL_ECRD) from None
    guard()
    if search.count()!=1 or not search.is_enabled():raise DetailError('detail_options',SCHOOL_ECRD)
    search.fill(wanted,timeout=3000)
    digits=''.join(f'[{digit}{chr(0x660+int(digit))}{chr(0x6f0+int(digit))}]' for digit in wanted)
    badge_pattern=re.compile(r'^\s*'+ECRD_PREFIX+digits+r'\s*$',re.IGNORECASE)
    option_pattern=re.compile(ECRD_PREFIX+digits+r'(?![0-9٠-٩۰-۹])',re.IGNORECASE)
    clickable='xpath=ancestor-or-self::*[self::button or @role="option" or @role="button"][1]'
    deadline=time.monotonic()+6
    while time.monotonic()<deadline:
        guard()
        controls=trigger.get_attribute('aria-controls')
        menus=[item for item in page.get_by_role('listbox').all()
               if item.is_visible() and (not controls or item.get_attribute('id')==controls)]
        if len(menus)>1:raise DetailError('detail_options',SCHOOL_ECRD)
        menu=menus[0] if menus else scope
        candidates=menu.get_by_text(badge_pattern).locator(clickable)
        if not candidates.count():
            candidates=menu.locator('button,[role="option"],[role="button"]').filter(has_text=option_pattern)
        options=[option for option in candidates.all()
                 if option.is_visible() and option.is_enabled()
                 and option.get_attribute('id')!='field-previousSchoolId' and matches_ecrd(option,wanted)]
        if len(options)>1:raise DetailError('detail_options',SCHOOL_ECRD)
        if options:
            option=options[0]
            if current not in ('','اختر مدرسة','--اختيار--'):
                if option.get_attribute('aria-selected')=='true':
                    guard();trigger.click(timeout=2000)
                    return False
                raise DetailError('detail_existing',SCHOOL_ECRD)
            name_text=re.sub(r'(?:'+ECRD_PREFIX+r'|رقم\s+الوزارة\s*[:#：-]?\s*)[0-9٠-٩۰-۹]+',
                             '',option.inner_text(),flags=re.IGNORECASE)
            names={norm(line).strip(' —-|:،') for line in [name_text,*name_text.splitlines()]}
            names.discard('')
            guard()
            option.click(timeout=3000)
            confirm=time.monotonic()+3
            while time.monotonic()<confirm:
                guard()
                selected=norm(trigger.inner_text())
                if trigger.get_attribute('aria-expanded')!='true' and (matches_ecrd(trigger,wanted) or selected in names):
                    return True
                page.wait_for_timeout(80)
            raise DetailError('detail_school_unconfirmed',SCHOOL_ECRD)
        page.wait_for_timeout(80)
    if current not in ('','اختر مدرسة','--اختيار--'):
        raise DetailError('detail_existing',SCHOOL_ECRD)
    raise DetailError('detail_school_not_found',SCHOOL_ECRD)
