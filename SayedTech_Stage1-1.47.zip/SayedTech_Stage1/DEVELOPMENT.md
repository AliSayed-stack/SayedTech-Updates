# Development and verification

## Runtime and setup

Python desktop app targeting Windows 10/11 x64, PySide6 and Playwright using installed Chrome/Edge. Application dependencies are pinned in `requirements.txt`. Use Python 3.12 and the included Windows setup/start scripts.

Offline Excel/HTML regression tests additionally use `requirements-dev.txt`:

```sh
python -m pip install -r requirements-dev.txt
```

Node.js is required by the production JavaScript extraction tests. Their structural DOM adapter is not a live browser.

## Tests

Run from the project directory:

```sh
python -m unittest discover -p "test_*.py" -q
```

Login startup, blank navigation, OAuth handoff and browser/profile packaging:

```sh
python -m unittest test_login_startup test_login test_account_session test_packaging -q
```

Startup uses fake contexts/navigation, never a real school account. The printed installer-ready path from packaging tests is synthetic; it is not a Windows installer build. Native Chrome/Edge startup still requires validation on Windows.

Focused manual import regressions:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_birth_identity test_document_import test_detailed_batch test_manual_dynamic_forms test_manual_site_bindings test_manual_sections test_manual_auto_save test_manual_save test_manual_address test_detailed_import -q
```

Shared student-attendance workbook, supplied-shape DOM binder, serial queue and RTL UI:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_attendance test_attendance_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_attendance_ui -q
```

AttendanceExportDialog handles the extraction-only screen; AttendanceDialog handles the recovery-only screen. Keep app.py routing them separately for both shifts.

The attendance tests use synthetic DOM and a fake download; they do not run Playwright against a signed-in site. The native attendance template is authored by `tools/build_attendance_template.mjs` with `@oai/artifact-tool` in a development-only Node environment. Generate its contract JSON from `attendance_schema.HEADERS` and `list(attendance_schema.REASONS.items())` as `headers` and `reasons`, then invoke `node tools/build_attendance_template.mjs assets/student_attendance.xlsx <contract.json>`. Move generated PNG/inspection sidecars outside the source. Runtime XLSX reading/writing uses only ZIP/XML.

Afternoon database/unified dimensions and native-feature preservation:

```sh
python -m unittest test_student_excel_layout test_nsldb test_student_unified test_student_detailed -q
```

Morning export defaults and checkpoint/recovery propagation:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_checkpoint -q
```

Defaults require explicit morning shift metadata supplied by the scan wrapper. Keep raw reads unchanged and retain populated cells, including checkbox False. The regression checks that only the five requested blank cells differ from an afternoon export and that every other XLSX part is byte-identical.

Grade-menu timing, pending/open state, delayed target options and scope:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_grade_sync test_scan_grade_trigger test_scan_grade_menu test_grade_scan test_detail_scope test_detailed_batch_ui -q
```

Grade-sync tests exercise the existing correlated worker entry without inventory, draft navigation or pupil writes; Qt tests check pending/stale/failure/session routing. The DOM snapshot runs production LIST_SCRIPT on nested/repeated synthetic wrappers using Node. The trigger regressions execute production XPath against supplied-shape HTML with lxml; the label wrapper and unrelated controls are synthetic. The menu regressions use a deterministic clock and synthetic Playwright-shaped adapters. They reproduce pre-open toggle closure and partial-menu timing against 1.24, and preserve strict identity, account and grade-scope checks.

Excel layout and prior-file upgrades:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_detail_dom -q
```

Detailed-import window geometry, action reachability, inherited-theme regression and screen fitting:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_detailed_layout test_detailed_batch_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_detailed_layout -q
```

Qt tests skip when PySide6 is unavailable. On a headless system with Qt installed, set `QT_QPA_PLATFORM=offscreen`. Test fixtures contain synthetic values.

The multi-document regressions use a populated synthetic prior-format workbook and an lxml adapter around the supplied document form. They check unchanged input bytes, grouping/identity conflicts, independent card saves, review ordering, file preservation and uncertain-save/cancellation gates. They are not a live SIMS save.

## Modules

| Area | Files |
| --- | --- |
| Manual schema, Excel reading and field filling | `manual_sections.py` |
| Serial document cards from repeated pupil rows | `document_import.py` |
| Strict birth-date identity and sanitized mismatch diagnostics | `identity_dates.py` |
| Identity guards and section routing | `detailed_import.py` |
| Batch detail import UI and queue | `detailed_dialog.py`, `detailed_batch.py` |
| Student attendance contract, native Excel, browser binding and queue UI | `attendance_schema.py`, `attendance_excel.py`, `attendance_browser.py`, `attendance_dialog.py` |
| Save/confirm and separate review submission | `manual_save.py` |
| Extraction, snapshots and checkpoints | `student_scan.py`, `detail_dom.py`, `student_checkpoint.py` |
| Column relocation and native Excel lists | `scan_workbook_layout.py`, `scan_dropdowns.py` |
| Browser process event protocol | `login_worker.py`, `login_controller.py` |
| Windows build and update manifest | `build_windows.py`, `publish_update.py` |

## Source packaging

```sh
python tools/package_source.py
```

The ZIP is created beside the project folder using an explicit source allowlist. The script reads `core.APP_VERSION`; it does not change it. The ZIP retains the `SayedTech_Stage1/` root required by the updater.

GitHub's current Windows build workflow lives in the update repository, as documented in `UPDATE_GUIDE_AR.md`. This cleanup does not replace that workflow.

## Verification limits

Local tests cover ZIP/XML structure, supplied/adapted HTML bindings, rendering delays, identity guards and save routing using offline adapters. Passing them does not establish a native Excel opening, a live SIMS session or a compiled Windows installer. Verify the Windows build in GitHub Actions.


Custom extraction scopes (both shifts):

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_scan_filters test_scan_picker_ui test_grade_scan test_checkpoint test_scan -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_scan_picker_ui -q
```

scan_selection.py validates account/scope-bound snapshot signatures and bounded roster metadata; scan_picker.py handles transient checkboxes/search/live status choices. The helper accepts at most 5000 integer indexes within the existing 32-KiB command bound. Selection is revalidated against a fresh full table inventory before any pupil file is opened. Complete grade inventories remain the coverage baseline, while only selected files are read. Checkpoints bind both the subset roster and filter digest. No real school roster is used in tests.


Afternoon unified registration:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_registration_workbook test_registration_ui test_students test_existing_student test_student_save test_detailed_import test_document_import test_student_unified test_login_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_registration_ui -q
```

registration_workbook.py composes the established native scan template with its 56 columns and adds one registration-route column only to this separate creation template. Runtime authoring remains ZIP/XML, preserving dropdowns/names/styles and using an explicit registration marker. Simple and detailed readers dispatch separately; the generic existing-record scan is still refused for creation. Translation reuses the namespace-preserving ASCII spelling patcher, never a full worksheet rewrite. Tests use synthetic workbooks; openpyxl remains test-only.


Date input consistency: `python -m unittest test_date_consistency test_registration_dates test_birth_identity test_manual_dynamic_forms test_identity_card test_attendance -q`. normalize_date provides strict ISO/year-first slash/month-first slash/numeric parsing and explicit allow_future. Documents reuse it, keeping only legacy DD-MM-YYYY as a separate dash format; slash dates are month-first across user inputs. Existing attendance table overlap detection retains its conservative legacy interpretation set and additionally recognizes year-first slashes. Future attendance still requires the live calendar bounds.


Formatted document dates: test_document_import simulates a date control reformatting an ISO fill to YYYY/MM/DD. It checks both flags and two serial card saves, reusing an unsaved partial editable card, and refusing a genuinely different rendered date before flags/save/next Add. This models the observed value format using the supplied-form adapter, not a live browser or complete new custom-calendar HTML.


1.38 registration route coverage checks three mixed types in one workbook, existing/new-site routing with and without UID, no global UI filter, blank/unknown type stops, old-label compatibility, and older unified readers. Route-list copy tests compare exact sheetData bytes and every unrelated ZIP part before/after; use the real updater in test_registration_workbook and test_student_unified, not a workbook rewrite. Source cells retain their old compatible labels when list validation is upgraded.


Afternoon template defaults: test_registration_workbook checks every one of 500 input rows, exact native option labels, empty pupil selection/route/UID/birth, and preservation of employee edits through reading and route-list upgrades. A release audit against 1.38 confirmed that only the eleven requested cell columns differ; all other XLSX parts and formulas are unchanged.


## 1.40 — afternoon registration class list
The supplied native select contains kg_3 and grade_1 through grade_6, labelled الروضة الثالثة through السادس أساسي. The blank registration template previously had no validation on صف الطالب (AA). Add an explicit visible list for all 500 rows, afternoon registration only. Existing fill_student already resolves the requested Arabic label against current live enabled options; it never hardcodes native option values and still rejects absent/ambiguous live options. No browser binding was changed. These supplied options are not a discovery of every school's live classes.
The existing update-options button adds/replaces a grade-only validation for marked registration workbooks in a separate copy, while retaining route updates. Legacy unified files retain route-only upgrading. Patch validation XML only; keep sheetData and all other ZIP parts unchanged. Employee values, defaults, dimensions and morning exports remain unchanged.
Verification: 32 focused workbook/simple-fill/shift/UI tests completed: 28 passed, four Qt tests skipped because PySide6 is unavailable. New coverage confirms list labels/range/visible arrow, upgrade of an older filled file with missing grade validation, immutable source and retained pupil class. No native SIMS/Excel/Windows verification.


1.41: User clarified that afternoon schools may extend to الثاني ثانوي. Extend registration-only Excel class choices in progression with السابع أساسي، الثامن أساسي، التاسع أساسي، الأول ثانوي، الثاني ثانوي. Both fresh templates and existing-file copy upgrades share the expanded choices. Browser selection remains bound to the actual live enabled class options; an unavailable grade still stops rather than silently choosing another. No account, date, save or morning change. Test the upper-grade choices and preservation of a filled الثاني ثانوي class. Offline verification only.


## 1.42 — simple save date comparison
User screenshots show a pre-save blocked result naming birth date; registration date visibly uses YYYY/MM/DD. student_save.snapshot previously compared raw visible date strings with canonical ISO record values. Normalize nonblank date-spec values and raw snapshot values using shared normalize_date before equality/stability comparison. This is in-memory verification only: no new birth writes or workbook changes. Reject invalid/future/different calendar dates; retain browser validity, required fields, modal/account checks, one Save/confirmation and fresh success requirement. Both shifts share this path. Synthetic tests cover year-first slash birth/registration values, both shifts, one save/confirm, unchanged form values, and different/invalid/future dates blocking before Save. Native live cause/verification is not claimed; screenshots do not supply full date DOM.


## 1.43 — existing pupil birth identity before filling
New screenshots on 1.42 show student_existing_mismatch naming birth before any filling; visible birth uses YYYY/MM/DD. The earlier 1.42 correction covered save snapshots only. select_existing_student now compares birth through identity_birth, with unchanged strict names/UID and stability checks. For existing pupils, fill_student rechecks calendar birth and skips writing that field entirely, even if enabled. New-from-home still fills its provided birth. Different/invalid/missing existing birth stops; never swap components or bypass identity. Synthetic both-shift regressions verify slash birth proceeds through one save while retaining the original slash form value with no birth fill action, and a genuinely swapped date stops before writes. No live site verification.


## 1.44 — grade option text normalization
User supplied both open grade trigger and menu; both structurally match current selectors. No confirmed live cause is established. A concrete inconsistent text check existed: grade_menu used raw labels.count for the all-levels sentinel whereas other grade checks normalize text. Strip direction marks/collapse whitespace for menu labels and normalize sentinel comparisons. Retain unique-menu/unique-option/stability/account/cancel/one-toggle guards; no fallback grade or school-wide search. Synthetic regression covers direction marks and multiline labels; do not claim this reproduces the unknown live cause. Existing birth write protection unchanged.


## 1.45 — strict student Excel dates YYYY/MM/DD
Explicit user supersedes permissive Excel date input: only padded ASCII YYYY/MM/DD text or numeric Excel dates whose exact display format is yyyy/mm/dd are accepted at student simple/detail importer boundaries. excel_dates.strict_dates checks chosen rows and reports row/header before browser dispatch. Internal normalize_date and site identity parsers remain permissive for site/legacy source readings; no date guessing or altered birth. Calendar validity/future field policy still enforced by existing readers.
New student scan (both shifts), afternoon registration (through shared scan), NSLDB export, unified conversion, card workbook and bundled morning blank template use excel_dates.format_dates. Numeric serials remain untouched; text values with a known valid source format are converted to year-first text on new outputs. Clone styles per date column; retain other formatting/parts. Existing-file registration options upgrade now also formats dates in its separate output copy under explicit unified-date request, overriding the old route-only restriction; never replace original. Unparseable dates remain unchanged and blocked on import. Attendance is outside the four requested categories. Existing pupil birth remains verification-only and site inputs retain their required internal format.
Synthetic test_excel_dates covers strict rejection, numeric display requirements, date equality, document boundary and unchanged input bytes/other parts. Local tests are not native Excel/SIMS validation.

Strict-date verification in 1.45: test_excel_dates + simple save/existing-pupil suite: 29 passed. Updated prior permissive Excel-reader regression to expect strict rejection under explicit user instruction; internal source/site parser tests retain their permissive contract. Date consistency/registration/birth checks: 19 passed, one Qt skip. NSLDB fixtures now enter user Excel dates in the required year-first format (source-table records remain unchanged); NSLDB + strict boundary tests: 20 passed. Layout/packaging/updater checks: 18 passed. No native Windows, live SIMS or native Excel application test.


## 1.46 — explicit simple/detail commands start at management
User explicitly requests any student registration/restoration command to restart from management. login_worker now invokes student_start.reset_management before simple fill/save/duplicate-check and detailed commands (including review). It validates account/cancellation before and after one public management navigation, even if already at management with a modal/page/filter. Wrong shift blocks detail navigation first. This deliberate explicit new-command start may discard an existing unsaved draft under the user's request, superseding old draft-retention behavior at that boundary. Internal section recursion/confirmed-save re-entry is unchanged: never restart inside a section, replay an uncertain save or change birth data.
The correlated scope_grade helper is not a registration/restoration button and retains its existing behavior. Attendance stays on its separate requested workflow. No login/startup/extraction/date logic changes. Synthetic tests check both shifts, management/form/analytics origins, no writes, account/host/cancel blocks, failed/redirected navigation. No live SIMS/Windows test.


## 1.47 — remove redundant afternoon menu entries
User screenshot identifies student_simple/student_detailed legacy placeholders in afternoon management as unnecessary. Hide those two menu buttons when show_section runs under afternoon; restore visibility under morning. Keep registration chooser's real registration_simple/registration_detailed, scan, NSLDB and registration/import backends unchanged. Reversible presentation-only edit; no new redundant test. Packaging/updater checks apply.
