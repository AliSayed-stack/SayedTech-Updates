"""Offline interruption, durable progress, conservative resume and recovery XLSX."""
from pathlib import Path
import sqlite3
import json
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

from student_checkpoint import ScanCheckpoint,run_student_scan
from student_scan import StudentBrowser,ScanError,collect_students,clean_detail,export_students,SETTLED_TAB_SCRIPT,TABS
from test_scan import Page as ScanPage,Clock


class Page(ScanPage):
    """Checkpoint completion fixtures have verified empty later sections."""
    def evaluate(self,script,*args):
        if script==SETTLED_TAB_SCRIPT and args[0] in TABS[3:]:
            return {'found':True,'loading':False,'empty':True,'text':'لم يُعثر على أية سجلات','fields':[]}
        return super().evaluate(script,*args)

USERNAME='test@te.mehe.school'


class CheckpointTests(unittest.TestCase):
    def test_partial_v5_or_v6_cache_refreshes_only_its_unread_sections(self):
        for version in (5,6):
            with tempfile.TemporaryDirectory() as tmp:
                path=Path(tmp)/'students.xlsx';self.interrupt(Page(4),path,2)
                with sqlite3.connect(path.with_suffix('.sayedtech-progress.sqlite3')) as db:
                    saved=db.execute('SELECT token,payload FROM students ORDER BY position').fetchall()
                    for i,(token,payload) in enumerate(saved):
                        row=json.loads(payload);row['reader_version']=version
                        if i==1:row['unread_tabs']=['الهواتف']
                        db.execute('UPDATE students SET payload=? WHERE token=?',(json.dumps(row),token))
                resumed=Page(4)
                with patch('student_scan.time.monotonic',Clock()):
                    result=run_student_scan(resumed,USERNAME,threading.Event(),path,0)
                self.assertEqual(result[1],4)
                self.assertEqual(sum(a[0]=='opened' for a in resumed.actions),3)
    def test_known_previous_reader_refreshes_later_tabs(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx'
            self.interrupt(Page(4),path,2)
            with sqlite3.connect(path.with_suffix('.sayedtech-progress.sqlite3')) as db:
                for token,payload in db.execute('SELECT token,payload FROM students').fetchall():
                    row=json.loads(payload);row['reader_version']=3
                    db.execute('UPDATE students SET payload=? WHERE token=?',(json.dumps(row),token))
            page=Page(4)
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(page,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[1],4)
            self.assertEqual(sum(a[0]=='opened' for a in page.actions),4)

    def interrupt(self,page,path,after=2,reason='tab_timeout'):
        original=StudentBrowser.read;calls=[0]
        def read(browser,item):
            if calls[0]>=after:raise ScanError('scan_changed',reason)
            calls[0]+=1
            return original(browser,item)
        with patch('student_scan.time.monotonic',Clock()),patch.object(StudentBrowser,'read',read):
            return run_student_scan(page,USERNAME,threading.Event(),path,0)

    def test_previous_reader_cache_is_read_again(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx'
            self.interrupt(Page(4),path,2)
            with sqlite3.connect(path.with_suffix('.sayedtech-progress.sqlite3')) as db:
                for token,payload in db.execute('SELECT token,payload FROM students').fetchall():
                    row=json.loads(payload);row.pop('reader_version',None)
                    db.execute('UPDATE students SET payload=? WHERE token=?',(json.dumps(row),token))
            page=Page(4)
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(page,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[1],4)
            self.assertEqual(sum(a[0]=='opened' for a in page.actions),4)

    def test_interruption_preserves_final_and_resumes_missing_ids_after_reordering(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx';path.write_bytes(b'PREVIOUS FINAL')
            page=Page(9)
            for i,r in enumerate(page.records):r.update(uid='—',first=f'TEST{i}')
            event,first,total,detail=self.interrupt(page,path,3)
            self.assertEqual((event,first,total),('scan_paused',3,9))
            self.assertEqual(path.read_bytes(),b'PREVIOUS FINAL')
            recovery=path.parent/detail['recovery_file']
            with zipfile.ZipFile(recovery) as z:
                self.assertIn('سحب متوقف وغير مكتمل',z.read('xl/worksheets/sheet5.xml').decode())
            checkpoint=path.with_suffix('.sayedtech-progress.sqlite3')
            self.assertTrue(checkpoint.exists())
            with sqlite3.connect(checkpoint) as db:
                self.assertEqual(db.execute('SELECT count(*) FROM students').fetchone()[0],3)
                payload=' '.join(r[0] for r in db.execute('SELECT payload FROM students'))
                self.assertNotIn('https://',payload)
                self.assertNotIn(USERNAME,payload)
            resumed=Page(9);resumed.records=list(reversed(page.records))
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(resumed,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[:3],('scan_saved_partial',9,9))
            self.assertEqual(sum(a[0]=='opened' for a in resumed.actions),6)
            self.assertFalse(checkpoint.exists())
            self.assertTrue(recovery.exists())
            with zipfile.ZipFile(path) as z:
                self.assertNotIn('سحب متوقف وغير مكتمل',z.read('xl/worksheets/sheet5.xml').decode())

    def test_same_full_rows_are_reread_instead_of_resumed_by_shared_uid(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx';page=Page(4)
            for r in page.records:r.update(uid='SAME',grade='الأول أساسي')
            self.assertEqual(self.interrupt(page,path)[1],2)
            resumed=Page(4);resumed.records=page.records
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(resumed,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[1],4)
            self.assertEqual(sum(a[0]=='opened' for a in resumed.actions),4)

    def test_account_scope_and_roster_mismatch_do_not_modify_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx'
            self.interrupt(Page(6),path)
            checkpoint=path.with_suffix('.sayedtech-progress.sqlite3');before=checkpoint.read_bytes()
            changed=Page(6);changed.records[0]['first']='CHANGED'
            cases=[(Page(6,account='other@te.pm.mehe.school'),'other@te.pm.mehe.school',0),
                   (Page(6),USERNAME,10),(changed,USERNAME,0)]
            for page,username,limit in cases:
                with self.subTest(username=username,limit=limit),patch('student_scan.time.monotonic',Clock()):
                    result=run_student_scan(page,username,threading.Event(),path,limit)
                self.assertEqual(result[3]['reason'],'checkpoint_mismatch')
                self.assertEqual(checkpoint.read_bytes(),before)
                self.assertFalse(any(a[0]=='opened' for a in page.actions))
            self.assertFalse(path.exists())

    def test_cancellation_commits_completed_records_and_returns_recovery_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx';cancelled=threading.Event()
            def progress(first,second,detail):
                if detail.get('stage')=='read' and first==2:cancelled.set()
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(Page(6),USERNAME,cancelled,path,0,progress)
            self.assertEqual(result[:3],('scan_paused',2,6))
            self.assertEqual(result[3]['cause'],'scan_cancelled')
            self.assertTrue((path.parent/result[3]['recovery_file']).exists())
            self.assertFalse(path.exists())
            from student_workflow import workbook_rows
            with zipfile.ZipFile(path.parent/result[3]['recovery_file']) as z:
                rows=workbook_rows(z,'الطلاب');headers={v:k for k,v in rows[0][1].items()}
                self.assertEqual(rows[1][1][headers['البلد']],'لبنان')
                self.assertEqual(rows[1][1][headers['الهواتف / رمز الدولة']],'961 (LB)')

    def test_failed_recovery_export_keeps_checkpoint_and_failed_commit_keeps_prior_students(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx'
            with patch('student_checkpoint.export_students',side_effect=ScanError('scan_failed')):
                result=self.interrupt(Page(6),path)
            self.assertEqual(result[:3],('scan_paused_checkpoint',2,6))
            self.assertTrue(path.with_suffix('.sayedtech-progress.sqlite3').exists())
            original=ScanCheckpoint.save
            def failed_commit(checkpoint,row,occurrence,position):
                if position==3:raise ScanError('scan_failed','checkpoint_write')
                return original(checkpoint,row,occurrence,position)
            with patch('student_scan.time.monotonic',Clock()),patch.object(ScanCheckpoint,'save',failed_commit):
                result=run_student_scan(Page(6),USERNAME,threading.Event(),path,0)
            self.assertEqual(result[:3],('scan_paused',2,6))
            self.assertEqual(result[3]['reason'],'checkpoint_write')
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(Page(6),USERNAME,threading.Event(),path,0)
            self.assertEqual(result[1],6)

    def test_hard_interruption_has_durable_commits_and_no_total_two_hour_deadline(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx';checkpoint=ScanCheckpoint(path,USERNAME,0)
            original=StudentBrowser.read;calls=[0]
            def crash(browser,item):
                if calls[0]==2:raise RuntimeError('TEST CRASH')
                calls[0]+=1;return original(browser,item)
            try:
                with patch('student_scan.time.monotonic',Clock()),patch.object(StudentBrowser,'read',crash),self.assertRaises(RuntimeError):
                    collect_students(Page(6),USERNAME,threading.Event(),0,checkpoint=checkpoint)
            finally:checkpoint.close()
            resumed=Page(6)
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(resumed,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[1],6)
            self.assertEqual(sum(a[0]=='opened' for a in resumed.actions),4)
        clock=Clock()
        with patch('student_scan.time.monotonic',clock):
            browser=StudentBrowser(Page(),USERNAME,threading.Event())
            clock.value=100000
            browser.guard()
        self.assertEqual(clean_detail({'recovery_file':'../secret.xlsx','cause':'SECRET'}),{})

    def test_final_excel_write_failure_can_retry_without_reopening_any_student(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx';path.write_bytes(b'PREVIOUS FINAL')
            def fail_final(data,destination,cancelled):
                if Path(destination)==path:raise ScanError('scan_failed')
                return export_students(data,destination,cancelled)
            with patch('student_scan.time.monotonic',Clock()),patch('student_checkpoint.export_students',fail_final):
                result=run_student_scan(Page(6),USERNAME,threading.Event(),path,0)
            self.assertEqual(result[:3],('scan_paused',6,6))
            self.assertEqual(path.read_bytes(),b'PREVIOUS FINAL')
            resumed=Page(6)
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(resumed,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[:3],('scan_saved_partial',6,6))
            self.assertFalse(any(a[0]=='opened' for a in resumed.actions))

    def test_invalid_checkpoint_is_preserved_and_not_used(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'students.xlsx'
            checkpoint=path.with_suffix('.sayedtech-progress.sqlite3')
            checkpoint.write_bytes(b'INVALID TEST FILE')
            before=checkpoint.read_bytes();page=Page(6)
            with patch('student_scan.time.monotonic',Clock()):
                result=run_student_scan(page,USERNAME,threading.Event(),path,0)
            self.assertEqual(result[3]['reason'],'checkpoint_invalid')
            self.assertEqual(checkpoint.read_bytes(),before)
            self.assertFalse(any(a[0]=='opened' for a in page.actions))


if __name__=='__main__':unittest.main()
