"""The same pupil must read identically alone and in a multi-pupil scan."""
import threading
import unittest
from unittest.mock import patch

from student_scan import StudentBrowser,ScanError,FORM_SCRIPT,SETTLED_TAB_SCRIPT,TABS,collect_students
from test_scan import Clock
from test_scan_tail_retry import RetryPage


class BatchStatePage(RetryPage):
    def __init__(self,user,missing_uid=False):
        super().__init__(user);self.fail_first=False;self.seen=set();self.dirty=False;self.after_reload=lambda:None
        template=self.records[0]
        self.records=[dict(template,record_id='record-'+str(i),first='TEST'+str(i),uid='' if missing_uid else 'TEST-UID-'+str(i)) for i in range(1,4)]
    def evaluate(self,script,*args):
        if script==FORM_SCRIPT and self.view=='record':
            key=self.selected['record_id']
            if key not in self.seen:self.dirty=bool(self.seen);self.seen.add(key)
        if script==SETTLED_TAB_SCRIPT and args[0] in TABS[3:] and self.dirty:
            return {'found':False,'fields':[]}
        result=super().evaluate(script,*args)
        if script==SETTLED_TAB_SCRIPT and args[0]=='الهواتف' and result.get('fields'):
            result['fields'][0]['value']='0312345'+self.selected['record_id'][-1]
        return result
    def reload(self,**kwargs):
        super().reload(**kwargs);self.dirty=False;self.after_reload()


class BatchIsolationTests(unittest.TestCase):
    def scan(self,page,cancel=None):
        with patch('student_scan.time.monotonic',Clock()):
            return collect_students(page,page.account,cancel or threading.Event(),0,grade=page.records[0]['grade'])['records']

    def test_each_pupil_matches_standalone_read_in_batch_for_both_shifts_with_or_without_uid(self):
        for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
            for missing_uid in (False,True):
                batch=BatchStatePage(user,missing_uid);rows=self.scan(batch)
                self.assertEqual(len(rows),3)
                self.assertEqual(sum(a[0]=='reload' for a in batch.actions),3)
                for row in rows:
                    single=BatchStatePage(user,missing_uid)
                    single.records=[r for r in batch.records if r['first']==row['item']['first']]
                    alone=self.scan(single)[0]
                    self.assertEqual(row['fields'],alone['fields'])
                    self.assertFalse(set(TABS[3:])&set(row['unread_tabs']))
                    phone=next(f['value'] for f in row['fields'] if f['section']=='الهواتف')
                    self.assertEqual(phone,'0312345'+row['item']['first'][-1])
                self.assertFalse(any(a[0] in ('fill','select') or 'حفظ' in str(a) or 'إضافة' in str(a) for a in batch.actions))

    def test_wrong_name_after_reload_stops_before_reading_later_tabs(self):
        page=BatchStatePage('test@te.mehe.school',missing_uid=True)
        page.after_reload=lambda:setattr(page,'wrong_names',True)
        with self.assertRaises(ScanError) as error:self.scan(page)
        self.assertEqual(error.exception.reason,'identity_changed')
        self.assertFalse(page.tail_reads)
        self.assertEqual(sum(a[0]=='opened' for a in page.actions),1)

    def test_account_change_or_cancel_during_reload_aborts_before_tabs(self):
        for failure in ('account','cancel'):
            page=BatchStatePage('test@te.mehe.school');cancel=threading.Event()
            page.after_reload=(lambda:cancel.set()) if failure=='cancel' else lambda:setattr(page,'account','other@te.mehe.school')
            with self.assertRaises(ScanError) as error:self.scan(page,cancel)
            self.assertEqual(error.exception.code,'scan_cancelled' if failure=='cancel' else 'scan_account_required')
            self.assertFalse(page.tail_reads)

    def test_identity_failure_before_reload_does_not_reload_any_route(self):
        page=BatchStatePage('test@te.mehe.school');page.wrong_names=True
        with self.assertRaises(ScanError):self.scan(page)
        self.assertFalse(any(a[0]=='reload' for a in page.actions))

    def test_changed_uid_or_route_after_reload_is_rejected_before_tabs(self):
        for failure in ('uid','route'):
            page=BatchStatePage('test@te.mehe.school')
            page.after_reload=(lambda:setattr(page,'wrong_uid',True)) if failure=='uid' else lambda:setattr(page,'url','about:blank')
            with self.assertRaises(ScanError) as error:self.scan(page)
            self.assertEqual(error.exception.code,'scan_account_required' if failure=='route' else 'scan_changed')
            self.assertFalse(page.tail_reads)


if __name__=='__main__':unittest.main()
