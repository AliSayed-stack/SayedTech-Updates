"""Execute the production JS on parsed, supplied/adapted HTML, then read Excel."""
import json
import subprocess
from pathlib import Path
import tempfile
import threading
import unittest
from lxml import html
from openpyxl import load_workbook
from student_scan import TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT,StudentBrowser,export_students,TABS
from manual_sections import observed_values,MOTHER_SURNAME,SELECT,SPECS
from detailed_import import read_details
from test_students import record
from scan_workbook_layout import shift_formula

ROOT=Path(__file__).parent/'test_fixtures'


def extract(name,title,settled=False,delayed=False,rename=False,locked=False):
    doc=html.fromstring((ROOT/name).read_text())
    if locked:
        for e in doc.xpath('//fieldset|//input|//select|//textarea'):e.set('disabled','disabled')
    if rename:
        for e in doc.xpath('//*[@id]'):
            old=e.get('id');e.set('id','new_'+old)
            for label in doc.xpath('//label[@for=$id]',id=old):label.set('for','new_'+old)
    def tree(e):
        return {'tag':e.tag,'attrs':dict(e.attrib),'text':e.text or '','tail':e.tail or '',
                'children':[tree(c) for c in e if isinstance(c.tag,str)]}
    payload={'tree':tree(doc),'script':SETTLED_TAB_SCRIPT if settled else TAB_SNAPSHOT_SCRIPT,'tab':title}
    if delayed:payload['delayed']={'id':doc.xpath('//input[@maxlength="8"]')[0].get('id'),'ms':100}
    result=subprocess.run(['node',str(ROOT/'dom_runner.js')],input=json.dumps(payload),text=True,capture_output=True,check=True)
    return json.loads(result.stdout)


class SuppliedHTMLTests(unittest.TestCase):
    def test_locked_phone_and_document_controls_remain_readable(self):
        for fixture,title in (('phones_site.html','الهواتف'),('documents_site.html','المستندات')):
            self.assertEqual(extract(fixture,title,locked=True),extract(fixture,title))

    def test_incomplete_step_number_does_not_hide_a_tab_from_the_locator(self):
        from detail_dom import tab_locator
        class Page:
            def get_by_role(self,role,name,**kwargs):
                class Found:
                    def count(self):return int(bool(name.search('٥ البريد الإلكتروني'))) if hasattr(name,'search') else 0
                return Found()
        self.assertEqual(tab_locator(Page(),'البريد الإلكتروني').count(),1)

    def snapshots(self):
        out={}
        for name,title in [('phones_site.html','الهواتف'),('email_site.html','البريد الإلكتروني'),
                           ('relatives_scan_site.html','الأقارب'),('identity_site.html','بطاقات التعريف'),
                           ('documents_site.html','المستندات'),('registration_site.html','حالة التسجيل')]:
            out[title]=extract(name,title)
        return out

    def test_real_phone_value_and_unassociated_primary_checkbox_with_changed_ids(self):
        for rename in (False,True):
            snap=extract('phones_site.html','الهواتف',rename=rename)
            self.assertTrue(snap['found'])
            fields={f['label'].rstrip('*'):f['value'] for f in snap['fields']}
            self.assertEqual(fields['رقم الهاتف'],'03123456')
            self.assertIs(fields['الأساسية'],True)
            self.assertFalse(any(f['kind']=='display' and 'رقم الهاتف' in f['label'] for f in snap['fields']))

    def test_waits_for_live_value_property_to_settle_before_reading(self):
        snap=extract('phones_site.html','الهواتف',settled=True,delayed=True)
        self.assertNotIn('timed_out',snap)
        self.assertEqual(next(f['value'] for f in snap['fields'] if f['label'].startswith('رقم الهاتف')),'03123456')

    def test_fields_from_all_sections_project_and_round_trip_through_excel(self):
        values=record();values['field-existingUniqueId']='000123'
        item=dict(uid='000123',first=values['field-firstName'],middle=values['field-middleName'],
                  last=values['field-lastName'],grade='الأول أساسي',language='الفرنسية',section='الشعبة أ')
        row=dict(item=item,values=values,address={},read_ids=list(values),fields=[],tab_texts={},unread_tabs=[],empty_tabs=[])
        for title,snap in self.snapshots().items():
            self.assertTrue(snap['found'],title)
            StudentBrowser.capture(row,title,snap['fields'])
        got=observed_values(row)
        expected={'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True,
                  'البريد الإلكتروني / البريد الإلكتروني':'fixture@example.invalid',
                  'البريد الإلكتروني / النوع':'مدرسي','البريد الإلكتروني / الأساسية':True,
                  MOTHER_SURNAME:'MOTHER_SURNAME','بطاقات التعريف / رقم الوثيقة':'001234',
                  'بطاقات التعريف / تاريخ الإصدار':'2020-01-02','بطاقات التعريف / تاريخ الإنتهاء':'2030-01-02',
                  'المستندات / نوع المستند':'بطاقة تلقيح','المستندات / رقم الوثيقة':'00007',
                  'المستندات / جرى التسليم':True,'المستندات / طباعة على اللائحة':False,
                  'حالة التسجيل / الحالة الحالية':'قيد الانتظار','حالة التسجيل / ملاحظة (اختياري)':'TEST NOTE'}
        for key,value in expected.items():self.assertEqual(got[key],value,key)
        self.assertFalse(any('إنهاء' in s['header'] for s in SPECS))
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'result.xlsx'
            export_students({'inventory':1,'records':[row]},path,threading.Event())
            book=load_workbook(path);sheet=book['الطلاب'];headers=[c.value for c in sheet[1]]
            mother_index=headers.index('اسم الأم (بالعربية)')
            self.assertEqual(headers[mother_index+1:mother_index+3],[MOTHER_SURNAME,'اسم الأم (بالإنكليزية)'])
            for key,value in expected.items():
                if isinstance(value,bool):value='نعم' if value else 'لا'
                elif ' / تاريخ ' in key:value=value.replace('-','/')
                self.assertEqual(sheet.cell(2,headers.index(key)+1).value,value,key)
            formula=sheet.cell(2,headers.index('حالة العنوان')+1).value
            self.assertIn('AD2:AJ2',formula)
            self.assertIn("'قوائم العناوين'!$S$8:$S$10",formula)
            sheet.cell(2,headers.index(SELECT)+1).value='1';book.save(path);book.close()
            parsed=read_details(path)[0]
            self.assertEqual(parsed['mother_surname'],'MOTHER_SURNAME')
            self.assertEqual(parsed['manual']['الهواتف / رقم الهاتف'],'03123456')
            self.assertIs(parsed['manual']['المستندات / طباعة على اللائحة'],False)
            self.assertEqual(parsed['manual']['حالة التسجيل / الحالة الحالية'],'قيد الانتظار')

    def test_external_lookup_references_and_indirect_strings_do_not_shift(self):
        source='IF($AB2="لبنان",COUNTIFS(\'قوائم العناوين\'!$S$8:$S$10,AG2),INDIRECT("\'قوائم العناوين\'!$S$8"))'
        result=shift_formula(source)
        self.assertIn('$AC2',result);self.assertIn(',AH2)',result)
        self.assertEqual(result.count("'قوائم العناوين'!$S$8"),2)


if __name__=='__main__':unittest.main()
