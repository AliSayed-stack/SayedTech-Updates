"""Bounded read-only recovery of later tabs; synthetic pupil data only."""
from collections import Counter
import json
from pathlib import Path
import subprocess
import threading
import unittest
from unittest.mock import patch

from detail_dom import settled_script
from student_scan import (StudentBrowser,ScanError,TABS,SETTLED_TAB_SCRIPT,collect_students)
from test_scan import Clock
from test_manual_sections import FastPage


class RetryPage(FastPage):
    def __init__(self,user):
        super().__init__();self.account=user;self.tail_reads=Counter();self.fail_first=True;self.on_snapshot=lambda:None
    def evaluate(self,script,*args):
        if script==SETTLED_TAB_SCRIPT and args[0] in TABS[3:]:
            title=args[0];self.tail_reads[title]+=1;self.on_snapshot()
            if self.fail_first and self.tail_reads[title]==1:return {'found':False,'fields':[]}
            label,value={
                'الهواتف':('رقم الهاتف','03123456'),
                'البريد الإلكتروني':('البريد الإلكتروني','test@example.invalid'),
                'الأقارب':('الشهرة (بالعربية)','TEST MOTHER SURNAME'),
                'بطاقات التعريف':('رقم الوثيقة','00123'),
                'المستندات':('جرى التسليم',True),
                'حالة التسجيل':('الحالة الحالية','مقدّم للمراجعة')}[title]
            return {'found':True,'loading':False,'text':label,'fields':[
                dict(id='',label=label,value=value,group='الأقارب #2' if title=='الأقارب' else '',required=False,kind='checkbox' if value is True else 'display')]}
        return super().evaluate(script,*args)


class TailRetryTests(unittest.TestCase):
    def scan(self,page):
        with patch('student_scan.time.monotonic',Clock()):
            return collect_students(page,page.account,threading.Event(),0)['records'][0]

    def test_all_six_late_tabs_recovered_on_second_pass_for_both_shifts(self):
        for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
            page=RetryPage(user);row=self.scan(page)
            self.assertEqual(page.tail_reads,Counter({t:2 for t in TABS[3:]}))
            self.assertFalse(set(TABS[3:])&set(row['unread_tabs']))
            self.assertEqual(row['reader_version'],6)
            phone=[f['value'] for f in row['fields'] if f['section']=='الهواتف' and f['label']=='رقم الهاتف']
            self.assertEqual(phone,['03123456'])
            self.assertTrue(next(f['value'] for f in row['fields'] if f['section']=='المستندات'))
            self.assertFalse(any('حفظ' in str(a) or 'إضافة' in str(a) or a[0] in ('fill','select') for a in page.actions))

    def test_completed_tabs_are_not_revisited_or_duplicated(self):
        page=RetryPage('test@te.mehe.school');page.fail_first=False
        row=self.scan(page)
        self.assertEqual(page.tail_reads,Counter({t:1 for t in TABS[3:]}))
        self.assertFalse(set(TABS[3:])&set(row['unread_tabs']))

    def test_checkpoint_refresh_retains_successful_phone_and_reads_only_unread_document(self):
        page=RetryPage('test@te.mehe.school');page.fail_first=False
        row=self.scan(page);row['reader_version']=5;row['unread_tabs']=['المستندات']
        page.tail_reads.clear()
        with patch('student_scan.time.monotonic',Clock()):
            browser=StudentBrowser(page,page.account,threading.Event());browser.selected_grade=row['item']['grade']
            browser.inventory(lambda *_:None,grade=row['item']['grade'])
            restored=browser.read(row['item'],previous=row)
        self.assertEqual(page.tail_reads,Counter({'المستندات':1}))
        phone=[f for f in restored['fields'] if f['section']=='الهواتف']
        self.assertEqual(len(phone),1);self.assertEqual(phone[0]['value'],'03123456')
        self.assertNotIn('المستندات',restored['unread_tabs'])
        self.assertEqual(row['unread_tabs'],['المستندات'])

    def test_failed_second_read_stays_unread_not_empty(self):
        page=FastPage();row=self.scan(page)
        self.assertEqual(page.fast_reads['المستندات'],2)
        self.assertIn('المستندات',row['unread_tabs']);self.assertNotIn('المستندات',row['empty_tabs'])
        self.assertFalse(any(f['section']=='المستندات' for f in row['fields']))

    def test_account_change_after_snapshot_aborts_instead_of_capturing(self):
        page=RetryPage('test@te.mehe.school')
        page.on_snapshot=lambda:setattr(page,'account','other@te.mehe.school')
        with self.assertRaises(ScanError) as error:self.scan(page)
        self.assertEqual(error.exception.code,'scan_account_required')
        self.assertEqual(sum(page.tail_reads.values()),1)

    def test_production_settled_script_waits_for_panel_after_old_deadline(self):
        # Deterministic JS clock, using the actual production wait function.
        snapshot='title => ({found:clock>=2400,loading:clock<2400,text:"TEST",fields:clock>=2400?[{label:"رقم الهاتف",value:"03123456"}]:[]})'
        script='let clock=0; global.performance={now:()=>clock}; global.setTimeout=(fn,ms)=>{clock+=ms;fn();};\n'
        script+='const read=('+settled_script(snapshot)+');read("الهواتف").then(result=>process.stdout.write(JSON.stringify({result,clock})));'
        reply=subprocess.run(['node','-e',script],text=True,capture_output=True,check=True)
        result=json.loads(reply.stdout)
        self.assertGreaterEqual(result['clock'],2900)
        self.assertLess(result['clock'],8000)
        self.assertNotIn('timed_out',result['result'])
        self.assertEqual(result['result']['fields'][0]['value'],'03123456')


if __name__=='__main__':unittest.main()
