"""Account-bound section transfers, with original enrollment identities."""
import hashlib
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as E
from student_excel import NS,ExcelInputError
from student_workflow import workbook_rows,selection_value,column
from registration_workbook import _write
HEADERS=('اختيار','اسم الطالب','الشعبة الحالية','الشعبة الجديدة','الصف','لغة التعليم','معرّف التسجيل')
LEGACY_HEADERS=('اختيار','الصف','لغة التعليم','الشعبة الحالية','اسم الطالب','الشعبة المطلوبة','معرّف التسجيل')
OPTIONS_SHEET='خيارات الشعب'

def section_options(items):
    """Exact live options, including empty destination cards, grouped by class/language."""
    if not isinstance(items,list) or not items or len(items)>5000:raise ExcelInputError('تعذّرت قراءة شعب المدرسة من الموقع.')
    groups={}
    for item in items:
        if not isinstance(item,dict) or any(not isinstance(item.get(k),str) or not item[k].strip() or len(item[k])>500 for k in ('grade','language','section')):raise ExcelInputError('تعذّرت قراءة شعب المدرسة من الموقع.')
        grade,language,section=(label_text(item[k]) for k in ('grade','language','section'))
        if not all((grade,language,section)):raise ExcelInputError('تعذّرت قراءة شعب المدرسة من الموقع.')
        choices=groups.setdefault((grade,language),[])
        if section in choices:raise ExcelInputError('شعب مكررة ضمن نفس الصف واللغة.')
        choices.append(section)
    return groups

def account_key(username):return hashlib.sha256(username.strip().lower().encode()).hexdigest()

def label_text(value):
    """Same display-text normalization as the browser snapshot, not fuzzy matching."""
    return ' '.join(re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',value).split())

def validate(row,*,allow_same=False):
    keys=('grade','language','source','name','target','id','account')
    if not isinstance(row,dict) or any(not isinstance(row.get(k),str) or not row[k].strip() or len(row[k])>500 for k in keys):raise ExcelInputError('أكمل الصف واللغة والشعبتين واسم الطالب في ملف التشعيب.')
    row=dict(row)
    for key in ('grade','language','source','name','target'):
        row[key]=label_text(row[key])
        if not row[key]:raise ExcelInputError('أكمل الصف واللغة والشعبتين واسم الطالب في ملف التشعيب.')
    if not re.fullmatch('[a-zA-Z0-9-]{1,100}',row['id']) or not re.fullmatch('[a-f0-9]{64}',row['account']):raise ExcelInputError('مرجع التشعيب غير صالح؛ أعد الاستخراج.')
    if not allow_same and row['source']==row['target']:raise ExcelInputError('الشعبة المطلوبة هي الشعبة الحالية.')
    return dict(row)

def write_sections(path,rows,username,*,options):
    import core
    if Path(path).suffix.lower()!='.xlsx' or (core.ASSET_BASE/'assets').resolve() in Path(path).resolve().parents:raise ExcelInputError('اختر صيغة xlsx.')
    q=lambda n:'{'+NS['m']+'}'+n
    groups=section_options(options);names={};option_rows=[['الصف','لغة التعليم','الشعبة']]
    for index,(key,choices) in enumerate(groups.items(),1):
        start=len(option_rows)+1;option_rows.extend([[*key,choice] for choice in choices])
        names[key]=(f'_SayedSection_{index}',start,len(option_rows))
    refs={}
    for n,row in enumerate(rows,2):
        key=(row['grade'],row['language'])
        if key not in groups or row['source'] not in groups[key]:raise ExcelInputError('شعبة التلميذ غير موجودة في خيارات الصف المسحوبة.')
        refs.setdefault(key,[]).append('D'+str(n))
    def sheet(grid,*,dropdowns=False):
        root=E.Element(q('worksheet'));views=E.SubElement(root,q('sheetViews'));E.SubElement(views,q('sheetView'),workbookViewId='0',rightToLeft='1')
        cols=E.SubElement(root,q('cols'))
        for i,width in enumerate((10,38,22,22,22,20,40),1):E.SubElement(cols,q('col'),min=str(i),max=str(i),width=str(width),customWidth='1')
        body=E.SubElement(root,q('sheetData'))
        for i,values in enumerate(grid,1):
            r=E.SubElement(body,q('row'),r=str(i),ht='48' if i==1 else '23',customHeight='1')
            for j,value in enumerate(values,1):
                c=E.SubElement(r,q('c'),r=column(j)+str(i),t='inlineStr');E.SubElement(E.SubElement(c,q('is')),q('t')).text=str(value)
        if dropdowns and refs:
            validations=E.SubElement(root,q('dataValidations'),count=str(len(refs)))
            for key,cells in refs.items():
                rule=E.SubElement(validations,q('dataValidation'),type='list',allowBlank='1',showDropDown='0',showErrorMessage='1',errorStyle='stop',errorTitle='اختر الشعبة من القائمة',error='اختر إحدى شعب نفس الصف ولغة التعليم.',sqref=' '.join(cells))
                E.SubElement(rule,q('formula1')).text=names[key][0]
        return E.tostring(root,encoding='utf-8',xml_declaration=True)
    grid=[HEADERS]+[['0',r['name'],r['source'],'',r['grade'],r['language'],r['id']] for r in rows]
    parts={'[Content_Types].xml':b'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
    '_rels/.rels':b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    'xl/workbook.xml':('<workbook xmlns="'+NS['m']+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="التشعيب" sheetId="1" r:id="r1"/><sheet name="سياق التشعيب" sheetId="2" r:id="r2"/></sheets></workbook>').encode(),
    'xl/_rels/workbook.xml.rels':b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="r2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>',
    'xl/worksheets/sheet1.xml':sheet(grid,dropdowns=True),'xl/worksheets/sheet2.xml':sheet([['Sayed tech | sections v2',account_key(username)],['الاستخدام','ضع 1 في اختيار واختر الشعبة الجديدة من القائمة. لا تعدّل معرّف التسجيل. الخيارات من نفس الصف واللغة.']]),'xl/worksheets/sheet3.xml':sheet(option_rows)}
    content=E.fromstring(parts['[Content_Types].xml']);E.SubElement(content,'{'+content.tag.split('}')[0][1:]+'}Override',PartName='/xl/worksheets/sheet3.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');parts['[Content_Types].xml']=E.tostring(content)
    book=E.fromstring(parts['xl/workbook.xml']);E.SubElement(book.find(q('sheets')),q('sheet'),name=OPTIONS_SHEET,sheetId='3',state='hidden',attrib={'{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id':'r3'})
    defined=E.SubElement(book,q('definedNames'))
    for name,start,end in names.values():E.SubElement(defined,q('definedName'),name=name).text=f"'{OPTIONS_SHEET}'!$C${start}:$C${end}"
    parts['xl/workbook.xml']=E.tostring(book)
    rels=E.fromstring(parts['xl/_rels/workbook.xml.rels']);E.SubElement(rels,'{http://schemas.openxmlformats.org/package/2006/relationships}Relationship',Id='r3',Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet',Target='worksheets/sheet3.xml');parts['xl/_rels/workbook.xml.rels']=E.tostring(rels)
    _write(parts,path)

def read_sections(path):
    try:
        if Path(path).stat().st_size>64000000:raise ValueError()
        with zipfile.ZipFile(path) as z:
            if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128000000:raise ValueError()
            rows=workbook_rows(z,'التشعيب');context=workbook_rows(z,'سياق التشعيب')
            marker=context[0][1].get('A');groups=None
            if marker=='Sayed tech | sections v2':
                catalog=workbook_rows(z,OPTIONS_SHEET)
                if list(catalog[0][1].values())!=['الصف','لغة التعليم','الشعبة'] or any(f for _,_,f in catalog):raise ValueError()
                groups=section_options([dict(grade=v.get('A',''),language=v.get('B',''),section=v.get('C','')) for _,v,_ in catalog[1:]])
        if marker not in ('Sayed tech | sections v1','Sayed tech | sections v2') or context[0][2] or rows[0][2]:raise ValueError()
        headers={('الشعبة الجديدة' if v=='الشعبة المطلوبة' else v):k for k,v in rows[0][1].items()}
        if len(rows[0][1])!=7 or set(headers)!=set(HEADERS):raise ValueError()
        result=[];seen=set()
        for n,values,formulas in rows[1:]:
            if headers['اختيار'] in formulas:raise ValueError()
            if not selection_value(values.get(headers['اختيار'],'')):continue
            if formulas:raise ValueError()
            row={key:values.get(headers[header],'') for key,header in zip(('grade','language','source','name','target','id'),('الصف','لغة التعليم','الشعبة الحالية','اسم الطالب','الشعبة الجديدة','معرّف التسجيل'))}
            row.update(account=context[0][1].get('B',''),excel_row=n)
            # Selected unchanged rows are displayed as no-ops by the dialog.
            # Keep strict destination validation for actual browser transfers.
            row=validate(row,allow_same=True)
            if groups is not None and (row['source'] not in groups.get((row['grade'],row['language']),[]) or row['target'] not in groups.get((row['grade'],row['language']),[])):raise ExcelInputError(f'الصف {n}: اختر الشعبة الجديدة من قائمة نفس الصف ولغة التعليم.')
            if row['id'] in seen:raise ExcelInputError(f'الصف {n}: التلميذ محدد أكثر من مرة.')
            seen.add(row['id']);result.append(row)
        if not result:raise ExcelInputError('ضع 1 في اختيار للتلاميذ المطلوب نقلهم.')
        return result
    except ExcelInputError:raise
    except Exception:raise ExcelInputError('اختر ملف التشعيب المستخرج من البرنامج بعد تعبئته.') from None
