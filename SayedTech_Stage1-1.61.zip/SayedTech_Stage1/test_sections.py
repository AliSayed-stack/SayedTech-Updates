"""Synthetic section identities, immutable inputs, one move/save and retry gate."""
import tempfile,unittest,threading,copy
from pathlib import Path
from openpyxl import load_workbook
from section_excel import write_sections as write_native_sections,read_sections,account_key,validate,label_text
from section_browser import SectionRunner,SectionError,PATH,WATCH
from student_excel import ExcelInputError
USER='test@te.pm.mehe.school'
def record():return dict(grade='الأول أساسي',language='الفرنسية',source='الشعبة أ',target='الشعبة ب',name='اسم اختبار',id='synthetic-1',account=account_key(USER))
def write_sections(path,rows,user):
    options=[];seen=set()
    for row in rows:
        for choice in (row['source'],row.get('target',row['source'])):
            key=(row['grade'],row['language'],label_text(choice))
            if key not in seen:seen.add(key);options.append(dict(zip(('grade','language','section'),key)))
    return write_native_sections(path,rows,user,options=options)
class Node:
    def __init__(self,p,kind):self.p=p;self.kind=kind
    def count(self):return 1
    def is_visible(self):return True
    def is_enabled(self):return True
    def set_checked(self,value):self.p.checked=value;self.p.actions.append('check')
    def locator(self,s):return self
    def filter(self,**kw):return self
    def get_by_role(self,*args,**kw):return Node(self.p,'move')
    def click(self,**kw):
        self.p.actions.append(self.kind)
        if self.kind=='save' and self.p.save_timeout:raise RuntimeError()
        if self.kind=='save':self.p.saved=True
class Page:
    def __init__(self):self.checked=False;self.saved=False;self.actions=[];self.save_timeout=False;self.toast=True;self.correct_destination=True
    def locator(self,s):return Node(self,'check' if 'data-enrollment-id=' in s else 'scope')
    def get_by_role(self,*args,**kw):return Node(self,'save' if kw.get('name')=='حفظ' else 'heading')
    def evaluate(self,script,arg):
        if script==WATCH:self.actions.append('watch');return
        if 'ok===true' in script:return self.saved and self.toast
        return None
class Runner(SectionRunner):
    def start(self,*args):args[0].actions.append('start')
    def sections_guard(self,*args):pass
    def grade(self,*args):pass
    def wait(self,page,check,guard,code='section_options'):
        value=check()
        if not value:raise SectionError(code)
        return value
    def cards(self,page,guard):
        r=record();source={'language':r['language'],'section':r['source'],'pupils':[]};target={'language':r['language'],'section':r['target'],'pupils':[]}
        pupil={'id':r['id'],'name':r['name'],'checked':page.checked}
        (target if page.saved and page.correct_destination else source)['pupils'].append(pupil)
        return [source,target]
class SectionTests(unittest.TestCase):
    def test_already_at_destination_requires_exact_identity_and_does_not_write_both_shifts(self):
        class Placed(Runner):
            def cards(self,page,guard):
                cards=super().cards(page,guard);cards[1]['pupils']=cards[0]['pupils'];cards[0]['pupils']=[];return cards
        for user in (USER,'test@te.mehe.school'):
            page=Page();runner=Placed();row=dict(record(),account=account_key(user))
            self.assertEqual(runner.transfer(page,user,threading.Event(),row),'section_already')
            self.assertEqual(page.actions,['start']);self.assertEqual(runner.attempted,set())
            for key,value,code in [('name','Different','section_name'),('id','missing','section_pupil_missing'),('language','OTHER','section_language'),('target','OTHER','section_destination')]:
                page=Page()
                with self.assertRaises(SectionError) as error:Placed().transfer(page,user,threading.Event(),dict(row,**{key:value}))
                self.assertEqual(error.exception.code,code);self.assertNotIn('check',page.actions);self.assertNotIn('move',page.actions)
        class Elsewhere(Runner):
            def cards(self,page,guard):
                cards=super().cards(page,guard);cards[0]['section']='الشعبة ج';return cards
        page=Page()
        with self.assertRaises(SectionError) as error:Elsewhere().transfer(page,USER,threading.Event(),record())
        self.assertEqual(error.exception.code,'section_source');self.assertNotIn('check',page.actions)

    def test_new_exports_both_shifts_adjacent_columns_and_live_scoped_dropdowns(self):
        from section_excel import OPTIONS_SHEET,HEADERS
        for user in (USER,'test@te.mehe.school'):
            with self.subTest(user=user),tempfile.TemporaryDirectory() as directory:
                path=Path(directory)/'sections.xlsx';a=record();b=dict(a,id='synthetic-english',language='الإنكليزية',source='الشعبة ب',target='الشعبة ج')
                options=[dict(grade=a['grade'],language=lang,section=section) for lang,choices in [('الفرنسية',['الشعبة أ','الشعبة ب']),('الإنكليزية',['الشعبة ب','الشعبة ج'])] for section in choices]
                write_native_sections(path,[a,b],user,options=options)
                book=load_workbook(path);sheet=book['التشعيب']
                self.assertEqual(tuple(c.value for c in sheet[1]),HEADERS)
                self.assertEqual(tuple(sheet.cell(1,n).value for n in (2,3,4)),('اسم الطالب','الشعبة الحالية','الشعبة الجديدة'))
                self.assertEqual(book[OPTIONS_SHEET].sheet_state,'hidden');self.assertTrue(sheet.sheet_view.rightToLeft)
                rules=list(sheet.data_validations.dataValidation);self.assertEqual(len(rules),2)
                for cell,choices in [('D2',['الشعبة أ','الشعبة ب']),('D3',['الشعبة ب','الشعبة ج'])]:
                    rule=next(r for r in rules if cell in r)
                    self.assertFalse(rule.showDropDown);self.assertTrue(rule.showErrorMessage);self.assertEqual(rule.errorStyle,'stop')
                    name=book.defined_names[rule.formula1];tab,area=next(name.destinations)
                    self.assertEqual([c[0].value for c in book[tab][area]],choices)
                self.assertEqual(sheet.row_dimensions[2].height,23);self.assertIn(sheet['D2'].value,(None,''))
                sheet['A2']='1';sheet['D2']='الشعبة ب';sheet['A3']='1';sheet['D3']='الشعبة ج';book.save(path);book.close()
                before=path.read_bytes();rows=read_sections(path);self.assertEqual(len(rows),2);self.assertEqual(rows[0]['account'],account_key(user));self.assertEqual(path.read_bytes(),before)
                book=load_workbook(path);book['التشعيب']['D2']='الشعبة ج';book.save(path);book.close()
                with self.assertRaises(ExcelInputError):read_sections(path)

    def test_browser_export_keeps_empty_destination_card_in_dropdown(self):
        class ExportRunner(Runner):
            def cards(self,page,guard):return [dict(language='الفرنسية',section='الشعبة أ',pupils=[dict(id='synthetic-1',name='اسم اختبار')]),dict(language='الفرنسية',section='الشعبة ب',pupils=[])]
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sections.xlsx';self.assertEqual(ExportRunner().export(Page(),USER,threading.Event(),path,grade='الأول أساسي'),'section_exported')
            book=load_workbook(path);sheet=book['التشعيب'];rule=next(iter(sheet.data_validations.dataValidation));tab,area=next(book.defined_names[rule.formula1].destinations)
            self.assertEqual([c[0].value for c in book[tab][area]],['الشعبة أ','الشعبة ب']);book.close()

    def test_legacy_filled_workbook_still_reads_with_original_column_order(self):
        import zipfile,xml.etree.ElementTree as E
        from section_excel import LEGACY_HEADERS
        from student_excel import NS
        from student_workflow import column
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'legacy.xlsx';write_sections(path,[record()],USER)
            with zipfile.ZipFile(path) as archive:parts={name:archive.read(name) for name in archive.namelist()}
            q=lambda name:'{'+NS['m']+'}'+name
            sheet=E.fromstring(parts['xl/worksheets/sheet1.xml']);data=sheet.find(q('sheetData'));data.clear();r=record()
            for n,values in enumerate((LEGACY_HEADERS,('1',r['grade'],r['language'],r['source'],r['name'],r['target'],r['id'])),1):
                row=E.SubElement(data,q('row'),r=str(n))
                for j,value in enumerate(values,1):
                    c=E.SubElement(row,q('c'),r=column(j)+str(n),t='inlineStr');E.SubElement(E.SubElement(c,q('is')),q('t')).text=value
            sheet.remove(sheet.find(q('dataValidations')));parts['xl/worksheets/sheet1.xml']=E.tostring(sheet)
            parts['xl/worksheets/sheet2.xml']=parts['xl/worksheets/sheet2.xml'].replace(b'sections v2',b'sections v1')
            with zipfile.ZipFile(path,'w') as archive:
                for name,blob in parts.items():archive.writestr(name,blob)
            before=path.read_bytes();row=read_sections(path)[0]
            self.assertEqual(row['name'],record()['name']);self.assertEqual(row['target'],'الشعبة ب');self.assertEqual(path.read_bytes(),before)

    def test_grade_click_binds_caption_when_optional_chip_shifts_positions(self):
        from unittest.mock import patch
        class Caption:
            def __init__(self,page,role,name,position=None):self.page=page;self.role=role;self.name=name;self.position=position
            def labels(self):
                return [self.page.selected] if self.role=='heading' else self.page.labels
            def matches(self):
                if self.position is not None:return [self.labels()[self.position]]
                return [name for name in self.labels() if self.name.search(name)]
            def count(self):return len(self.matches())
            def is_visible(self):return bool(self.matches())
            def is_enabled(self):return True
            def click(self,**kwargs):
                label=self.matches()[0];self.page.actions.append(label)
                if not self.page.ignore:self.page.selected=label
        class Bar:
            def __init__(self,page):self.page=page
            def count(self):return 1
            def get_by_role(self,role,name):return Caption(self.page,role,name)
        class Dynamic:
            def __init__(self):self.now=0;self.selected='الروضة الثالثة';self.labels=['الروضة الثالثة','الأول أساسي'];self.actions=[];self.ignore=False
            def locator(self,selector):return Bar(self)
            def get_by_role(self,role,name,**kwargs):
                return Caption(self,role,name if hasattr(name,'search') else __import__('re').compile('^'+name+'$'))
            def wait_for_timeout(self,ms):self.now+=ms/1000
            def evaluate(self,script):return [dict(language='الفرنسية',section='الشعبة أ',count=0,open=False,pupils=[])]
        class DynamicRunner(SectionRunner):
            def grade_buttons(self,page,guard):
                # Live nth locators returned by .all() do not retain node identity.
                pairs=[(name,Caption(page,'button',None,i)) for i,name in enumerate(page.labels)]
                if not page.labels[0].startswith('غير'):page.labels.insert(0,'غير موزّعين على شعبة (2)')
                return pairs
        page=Dynamic()
        with patch('section_browser.time.monotonic',lambda:page.now):DynamicRunner().grade(page,'الأول أساسي',lambda:None)
        self.assertEqual(page.actions,['الأول أساسي']);self.assertEqual(page.selected,'الأول أساسي');self.assertGreaterEqual(page.now,.8)
        page=Dynamic();page.ignore=True
        with patch('section_browser.time.monotonic',lambda:page.now),self.assertRaises(SectionError) as error:DynamicRunner().grade(page,'الأول أساسي',lambda:None)
        self.assertEqual(error.exception.code,'section_grade_applied');self.assertEqual(page.actions,['الأول أساسي'])
        page=Dynamic()
        with patch('section_browser.time.monotonic',lambda:page.now),self.assertRaises(SectionError) as error:DynamicRunner().grade(page,'الثاني ثانوي',lambda:None)
        self.assertEqual(error.exception.code,'section_grade_missing');self.assertEqual(page.actions,[])

    def test_grade_caption_regex_ignores_only_display_whitespace_and_direction(self):
        from section_browser import caption_pattern
        pattern=caption_pattern('الأول أساسي')
        for value in ('الأول أساسي','\u200fالأول\u00a0أساسي\u200f','الأول\nأساسي'):
            self.assertIsNotNone(pattern.search(value))
        for value in ('الروضة الثالثة','الاول أساسي','الأول أساسي إضافي'):
            self.assertIsNone(pattern.search(value))

    def test_display_whitespace_normalized_before_target_lookup_and_noop_classification(self):
        original=record();padded=dict(original,target='\u200f  الشعبة\u00a0ب \u200f')
        self.assertEqual(validate(padded)['target'],original['target']);self.assertEqual(padded['target'],'\u200f  الشعبة\u00a0ب \u200f')
        page=Page();runner=Runner()
        self.assertEqual(runner.transfer(page,USER,threading.Event(),padded),'section_saved')
        self.assertEqual(page.actions.count('move'),1);self.assertEqual(page.actions.count('save'),1)
        noop=dict(original,source='الشعبة ب',target='الشعبة ب ')
        self.assertEqual(validate(noop,allow_same=True)['source'],validate(noop,allow_same=True)['target'])
        with self.assertRaises(ExcelInputError):validate(noop)
        for bad in ('الشعبة ج','الشعبة ا'):
            page=Page()
            with self.assertRaises(SectionError):Runner().transfer(page,USER,threading.Event(),dict(original,target=bad))
            self.assertNotIn('move',page.actions)
        with self.assertRaises(ExcelInputError):validate(dict(original,id=' '+original['id']))
        with self.assertRaises(ExcelInputError):validate(dict(original,target='\u200f'))

    def test_spaced_destination_workbook_is_read_without_rewriting(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sections.xlsx';r=record();write_sections(path,[r,dict(r,id='synthetic-2',source='الشعبة ب')],USER)
            book=load_workbook(path);sheet=book['التشعيب']
            for n in (2,3):sheet['A'+str(n)]='1';sheet['D'+str(n)]='الشعبة ب '
            book.save(path);book.close();before=path.read_bytes();rows=read_sections(path)
            self.assertEqual(sum(r['source']!=r['target'] for r in rows),1);self.assertEqual(rows[0]['target'],'الشعبة ب');self.assertEqual(path.read_bytes(),before)

    def test_mixed_selected_workbook_allows_unchanged_rows_but_browser_blocks_noop(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sections.xlsx';first=record();other=dict(first,id='synthetic-2')
            write_sections(path,[first,other],USER)
            book=load_workbook(path);sheet=book['التشعيب']
            sheet['A2']='1';sheet['D2']=first['source'];sheet['A3']='1';sheet['D3']=other['target'];book.save(path);book.close()
            before=path.read_bytes();rows=read_sections(path)
            self.assertEqual(len(rows),2);self.assertEqual(rows[0]['source'],rows[0]['target']);self.assertNotEqual(rows[1]['source'],rows[1]['target']);self.assertEqual(path.read_bytes(),before)
            page=Page();runner=Runner()
            with self.assertRaises(ExcelInputError):runner.transfer(page,USER,threading.Event(),rows[0])
            self.assertEqual(page.actions,[]);self.assertEqual(runner.attempted,set())
            # A selected no-op must still have valid identity and a destination;
            # selected duplicates are still rejected even if one is unchanged.
            book=load_workbook(path);sheet=book['التشعيب'];sheet['G3']=sheet['G2'].value;book.save(path);book.close()
            with self.assertRaises(ExcelInputError):read_sections(path)
            book=load_workbook(path);sheet=book['التشعيب'];sheet['G3']='synthetic-2';sheet['D2']='';book.save(path);book.close()
            with self.assertRaises(ExcelInputError):read_sections(path)

    def test_two_cards_use_locators_that_survive_expansion_state_change(self):
        from unittest.mock import patch
        class LiveLocator:
            def __init__(self,page,selector,index=0):self.page=page;self.selector=selector;self.index=index
            def matches(self):
                return [i for i,state in enumerate(self.page.states) if '="false"' not in self.selector or not state]
            def all(self):return [LiveLocator(self.page,self.selector,i) for i in range(len(self.matches()))]
            def is_visible(self):return self.index<len(self.matches())
            def get_attribute(self,name):
                matches=self.matches()
                return ('true' if self.page.states[matches[self.index]] else 'false') if self.index<len(matches) else None
            def click(self,**kwargs):
                index=self.matches()[self.index];self.page.clicks.append(index);self.page.states[index]=not self.page.states[index]
        class LivePage:
            def __init__(self):self.now=0;self.states=[False,False];self.clicks=[]
            def locator(self,selector):return LiveLocator(self,selector)
            def wait_for_timeout(self,ms):self.now+=ms/1000
            def evaluate(self,script):
                return [dict(language='الفرنسية',section='الشعبة '+str(i),open=state,count=1,pupils=[dict(id='synthetic-'+str(i),name='اسم اختبار',checked=False)] if state else []) for i,state in enumerate(self.states)]
        page=LivePage()
        with patch('section_browser.time.monotonic',lambda:page.now):cards=SectionRunner().cards(page,lambda:None)
        self.assertEqual(page.clicks,[0,1]);self.assertEqual(sum(len(c['pupils']) for c in cards),2)

    def test_export_without_grade_stops_before_navigation_or_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sections.xlsx';page=Page()
            with self.assertRaises(SectionError) as error:Runner().export(page,USER,threading.Event(),path)
            self.assertEqual(error.exception.code,'section_input');self.assertEqual(page.actions,[]);self.assertFalse(path.exists())

    def test_export_waits_for_options_after_title_before_grade_and_cards(self):
        from unittest.mock import patch
        from test_student_save import Page as AccountPage
        for user in ('test@te.mehe.school',USER):
            with self.subTest(user=user),tempfile.TemporaryDirectory() as directory:
                p=AccountPage(user);p.now=0;ready=[float('inf')];original=p.goto
                def goto(*args,**kwargs):
                    original(*args,**kwargs)
                    if p.url.endswith(PATH):ready[0]=p.now+.9
                class Heading:
                    def wait_for(self,**kwargs):p.actions.append(('title',p.now))
                class Search:
                    def count(self):return int(p.now>=ready[0])
                    def is_visible(self):return True
                    def is_enabled(self):return True
                    def fill(self,value):
                        self.assert_ready();p.actions.append(('search',value))
                    def assert_ready(self):
                        if p.now<ready[0]:raise AssertionError('options not loaded')
                class ExportRunner(SectionRunner):
                    def grade_buttons(self,page,guard):
                        guard();return [('الأول أساسي',None)]
                    def grade(self,page,grade,guard):
                        guard();p.actions.append(('grade',grade))
                    def cards(self,page,guard):
                        guard();p.actions.append(('cards','opened'))
                        return [dict(language='الفرنسية',section='الشعبة أ',pupils=[dict(id='synthetic-1',name='اسم اختبار')])]
                p.goto=goto;p.wait_for_timeout=lambda ms:setattr(p,'now',p.now+ms/1000)
                p.get_by_role=lambda *args,**kwargs:Heading();p.get_by_placeholder=lambda *args,**kwargs:Search()
                path=Path(directory)/'sections.xlsx'
                with patch('section_browser.time.monotonic',lambda:p.now):
                    result=ExportRunner().export(p,user,p.cancelled,path,grade='الأول أساسي')
                self.assertEqual(result,'section_exported');self.assertTrue(path.is_file())
                self.assertGreaterEqual(p.now,.9)
                self.assertEqual([a[0] for a in p.actions][-3:],['search','grade','cards'])
                workbook=load_workbook(path);self.assertEqual(workbook['التشعيب']['B2'].value,'اسم اختبار');workbook.close()

    def test_missing_options_times_out_with_search_diagnostic_without_export(self):
        from unittest.mock import patch
        from test_student_save import Page as AccountPage
        p=AccountPage(USER);p.now=0
        class Heading:
            def wait_for(self,**kwargs):pass
        class Missing:
            def count(self):return 0
            def fill(self,value):raise AssertionError('must not fill missing control')
        p.get_by_role=lambda *args,**kwargs:Heading();p.get_by_placeholder=lambda *args,**kwargs:Missing()
        p.wait_for_timeout=lambda ms:setattr(p,'now',p.now+ms/1000)
        with tempfile.TemporaryDirectory() as directory,patch('section_browser.time.monotonic',lambda:p.now):
            path=Path(directory)/'sections.xlsx'
            with self.assertRaises(SectionError) as error:SectionRunner().export(p,USER,p.cancelled,path,grade='الأول أساسي')
            self.assertEqual(error.exception.code,'section_search');self.assertFalse(path.exists())
            self.assertGreaterEqual(p.now,15);self.assertLess(p.now,16)

    def test_production_snapshot_supplied_card_structure_with_synthetic_names(self):
        import subprocess,json
        from lxml import html
        from section_browser import SNAP
        root=Path(__file__).parent/'test_fixtures';doc=html.fromstring((root/'sections_site.html').read_text())
        def tree(e):return dict(tag=e.tag,attrs=dict(e.attrib),text=e.text or '',tail=e.tail or '',children=[tree(c) for c in e if isinstance(c.tag,str)])
        out=subprocess.run(['node',str(root/'dom_runner.js')],input=json.dumps(dict(tree=tree(doc),script=SNAP)),text=True,capture_output=True,check=True)
        cards=__import__('json').loads(out.stdout)
        self.assertEqual(len(cards),3);self.assertEqual(cards[0]['pupils'],[dict(id='synthetic-1',name='اسم اختبار',checked=False)])
        self.assertEqual(cards[1]['pupils'],[]);self.assertEqual(cards[2]['language'],'الإنكليزية');self.assertTrue(cards[2]['pupils'][0]['checked'])

    def test_start_waits_for_account_after_each_navigation_then_opens_sections(self):
        from unittest.mock import patch
        from test_student_save import Page as AccountPage
        p=AccountPage(USER);p.now=0;original=p.goto;ready=[0]
        def goto(*args,**kwargs):
            original(*args,**kwargs);p.email_visible=False;ready[0]=p.now+.3
        def wait(ms):
            p.now+=ms/1000
            if p.now>=ready[0]:p.email_visible=True
        class Control:
            def wait_for(self,**kwargs):pass
            def count(self):return 1
            def is_visible(self):return True
            def is_enabled(self):return True
            def fill(self,value):p.actions.append(('search',value))
        p.goto=goto;p.wait_for_timeout=wait;p.get_by_role=lambda *args,**kwargs:Control();p.get_by_placeholder=lambda *args,**kwargs:Control()
        with patch('student_start.time.monotonic',lambda:p.now):SectionRunner().start(p,USER,p.cancelled,None)
        self.assertTrue(p.url.endswith(PATH));self.assertEqual(len([a for a in p.actions if a[0]=='goto']),2);self.assertGreaterEqual(p.now,.6)
        self.assertEqual(p.actions[-1],('search',''))

    def test_grade_bar_excludes_unrelated_round_buttons_using_production_xpath(self):
        from lxml import html
        from test_scan_grade_trigger import Elements
        root=html.fromstring((Path(__file__).parent/'test_fixtures/sections_site.html').read_text())
        class DOM:
            def locator(self,selector):return Elements(self,root.xpath(selector[6:]))
        labels=[name for name,_ in Runner().grade_buttons(DOM(),lambda:None)]
        self.assertEqual(labels,['الروضة الثالثة','الأول أساسي','الثاني أساسي','الثالث أساسي','الرابع أساسي','الخامس أساسي','السادس أساسي'])
        self.assertNotIn('حساب المدرسة',labels)

    def test_cards_wait_for_expansion_without_clicking_again_and_closing(self):
        from unittest.mock import patch
        class Delayed:
            now=0;clicks=0;opening=None
            def locator(self,selector):return self
            def all(self):return [self]
            def is_visible(self):return True
            def click(self,**kwargs):self.clicks+=1;self.opening=self.now+.4
            def get_attribute(self,name):return 'true' if self.opening is not None and self.now>=self.opening else 'false'
            def wait_for_timeout(self,ms):self.now+=ms/1000
            def evaluate(self,script):return [dict(language='الفرنسية',section='الشعبة أ',open=True,count=1,pupils=[dict(id='synthetic-1',name='اسم اختبار',checked=False)])]
        p=Delayed()
        with patch('section_browser.time.monotonic',lambda:p.now):rows=SectionRunner().cards(p,lambda:None)
        self.assertEqual(p.clicks,1);self.assertGreaterEqual(p.now,.4);self.assertEqual(len(rows[0]['pupils']),1)

    def test_workbook_selected_identity_preserved_and_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'sections.xlsx';write_sections(p,[record()],USER)
            with self.assertRaises(ExcelInputError):read_sections(p)
            b=load_workbook(p);s=b['التشعيب'];s['A2']='1';s['D2']='الشعبة ب';b.save(p);b.close();before=p.read_bytes()
            r=read_sections(p)[0];self.assertEqual(r['id'],'synthetic-1');self.assertEqual(r['account'],account_key(USER));self.assertEqual(p.read_bytes(),before)
            b=load_workbook(p);s=b['التشعيب']
            for i in range(1,8):s.cell(3,i,s.cell(2,i).value)
            b.save(p);b.close()
            with self.assertRaises(ExcelInputError):read_sections(p)
    def test_move_then_save_and_fresh_success_then_server_readback(self):
        p=Page();runner=Runner();self.assertEqual(runner.transfer(p,USER,threading.Event(),record()),'section_saved')
        self.assertEqual(p.actions,['start','check','move','watch','save','start'])
        with self.assertRaises(SectionError) as e:runner.transfer(p,USER,threading.Event(),record())
        self.assertEqual(e.exception.code,'section_uncertain');self.assertEqual(p.actions.count('save'),1)
    def test_account_or_identity_mismatch_no_move(self):
        for key,value in (('account',account_key('other@te.pm.mehe.school')),('id','another'),('name','OTHER'),('source','OTHER'),('language','OTHER'),('target','OTHER')):
            p=Page();r=record();r[key]=value
            with self.assertRaises(SectionError):Runner().transfer(p,USER,threading.Event(),r)
            self.assertNotIn('move',p.actions)
    def test_missing_success_timeout_or_bad_readback_block_retry(self):
        for key in ('toast','save_timeout','correct_destination'):
            p=Page();setattr(p,key,key=='save_timeout');runner=Runner()
            with self.assertRaises(SectionError) as e:runner.transfer(p,USER,threading.Event(),record())
            self.assertEqual(e.exception.code,'section_unknown')
            with self.assertRaises(SectionError) as e:runner.transfer(p,USER,threading.Event(),record())
            self.assertEqual(e.exception.code,'section_uncertain');self.assertEqual(p.actions.count('save'),1)
    def test_existing_checked_pupil_blocks_before_move(self):
        p=Page();p.checked=True
        with self.assertRaises(SectionError):Runner().transfer(p,USER,threading.Event(),record())
        self.assertNotIn('move',p.actions)
