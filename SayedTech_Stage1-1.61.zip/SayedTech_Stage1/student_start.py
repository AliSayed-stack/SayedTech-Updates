"""One explicit student command starts from a clean management page."""
import re,time
from urllib.parse import urlsplit
from login_flow import exact_https_host,SIMS_HOST,visible
from student_fill import StudentFillError,MANAGEMENT


def verify_dashboard_account(page,username,cancelled,account_session=None,*,wait=False):
    deadline=time.monotonic()+15
    while True:
        if cancelled.is_set():raise StudentFillError('student_cancelled')
        if (not exact_https_host(page.url,SIMS_HOST) or not urlsplit(page.url).path.startswith('/dashboard/') or
                (account_session is not None and account_session.revoked)):
            raise StudentFillError('student_account_required')
        caption=visible(page.get_by_text(re.compile(r'^\s*'+re.escape(username)+r'\s*$',re.I)))
        if caption is not None:return
        if account_session is not None and account_session.allows(page,username):return
        if account_session is not None and account_session.revoked:raise StudentFillError('student_account_required')
        if not wait or time.monotonic()>=deadline:raise StudentFillError('student_account_required')
        page.wait_for_timeout(100)


def reset_management(page,username,cancelled,account_session=None):
    verify_dashboard_account(page,username,cancelled,account_session)
    try:
        # Intentional even at management: remove an old search/modal/filter/page.
        page.goto('https://'+SIMS_HOST+MANAGEMENT,wait_until='domcontentloaded',timeout=20000)
    except Exception:raise StudentFillError('student_open_management') from None
    if urlsplit(page.url).path.rstrip('/')!=MANAGEMENT:raise StudentFillError('student_open_management')
    verify_dashboard_account(page,username,cancelled,account_session,wait=True)
