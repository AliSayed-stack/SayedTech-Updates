"""Sections UI only: one selected enrollment, move here, Save, fresh success."""
import re,time
from urllib.parse import urlsplit
from section_excel import account_key,validate,write_sections,label_text
from student_start import reset_management,verify_dashboard_account
from student_fill import StudentFillError
from login_flow import exact_https_host,SIMS_HOST,visible
PATH='/dashboard/students/sections'
GRADE_BAR='xpath=//div'+''.join('[contains(concat(" ",normalize-space(@class)," ")," '+c+' ")]' for c in ('flex','gap-2','overflow-x-auto','pb-1'))
EVENTS={'section_exported','section_saved','section_account','section_options','section_search','section_grades','section_grade_missing','section_grade_click','section_grade_applied','section_cards','section_rows','section_identity','section_unknown','section_uncertain','section_failed','section_input','section_busy'}
EVENTS.update({'section_already','section_pupil_missing','section_pupil_ambiguous','section_destination','section_name','section_language','section_source','section_locked'})
def caption_pattern(value):
    marks='[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]*'
    space=r'[\s\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
    words=[marks.join(re.escape(c) for c in word) for word in label_text(value).split()]
    return re.compile('^'+space+'*'+(space+'+').join(words)+space+'*$')
class SectionError(Exception):
    def __init__(self,code):self.code=code

SNAP=r'''() => {
 const shown=e=>!!e.getClientRects().length;
 const txt=e=>(e?.textContent||'').replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g,'').replace(/\s+/g,' ').trim();
 return [...document.querySelectorAll('section')].filter(shown).flatMap(s=>{
 const language=txt(s.querySelector('h3'));
 return [...s.querySelectorAll('button[aria-expanded]')].filter(shown).map(b=>{
 const card=b.parentElement;
 return {language,section:txt(b.querySelector('span')),count:Number([...b.querySelectorAll('span')].map(txt).find(t=>/^[0-9]+$/.test(t))??NaN),open:b.getAttribute('aria-expanded')==='true',
 pupils:[...card.querySelectorAll('label[data-enrollment-id]')].filter(shown).map(l=>({id:l.getAttribute('data-enrollment-id'),name:txt(l.querySelector('span')),checked:!!l.querySelector('input[type=checkbox]')?.checked}))};});
 })}'''
WATCH=r'''key=>{const sel='.Toastify__toast--success';const seen=new WeakSet(document.querySelectorAll(sel));const state={ok:false};
 const inspect=()=>document.querySelectorAll(sel).forEach(e=>{if(seen.has(e)||!e.getClientRects().length)return;const c=e.cloneNode(true);c.querySelectorAll('button,svg,.Toastify__toast-icon,.Toastify__progress-bar--wrp').forEach(n=>n.remove());if(c.textContent.trim()==='تم نقل طالب واحد.')state.ok=true;});
 const o=new MutationObserver(inspect);o.observe(document.body,{subtree:true,childList:true,characterData:true});state.stop=()=>o.disconnect();window[key]=state;}'''

class SectionRunner:
    def __init__(self):self.attempted=set()
    def guard(self,page,user,cancel,session):
        if cancel.is_set() or not exact_https_host(page.url,SIMS_HOST) or (session is not None and session.revoked):raise SectionError('section_account')
        if visible(page.get_by_text(re.compile(r'^\s*'+re.escape(user)+r'\s*$',re.I))) is None and not(session is not None and session.allows(page,user)):raise SectionError('section_account')
    def start(self,page,user,cancel,session):
        try:reset_management(page,user,cancel,session)
        except StudentFillError as exc:
            raise SectionError('section_options' if exc.code=='student_open_management' else 'section_account') from None
        self.guard(page,user,cancel,session);page.goto('https://'+SIMS_HOST+PATH,wait_until='domcontentloaded',timeout=20000)
        try:verify_dashboard_account(page,user,cancel,session,wait=True)
        except StudentFillError:raise SectionError('section_account') from None
        if urlsplit(page.url).path.rstrip('/')!=PATH:raise SectionError('section_options')
        page.get_by_role('heading',name='الشعب',exact=True).wait_for(state='visible',timeout=10000)
        search=page.get_by_placeholder('ابحث عن طالب بالاسم أو الرقم',exact=True)
        # The page title renders before asynchronous year/section options.
        # Search and grade chips mount only once those options have arrived.
        guard=lambda:self.sections_guard(page,user,cancel,session)
        self.wait(page,lambda:search.count()==1 and search.is_visible() and search.is_enabled(),guard,'section_search')
        guard()
        search.fill('')
    def sections_guard(self,page,user,cancel,session):
        self.guard(page,user,cancel,session)
        if urlsplit(page.url).path.rstrip('/')!=PATH:raise SectionError('section_options')
    def wait(self,page,check,guard,code='section_options'):
        end=time.monotonic()+15
        while time.monotonic()<end:
            guard();value=check()
            if value:return value
            page.wait_for_timeout(100)
        raise SectionError(code)
    def grade_buttons(self,page,guard):
        def ready():
            bars=[b for b in page.locator(GRADE_BAR).all() if b.is_visible()]
            if len(bars)!=1:return None
            buttons=[b for b in bars[0].locator('xpath=./button[@type="button"]').all() if b.is_visible()]
            labels=[label_text(b.inner_text()) for b in buttons]
            if not labels or len(labels)>50 or any(not g for g in labels) or len(set(labels))!=len(labels):return None
            return list(zip(labels,buttons))
        return self.wait(page,ready,guard,'section_grades')
    def grade(self,page,grade,guard):
        # Enumerate for readiness, but never retain a position-based nth locator:
        # optional chips (e.g. unassigned) may shift those positions on render.
        self.grade_buttons(page,guard)
        bars=page.locator(GRADE_BAR)
        if bars.count()!=1:raise SectionError('section_grades')
        pattern=caption_pattern(grade)
        button=bars.get_by_role('button',name=pattern)
        if button.count()!=1 or not button.is_visible() or not button.is_enabled():raise SectionError('section_grade_missing')
        guard()
        try:button.click(timeout=5000)
        except Exception:raise SectionError('section_grade_click') from None
        heading=page.get_by_role('heading',name=pattern)
        self.wait(page,lambda:heading.count()==1 and heading.is_visible(),guard,'section_grade_applied')
        # Heading and inventory must stay on the requested grade together.
        last=None;since=time.monotonic()
        def ready():
            nonlocal last,since
            if heading.count()!=1 or not heading.is_visible():last=None;since=time.monotonic();return None
            now=page.evaluate(SNAP)
            if now!=last:last=now;since=time.monotonic()
            return now if now and time.monotonic()-since>=.8 else None
        self.wait(page,ready,guard,'section_cards')
    def cards(self,page,guard):
        # Keep the locator independent of the changing expanded value. A locator
        # ending in [aria-expanded=false] stops matching immediately after click,
        # so waiting on it can observe the next closed card or no card at all.
        guard();buttons=[b for b in page.locator('section button[aria-expanded]').all() if b.is_visible()]
        if not buttons or len(buttons)>100:raise SectionError('section_cards')
        for button in buttons:
            guard()
            state=button.get_attribute('aria-expanded')
            if state=='true':continue
            if state!='false':raise SectionError('section_cards')
            button.click(timeout=5000)
            self.wait(page,lambda:button.get_attribute('aria-expanded')=='true',guard,'section_cards')
        def complete():
            data=page.evaluate(SNAP)
            return data if data and all(isinstance(c.get('count'),int) and c['count']==len(c['pupils']) for c in data) else None
        rows=self.wait(page,complete,guard,'section_rows')
        if not rows or len({(r['language'],r['section']) for r in rows})!=len(rows) or any(not r['open'] for r in rows):raise SectionError('section_options')
        return rows
    def grades(self,page,user,cancel,session=None):
        self.start(page,user,cancel,session)
        return [name for name,_ in self.grade_buttons(page,lambda:self.sections_guard(page,user,cancel,session))]
    def export(self,page,user,cancel,path,session=None,*,grade=''):
        if not isinstance(grade,str) or not grade.strip() or len(grade)>150:raise SectionError('section_input')
        self.start(page,user,cancel,session);guard=lambda:self.sections_guard(page,user,cancel,session)
        # Export only the explicitly selected live grade; never fall back to all.
        records=[];seen=set()
        self.grade(page,grade,guard)
        cards=self.cards(page,guard)
        options=[dict(grade=grade,language=c['language'],section=c['section']) for c in cards]
        for card in cards:
            for pupil in card['pupils']:
                if pupil['id'] in seen:raise SectionError('section_identity')
                seen.add(pupil['id']);records.append(dict(grade=grade,language=card['language'],source=card['section'],name=pupil['name'],id=pupil['id']))
        if not records or len(records)>5000:raise SectionError('section_identity')
        guard();write_sections(path,records,user,options=options);return 'section_exported'
    def transfer(self,page,user,cancel,raw,session=None):
        row=validate(raw)
        if row['account']!=account_key(user):raise SectionError('section_account')
        key=(row['account'],row['id'])
        if key in self.attempted:raise SectionError('section_uncertain')
        self.start(page,user,cancel,session);guard=lambda:self.sections_guard(page,user,cancel,session)
        self.grade(page,row['grade'],guard);cards=self.cards(page,guard)
        matches=[(c,p) for c in cards for p in c['pupils'] if p['id']==row['id']]
        targets=[c for c in cards if c['language']==row['language'] and c['section']==row['target']]
        if not matches:raise SectionError('section_pupil_missing')
        if len(matches)!=1:raise SectionError('section_pupil_ambiguous')
        source,pupil=matches[0]
        if pupil['name']!=row['name']:raise SectionError('section_name')
        if source['language']!=row['language']:raise SectionError('section_language')
        if len(targets)!=1:raise SectionError('section_destination')
        if source['section']==row['target']:
            guard();return 'section_already'
        if source['section']!=row['source']:raise SectionError('section_source')
        if any(p['checked'] for c in cards for p in c['pupils']):raise SectionError('section_options')
        checkbox=page.locator('label[data-enrollment-id="'+row['id']+'"] input[type="checkbox"]')
        if checkbox.count()!=1:raise SectionError('section_locked')
        guard();checkbox.set_checked(True)
        rows=self.cards(page,guard)
        if [p['id'] for c in rows for p in c['pupils'] if p['checked']]!=[row['id']]:raise SectionError('section_identity')
        repeated=[(c,p) for c in rows for p in c['pupils'] if p['id']==row['id']]
        if len(repeated)!=1 or repeated[0][0]['section']!=row['source'] or repeated[0][0]['language']!=row['language'] or repeated[0][1]['name']!=row['name']:raise SectionError('section_identity')
        language=page.locator('section').filter(has=page.get_by_role('heading',name=row['language'],exact=True))
        # Exact supplied card parent, avoiding outer divs containing other cards.
        target=language.locator('button[aria-expanded]').filter(has_text=re.compile('^'+re.escape(row['target'])+r'\s*\d+\s*طالب$')).locator('..')
        move=target.get_by_role('button',name='انقل إلى هنا',exact=True)
        if move.count()!=1 or not move.is_enabled():raise SectionError('section_options')
        guard();self.attempted.add(key);watch='__sayed_sections';armed=False
        try:
            move.click(timeout=5000)
            save=page.get_by_role('button',name='حفظ',exact=True)
            self.wait(page,lambda:save.count()==1 and save.is_visible() and save.is_enabled(),guard)
            page.evaluate(WATCH,watch);armed=True;guard();save.click(timeout=5000)
            self.wait(page,lambda:page.evaluate('key=>window[key]?.ok===true',watch),guard)
            # Fresh server view must show the same enrollment at destination.
            self.start(page,user,cancel,session);self.grade(page,row['grade'],guard);cards=self.cards(page,guard)
            found=[(c,p) for c in cards for p in c['pupils'] if p['id']==row['id']]
            if len(found)!=1 or found[0][0]['language']!=row['language'] or found[0][0]['section']!=row['target'] or found[0][1]['name']!=row['name']:raise SectionError('section_unknown')
            return 'section_saved'
        except Exception:raise SectionError('section_unknown') from None
        finally:
            if armed:
                try:page.evaluate('key=>{window[key]?.stop();delete window[key]}',watch)
                except Exception:pass
