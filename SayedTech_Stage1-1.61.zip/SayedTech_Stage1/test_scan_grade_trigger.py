"""Production XPath on supplied trigger/menu HTML; synthetic surrounding DOM."""
import copy
from pathlib import Path
import threading
import unittest
from unittest.mock import patch
from lxml import html
from student_scan import StudentBrowser, ScanError
from test_scan_grade_menu import DelayedPage, ALL


class Elements:
    def __init__(self,page,nodes):self.page,self.nodes=page,nodes
    def all(self):return [Elements(self.page,[n]) for n in self.nodes]
    def locator(self,selector):
        expr=selector[6:] if selector.startswith('xpath=') else './/'+selector
        return Elements(self.page,[e for n in self.nodes for e in n.xpath(expr)])
    def is_visible(self):
        return bool(self.nodes) and not any('hidden' in n.attrib for n in [self.nodes[0],*self.nodes[0].iterancestors()])
    def is_enabled(self):return 'disabled' not in self.nodes[0].attrib
    def get_attribute(self,name):return self.nodes[0].get(name)
    def inner_text(self):return self.nodes[0].text_content()
    def click(self,**kwargs):
        node=self.nodes[0]
        if node is self.page.trigger:
            self.page.actions.append(('trigger',))
            if 'hidden' in self.page.overlay.attrib:self.page.overlay.attrib.pop('hidden')
            else:self.page.overlay.set('hidden','')
        elif node in self.page.menu.xpath('./button'):
            caption=self.inner_text().strip()
            self.page.trigger.xpath('./span')[0].text=caption
            self.page.grade=None if caption==ALL else caption
            self.page.overlay.set('hidden','');self.page.actions.append(('grade',caption))
        else:raise AssertionError('Unexpected click')


class TriggerPage(DelayedPage):
    def __init__(self,username='test@te.mehe.school'):
        super().__init__(username)
        self.root=html.fromstring((Path(__file__).parent/'test_fixtures/grade_trigger_site.html').read_bytes())
        self.trigger=self.root.xpath('//div[@class="field"]//button')[0]
        self.menu=self.root.xpath('//div[@class="max-h-60 overflow-y-auto"]')[0]
        self.overlay=self.menu.getparent()
    def locator(self,selector):
        if selector.startswith('xpath='):return Elements(self,self.root.xpath(selector[6:]))
        if selector=='div.max-h-60.overflow-y-auto':return Elements(self,self.root.xpath('//div[@class="max-h-60 overflow-y-auto"]'))
        return super().locator(selector)


class GradeTriggerTests(unittest.TestCase):
    def browser(self,page):return StudentBrowser(page,page.account,threading.Event())

    def test_unlabelled_trigger_opens_and_selects_using_actual_html_for_both_shifts(self):
        for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
            page=TriggerPage(user)
            label=page.root.xpath('//span[normalize-space(.)="الصف"]')[0]
            label.getparent().remove(label)
            # This supplied button has no aria-expanded and no nearby span "الصف".
            self.assertIsNone(page.trigger.get('aria-expanded'))
            self.assertEqual(page.root.xpath('//span[normalize-space(.)="الصف"]'),[])
            with patch('student_scan.time.monotonic',lambda:page.now):
                self.browser(page).select_grade('الخامس أساسي')
            self.assertEqual(page.actions,[('trigger',),('grade','الخامس أساسي')])
            self.assertIn('hidden',page.overlay.attrib)

    def test_supplied_label_wrapper_and_selected_check_for_every_grade_both_shifts(self):
        for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
            for wanted in ('الروضة الأولى','الروضة الثانية','الروضة الثالثة','الأول أساسي',
                           'الثاني أساسي','الثالث أساسي','الرابع أساسي','الخامس أساسي','السادس أساسي'):
                page=TriggerPage(user)
                check=page.menu.xpath('.//svg')[0];check.getparent().remove(check)
                page.menu.xpath('./button[span="الرابع أساسي"]')[0].append(check)
                page.trigger.xpath('./span')[0].text='الرابع أساسي';page.grade='الرابع أساسي'
                page.overlay.attrib.pop('hidden')
                with patch('student_scan.time.monotonic',lambda:page.now):
                    self.browser(page).select_grade(wanted)
                self.assertEqual(page.grade,wanted)
                self.assertIn('hidden',page.overlay.attrib)
                self.assertEqual(len(page.actions),1)

    def test_unrelated_open_filter_cannot_block_grade_open_or_closure(self):
        for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
            page=TriggerPage(user)
            other=html.fromstring('<div class="max-h-60 overflow-y-auto"><button>جميع الشعب</button><button>الشعبة أ</button></div>')
            page.root.append(other)
            with patch('student_scan.time.monotonic',lambda:page.now):
                self.browser(page).select_grade('الروضة الثانية')
            self.assertEqual(page.actions,[('trigger',),('grade','الروضة الثانية')])
            self.assertNotIn('hidden',other.attrib)

    def test_listing_supplied_options_closes_same_trigger_without_grade_change(self):
        page=TriggerPage()
        with patch('student_scan.time.monotonic',lambda:page.now):grades=self.browser(page).grades()
        self.assertEqual(len(grades),9);self.assertIn('الخامس أساسي',grades)
        self.assertEqual(page.actions,[('trigger',),('trigger',)])
        self.assertEqual(page.trigger.xpath('./span')[0].text,ALL)

    def test_selected_caption_and_open_menu_do_not_bind_option_as_trigger(self):
        page=TriggerPage();page.trigger.xpath('./span')[0].text='الخامس أساسي'
        page.overlay.attrib.pop('hidden')
        with patch('student_scan.time.monotonic',lambda:page.now):self.browser(page).select_grade('الخامس أساسي')
        self.assertEqual(page.actions,[('trigger',)])

    def test_duplicate_triggers_fail_without_clicking(self):
        page=TriggerPage();page.root.append(copy.deepcopy(page.root.xpath('//div[@class="field"]')[0]))
        with self.assertRaises(ScanError) as caught:self.browser(page).grade_button()
        self.assertEqual(caught.exception.reason,'grade_filter');self.assertEqual(page.actions,[])

    def test_supplied_label_disambiguates_an_unrelated_grade_caption_button(self):
        page=TriggerPage();page.root.append(copy.deepcopy(page.trigger))
        self.assertIs(self.browser(page).grade_button().nodes[0],page.trigger)

    def test_hidden_duplicate_is_ignored(self):
        page=TriggerPage();duplicate=copy.deepcopy(page.trigger);duplicate.set('hidden','');page.root.append(duplicate)
        self.assertIs(self.browser(page).grade_button().nodes[0],page.trigger)

    def test_missing_trigger_reports_filter_not_options_after_bounded_wait(self):
        page=TriggerPage();page.trigger.getparent().remove(page.trigger)
        with patch('student_scan.time.monotonic',lambda:page.now),self.assertRaises(ScanError) as caught:
            self.browser(page).open_grades()
        self.assertEqual(caught.exception.reason,'grade_filter');self.assertEqual(page.actions,[])


if __name__=='__main__':unittest.main()
