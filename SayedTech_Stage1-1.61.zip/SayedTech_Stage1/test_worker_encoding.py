"""Real JSON bytes through Windows-codepage pipes; no account/site access."""
import ast
import io
import json
from pathlib import Path
import threading
import unittest
from unittest.mock import patch

import login_worker
from student_scan import StudentBrowser,ScanError
from test_scan_grade_menu import DelayedPage

GRADE='الروضة الأولى'
REQUEST='a'*32


def controller_call(name,*args,**kwargs):
    # Execute the production Qt method with a pipe sink without requiring Qt.
    tree=ast.parse(Path(__file__).with_name('login_controller.py').read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='LoginController')
    method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    namespace={'json':json}
    exec(compile(ast.Module(body=[method],type_ignores=[]),'login_controller.py','exec'),namespace)
    class Sink:
        def write(self,data):self.data=data;return len(data)
    class Controller:
        process=Sink()
        def running(self):return True
    c=Controller();assert namespace[name](c,*args,**kwargs)
    return c.process.data


class WorkerEncodingTests(unittest.TestCase):
    def pipes(self,data,encoding):
        return io.TextIOWrapper(io.BytesIO(data),encoding=encoding),io.TextIOWrapper(io.BytesIO(),encoding=encoding)

    def test_old_locale_read_reproduces_missing_grade_but_explicit_utf8_selects_both_shifts(self):
        raw=controller_call('scan_students','C:/اختبار/طلاب.xlsx',0,REQUEST,GRADE)
        for encoding in ('cp1256','cp1252'):
            for user in ('test@te.mehe.school','test@te.pm.mehe.school'):
                stream,out=self.pipes(raw,encoding)
                try:
                    corrupted=json.loads(stream.readline())['grade']
                    self.assertNotEqual(corrupted,GRADE)
                    page=DelayedPage(user)
                    with patch('student_scan.time.monotonic',lambda:page.now),self.assertRaises(ScanError) as error:
                        StudentBrowser(page,user,threading.Event()).select_grade(corrupted)
                    self.assertEqual(error.exception.reason,'grade_target_missing')
                    self.assertFalse(any(a[0]=='grade' for a in page.actions))
                finally:stream.close();out.close()
                stream,out=self.pipes(raw,encoding)
                try:
                    with patch.object(login_worker.sys,'stdin',stream),patch.object(login_worker.sys,'stdout',out):
                        login_worker.configure_protocol_streams()
                        restored=json.loads(stream.readline())
                    self.assertEqual(restored['grade'],GRADE)
                    self.assertEqual(restored['path'],'C:/اختبار/طلاب.xlsx')
                    page=DelayedPage(user)
                    with patch('student_scan.time.monotonic',lambda:page.now):
                        StudentBrowser(page,user,threading.Event()).select_grade(restored['grade'])
                    self.assertEqual(page.grade,GRADE)
                    self.assertEqual([a for a in page.actions if a[0]=='grade'],[('grade',GRADE)])
                finally:stream.close();out.close()

    def test_real_controller_commands_preserve_arabic_and_birth_without_rewriting(self):
        record={'name':'اسم اختبار تجريبي','birth':'2014/08/01','grade':GRADE,'notes':'سطر أول\nسطر ثانٍ'}
        calls=[('fill_details',(record,'الهواتف',REQUEST),{}),
               ('fill_student',(record,REQUEST),{'entry_kind':'طالب جديد من البيت'}),
               ('check_student',(record,REQUEST,'b'*32),{}),
               ('sections',('section_import',REQUEST),{'record':dict(record,target='الشعبة ب')}),
               ('attendance',('attendance_import',REQUEST),{'record':dict(record,reason='عذر مقبول')})]
        for name,args,kwargs in calls:
            raw=controller_call(name,*args,**kwargs);expected=json.loads(raw.decode('utf-8'))
            stream,out=self.pipes(raw,'cp1256')
            try:
                with patch.object(login_worker.sys,'stdin',stream),patch.object(login_worker.sys,'stdout',out):
                    login_worker.configure_protocol_streams();actual=json.loads(stream.readline())
                self.assertEqual(actual,expected)
                self.assertEqual(actual['record']['birth'],'2014/08/01')
                self.assertEqual(actual['record']['name'],record['name'])
            finally:stream.close();out.close()

    def test_run_configures_before_first_read_without_launching_browser(self):
        class FirstRead(io.TextIOWrapper):
            def readline(self,*args):
                self.assertion(self.encoding.lower().replace('_','-')=='utf-8')
                return super().readline(*args)
        stream=FirstRead(io.BytesIO(b'{}\n'),encoding='cp1256');stream.assertion=self.assertTrue
        out=io.TextIOWrapper(io.BytesIO(),encoding='cp1256')
        try:
            with patch.object(login_worker.sys,'stdin',stream),patch.object(login_worker.sys,'stdout',out),patch.object(login_worker,'LoginFlow') as flow:
                self.assertEqual(login_worker.run(),2)
                flow.assert_not_called()
                out.flush();out.buffer.seek(0);reply=json.loads(out.buffer.read().decode('utf-8'))
            self.assertEqual(reply,{'event':'invalid_input'})
        finally:stream.close();out.close()

    def test_multiple_lines_and_fixed_output_survive_the_same_pipe(self):
        raw=json.dumps({'username':'test@te.mehe.school','password':'اختبار فقط'}).encode('ascii')+b'\n'
        raw+=controller_call('scan_students','C:/اختبار.xlsx',0,REQUEST,GRADE)+b'cancel\n'
        stream,out=self.pipes(raw,'cp1252')
        try:
            with patch.object(login_worker.sys,'stdin',stream),patch.object(login_worker.sys,'stdout',out):
                login_worker.configure_protocol_streams()
                self.assertEqual(json.loads(stream.readline())['password'],'اختبار فقط')
                self.assertEqual(json.loads(stream.readline())['grade'],GRADE)
                self.assertEqual(stream.readline(),'cancel\n')
                login_worker.emit_scan('scan_grades',REQUEST,detail={'grades':[GRADE]})
                out.flush();out.buffer.seek(0);reply=json.loads(out.buffer.read().decode('utf-8'))
            self.assertEqual(reply['detail'],{'grades':[GRADE]})
        finally:stream.close();out.close()

    def test_missing_stream_returns_before_read_or_browser(self):
        with patch.object(login_worker.sys,'stdin',None),patch.object(login_worker,'LoginFlow') as flow:
            self.assertEqual(login_worker.run(),2);flow.assert_not_called()

    def test_invalid_utf8_is_rejected_without_replacement_or_browser(self):
        stream,out=self.pipes(b'{"grade":"\xff"}\n','cp1256')
        try:
            with patch.object(login_worker.sys,'stdin',stream),patch.object(login_worker.sys,'stdout',out),patch.object(login_worker,'LoginFlow') as flow:
                self.assertEqual(login_worker.run(),2);flow.assert_not_called()
                out.flush();out.buffer.seek(0)
                self.assertEqual(json.loads(out.buffer.read()),{'event':'invalid_input'})
        finally:stream.close();out.close()


if __name__=='__main__':unittest.main()
