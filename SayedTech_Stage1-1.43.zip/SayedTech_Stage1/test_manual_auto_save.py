import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
from detailed_import import fill_details,read_details
from manual_sections import TAIL_HEADERS,SELECT,SPECS
from student_scan import export_students
import test_manual_sections as manual_tests
from test_detailed_import import Page


class AutomaticDocumentSaveTests(unittest.TestCase):
    def invoke(self,page,row,section):
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,section,'school@te.mehe.school',threading.Event())

    def test_both_document_sections_save_after_filling_without_attachment_payload(self):
        for title in ('بطاقات التعريف','المستندات'):
            with self.subTest(title=title):
                page=Page();row={'values':page.values.copy(),'manual':{title+' / نوع المستند':'هوية',title+' / رقم الوثيقة':'00123'}}
                events=[]
                def fill(*args):events.append('fill');return 'detail_filled'
                def save(*args):events.append('save');return 'detail_saved'
                with patch('manual_sections.fill_manual_section',side_effect=fill) as entered,patch('manual_save.save_manual',side_effect=save) as saved:
                    self.assertEqual(self.invoke(page,row,'manual:'+title),'detail_saved')
                self.assertEqual(events,['fill','save']);entered.assert_called_once();saved.assert_called_once()

    def test_empty_sections_and_old_attachment_columns_only_do_not_trigger_save(self):
        for title in ('بطاقات التعريف','المستندات'):
            page=Page();row={'values':page.values.copy(),'manual':{title+' / مسار الملف':'C:\\missing.pdf'}}
            with patch('manual_sections.fill_manual_section') as entered,patch('manual_save.save_manual') as saved:
                self.assertEqual(self.invoke(page,row,'manual:'+title),'detail_no_data')
                entered.assert_not_called();saved.assert_not_called()
            self.assertEqual(page.actions,[])

    def test_removed_columns_absent_and_older_workbooks_still_import(self):
        _,data=manual_tests.ManualWorkbookTests().data()
        removed=[title+' / '+name for title in ('بطاقات التعريف','المستندات') for name in ('الملف المحفوظ','مسار الملف')]
        self.assertTrue(all(s['kind']!='file' for s in SPECS))
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'scan.xlsx';export_students(data,path,threading.Event())
            book=load_workbook(path);sheet=book['الطلاب'];headers=[c.value for c in sheet[1]]
            self.assertEqual(len(headers),56)
            self.assertFalse(set(headers)&set(removed))
            sheet.cell(2,headers.index(SELECT)+1).value='1'
            # Previous exports have these extra columns; the reader ignores them.
            for n,label in enumerate(removed,len(headers)+1):
                sheet.cell(1,n).value=label;sheet.cell(2,n).value='C:\\missing.pdf'
            book.save(path);book.close()
            row=read_details(path)[0]
            self.assertFalse(set(row['manual'])&set(removed))
            self.assertEqual(row['manual']['بطاقات التعريف / رقم الوثيقة'],'00123')


if __name__=='__main__':unittest.main()
