"""Local grade scope shared by the detail preview, queue and roster lookup."""
import re


def grade_text(value):
    if not isinstance(value,str):return ''
    return re.sub(r'\s+',' ',re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',value)).strip()


def row_grade(row):
    return grade_text(row.get('values',{}).get('field-enrollment-promoted-class',''))


def in_grade(row,grade):
    return grade is None or row_grade(row)==grade


def scoped_record(row,grade):
    # Request metadata only; never change the source Excel values.
    return dict(row,search_grade=grade) if grade is not None else row


def grade_choices(rows):
    return list(dict.fromkeys(row_grade(row) for row in rows if row_grade(row)))


def apply_site_grade(page,record,username,cancelled,account_session=None):
    """Apply the user's scope on the visible roster, without inventory or saves."""
    from detailed_import import DetailError
    from student_scan import StudentBrowser,ScanError
    if not isinstance(record,dict) or set(record)!={'search_grade'}:raise DetailError('detail_input')
    grade=record['search_grade']
    if grade is not None and (not isinstance(grade,str) or not grade_text(grade) or len(grade)>128):raise DetailError('detail_input')
    browser=StudentBrowser(page,username,cancelled,account_session=account_session)
    browser.selected_grade=grade_text(grade) if grade is not None else None
    try:
        # prepare refuses an already-open pupil form, preserving any draft.
        # move(1) verifies the selected caption and first roster page only.
        browser.prepare()
    except ScanError as exc:
        if exc.code in ('scan_account_required','scan_cancelled'):raise DetailError('detail_account') from None
        event={'grade_filter':'detail_grade_trigger','grade_options':'detail_grade_options',
               'filters_active':'detail_grade_filters','search_active':'detail_grade_filters',
               'page_not_changed':'detail_grade_rows','row_count':'detail_grade_rows',
               'loading':'detail_grade_rows','table_missing':'detail_grade_rows',
               'headers_changed':'detail_grade_rows','pagination_missing':'detail_grade_rows',
               'pagination_format':'detail_grade_rows','page_size':'detail_grade_rows',
               'rows_invalid':'detail_grade_rows','count_changed':'detail_grade_rows'}.get(exc.reason,'detail_management')
        raise DetailError(event) from None
    return 'detail_grade_ready'
