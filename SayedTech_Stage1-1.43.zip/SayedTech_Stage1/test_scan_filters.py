"""Synthetic scoped roster selection; no real student records."""
import copy
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from student_scan import collect_students,ScanError,clean_detail,StudentBrowser
from scan_selection import roster_choices,select_records,clean_selection
from student_checkpoint import ScanCheckpoint,run_student_scan
from test_scan import Page,Clock

USER='test@te.mehe.school'


class ScanFilterTests(unittest.TestCase):
    def preview(self,page):
        with patch('student_scan.time.monotonic',Clock()):
            rows=StudentBrowser(page,page.account,threading.Event()).inventory(lambda *_:None)
        return roster_choices(rows,page.account)

    def collect(self,page,selection,**kw):
        with patch('student_scan.time.monotonic',Clock()):
            return collect_students(page,page.account,threading.Event(),0,selection=selection,**kw)

    def test_selected_pupils_only_open_the_chosen_files_for_both_shifts(self):
        for username in (USER,'test@te.pm.mehe.school'):
            page=Page(306,account=username)
            for i,row in enumerate(page.records):row['uid']='';row['first']=f'TEST{i}'
            choices=self.preview(page)
            selected={'signature':choices['signature'],'indexes':[0,104,305]}
            result=self.collect(page,selected)
            self.assertEqual(result['inventory'],3);self.assertEqual(len(result['records']),3)
            self.assertEqual(len([a for a in page.actions if a[0]=='opened']),3)
            self.assertEqual({r['item']['first'] for r in result['records']},{page.records[i]['first'] for i in selected['indexes']})

    def test_status_is_matched_to_live_roster_and_does_not_open_other_statuses(self):
        page=Page(12)
        for i,row in enumerate(page.records):row['status']='قيد الانتظار' if i%2 else 'مقدّم للمراجعة'
        result=self.collect(page,{'status':'قيد الانتظار'})
        self.assertEqual(result['inventory'],6)
        self.assertTrue(all(r['item']['status']=='قيد الانتظار' for r in result['records']))
        self.assertEqual(len([a for a in page.actions if a[0]=='opened']),6)

    def test_grade_and_status_combine_without_losing_full_grade_coverage(self):
        page=Page(12);grade='الأول أساسي'
        for i,row in enumerate(page.records):row['status']='جاهز' if i%2 else 'انتظار'
        result=self.collect(page,{'status':'جاهز'},grade=grade)
        self.assertEqual(result['inventory'],2)
        self.assertTrue(all(r['item']['grade']==grade for r in result['records']))

    def test_stale_account_order_or_duplicate_identity_stops_before_opening(self):
        for failure in ('account','order','duplicate'):
            page=Page(6);choices=self.preview(page)
            if failure=='account':page.account='other@te.mehe.school'
            if failure=='order':page.records.reverse()
            if failure=='duplicate':
                page.records[1].update({k:v for k,v in page.records[0].items() if k not in ('page','index')})
                choices=self.preview(page)
            with self.assertRaises(ScanError) as error:
                self.collect(page,{'signature':choices['signature'],'indexes':[0]})
            self.assertEqual(error.exception.reason,'selection_changed')
            self.assertFalse(any(a[0]=='opened' for a in page.actions))

    def test_empty_status_match_stops_without_student_visits(self):
        page=Page(6)
        with self.assertRaises(ScanError) as error:self.collect(page,{'status':'غير موجود'})
        self.assertEqual(error.exception.code,'scan_empty')
        self.assertFalse(any(a[0]=='opened' for a in page.actions))

    def test_choices_protocol_is_bounded_and_excludes_extra_record_data(self):
        page=Page(3);choices=roster_choices(page.records,USER)
        payload=copy.deepcopy(choices);payload['roster'][0]['secret']='not emitted'
        self.assertEqual(clean_detail(payload),choices)
        self.assertEqual(clean_detail({'signature':choices['signature'],'roster':[{'uid':'x'}]}),{})
        for invalid in ({'status':''},{'signature':'x','indexes':[0]},
                        {'signature':choices['signature'],'indexes':[True]},
                        {'signature':choices['signature'],'indexes':[0,0]}):
            with self.assertRaises(ValueError):clean_selection(invalid)

    def test_checkpoint_cannot_resume_a_different_filter(self):
        page=Page(3)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'selected.xlsx'
            first=ScanCheckpoint(path,USER,0,selection={'status':'قيد الانتظار'});first.bind(page.records);first.close()
            original=path.with_suffix('.sayedtech-progress.sqlite3').read_bytes()
            second=ScanCheckpoint(path,USER,0,selection={'status':'مقدّم للمراجعة'})
            with self.assertRaises(ScanError):second.bind(page.records)
            self.assertEqual(path.with_suffix('.sayedtech-progress.sqlite3').read_bytes(),original)

    def test_filtered_export_writes_only_requested_students_and_empty_scope_preserves_prior_file(self):
        import zipfile
        page=Page(9)
        for i,row in enumerate(page.records):row['status']='قيد الانتظار' if i==4 else 'مقدّم للمراجعة'
        with tempfile.TemporaryDirectory() as tmp,patch('student_scan.time.monotonic',Clock()):
            target=Path(tmp)/'students.xlsx'
            result=run_student_scan(page,USER,threading.Event(),target,0,selection={'status':'قيد الانتظار'})
            self.assertIn(result[0],('scan_saved','scan_saved_partial'));self.assertEqual(result[1:3],(1,1))
            with zipfile.ZipFile(target) as z:self.assertIsNone(z.testzip())
            original=target.read_bytes()
            result=run_student_scan(page,USER,threading.Event(),target,0,selection={'status':'حالة غير موجودة'})
            self.assertEqual(result[0],'scan_empty');self.assertEqual(target.read_bytes(),original)


if __name__=='__main__':unittest.main()
