"""Equivalent site/Excel date formats never weaken the identity gate."""
import copy
import threading
import unittest
import json
import io
from contextlib import redirect_stdout
from unittest.mock import patch
from student_scan import StudentBrowser,FORM_SCRIPT,MANAGEMENT
from detailed_import import fill_details,DetailError
import test_scan as site
from test_detailed_import import Page as DetailPage


class SiteBirthPage(site.Page):
    def __init__(self,birth):
        super().__init__(1);self.birth=birth
        self.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
    def evaluate(self,script,*args):
        result=super().evaluate(script,*args)
        if script==FORM_SCRIPT:
            for field in result:
                if field['id']=='field-birthDate':field['value']=self.birth
        return result


class BirthIdentityTests(unittest.TestCase):
    def test_roster_date_reader_returns_canonical_date_and_keeps_verified_form_open(self):
        for raw in ('02/03/2015','2015-02-03','2015/02/03'):
            for no_uid in (False,True):
                page=SiteBirthPage(raw)
                if no_uid:page.records[0]['uid']=''
                browser=StudentBrowser(page,page.account,threading.Event())
                with patch('student_scan.time.monotonic',site.Clock()):
                    items=browser.inventory(lambda *_:None,grade=page.records[0]['grade'])
                    birth=browser.read_birth_date(items[0],keep_open_if_birth='2015-02-03')
                self.assertEqual(birth,'2015-02-03');self.assertEqual(page.view,'record')

    def test_form_identity_accepts_same_date_in_site_month_day_format_for_both_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            page=DetailPage();page.values['field-birthDate']='02/03/2015'
            row={'values':copy.deepcopy(page.values),'phone':'03123456'}
            row['values']['field-birthDate']='2015-02-03'
            with patch('detailed_import.time.monotonic',lambda:page.clock):
                self.assertEqual(fill_details(page,row,'phone',username,threading.Event()),'detail_saved')

    def test_supplied_site_year_first_textbox_enters_detail_for_both_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            page=DetailPage();page.values['field-birthDate']='2015/02/03'
            row={'values':copy.deepcopy(page.values),'phone':'03123456'}
            row['values']['field-birthDate']='2015-02-03'
            with patch('detailed_import.time.monotonic',lambda:page.clock):
                self.assertEqual(fill_details(page,row,'phone',username,threading.Event()),'detail_saved')
            self.assertTrue(page.actions)

    def test_year_first_dates_are_strict_and_do_not_flip_day_month(self):
        from identity_dates import identity_birth
        self.assertEqual(identity_birth('2015/02/03'),'2015-02-03')
        self.assertEqual(identity_birth('2015/03/02'),'2015-03-02')
        self.assertEqual(identity_birth('٢٠١٥/٠٢/٠٣'),'2015-02-03')
        for value in ('2015/02/30','2015/13/02','9999/01/01','2015/2/03'):
            with self.assertRaises(ValueError):identity_birth(value)

    def test_day_month_swap_and_different_birth_still_block_every_write(self):
        for raw in ('03/02/2015','2016-02-03','2015/03/02','2016/02/03'):
            page=DetailPage();page.values['field-birthDate']=raw
            row={'values':copy.deepcopy(page.values),'phone':'03123456'}
            row['values']['field-birthDate']='2015-02-03'
            with patch('detailed_import.time.monotonic',lambda:page.clock),self.assertRaises(DetailError):
                fill_details(page,row,'phone','school@te.mehe.school',threading.Event())
            self.assertEqual(page.actions,[])

    def test_both_automatic_modes_reverify_equivalent_birth_at_each_section(self):
        for raw in ('02/03/2015','2015/02/03'):
            for review in (False,True):
                page=DetailPage();page.values['field-birthDate']=raw
                row={'values':copy.deepcopy(page.values),'address':{},'manual':{
                    'الهواتف / رقم الهاتف':'03123456','المستندات / نوع المستند':'بطاقة هوية'}}
                row['values']['field-birthDate']='2015-02-03'
                original=copy.deepcopy(row)
                with patch('detailed_import.time.monotonic',lambda:page.clock),\
                     patch('manual_sections.fill_manual_section',return_value='detail_filled'),\
                     patch('manual_save.save_manual',return_value='detail_saved') as save,\
                     patch('manual_save.send_review',return_value='detail_review_sent') as send:
                    result=fill_details(page,row,'details_import_review' if review else 'details_import','school@te.mehe.school',threading.Event())
                self.assertEqual(result,'detail_import_review_sent' if review else 'detail_import_saved')
                self.assertEqual(save.call_count,2);self.assertEqual(send.call_count,int(review))

                self.assertEqual(row,original)
                self.assertEqual(page.values['field-birthDate'],raw)
                self.assertFalse(any(action[0] in ('fill','select') and action[1]=='field-birthDate' for action in page.actions))
    def test_real_birth_difference_has_two_dates_and_no_write(self):
        page=DetailPage();page.values['field-birthDate']='03/02/2015'
        row={'values':copy.deepcopy(page.values),'phone':'03123456'}
        row['values']['field-birthDate']='2015-02-03'
        with patch('detailed_import.time.monotonic',lambda:page.clock),self.assertRaises(DetailError) as caught:
            fill_details(page,row,'phone','school@te.mehe.school',threading.Event())
        self.assertEqual(caught.exception.code,'detail_birth_mismatch')
        self.assertEqual(caught.exception.detail,{'expected_birth':'2015-02-03','observed_birth':'2015-03-02'})
        self.assertEqual(page.actions,[])

    def test_diagnostics_only_accept_two_canonical_past_dates(self):
        from identity_dates import clean_birth_detail,identity_birth
        expected={'expected_birth':'2015-02-03','observed_birth':'2015-03-02'}
        self.assertEqual(clean_birth_detail(dict(expected,secret='NOT_FOR_OUTPUT')),expected)
        for bad in ({'expected_birth':'arbitrary'},dict(expected,observed_birth='2015-02-30'),dict(expected,observed_birth='9999-01-01')):
            self.assertEqual(clean_birth_detail(bad),{})
        self.assertEqual(identity_birth('\u200f٠٢/٠٣/٢٠١٥\u200e'),'2015-02-03')
        self.assertEqual(identity_birth('۰۲/۰۳/۲۰۱۵'),'2015-02-03')

    def test_worker_emits_only_fixed_date_diagnostics_for_birth_mismatch(self):
        from login_worker import emit
        stream=io.StringIO();detail={'expected_birth':'2015-02-03','observed_birth':'2015-03-02','secret':'NOT_FOR_OUTPUT'}
        with redirect_stdout(stream):emit('detail_birth_mismatch','a'*32,detail=detail)
        actual=json.loads(stream.getvalue())
        self.assertEqual(actual['detail'],{k:v for k,v in detail.items() if k!='secret'})
        self.assertNotIn('NOT_FOR_OUTPUT',stream.getvalue())


try:
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QByteArray
    from login_controller import LoginController
    QT=True
except ImportError:QT=False


@unittest.skipUnless(QT,'Qt is unavailable')
class BirthProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])
    def test_controller_forwards_sanitized_dates_before_result_and_rejects_bad_ids(self):
        controller=LoginController();events=[]
        controller.detail_diagnostic.connect(lambda req,detail:events.append(('diagnostic',req,detail)))
        controller.student_result.connect(lambda *args:events.append(('result',)+args))
        detail={'expected_birth':'2015-02-03','observed_birth':'2015-03-02','secret':'NOT_FOR_OUTPUT'}
        data={'event':'detail_birth_mismatch','request_id':'a'*32,'detail':detail}
        with patch.object(controller.process,'readAllStandardOutput',return_value=QByteArray((json.dumps(data)+'\n').encode())):
            controller._read_output()
        self.assertEqual([e[0] for e in events],['diagnostic','result'])
        self.assertEqual(set(events[0][2]),{'expected_birth','observed_birth'})
        data['request_id']='invalid';events.clear()
        with patch.object(controller.process,'readAllStandardOutput',return_value=QByteArray((json.dumps(data)+'\n').encode())):
            controller._read_output()
        self.assertEqual(events,[]);controller.deleteLater()


if __name__=='__main__':unittest.main()
