"""Only this app's two SIMS entries in Windows Credential Manager.

No plaintext file fallback, enumeration, logging, or network transmission.
"""
import ctypes
import os
from login_flow import validate_credentials, LoginInputError

GENERIC = 1
LOCAL_MACHINE = 2
NOT_FOUND = 1168
MAX_BLOB = 5 * 512
DWORD = ctypes.c_uint32
BYTE = ctypes.c_ubyte


class FILETIME(ctypes.Structure):
    _fields_ = [('low',DWORD),('high',DWORD)]


class CREDENTIALW(ctypes.Structure):
    _fields_ = [('Flags',DWORD),('Type',DWORD),('TargetName',ctypes.c_wchar_p),
        ('Comment',ctypes.c_wchar_p),('LastWritten',FILETIME),('CredentialBlobSize',DWORD),
        ('CredentialBlob',ctypes.POINTER(BYTE)),('Persist',DWORD),('AttributeCount',DWORD),
        ('Attributes',ctypes.c_void_p),('TargetAlias',ctypes.c_wchar_p),('UserName',ctypes.c_wchar_p)]


class CredentialError(Exception):
    pass


def target(shift):
    if shift not in ('morning','afternoon'):raise CredentialError('دوام غير صالح لحفظ بيانات الدخول.')
    return 'SayedTech/SIMS/'+shift


def check(shift,username,password):
    try:
        username,password,_=validate_credentials(username,password,'edge',shift)
        if '\x00' in username:raise ValueError()
        if len(password.encode('utf-16-le'))>MAX_BLOB:raise ValueError()
    except (LoginInputError,UnicodeError,ValueError):
        raise CredentialError('بيانات الدخول غير صالحة للحفظ المحمي. راجع الإيميل وطول كلمة السر.') from None
    return username,password


class CredentialStore:
    def __init__(self,native=None):
        self.available=os.name=='nt' or native is not None
        self._native=native
        self._injected=native is not None

    def api(self):
        if not self.available:raise CredentialError('حفظ كلمة السر المحمي متاح على Windows فقط.')
        if self._native is None:
            try:
                api=ctypes.WinDLL('advapi32',use_last_error=True)
                pointer=ctypes.POINTER(CREDENTIALW)
                api.CredWriteW.argtypes=[pointer,DWORD];api.CredWriteW.restype=ctypes.c_int
                api.CredReadW.argtypes=[ctypes.c_wchar_p,DWORD,DWORD,ctypes.POINTER(pointer)]
                api.CredReadW.restype=ctypes.c_int
                api.CredDeleteW.argtypes=[ctypes.c_wchar_p,DWORD,DWORD];api.CredDeleteW.restype=ctypes.c_int
                api.CredFree.argtypes=[ctypes.c_void_p];api.CredFree.restype=None
                self._native=api
            except (OSError,AttributeError):
                raise CredentialError('تعذّر فتح مدير بيانات اعتماد Windows. لن تُحفظ كلمة السر في ملف عادي.') from None
        return self._native

    def last_error(self):
        if self._injected:return getattr(self._native,'last_error',0)
        return ctypes.get_last_error() if os.name=='nt' else getattr(self._native,'last_error',0)

    def save(self,shift,username,password):
        key=target(shift);username,password=check(shift,username,password)
        api=self.api()
        secret=password.encode('utf-16-le')
        buffer=ctypes.create_string_buffer(secret)
        credential=CREDENTIALW()
        credential.Type=GENERIC;credential.TargetName=key;credential.UserName=username
        credential.Persist=LOCAL_MACHINE
        credential.CredentialBlobSize=len(secret)
        credential.CredentialBlob=ctypes.cast(buffer,ctypes.POINTER(BYTE))
        try:
            if not api.CredWriteW(ctypes.byref(credential),0):
                raise CredentialError('تعذّر حفظ بيانات الدخول في مدير Windows؛ يمكنك متابعة الدخول دون حفظ.')
        finally:
            ctypes.memset(buffer,0,ctypes.sizeof(buffer))

    def load(self,shift):
        key=target(shift);api=self.api()
        pointer=ctypes.POINTER(CREDENTIALW)()
        if not api.CredReadW(key,GENERIC,0,ctypes.byref(pointer)):
            if self.last_error()==NOT_FOUND:return None
            raise CredentialError('تعذّرت قراءة بيانات الدخول المحفوظة؛ يمكنك إدخالها يدوياً.')
        try:
            if not pointer:raise ValueError()
            value=pointer.contents
            if value.Type!=GENERIC or value.TargetName!=key or not 0<value.CredentialBlobSize<=MAX_BLOB or not value.CredentialBlob:
                raise ValueError()
            password=ctypes.string_at(value.CredentialBlob,value.CredentialBlobSize).decode('utf-16-le')
            username,password=check(shift,value.UserName,password)
            return {'username':username,'password':password}
        except (ValueError,UnicodeError,CredentialError):
            raise CredentialError('بيانات الدخول المحفوظة غير صالحة لهذا الدوام؛ احذفها وأدخلها مجدداً.') from None
        finally:
            if pointer:api.CredFree(pointer)

    def delete(self,shift):
        key=target(shift);api=self.api()
        if not api.CredDeleteW(key,GENERIC,0) and self.last_error()!=NOT_FOUND:
            raise CredentialError('تعذّر حذف بيانات الدخول المحفوظة من Windows. أعد المحاولة.')
