"""Prepare local detail data for review; no SIMS mutations or import support."""
from pathlib import Path
import hashlib
import os
import re
import tempfile
import zipfile
import xml.etree.ElementTree as ET
import core
from student_excel import ExcelInputError, NS
from student_workflow import workbook_rows, column
from nsldb_reference import DETAILED_HEADERS, FULL_REFERENCE_HEADERS, canonical_year, TARGET_YEAR

ADDRESS_COLUMNS = ['بلد السكن', 'محافظة السكن', 'قضاء السكن', 'منطقة / بلدة السكن',
                   'الشارع', 'تفاصيل العنوان', 'نوع الهاتف', 'ملاحظات تجهيز العنوان', 'نوع السكن']
DEFAULT_RESIDENCE_COUNTRY = 'لبنان'
OLD_PREP_HEADERS = ['اختيار للاستكمال لاحقاً'] + DETAILED_HEADERS + ADDRESS_COLUMNS
PREP_HEADERS = [h for h in OLD_PREP_HEADERS if h != 'نوع السكن']
PREP_HEADERS.insert(PREP_HEADERS.index('تفاصيل العنوان') + 1, 'نوع السكن')


def normalize_phone(value):
    """Remove visual separators without guessing digits or a country code."""
    return re.sub(r'[\s\-\u2010-\u2015\u2212]', '', value) if isinstance(value, str) else value


def normalized_id(value):
    if isinstance(value, float) and value.is_integer(): return str(int(value))
    return str(value or '').strip()


def read_table(z, name):
    rows = workbook_rows(z, name)
    if not rows or rows[0][0] != 1 or len(set(rows[0][1].values())) != len(rows[0][1]):
        raise ExcelInputError('عناوين ورقة المصدر غير صالحة: ' + name)
    if any(formulas for _, _, formulas in rows):
        raise ExcelInputError('المعادلات غير مسموحة في ملف السحب الكامل.')
    headers = rows[0][1]
    return [{label: values.get(c, '') for c, label in headers.items()}
            for _, values, _ in rows[1:] if any(v != '' for v in values.values())]


def prepared_rows(z):
    students = read_table(z, 'الطلاب')
    registrations = read_table(z, 'تسجيلات القاعدة')
    lookups = read_table(z, 'قوائم القاعدة')
    if not students or not all(h in students[0] for h in FULL_REFERENCE_HEADERS if h != 'إدخال مبسّط؟'):
        raise ExcelInputError('اختر ملف السحب الكامل الحديث.')
    addresses = {}
    for row in registrations:
        def field(name):
            matches = [v for h, v in row.items() if h == name or h.endswith(' (' + name + ')')]
            return matches[0] if len(matches) == 1 else ''
        if canonical_year(field('TermID')) != TARGET_YEAR: continue
        key = (normalized_id(field('MEHEID')), normalized_id(field('GPersonID')))
        address = tuple(normalized_id(field(n)) for n in ('LivingRegionID', 'LivingCasaID', 'LivingAreaID'))
        if key in addresses and addresses[key] != address:
            raise ExcelInputError('توجد تسجيلات لنفس الطالب بعناوين مختلفة؛ راجع ملف المصدر قبل التحويل.')
        addresses[key] = address
    names = {}
    for row in lookups:
        if row.get('جدول المصدر') not in ('Regions', 'Casa', 'Area'): continue
        key = (row['جدول المصدر'], normalized_id(row.get('المعرّف (ID)')))
        value = str(row.get('الاسم') or '').strip()
        if key in names and names[key] != value:
            raise ExcelInputError('تكرار متعارض في قوائم مناطق المصدر.')
        names[key] = value
    output = []
    for row in students:
        if canonical_year(row.get('السنة في القاعدة')) != TARGET_YEAR: continue
        key = tuple(normalized_id(row.get(k)) for k in ('معرّف المدرسة في القاعدة', 'معرّف الشخص في القاعدة'))
        if key not in addresses:
            raise ExcelInputError('تعذّر ربط عنوان طالب بسجله الأصلي. أعد السحب الكامل.')
        resolved, notes = [], []
        for table, code in zip(('Regions', 'Casa', 'Area'), addresses[key]):
            name = names.get((table, code), '') if code not in ('', '0') else ''
            if code not in ('', '0') and not name:
                raise ExcelInputError('أسماء مناطق المصدر ناقصة. أعد «سحب كافة بيانات 2025–2026» بهذه النسخة ثم حوّل للمفصّل.')
            resolved.append(name)
        if not all(resolved): notes.append('عنوان السكن ناقص في المصدر')
        phone = normalize_phone(row.get('رقم الهاتف (LivingPhone)', ''))
        if phone and not re.fullmatch(r'[0-9]{8}', str(phone).strip()):
            notes.append('راجع رقم الهاتف؛ يجب أن يكون 8 أرقام، لم تُحذف أو تُضف أرقام')
        values = [row.get(h, '') for h in DETAILED_HEADERS]
        values[DETAILED_HEADERS.index('رقم الهاتف (LivingPhone)')] = phone
        values[DETAILED_HEADERS.index('استكمال مفصّل؟')] = 'لا'
        prepared=dict(zip(OLD_PREP_HEADERS,['0'] + values + [DEFAULT_RESIDENCE_COUNTRY, *resolved, '', '', 'خلوي' if phone else '', '؛ '.join(notes), '']))
        output.append([prepared.get(h,'') for h in PREP_HEADERS])
    if not output: raise ExcelInputError('لا توجد تسجيلات للعام 2025–2026.')
    return output


def convert_to_detailed(source, destination, unified=False):
    source, destination = Path(source), Path(destination)
    if source.resolve() == destination.resolve() or (core.ASSET_BASE/'assets').resolve() in destination.resolve().parents or destination.suffix.lower() != '.xlsx':
        raise ExcelInputError('احفظ المفصّل باسم مستقل خارج مجلد assets.')
    temporary = None
    try:
        if source.stat().st_size > 64_000_000: raise ExcelInputError('ملف المصدر كبير جداً.')
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        with zipfile.ZipFile(source) as z:
            if len(z.infolist()) > 1000 or sum(i.file_size for i in z.infolist()) > 128_000_000:
                raise ExcelInputError('ملف المصدر كبير جداً.')
            rows = prepared_rows(z)
            if unified:
                from student_promotion import source_results, apply_promotion
                results = source_results(z)
        if unified:
            from student_unified import UNIFIED_HEADERS, SELECTION, ENTRY_KIND, MOTHER_SURNAME, source_mother_surname
            from student_excel import FIELDS, apply_simple_defaults
            from name_transliteration import suggest_english_names
            converted=[]
            for values in rows:
                row=dict(zip(PREP_HEADERS,values))
                if not str(row.get('بلد السكن','') or '').strip():row['بلد السكن']=DEFAULT_RESIDENCE_COUNTRY
                defaults=suggest_english_names(apply_simple_defaults({f['id']:row.get(f['label'],'') for f in FIELDS}, for_export=True))
                for f in FIELDS:row[f['label']]=defaults.get(f['id'],'')
                row[SELECTION]='0'
                row[ENTRY_KIND]='طالب موجود'
                row[MOTHER_SURNAME]=source_mother_surname(row.get('ملاحظات المصدر',''))
                from identity_card import CARD_COLUMNS, REGISTRY_COLUMN
                row[CARD_COLUMNS[1]]=row.get(REGISTRY_COLUMN,'')
                apply_promotion(row, results)
                converted.append([row.get(h,'') for h in UNIFIED_HEADERS])
            rows=converted
        else:
            # The legacy detailed route also gets the requested defaults and names.
            from student_excel import FIELDS, apply_simple_defaults
            from name_transliteration import suggest_english_names
            converted=[]
            for values in rows:
                row=dict(zip(PREP_HEADERS,values))
                if not str(row.get('بلد السكن','') or '').strip():row['بلد السكن']=DEFAULT_RESIDENCE_COUNTRY
                defaults=suggest_english_names(apply_simple_defaults({f['id']:row.get(f['label'],'') for f in FIELDS}, for_export=True))
                for f in FIELDS:row[f['label']]=defaults.get(f['id'],'')
                values=[row.get(h,'') for h in PREP_HEADERS]
                converted.append(values)
            rows=converted
        if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            raise ExcelInputError('تغيّر المصدر أثناء القراءة. أغلق الملف وأعد التحويل.')
        template='student_unified.xlsx' if unified else 'student_detailed_prepared.xlsx'
        with zipfile.ZipFile(core.ASSET_BASE/'assets'/template) as z:
            parts = {n:z.read(n) for n in z.namelist()}
        q = lambda n: '{'+NS['m']+'}'+n
        sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
        headers = UNIFIED_HEADERS if unified else PREP_HEADERS
        # The bundled template predates the two optional columns. Extend its
        # table, header and validations together so Excel can edit new rows.
        first = sheet.find('m:sheetData/m:row', NS)
        existing = len(first)
        for j in range(existing + 1, len(headers) + 1):
            letter = column(j)
            c = ET.SubElement(first, q('c'), r=letter+'1', t='inlineStr')
            ET.SubElement(ET.SubElement(c, q('is')), q('t')).text = headers[j-1]
            cols = sheet.find('m:cols', NS)
            if cols is not None: ET.SubElement(cols, q('col'), min=str(j), max=str(j), width='22', customWidth='1')
        if unified:
            from student_unified import MOTHER_SURNAME_INDEX
            # Existing validation references precede the moved address type.
            # Original template validations are tied to column letters. Make
            # room for the detailed-only mother surname next to her name.
            def moved(match):
                name=match.group(1)
                number=0
                for char in name:number=number*26+ord(char)-64
                number=number+1 if number>MOTHER_SURNAME_INDEX else number
                from student_unified import CARD_INDEX
                return column(number+3 if number>CARD_INDEX else number)+match.group(2)
            for validation in sheet.findall('m:dataValidations/m:dataValidation',NS):
                selection=validation.get('sqref','')
                validation.set('sqref',re.sub(r'([A-Z]{1,3})(\d+)',moved,selection))
        for j,c in enumerate(first,1):
            for child in list(c):c.remove(child)
            c.set('t','inlineStr')
            ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=headers[j-1]
        validations = sheet.find('m:dataValidations', NS)
        if validations is not None:
            if unified and 'نوع المستند (بطاقة التعريف)' in headers:
                from identity_card import CARD_COLUMNS, DOCUMENT_TYPES
                # Reference a hidden list: all twelve Arabic labels exceed the
                # Excel inline-list size limit.
                list_sheet=ET.Element(q('worksheet'))
                list_body=ET.SubElement(list_sheet,q('sheetData'))
                for i,label in enumerate(DOCUMENT_TYPES,1):
                    r=ET.SubElement(list_body,q('row'),r=str(i))
                    c=ET.SubElement(r,q('c'),r='A'+str(i),t='inlineStr')
                    ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=label
                from identity_workbook import attach_card_list
                attach_card_list(parts,ET.tostring(list_sheet,encoding='utf-8'))
                letter=column(headers.index(CARD_COLUMNS[0])+1)
                node=ET.SubElement(validations,q('dataValidation'),type='list',sqref=f'{letter}2:{letter}501',allowBlank='1')
                ET.SubElement(node,q('formula1')).text='IdentityDocumentTypes'
            for name, choices in (('نوع السكن','دائم,صيفي,غير ذلك'),
                                  ('طريقة تسجيل الطالب','طالب موجود,طالب جديد,طالب موجود بمدرسة أخرى')):
                if name in headers:
                    node=ET.SubElement(validations,q('dataValidation'),type='list',sqref=f'{column(headers.index(name)+1)}2:{column(headers.index(name)+1)}501',allowBlank='1')
                    ET.SubElement(node,q('formula1')).text='"'+choices+'"'
            validations.set('count',str(len(validations)))
        body = sheet.find('m:sheetData', NS)
        styles = {re.sub(r'\d+', '', c.get('r')):c.get('s') for r in list(body)[1:] for c in r}
        for r in list(body)[1:]: body.remove(r)
        for i, values in enumerate(rows, 2):
            r = ET.SubElement(body, q('row'), r=str(i))
            for j, value in enumerate(values, 1):
                letter = column(j)
                c = ET.SubElement(r, q('c'), r=letter+str(i))
                if styles.get(letter): c.set('s', styles[letter])
                if isinstance(value,bool):value='نعم' if value else 'لا'
                if isinstance(value, (float, int)) and not isinstance(value, bool):
                    ET.SubElement(c, q('v')).text = str(value)
                else:
                    c.set('t','inlineStr')
                    ET.SubElement(ET.SubElement(c,q('is')),q('t')).text = str(value or '')
        end = column(len(headers)); last = max(501, len(rows)+1)
        dimension = sheet.find('m:dimension',NS)
        if dimension is not None: dimension.set('ref',f'A1:{end}{last}')
        for node in sheet.findall('m:dataValidations/m:dataValidation', NS)+sheet.findall('m:conditionalFormatting',NS):
            node.set('sqref',re.sub(r'501\b',str(last),node.get('sqref','')))
        from student_excel_layout import apply_student_dimensions
        apply_student_dimensions(sheet,headers)
        parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
        if unified:
            from student_excel import REL
            from student_unified import MARKER
            book=ET.fromstring(parts['xl/workbook.xml'])
            marker=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')==MARKER)
            relations=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
            target=next(r.get('Target') for r in relations if r.get('Id')==marker.get(REL))
            part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
            meta=ET.fromstring(parts[part]);body=meta.find('m:sheetData',NS)
            for number,value in ((3,source.name),(4,digest)):
                row=next(r for r in body if r.get('r')==str(number))
                cell=next((c for c in row if c.get('r')=='B'+str(number)),None)
                if cell is None:cell=ET.SubElement(row,q('c'),r='B'+str(number))
                for child in list(cell):cell.remove(child)
                cell.set('t','inlineStr');ET.SubElement(ET.SubElement(cell,q('is')),q('t')).text=value
            parts[part]=ET.tostring(meta,encoding='utf-8',xml_declaration=True)

        for n in list(parts):
            if n.startswith('xl/tables/') and n.endswith('.xml'):
                table = ET.fromstring(parts[n]); table.set('ref',f'A1:{end}{last}')
                columns = table.find('m:tableColumns',NS)
                if columns is not None:
                    for j in range(len(columns)+1,len(headers)+1):
                        ET.SubElement(columns,q('tableColumn'),id=str(j),name=headers[j-1])
                    columns.set('count',str(len(columns)))
                    if unified:
                        for j,item in enumerate(columns,1):item.set('name',headers[j-1])
                auto = table.find('m:autoFilter',NS)
                if auto is not None: auto.set('ref',f'A1:{end}{last}')
                parts[n] = ET.tostring(table,encoding='utf-8',xml_declaration=True)
        from address_excel import attach_address_lists
        attach_address_lists(parts, UNIFIED_HEADERS if unified else PREP_HEADERS, last)
        with tempfile.NamedTemporaryFile(dir=destination.parent,suffix='.xlsx',delete=False) as f: temporary = Path(f.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
            for n,v in parts.items(): z.writestr(n,v)
        os.replace(temporary,destination)
        return len(rows)
    except ExcelInputError: raise
    except (OSError, ValueError, KeyError, IndexError, TypeError, zipfile.BadZipFile, ET.ParseError):
        raise ExcelInputError('تعذّر تجهيز المفصّل؛ اختر السحب الكامل وأغلق ملف الإخراج.') from None
    finally:
        if temporary and temporary.exists(): temporary.unlink()
