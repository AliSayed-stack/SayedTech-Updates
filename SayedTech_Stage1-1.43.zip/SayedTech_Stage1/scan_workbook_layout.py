"""Insert the mother surname next to the Arabic name without breaking address lists."""
import re
import copy
from student_excel import NS,FIELDS
from student_workflow import column
from manual_sections import MOTHER_SURNAME

MOTHER_INDEX=next(i for i,f in enumerate(FIELDS,1) if f['id']=='field-motherName')+1
BASE_COUNT=36


def col_index(text):
    out=0
    for c in text:out=out*26+ord(c)-64
    return out


def shift_ref(text):
    def replace(m):
        n=col_index(m[2]);return m[1]+column(n+(n>=MOTHER_INDEX))+m[3]+m[4]
    return re.sub(r'(\$?)([A-Z]{1,3})(\$?)(\d+)',replace,text)


def shift_formula(text, transform=shift_ref, local=True):
    # String literals (INDIRECT addresses) and references to lookup worksheets
    # remain untouched; only unqualified/current-sheet references move.
    parts=re.split(r'("(?:[^"]|"")*")',text)
    pattern=re.compile(r"(?<![\w.])(?:(?P<sheet>'(?:[^']|'')+'|[A-Za-z_][\w.]*)!)?(?P<refs>\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)(?![\w])")
    def replace(m):
        name=m['sheet']
        if (name and name.strip("'")!='الطلاب') or (not name and not local):return m[0]
        return (name+'!' if name else '')+transform(m['refs'])
    return ''.join(piece if i%2 else pattern.sub(replace,piece) for i,piece in enumerate(parts))


def insert_mother_header(sheet):
    q=lambda tag:'{'+NS['m']+'}'+tag
    header=sheet.find('m:sheetData/m:row',NS)
    for e in sheet.iter():
        for attr in ('ref','sqref','activeCell','topLeftCell'):
            if e.get(attr):e.set(attr,shift_ref(e.get(attr)))
        if e.tag.rsplit('}',1)[-1] in ('formula','formula1','formula2') and e.text:
            e.text=shift_formula(e.text)
    for c in header:
        c.set('r',shift_ref(c.get('r')))
    new=copy.deepcopy(header[1]);new.set('r',column(MOTHER_INDEX)+'1')
    for child in list(new):new.remove(child)
    new.set('t','inlineStr')
    import xml.etree.ElementTree as ET
    ET.SubElement(ET.SubElement(new,q('is')),q('t')).text=MOTHER_SURNAME
    header.insert(MOTHER_INDEX-1,new)
    cols=sheet.find('m:cols',NS)
    for c in cols:
        lo,hi=int(c.get('min')),int(c.get('max'))
        if lo>=MOTHER_INDEX:c.set('min',str(lo+1));c.set('max',str(hi+1))
        elif hi>=MOTHER_INDEX:c.set('max',str(hi+1))
    # Source widths may be spans; the inserted column inherits its name neighbour.
    if not any(int(c.get('min'))<=MOTHER_INDEX<=int(c.get('max')) for c in cols):
        ET.SubElement(cols,q('col'),min=str(MOTHER_INDEX),max=str(MOTHER_INDEX),width='22',customWidth='1')
        cols[:]=sorted(cols,key=lambda c:int(c.get('min')))


def insert_mother_table(table):
    import xml.etree.ElementTree as ET
    q=lambda tag:'{'+NS['m']+'}'+tag
    cols=table.find('m:tableColumns',NS)
    cols.insert(MOTHER_INDEX-1,ET.Element(q('tableColumn'),name=MOTHER_SURNAME))
    for i,c in enumerate(cols,1):c.set('id',str(i))
    cols.set('count',str(len(cols)))


def selection_first(parts):
    """Move the existing selection column to A and relocate native references."""
    import xml.etree.ElementTree as ET
    from identity_workbook import Q,OFFREL,serialize
    from manual_sections import SELECT
    book=ET.fromstring(parts['xl/workbook.xml'])
    sheets=list(book.find(Q('sheets')))
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    student=next(s for s in sheets if s.get('name')=='الطلاب')
    target=next(r.get('Target') for r in rels if r.get('Id')==student.get('{'+OFFREL+'}id'))
    part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    root=ET.fromstring(parts[part])
    header=root.find(Q('sheetData')).find(Q('row'))
    shared=[]
    if 'xl/sharedStrings.xml' in parts:
        shared=[''.join(s.itertext()) for s in ET.fromstring(parts['xl/sharedStrings.xml'])]
    def label(cell):
        if cell.get('t')=='s':return shared[int(cell.find(Q('v')).text)]
        return ''.join(t.text or '' for t in cell.iter(Q('t')))
    selected=next(col_index(re.match('[A-Z]+',c.get('r'))[0]) for c in header if label(c)==SELECT)
    if selected==1:return
    def position(n):return 1 if n==selected else n+1 if n<selected else n
    def refs(text):
        # Range endpoints must continue enclosing the moved table/dimension.
        pattern=r'(\$?)([A-Z]{1,3})(\$?\d+)(?::(\$?)([A-Z]{1,3})(\$?\d+))?'
        def change(m):
            first=col_index(m[2])
            if not m[5]:return m[1]+column(position(first))+m[3]
            last=col_index(m[5]);mapped=[position(i) for i in range(first,last+1)]
            return m[1]+column(min(mapped))+m[3]+':'+m[4]+column(max(mapped))+m[6]
        return re.sub(pattern,change,text)
    for node in root.iter():
        for attr in ('r','ref','sqref','activeCell','topLeftCell'):
            if node.get(attr) and not (node.tag==Q('row') and attr=='r'):
                node.set(attr,refs(node.get(attr)))
        if node.tag in {Q(n) for n in ('f','formula','formula1','formula2')} and node.text:
            node.text=shift_formula(node.text,refs)
        if node.tag==Q('pane') and node.get('state') in ('frozen','frozenSplit'):
            frozen=int(float(node.get('xSplit','0')))
            if 0<frozen<selected:node.set('xSplit',str(frozen+1))
    for row in root.find(Q('sheetData')):
        row[:]=sorted(row,key=lambda c:col_index(re.match('[A-Z]+',c.get('r'))[0]))
    cols=root.find(Q('cols'))
    if cols is not None:
        relocated=[]
        for node in cols:
            for i in range(int(node.get('min')),int(node.get('max'))+1):
                item=copy.deepcopy(node);item.set('min',str(position(i)));item.set('max',str(position(i)));relocated.append(item)
        cols[:]=sorted(relocated,key=lambda c:int(c.get('min')))
    parts[part]=serialize(root,parts[part])
    table_ids=set()
    relation_part=part.rsplit('/',1)[0]+'/_rels/'+part.rsplit('/',1)[1]+'.rels'
    if relation_part in parts:
        from posixpath import normpath,join,dirname
        for rel in ET.fromstring(parts[relation_part]):
            if rel.get('Type','').endswith('/table'):
                target=rel.get('Target');table_ids.add(target.lstrip('/') if target.startswith('/') else normpath(join(dirname(part),target)))
    for name in table_ids:
        table=ET.fromstring(parts[name]);columns=table.find(Q('tableColumns'))
        moved=columns[selected-1];columns.remove(moved);columns.insert(0,moved)
        for i,c in enumerate(columns,1):c.set('id',str(i))
        for node in table.iter():
            if node.get('ref'):node.set('ref',refs(node.get('ref')))
            if node.tag==Q('filterColumn'):node.set('colId',str(position(int(node.get('colId'))+1)-1))
            if node.tag in (Q('calculatedColumnFormula'),Q('totalsRowFormula')) and node.text:node.text=shift_formula(node.text,refs)
        parts[name]=serialize(table,parts[name])
    for name in list(parts):
        if name==part or not name.startswith('xl/worksheets/') or not name.endswith('.xml'):continue
        sheet=ET.fromstring(parts[name]);changed=False
        for f in sheet.iter(Q('f')):
            updated=shift_formula(f.text or '',refs,local=False)
            if updated!=f.text:f.text=updated;changed=True
        if changed:parts[name]=serialize(sheet,parts[name])
    for name in book.findall('m:definedNames/m:definedName',NS):
        if name.text:name.text=shift_formula(name.text,refs,local=name.get('localSheetId')==str(sheets.index(student)))
    parts['xl/workbook.xml']=serialize(book,parts['xl/workbook.xml'])
