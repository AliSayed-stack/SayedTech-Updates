import tempfile
import unittest
from unittest.mock import patch
import zipfile
from student_promotion import source_results, apply_promotion, GRADES, GRADE_HEADER, PROMOTION_HEADERS
from student_unified import SELECTION
from student_detailed import read_table
from student_excel import read_students
from test_student_unified import UnifiedTests, edit


class PromotionTests(unittest.TestCase):
    def row(self, grade):
        return {GRADE_HEADER:grade, 'معرّف المدرسة في القاعدة':'school', 'معرّف الشخص في القاعدة':'123'}

    def test_every_transition_and_terminal_grade(self):
        results={('school','123'):{('SUCC','ناجح')}}
        for i,grade in enumerate(GRADES):
            row=apply_promotion(self.row(grade),results)
            self.assertEqual(row[GRADE_HEADER],GRADES[i+1] if i<len(GRADES)-1 else '')
            self.assertEqual(row[PROMOTION_HEADERS[0]],grade)
        self.assertEqual(apply_promotion(self.row('غير معروف'),results)[GRADE_HEADER],'')

    def test_only_final_success_promotes_and_conflicts_need_manual_grade(self):
        for code in ('USUC','COMP','NRES',''):
            self.assertEqual(apply_promotion(self.row(GRADES[5]),{('school','123'):{(code,code)}})[GRADE_HEADER],GRADES[5])
        self.assertEqual(apply_promotion(self.row(GRADES[5]),{('school','123'):{('SUCC','ناجح'),('USUC','راسب')}})[GRADE_HEADER],'')

    def test_source_join_uses_current_final_result_not_previous_or_status(self):
        lookups=[{'جدول المصدر':'ResultType','المعرّف (ID)':93,'الرمز (Code)':'SUCC','الاسم':'ناجح'},
                 {'جدول المصدر':'ResultType','المعرّف (ID)':94,'الرمز (Code)':'USUC','الاسم':'راسب'}]
        rows=[{'TermID':'20252026','MEHEID':'school','GPersonID':123,'FinalResultID':93,'PrevResultID':94,'SystemStatus':'Deleted'},
              {'TermID':'20242025','MEHEID':'school','GPersonID':123,'FinalResultID':94},
              {'TermID':'20252026','MEHEID':'other','GPersonID':123,'FinalResultID':94,'PrevResultID':93}]
        with patch('student_promotion.read_table',side_effect=[lookups,rows]):results=source_results(None)
        self.assertEqual(results[('school','123')],{('SUCC','ناجح')})
        self.assertEqual(results[('other','123')],{('USUC','راسب')})

    def test_import_keeps_user_grade_no_second_promotion(self):
        with tempfile.TemporaryDirectory() as folder:
            p=UnifiedTests().make(folder)
            edit(p,{SELECTION:'1',GRADE_HEADER:'السابع أساسي',PROMOTION_HEADERS[1]:'ناجح'})
            for _ in range(2):
                self.assertEqual(read_students(p)[0]['values']['field-enrollment-promoted-class'],'السابع أساسي')


if __name__=='__main__':unittest.main()
