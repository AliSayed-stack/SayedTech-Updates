"""Synthetic supplied-shape DOM, input and save-gate regressions; no live writes."""
from contextlib import closing
import math
from pathlib import Path
import re
import tempfile
import threading
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import shutil
import zipfile
from lxml import html
from openpyxl import load_workbook
from attendance_schema import (HEADERS,REASONS,SUCCESS_TEXT,AttendanceError,absence_date,
 validate_absence,account_key,resolve_pupil,pupil_option)
from attendance_excel import write_attendance,read_attendance
from attendance_browser import AttendanceRunner,ATTENDANCE,ABSENCE_LIST_SCRIPT,has_overlap,TABLE_HEADERS
from student_excel import ExcelInputError

USERNAME='test@te.mehe.school'
PUPIL={'uid':'SITE-001','first':'اسم','middle':'أب','last':'اختبار','grade':'الأول أساسي','status':'قيد الانتظار'}


def record(username=USERNAME):
    return dict(PUPIL,start='10/25/2026',end='',reason='سفر',skip='نعم',notes='ملاحظة اختبار',account=account_key(username))


class Loc:
    def __init__(self,page,get):self.page=page;self.get=get
    def nodes(self):return self.get()
    def count(self):return len(self.nodes())
    def is_visible(self):return bool(self.nodes())
    def is_enabled(self):return self.nodes()[0].get('disabled') is None
    def all(self):return [Loc(self.page,lambda n=n:[n] if n.getparent() is not None else []) for n in self.nodes()]
    def inner_text(self):return self.nodes()[0].text_content()
    def all_inner_texts(self):return [n.text_content() for n in self.nodes()]
    all_text_contents=all_inner_texts
    def get_attribute(self,name):return self.nodes()[0].get(name)
    def input_value(self):
        n=self.nodes()[0];return n.text or '' if n.tag=='textarea' else n.get('value','')
    def is_checked(self):return self.nodes()[0].get('checked') is not None
    def set_checked(self,value,**kwargs):
        n=self.nodes()[0]
        if value:n.set('checked','checked')
        else:n.attrib.pop('checked',None)
    def select_option(self,value,**kwargs):self.nodes()[0].set('value',value)
    def fill(self,value,**kwargs):
        n=self.nodes()[0]
        if n.tag=='textarea':n.text=value
        else:n.set('value',value)
        if n.get('data-search')=='yes':self.page.filter_options(value)
    def click(self,**kwargs):self.page.click(self.nodes()[0])
    def wait_for(self,state,**kwargs):
        if (state=='visible')!=self.is_visible():raise TimeoutError('DOM state')
    def locator(self,selector):
        def read():
            out=[]
            for n in self.nodes():
                found=n.xpath('..') if selector=='xpath=..' else self.page.css(n,selector)
                for e in found:
                    if e not in out:out.append(e)
            return out
        return Loc(self.page,read)
    def filter(self,has=None,has_text=None):
        def read():
            return [n for n in self.nodes() if (has is None or any(e in list(n.iterdescendants()) for e in has.nodes())) and
                    (has_text is None or has_text.search(n.text_content()))]
        return Loc(self.page,read)
    def get_by_role(self,role,name=None,exact=False):
        tags={'button':['button'],'heading':['h1','h2','h3'],'alert':['div']}[role]
        def read():
            nodes=[e for n in self.nodes() for e in n.iterdescendants() if e.tag in tags and (role!='alert' or e.get('role')=='alert')]
            return [n for n in nodes if name is None or self.page.matches(n.get('aria-label') or n.text_content(),name,exact)]
        return Loc(self.page,read)
    def get_by_text(self,name,exact=False):
        def read():
            return [e for n in self.nodes() for e in n.iterdescendants()
                    if self.page.matches(e.text_content(),name,exact) and not any(self.page.matches(c.text_content(),name,exact) for c in e)]
        return Loc(self.page,read)
    def get_by_label(self,name,exact=False):
        def read():
            found=[]
            for n in self.nodes():
                for label in n.xpath('.//label[@for]'):
                    if self.page.matches(label.text_content(),name,exact):found+=n.xpath('.//*[@id=$id]',id=label.get('for'))
            return found
        return Loc(self.page,read)
    def get_by_placeholder(self,name,exact=False):
        return Loc(self.page,lambda:[e for n in self.nodes() for e in n.xpath('.//*[@placeholder]') if self.page.matches(e.get('placeholder'),name,exact)])


class Page(Loc):
    def __init__(self,username=USERNAME):
        self.url='https://new-sims.mehe.gov.lb'+ATTENDANCE;self.username=username;self.clock=0
        self.options=['اسم اختبار — OLD-DELETED','اسم اختبار — SITE-001'];self.reason_options=[k+' — '+v for k,v in REASONS.items()]
        self.actions=[];self.message='تم تسجيل الغياب — 1 أيام دراسية.';self.existing=[];self.saved_form=None;self.start_max='2027-08-31';self.old_message=''
        self.reset();super().__init__(self,lambda:[self.doc])
    def reset(self):
        self.number=1
        self.doc=html.fromstring(Path('test_fixtures/attendance_site.html').read_text())
        self.doc.xpath('.//div[@class="account"]')[0].text=self.username
    def matches(self,text,name,exact):return bool(name.search(text)) if hasattr(name,'search') else text==name if exact else name in text
    def css(self,node,selector):
        if selector.startswith('#'):return node.xpath('.//*[@id=$id]',id=selector[1:])
        if selector in ('select','option'):return node.xpath('.//'+selector)
        classes={'div.no-print':['no-print'],'div.max-h-60.overflow-y-auto':['max-h-60','overflow-y-auto'],
                 'div.rounded-xl':['rounded-xl'],'.print-area-modal':['print-area-modal'],
                 '.Toastify__toast--success[role="alert"]':['Toastify__toast--success']}[selector]
        return [e for e in node.iterdescendants() if all(c in e.get('class','').split() for c in classes)]
    def goto(self,url,**kwargs):self.url=url;self.actions.append(('goto',url));self.reset()
    def wait_for_timeout(self,ms):self.clock+=ms/1000
    def evaluate(self,script):
        assert script==ABSENCE_LIST_SCRIPT
        return {'tables':[{'headers':TABLE_HEADERS,'rows':self.existing[(self.number-1)*100:self.number*100]}],
                'pagers':[f'الصفحة {self.number} من {max(1,math.ceil(len(self.existing)/100))} · {len(self.existing)} سجل إجمالاً'],'busy':False}
    def filter_options(self,query):
        grid=self.doc.xpath('.//div[contains(@class,"max-h-60")]')[0]
        for n in list(grid):grid.remove(n)
        for text in self.menu_options:
            if query and query not in text:continue
            button=html.Element('button');button.set('data-option','yes');button.text=text;grid.append(button)
    def toast(self,message):
        n=html.Element('div',{'role':'alert','class':'Toastify__toast--success'});n.text=message
        n.append(html.fromstring('<button aria-label="close"/>'));self.doc.append(n)
    def click(self,node):
        text=node.text_content();self.actions.append(('click',text))
        if node.get('aria-label')=='close':node.getparent().getparent().remove(node.getparent());return
        if text=='تسجيل غياب':
            modal=html.fromstring(Path('test_fixtures/attendance_modal.html').read_text())
            modal.xpath('.//input[@required]')[0].set('max',self.start_max);self.doc.append(modal)
            if self.old_message:self.toast(self.old_message)
        elif text=='التالي':self.number+=1
        elif node.get('data-menu'):
            self.trigger=node;self.menu_options=self.options if node.get('data-menu')=='student' else self.reason_options
            popup=html.fromstring('<div class="no-print"><input placeholder="بحث" data-search="yes"/><div class="max-h-60 overflow-y-auto"/></div>')
            self.doc.append(popup);self.filter_options('')
        elif node.get('data-option'):
            self.trigger.text=text
            popup=self.doc.xpath('.//div[@class="no-print"]')[0];popup.getparent().remove(popup)
        elif text=='حفظ':
            modal=self.doc.xpath('.//div[@class="print-area-modal"]')[0]
            self.saved_form={e.get('id'):(e.text if e.tag=='textarea' else e.get('value','')) for e in modal.xpath('.//input|.//textarea')}
            self.doc.remove(modal)
            if self.message:self.toast(self.message)


class AttendanceTests(unittest.TestCase):
    def invoke(self,runner,page,raw=None,token='a'*32):
        with patch('attendance_browser.time.monotonic',side_effect=lambda:page.clock),patch.object(runner,'roster',return_value=[dict(PUPIL,status='قيد الانتظار')]):
            return runner.import_one(page,page.username,threading.Event(),raw or record(page.username),token)

    def test_complete_supplied_shape_flow_both_shifts_and_exact_fresh_success(self):
        for username in (USERNAME,'test@te.pm.mehe.school'):
            page=Page(username);runner=AttendanceRunner();page.toast('تم تسجيل الغياب — 9 أيام دراسية.')
            # A fresh navigation clears old notifications. Saving occurs once.
            self.assertEqual(self.invoke(runner,page),('attendance_saved',1))
            self.assertEqual(page.saved_form['_r_new_start_'],'2026-10-25')
            self.assertEqual(page.saved_form['_r_new_end_'],'')
            self.assertEqual(page.saved_form['_r_new_notes_'],'ملاحظة اختبار')
            self.assertEqual(page.actions.count(('click','حفظ')),1)
            self.assertEqual(self.invoke(runner,page),('attendance_already',0))
            self.assertEqual(page.actions.count(('click','حفظ')),1)

    def test_absent_error_or_unrelated_toast_blocks_retry_and_later_save(self):
        for message in ('','تعذر تسجيل الغياب','تم الحفظ بنجاح','تم تسجيل الغياب — 0 أيام دراسية.'):
            page=Page();page.message=message;page.old_message='تم تسجيل الغياب — 9 أيام دراسية.';runner=AttendanceRunner()
            with self.assertRaises(AttendanceError) as error:self.invoke(runner,page)
            self.assertEqual(error.exception.code,'attendance_save_unknown')
            with self.assertRaises(AttendanceError) as error:self.invoke(runner,page,token='b'*32)
            self.assertEqual(error.exception.code,'attendance_uncertain')
            self.assertEqual(page.actions.count(('click','حفظ')),1)
            with self.assertRaises(AttendanceError) as error:self.invoke(runner,page,dict(record(),notes='changed'),token='c'*32)
            self.assertEqual(error.exception.code,'attendance_uncertain')

    def test_previous_absences_read_every_page_and_reject_stale_or_wrong_student_rows(self):
        page=Page();page.existing=[['اسم اختبار','SITE-001','2026-08-01','2026-08-01','1','سفر',str(i)] for i in range(101)]
        self.assertEqual(self.invoke(AttendanceRunner(),page),('attendance_saved',1))
        self.assertIn(('click','التالي'),page.actions)
        page=Page();page.existing=[['اسم آخر','SITE-001','2026-08-01','2026-08-01','1','سفر','']]
        with self.assertRaises(AttendanceError) as error:self.invoke(AttendanceRunner(),page)
        self.assertEqual(error.exception.code,'attendance_identity');self.assertNotIn(('click','حفظ'),page.actions)

    def test_school_account_date_bounds_unknown_reason_and_duplicate_absence_stop_before_save(self):
        for variant,code in (('account','attendance_account'),('date','attendance_date'),('existing','attendance_existing'),('reason','attendance_input')):
            page=Page();runner=AttendanceRunner();raw=record()
            if variant=='account':raw['account']='b'*64
            if variant=='date':page.start_max='2026-10-01'
            if variant=='reason':raw['reason']='UNKNOWN'
            if variant=='existing':page.existing=[['اسم اختبار','SITE-001','2026-10-25','2026-10-25','1','سفر','']]
            with self.assertRaises(AttendanceError) as error:self.invoke(runner,page,raw)
            self.assertEqual(error.exception.code,code);self.assertNotIn(('click','حفظ'),page.actions)

    def test_pending_namesake_wins_deleted_and_popup_still_requires_unique_verified_id(self):
        deleted=dict(PUPIL,uid='OLD-DELETED',status='محذوف')
        raw=validate_absence(dict(record(),uid='OLD-DELETED'))
        self.assertEqual(resolve_pupil([deleted,PUPIL],raw)['uid'],'SITE-001')
        self.assertEqual(pupil_option(['اسم اختبار — OLD-DELETED','اسم اختبار — SITE-001'],PUPIL),'اسم اختبار — SITE-001')
        for roster in ([deleted],[PUPIL,dict(PUPIL,uid='OTHER')]):
            with self.assertRaises(AttendanceError):resolve_pupil(roster,dict(raw,uid=''))
        with self.assertRaises(AttendanceError):pupil_option(['اسم اختبار','اسم اختبار'],dict(PUPIL,uid=''))

    def test_date_formats_reason_codes_and_conservative_overlap(self):
        self.assertEqual(absence_date('04/05/2027'),'2027-04-05')
        self.assertEqual(absence_date(45292),'2024-01-01')
        for value in (True,60,45292.5,'31/12/2026'):
            with self.assertRaises(ValueError):absence_date(value)
        self.assertEqual(validate_absence(dict(record(),skip=False))['skip'],False)
        self.assertEqual(len(REASONS),22)
        self.assertTrue(SUCCESS_TEXT.fullmatch('تم تسجيل الغياب — ١٢ أيام دراسية.'))
        raw=validate_absence(dict(record(),start='04/05/2027',end='04/08/2027'))
        self.assertTrue(has_overlap([['','','05/04/2027','08/04/2027','','','']],raw))

    def test_native_workbook_roundtrip_keeps_ids_dropdowns_context_and_formula_rejection(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'attendance.xlsx';write_attendance(p,[PUPIL],USERNAME)
            with self.assertRaises(ExcelInputError):read_attendance(p)
            with closing(load_workbook(p)) as book:
                sheet=book['الحضور'];self.assertEqual([c.value for c in sheet[1]],HEADERS)
                self.assertEqual(sheet['B2'].value,'SITE-001');self.assertEqual(sheet.row_dimensions[2].height,23)
                self.assertEqual(len(sheet.data_validations.dataValidation),3)
                sheet['A2']='1';sheet['G2']='10/25/2026';sheet['I2']='سفر';book.save(p)
            row=read_attendance(p)[0];self.assertEqual(row['account'],account_key(USERNAME));self.assertEqual(row['start'],'2026-10-25')
            with closing(load_workbook(p)) as book:book['الحضور']['G2']='=TODAY()';book.save(p)
            with self.assertRaises(ExcelInputError):read_attendance(p)

    def test_template_export_excludes_deleted_and_extends_all_native_ranges(self):
        page=Page();runner=AttendanceRunner()
        roster=[dict(PUPIL,uid=f'000{i:04d}') for i in range(510)]+[dict(PUPIL,uid='deleted',status='محذوف')]
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'attendance.xlsx'
            with patch.object(runner,'roster',return_value=roster):
                self.assertEqual(runner.export_template(page,USERNAME,threading.Event(),target),('attendance_template_saved',510))
            with closing(load_workbook(target)) as book:
                sheet=book['الحضور'];self.assertEqual(sheet.max_row,511)
                self.assertEqual(sheet['B2'].value,'0000000');self.assertEqual(sheet['B511'].value,'0000509')
                self.assertEqual(sheet.tables['StudentAttendance'].ref,'A1:K511')
                self.assertEqual({str(v.sqref) for v in sheet.data_validations.dataValidation},{'A2:A511','I2:I511','J2:J511'})
                reason=next(v for v in sheet.data_validations.dataValidation if str(v.sqref)=='I2:I511')
                self.assertEqual(reason.formula1,'INDIRECT("\'أسباب الغياب\'!$B$2:$B$23")')
                self.assertEqual(book['أسباب الغياب'].max_row,23)
            self.assertEqual(page.url,'https://new-sims.mehe.gov.lb'+ATTENDANCE)

    def test_native_export_replaces_only_after_download_passes_and_preserves_filter(self):
        class Download:
            def __init__(self,source):self.source=source;self.value=self
            def __enter__(self):return self
            def __exit__(self,*args):return False
            def save_as(self,path):shutil.copyfile(self.source,path)
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'source.xlsx';target=Path(folder)/'target.xlsx'
            write_attendance(source,[PUPIL],USERNAME)
            page=Page();page.expect_download=lambda **kwargs:Download(source)
            self.assertEqual(AttendanceRunner().export_existing(page,USERNAME,threading.Event(),target),('attendance_exported',0))
            self.assertEqual(source.read_bytes(),target.read_bytes());self.assertFalse(any(a[0]=='goto' for a in page.actions))
            original=target.read_bytes();source.write_bytes(b'not a workbook')
            with self.assertRaises(zipfile.BadZipFile):AttendanceRunner().export_existing(page,USERNAME,threading.Event(),target)
            self.assertEqual(target.read_bytes(),original)
            self.assertEqual(sorted(p.name for p in Path(folder).iterdir()),['source.xlsx','target.xlsx'])

    def test_account_cancellation_and_roster_cache_stay_scoped(self):
        for failure in ('host','account','cancelled','revoked'):
            page=Page();runner=AttendanceRunner();cancel=threading.Event();session=None
            if failure=='host':page.url='https://example.invalid'+ATTENDANCE
            if failure=='account':page.doc.xpath('.//div[@class="account"]')[0].text='other@te.mehe.school'
            if failure=='cancelled':cancel.set()
            if failure=='revoked':session=SimpleNamespace(revoked=True)
            with self.assertRaises(AttendanceError):runner.bind(page,USERNAME,cancel,session)
            self.assertNotIn(('click','حفظ'),page.actions)
        page=Page();runner=AttendanceRunner()
        with patch.object(runner,'roster',return_value=[PUPIL]) as roster,patch('attendance_browser.time.monotonic',side_effect=lambda:page.clock):
            self.assertEqual(runner.import_one(page,USERNAME,threading.Event(),record(),'a'*32),('attendance_saved',1))
            other=dict(record(),start='10/26/2026')
            self.assertEqual(runner.import_one(page,USERNAME,threading.Event(),other,'a'*32),('attendance_saved',1))
            roster.assert_called_once_with('الأول أساسي')


if __name__=='__main__':unittest.main()
