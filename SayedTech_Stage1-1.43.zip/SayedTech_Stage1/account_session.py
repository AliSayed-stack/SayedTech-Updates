"""In-memory continuity of an already verified, user-run browser login.

SIMS can replace the email caption with a display name after profile loading.
No cookie, token, credential, or student record is read or persisted here.
"""
import hashlib
import re
import time
from urllib.parse import urlsplit

PROFILE_SCRIPT = r'''() => {
 const clean = s => s.replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g,'').replace(/\s+/g,' ').trim();
 const shown = el => !!el.getClientRects().length;
 const role = 'مدير النظام';
 const leaves = [...document.querySelectorAll('p,span,small,div')].filter(el =>
   shown(el) && clean(el.textContent)===role && ![...el.children].some(c=>clean(c.textContent)===role));
 const results = new Set();
 for (const leaf of leaves) {
   let parent=leaf.parentElement;
   for (let i=0; parent && i<4; i++, parent=parent.parentElement) {
     if (parent.querySelector('table,form,nav,input,select,textarea')) break;
     const text=clean(parent.innerText || parent.textContent);
     if (text.length>512) break;
     if (text && text!==role) { results.add(text); break; }
   }
 }
 return results.size===1 ? [...results][0] : null;
}'''

EMAIL = re.compile(r'[A-Za-z0-9._%+!\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}')


def caption(page):
    try: raw=page.evaluate(PROFILE_SCRIPT)
    except Exception:return None,[]
    if not isinstance(raw,str) or not 1<=len(raw)<=512:return None,[]
    raw=re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',raw)
    emails=[s.casefold() for s in EMAIL.findall(raw)]
    name=' '.join(EMAIL.sub('',raw).split())
    if not name or name=='مدير النظام':return None,emails
    return hashlib.sha256(name.encode('utf-8')).digest(),emails


class AccountSession:
    """Created only by LoginFlow after expected email + students menu verify.

    The profile name can resolve shortly after that verification. Bind its first
    non-email caption within 30 seconds in that same page. Once bound, a changed
    caption cannot rebind this session. No arbitrary current display name is
    accepted at scan start, and a second tab cannot reuse the proof.
    """
    def __init__(self,page,username,clock=None):
        self.page=page
        self.username=username.strip().casefold()
        self.clock=clock or time.monotonic
        self.until=self.clock()+30
        self.marker=None
        self.revoked=False
        self.reason='account_profile_missing'
        self.observe()

    def observe(self):
        from login_flow import exact_https_host,SIMS_HOST
        if self.revoked:return
        if not exact_https_host(self.page.url,SIMS_HOST) or not urlsplit(self.page.url).path.startswith('/dashboard/'):
            self.revoked=True;self.reason='account_session_changed';return
        marker,emails=caption(self.page)
        if any(email!=self.username for email in emails):
            self.revoked=True;self.reason='account_session_changed';return
        if marker is None:return None
        if self.marker is None:
            if self.clock()<=self.until:
                self.marker=marker;self.reason=''
        elif marker!=self.marker:
            self.revoked=True;self.reason='account_session_changed'
        return marker

    def allows(self,page,username):
        if page is not self.page or username.strip().casefold()!=self.username:
            return False
        marker=self.observe()
        if self.revoked:return False
        if self.marker is None or marker is None:
            self.reason='account_profile_missing';return False
        allowed=marker==self.marker
        if allowed:self.reason=''
        return allowed
