"""Filled legacy workbook compatibility and serial multi-document card entry."""
import copy
import hashlib
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from lxml import html
from openpyxl import load_workbook
from detailed_import import read_details,fill_verified_section,import_detailed_record,DetailError
from document_import import save_documents,validated_documents,CARD
from manual_sections import SELECT,merge_document_rows,section_summary
from student_excel import ExcelInputError
from student_scan import export_students
import test_manual_sections as manual_tests
from test_manual_site_bindings import Page,Locator

P='المستندات / '


class WorkbookDocumentTests(unittest.TestCase):
    def workbook(self,path):
        _,data=manual_tests.ManualWorkbookTests().data()
        export_students(data,path,threading.Event())
        book=load_workbook(path);sheet=book['الطلاب'];headers={c.value:c.column for c in sheet[1]}
        for key,value in {SELECT:'1',P+'نوع المستند':'بطاقة تلقيح',P+'رقم الوثيقة':'00007',
                          P+'تاريخ الإصدار':'2026-08-10',P+'جرى التسليم':'نعم',P+'طباعة على اللائحة':'لا'}.items():
            sheet.cell(2,headers[key]).value=value
        for c in sheet[2]:sheet.cell(3,c.column).value=c.value
        sheet.cell(3,headers[P+'نوع المستند']).value='إفادة سكن'
        sheet.cell(3,headers[P+'رقم الوثيقة']).value='00008'
        return book,sheet,headers

    def test_populated_previous_file_keeps_schema_values_and_is_read_only(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'already_filled.xlsx';book,sheet,h=self.workbook(path)
            self.assertEqual(sheet.max_column,56)
            book.save(path);book.close();before=hashlib.sha256(path.read_bytes()).hexdigest()
            rows=read_details(path)
            self.assertEqual(len(rows),1);row=rows[0]
            self.assertEqual(row['excel_rows'],[2,3])
            self.assertEqual([d[P+'رقم الوثيقة'] for d in row['documents']],['00007','00008'])
            self.assertIs(row['documents'][1][P+'جرى التسليم'],True)
            self.assertIs(row['documents'][1][P+'طباعة على اللائحة'],False)
            self.assertEqual(row['manual']['الهواتف / رقم الهاتف'],'03123456')
            self.assertIn('إفادة سكن',section_summary(row,'المستندات'))
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),before)

    def test_unmarked_copy_is_excluded_and_single_old_row_stays_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'old.xlsx';book,sheet,h=self.workbook(path)
            sheet.cell(3,h[SELECT]).value='0';book.save(path);book.close()
            rows=read_details(path)
            self.assertEqual(len(rows),1);self.assertNotIn('documents',rows[0])
            self.assertEqual(rows[0]['manual'][P+'رقم الوثيقة'],'00007')

    def test_conflicting_identity_other_data_and_formula_stop_before_import(self):
        for failure in ('identity','phone','formula'):
            with self.subTest(failure=failure),tempfile.TemporaryDirectory() as folder:
                path=Path(folder)/'old.xlsx';book,sheet,h=self.workbook(path)
                if failure=='identity':sheet.cell(3,h['الاسم الأول (بالعربية)']).value='OTHER'
                if failure=='phone':sheet.cell(3,h['الهواتف / رقم الهاتف']).value='03123457'
                if failure=='formula':sheet.cell(3,h[P+'رقم الوثيقة']).value='=1+1'
                book.save(path);book.close()
                with self.assertRaises(ExcelInputError):read_details(path)

    def test_filled_workbook_without_uid_combines_documents_and_enforces_its_grade_scope(self):
        with tempfile.TemporaryDirectory() as folder:
            from student_excel import BY_ID
            path=Path(folder)/'no_uid.xlsx';book,sheet,h=self.workbook(path)
            col=h[BY_ID['field-existingUniqueId']['label']]
            sheet.cell(2,col).value='';sheet.cell(3,col).value=''
            book.save(path);book.close();before=path.read_bytes()
            rows=read_details(path);self.assertEqual(len(rows),1)
            self.assertEqual(len(rows[0]['documents']),2)
            self.assertFalse(rows[0]['values']['field-existingUniqueId'])
            self.assertEqual(rows[0]['search_grade'],rows[0]['values']['field-enrollment-promoted-class'])
            self.assertEqual(path.read_bytes(),before)

    def test_no_uid_never_merges_different_birth_or_grade_and_rejects_missing_grade(self):
        row={'excel_row':2,'values':{'field-firstName':'A','field-middleName':'B','field-lastName':'C',
             'field-birthDate':'2015-01-02','field-enrollment-promoted-class':'الأول أساسي'},
             'manual':{P+'نوع المستند':'بطاقة تلقيح'}}
        for field,value in (('field-birthDate','2014-01-02'),('field-enrollment-promoted-class','الثاني أساسي')):
            other=copy.deepcopy(row);other['excel_row']=3;other['values'][field]=value
            self.assertEqual(len(merge_document_rows([row,other])),2)
        other=copy.deepcopy(row);other['excel_row']=3
        row['values']['field-enrollment-promoted-class']=''
        other['values']['field-enrollment-promoted-class']=''
        with self.assertRaises(ExcelInputError):merge_document_rows([row,other])

    def test_missing_uid_can_join_one_known_identity_but_not_two_different_uids(self):
        row={'excel_row':2,'values':{'field-firstName':'A','field-middleName':'B','field-lastName':'C',
             'field-birthDate':'2015-01-02','field-enrollment-promoted-class':'الأول أساسي'},
             'manual':{P+'نوع المستند':'بطاقة تلقيح'}}
        known=copy.deepcopy(row);known['excel_row']=3;known['values']['field-existingUniqueId']='00001'
        known['manual'][P+'نوع المستند']='إفادة سكن'
        combined=merge_document_rows([row,known])
        self.assertEqual(len(combined),1);self.assertEqual(combined[0]['values']['field-existingUniqueId'],'00001')
        self.assertEqual(len(combined[0]['documents']),2)
        other=copy.deepcopy(known);other['excel_row']=4;other['values']['field-existingUniqueId']='00002'
        with self.assertRaises(ExcelInputError):merge_document_rows([row,known,other])

    def test_live_lookup_ambiguity_without_uid_stops_before_document_entry(self):
        from detailed_import import open_existing_detail_student
        from test_detailed_import import Page as IdentityPage
        page=IdentityPage();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        record={'values':dict(page.values,**{'field-enrollment-promoted-class':'الأول أساسي'}),'search_grade':'الأول أساسي'}
        observations=[]
        class Browser:
            def __init__(self,*args,**kwargs):pass
            def inventory(self,progress,grade=None):
                observations.append(grade)
                return [dict(uid='',first='أحمد',middle='علي',last='السيد',status='قيد الانتظار') for _ in range(2)]
            def read_birth_date(self,item):return '2015-01-02'
        with patch('student_scan.StudentBrowser',Browser),self.assertRaises(DetailError) as caught:
            open_existing_detail_student(page,record,'school@te.mehe.school',threading.Event())
        self.assertEqual(caught.exception.code,'detail_ambiguous');self.assertEqual(observations,['الأول أساسي'])
        self.assertEqual(page.actions,[])

    def test_identical_document_copies_are_deduplicated(self):
        row={'excel_row':2,'values':{'field-existingUniqueId':'0001','field-firstName':'A',
             'field-middleName':'B','field-lastName':'C','field-birthDate':'2015-01-02'},
             'manual':{P+'نوع المستند':'بطاقة تلقيح',P+'رقم الوثيقة':'00007'}}
        second=copy.deepcopy(row);second['excel_row']=3
        got=merge_document_rows([row,second])[0]
        self.assertEqual(len(got['documents']),1);self.assertNotIn('documents',row)


class MultiPage(Page):
    def __init__(self):
        super().__init__('documents_site.html');self.clock=0
        self.section=self.doc.xpath('.//section')[0]
        self.template=copy.deepcopy(self.section.xpath('./div')[-1])
        select=self.template.xpath('.//select')[0]
        select.insert(0,html.fromstring('<option value="">--اختيار--</option>'))
        select.append(html.fromstring('<option value="id_card">بطاقة هوية</option>'))
        select.append(html.fromstring('<option value="residence_certificate">إفادة سكن</option>'))
        select.append(html.fromstring('<option value="medical_certificate">شهادة صحية</option>'))
        for e in self.template.xpath('.//input'):
            e.set('value','');e.attrib.pop('checked',None)
        for e in select:e.attrib.pop('selected',None)
        self.section.remove(self.section.xpath('./div')[-1])
        self.section.append(html.fromstring('<button data-add="yes">إضافة</button>'))
        self.saved=[]
    def after_click(self,node):
        if node.get('data-add')=='yes':
            card=copy.deepcopy(self.template)
            n=len(self.section.xpath('.//select'))+1
            for e in card.xpath('.//*[@id]'):
                old=e.get('id');e.set('id','fresh_'+str(n)+'_'+old)
                for label in card.xpath('.//label[@for=$id]',id=old):label.set('for','fresh_'+str(n)+'_'+old)
            self.section.append(card)
    def wait_for_timeout(self,ms):self.clock+=ms/1000
    def save(self,page,title,guard,*,document_block=None):
        guard();self.assert_scope=document_block
        node=document_block.nodes[0]
        number=node.xpath('.//input[@type="text"]')[0].get('value','')
        self.saved.append(number);return 'detail_saved'


class BrowserDocumentTests(unittest.TestCase):
    def slash_invoke(self,page,documents,wrong=False):
        original=Locator.fill
        def formatted(field,value,**kw):
            original(field,value,**kw)
            if field.nodes[0].get('type')=='date':
                field.nodes[0].set('value','2025/04/16' if wrong else value.replace('-','/'))
        with patch.object(Locator,'fill',formatted):return self.invoke(page,documents)

    def test_formatted_date_does_not_stop_checkboxes_or_second_document(self):
        page=MultiPage();docs=self.documents()
        for doc in docs:
            doc.update({P+'تاريخ الإصدار':'2025-04-15',P+'جرى التسليم':True,P+'طباعة على اللائحة':True})
        self.assertEqual(self.slash_invoke(page,docs),'detail_saved')
        self.assertEqual(page.saved,['00007','00008'])
        self.assertEqual(page.actions.count(('click','إضافة')),2)
        cards=page.section.xpath(CARD[6:])
        for card in cards:
            self.assertEqual(card.xpath('.//input[@type="date"]')[0].get('value'),'2025/04/15')
            self.assertTrue(all(c.get('checked') is not None for c in card.xpath('.//input[@type="checkbox"]')))

    def test_partial_card_with_formatted_date_reuses_card_and_completes_flags(self):
        page=MultiPage();doc=self.documents()[0]
        doc.update({P+'تاريخ الإصدار':'2025-04-15',P+'طباعة على اللائحة':True})
        page.after_click(page.section.xpath('.//button[@data-add]')[0])
        card=page.section.xpath(CARD[6:])[0]
        for option in card.xpath('.//option'):
            if option.get('value')=='vaccination_card':option.set('selected','')
        card.xpath('.//input[@type="text"]')[0].set('value','00007')
        card.xpath('.//input[@type="date"]')[0].set('value','2025/04/15')
        self.assertEqual(self.slash_invoke(page,[doc]),'detail_saved')
        self.assertEqual(page.actions.count(('click','إضافة')),0)
        self.assertEqual(page.saved,['00007']);self.assertEqual(len(page.section.xpath(CARD[6:])),1)
        self.assertTrue(all(c.get('checked') is not None for c in card.xpath('.//input[@type="checkbox"]')))

    def test_genuinely_wrong_rendered_date_stops_before_flags_save_and_next_document(self):
        page=MultiPage();docs=self.documents()
        docs[0][P+'تاريخ الإصدار']='2025-04-15'
        with self.assertRaises(DetailError):self.slash_invoke(page,docs,wrong=True)
        self.assertEqual(page.saved,[]);self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertFalse(any(a[0]=='check' for a in page.actions))

    def test_conflicting_flags_for_same_document_stop_before_any_write(self):
        page=MultiPage();first=self.documents()[0];second=dict(first)
        second[P+'جرى التسليم']=False
        with self.assertRaises(DetailError):self.invoke(page,[first,second])
        self.assertEqual(page.actions,[]);self.assertEqual(page.saved,[])

    def documents(self):return [
        {P+'نوع المستند':'بطاقة تلقيح',P+'رقم الوثيقة':'00007',P+'جرى التسليم':True},
        {P+'نوع المستند':'إفادة سكن',P+'رقم الوثيقة':'00008',P+'تاريخ الإصدار':'2026-08-10',P+'طباعة على اللائحة':False}]
    def invoke(self,page,documents,save=None,guard=lambda:None):
        with patch.object(Locator,'all',lambda obj:[Locator(obj.page,[n]) for n in obj.nodes],create=True),\
             patch('document_import.time.monotonic',lambda:page.clock),\
             patch('manual_sections.time.monotonic',lambda:page.clock),\
             patch('document_import.save_manual',side_effect=save or page.save):
            return save_documents(page,{'documents':documents},guard)

    def test_add_fill_save_each_card_without_overwriting_previous_or_using_react_ids(self):
        page=MultiPage();self.assertEqual(self.invoke(page,self.documents()),'detail_saved')
        self.assertEqual(page.saved,['00007','00008'])
        self.assertEqual(page.actions.count(('click','إضافة')),2)
        self.assertEqual(len(page.section.xpath('.//select')),2)
        self.assertEqual([c.xpath('.//input[@type="text"]')[0].get('value') for c in page.section.xpath(CARD[6:])],['00007','00008'])

    def test_unknown_second_save_prevents_third_add(self):
        page=MultiPage();documents=self.documents()+[{P+'نوع المستند':'شهادة صحية',P+'رقم الوثيقة':'00009'}]
        def save(*args,**kwargs):
            if len(page.saved)==1:raise DetailError('detail_save_unknown')
            return page.save(*args,**kwargs)
        with self.assertRaises(DetailError):self.invoke(page,documents,save)
        self.assertEqual(page.actions.count(('click','إضافة')),2);self.assertEqual(page.saved,['00007'])

    def test_unrelated_existing_attachment_and_form_are_preserved(self):
        page=MultiPage();add=page.section.xpath('.//button[@data-add]')[0]
        page.after_click(add)
        existing=page.section.xpath(CARD[6:])[0]
        file=existing.xpath('.//input[@type="file"]')[0];file.set('value','C:\\fakepath\\existing.pdf')
        before=html.tostring(existing)
        self.invoke(page,self.documents()[:1])
        self.assertEqual(html.tostring(existing),before)
        self.assertEqual(len(page.section.xpath(CARD[6:])),2);self.assertEqual(page.saved,['00007'])

    def test_all_dates_and_types_are_validated_before_first_write(self):
        for bad in ({P+'نوع المستند':'إفادة سكن',P+'تاريخ الإصدار':'31/2/2026'},
                    {P+'نوع المستند':'INVALID'}):
            page=MultiPage()
            with self.assertRaises(DetailError):self.invoke(page,self.documents()+[bad])
            self.assertEqual(page.actions,[]);self.assertEqual(page.saved,[])

    def test_existing_matching_card_is_reused_and_ambiguous_cards_stop(self):
        page=MultiPage();self.invoke(page,self.documents()[:1])
        before=page.actions.count(('click','إضافة'))
        self.invoke(page,self.documents())
        self.assertEqual(page.actions.count(('click','إضافة')),before+1)
        page.section.append(copy.deepcopy(page.section.xpath(CARD[6:])[0]))
        before=len(page.actions)
        with self.assertRaises(DetailError):self.invoke(page,self.documents()[:1])
        self.assertFalse(any(a==('click','إضافة') for a in page.actions[before:]))

    def test_cancellation_after_first_save_prevents_later_documents(self):
        page=MultiPage()
        def guard():
            if page.saved:raise DetailError('detail_account')
        with self.assertRaises(DetailError):self.invoke(page,self.documents(),guard=guard)
        self.assertEqual(page.saved,['00007']);self.assertEqual(page.actions.count(('click','إضافة')),1)

    def test_review_runs_once_after_all_docs_and_never_after_document_failure(self):
        for review in (False,True):
            for failed in (False,True):
                page=MultiPage();record={'manual':{},'documents':self.documents()};events=[]
                def run(section):
                    if section=='review_send':events.append('review');return 'detail_review_sent'
                    def save(*args,**kwargs):
                        if failed and page.saved:raise DetailError('detail_save_unknown')
                        return page.save(*args,**kwargs)
                    result=self.invoke(page,record['documents'],save);events.extend(page.saved);return result
                if failed:
                    with self.assertRaises(DetailError):import_detailed_record(page,record,'details_import_review' if review else 'details_import',lambda **kw:None,run)
                    self.assertNotIn('review',events)
                else:
                    result=import_detailed_record(page,record,'details_import_review' if review else 'details_import',lambda **kw:None,run)
                    self.assertEqual(events,['00007','00008']+(['review'] if review else []))
                    self.assertEqual(result,'detail_import_review_sent' if review else 'detail_import_saved')

    def test_selected_section_routes_documents_through_same_runner(self):
        with patch('document_import.save_documents',return_value='detail_saved') as saved:
            row={'manual':{},'documents':self.documents()}
            self.assertEqual(fill_verified_section(None,row,'manual_save:المستندات',lambda:None),'detail_saved')
            self.assertIs(saved.call_args.args[1],row)

    def test_actual_save_protocol_uses_supplied_card_and_one_confirmation(self):
        from manual_save import save_manual
        from test_manual_save import Page as SavePage,Node
        page=SavePage();card=Node(page,'card2')
        with patch('manual_save.scope_for',side_effect=AssertionError('Whole section must not be saved')):
            self.assertEqual(save_manual(page,'المستندات',lambda:None,document_block=card),'detail_saved')
        self.assertEqual(page.actions,[('click','حفظ'),('click','confirm:تأكيد')])


if __name__=='__main__':unittest.main()
