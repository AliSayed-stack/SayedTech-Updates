"""Detached Windows updater for a source ZIP; keeps .venv and local data intact."""
import os
from pathlib import Path
import shutil
import subprocess
import sys


def wait_for_exit(pid, timeout=120):
    if sys.platform != 'win32':
        return
    import ctypes
    kernel = ctypes.windll.kernel32
    kernel.OpenProcess.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.c_uint]
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.OpenProcess(0x00100000, False, pid)
    if handle:
        try:
            if kernel.WaitForSingleObject(handle, timeout * 1000) != 0:
                raise RuntimeError('Sayed tech is still running; close it and retry the update.')
        finally:
            kernel.CloseHandle(handle)


def apply_source(staged_root, target_root, backup_root):
    staged_root, target_root, backup_root = map(Path, (staged_root, target_root, backup_root))
    if not (staged_root / 'START_WINDOWS.bat').is_file() or not (target_root / 'START_WINDOWS.bat').is_file():
        raise RuntimeError('Update source or installation directory is invalid.')
    changed = []
    backup_root.mkdir(parents=True, exist_ok=True)
    try:
        for source in sorted(staged_root.rglob('*')):
            if not source.is_file():
                continue
            relative = source.relative_to(staged_root)
            if any(x in {'.venv', 'dist', '__pycache__'} for x in relative.parts):
                raise RuntimeError('The update includes a protected local folder.')
            target = target_root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            previous = target.is_file()
            if previous:
                saved = backup_root / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
            incoming = target.with_name(target.name + '.sayed-update')
            shutil.copy2(source, incoming)
            try:
                os.replace(incoming, target)
            finally:
                incoming.unlink(missing_ok=True)
            changed.append((target, previous, relative))
    except Exception:
        for target, previous, relative in reversed(changed):
            if previous:
                shutil.copy2(backup_root / relative, target)
            else:
                target.unlink(missing_ok=True)
        raise


def launch_detached(stage, target_root, pid):
    stage = Path(stage)
    script = stage / 'update_apply.py'
    shutil.copy2(Path(__file__), script)
    flags = getattr(subprocess, 'DETACHED_PROCESS', 0) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
    subprocess.Popen([sys.executable, str(script), str(pid), str(stage), str(target_root)],
                     cwd=str(stage), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, creationflags=flags, close_fds=True)


def main():
    pid, stage, target_root = int(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    try:
        wait_for_exit(pid)
        apply_source(stage / 'extracted' / 'SayedTech_Stage1', target_root, stage / 'backup')
        os.startfile(str(target_root / 'START_WINDOWS.bat'))
    except Exception as exc:
        # Only a fixed error class is written; never student data or credentials.
        (stage / 'update_error.txt').write_text(type(exc).__name__ + ': ' + str(exc), encoding='utf-8')
        try:os.startfile(str(target_root / 'START_WINDOWS.bat'))
        except OSError:pass


if __name__ == '__main__':
    main()
