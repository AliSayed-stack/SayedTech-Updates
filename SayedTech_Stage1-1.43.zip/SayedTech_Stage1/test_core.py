import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import core

class Checks(unittest.TestCase):
    def test_only_two_fields_and_arabic_digits(self):
        self.assertEqual(core.school_payload('مدرسة تجريبية','٠٠١٢٣'),{core.SCHOOL_FIELD:'مدرسة تجريبية',core.CENTER_FIELD:'00123'})
        for c in ('','12a','-2','1/2','1'*13):
            with self.assertRaises(core.AppError): core.school_payload('مدرسة',c)

    def test_confirmation_and_payload(self):
        calls=[]
        def post(url,**kw):
            calls.append((url,kw))
            return SimpleNamespace(status_code=200,text='Your response has been recorded.')
        self.assertEqual(core.submit_school('مدرسة','012',post),('مدرسة','012'))
        self.assertEqual(set(calls[0][1]['data']),{core.SCHOOL_FIELD,core.CENTER_FIELD})
        self.assertEqual(set(calls[0][1]['headers']),{'Accept-Language'})
        with self.assertRaises(core.AppError):
            core.submit_school('مدرسة','012',lambda *a,**kw:SimpleNamespace(status_code=200,text='Required question'))

    def test_only_school_fields_saved(self):
        with tempfile.TemporaryDirectory() as d,patch.object(core,'registration_path',return_value=Path(d)/'school.json'):
            core.save_school('مدرسة','012')
            self.assertEqual(core.read_school(), {'school':'مدرسة','center':'012'})
            self.assertEqual(set(__import__('json').loads((Path(d)/'school.json').read_text())), {'school','center'})

    def test_opening_correct_portal(self):
        with patch.object(core,'open_auth_browser') as fn:
            core.open_sims('edge')
            fn.assert_called_once_with('https://new-sims.mehe.gov.lb/login','edge')

if __name__=='__main__': unittest.main()
