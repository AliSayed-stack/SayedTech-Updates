@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
call "%~dp0SETUP_PYTHON_WINDOWS.bat"
if not "%errorlevel%"=="0" goto failure
if not defined SAYED_PYTHON goto failure
"%SAYED_PYTHON%" build_windows.py
if not "%errorlevel%"=="0" goto failure
echo Ready: dist\SayedTech-Setup-Windows-x64.exe
echo Send this one installer EXE. Recipients do not need Python.
pause
exit /b 0
:failure
echo Build failed. Review the error above. Do not send any previous installer in dist.
pause
exit /b 1
