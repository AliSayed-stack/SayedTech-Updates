; Compiled only after both frozen executables pass their offline self-tests.
[Setup]
AppId={{A028D558-46BA-48BD-A8F6-DC117D5C83A3}
AppName=Sayed tech
AppVersion=@APP_VERSION@
AppPublisher=Ali El Sayed
DefaultDirName={localappdata}\Programs\SayedTech
DefaultGroupName=Sayed tech
PrivilegesRequired=lowest
ArchitecturesAllowed=x64os
ArchitecturesInstallIn64BitMode=x64os
MinVersion=10.0
OutputDir=@OUTPUT_DIR@
OutputBaseFilename=SayedTech-Setup-Windows-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableDirPage=yes
UninstallDisplayIcon={app}\SayedTech.exe

[Files]
Source: "@PACKAGE_DIR@\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Sayed tech"; Filename: "{app}\SayedTech.exe"
Name: "{autodesktop}\Sayed tech"; Filename: "{app}\SayedTech.exe"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Run]
Filename: "{app}\SayedTech.exe"; Description: "Launch Sayed tech"; Flags: nowait postinstall skipifsilent
