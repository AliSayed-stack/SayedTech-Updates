"""Bounded login helper. Never persists or emits credentials."""
import re
import time
from urllib.parse import urlsplit

SHIFT_DOMAINS = {'morning': 'te.mehe.school', 'afternoon': 'te.pm.mehe.school'}
SIMS_HOST = 'new-sims.mehe.gov.lb'
MICROSOFT_HOST = 'login.microsoftonline.com'
PORTAL_MAX_ATTEMPTS = 6
PORTAL_RETRY_SECONDS = 8
PORTAL_LOGIN_NAME = re.compile(
    r'(?:تسجيل|sign\s*in|se\s*connecter|connexion)[\s\S]*(?:Microsoft|مايكروسوفت|ميكروسوفت)'
    r'|(?:Microsoft|مايكروسوفت|ميكروسوفت)[\s\S]*(?:تسجيل|sign\s*in|connexion)', re.I)


class LoginInputError(ValueError):
    pass


def validate_credentials(username, password, browser, shift):
    if not isinstance(shift, str) or shift not in SHIFT_DOMAINS:
        raise LoginInputError('اختر مدارس قبل الظهر أو مدارس بعد الظهر أولاً.')
    expected_domain = SHIFT_DOMAINS[shift]
    if not isinstance(username, str) or not isinstance(password, str):
        raise LoginInputError('بيانات الدخول غير صالحة.')
    username = username.strip().casefold()
    if (username.count('@') != 1 or not username.split('@')[0]
            or username.rsplit('@', 1)[-1] != expected_domain
            or len(username) > 254 or any(c.isspace() for c in username)):
        shift_name = 'قبل الظهر' if shift == 'morning' else 'بعد الظهر'
        raise LoginInputError(f'مدارس {shift_name}: استخدم إيميلاً ينتهي فقط بـ @{expected_domain}.')
    if not password or len(password) > 1024:
        raise LoginInputError('أدخل كلمة السر.')
    if browser not in ('edge', 'chrome'):
        raise LoginInputError('اختر Google Chrome أو Microsoft Edge.')
    return username, password, browser


def exact_https_host(url, host):
    try:
        parsed = urlsplit(url)
        return (parsed.scheme == 'https' and parsed.hostname == host
                and parsed.port in (None, 443) and parsed.username is None
                and parsed.password is None)
    except (TypeError, ValueError):
        return False


def is_dashboard(url):
    return exact_https_host(url, SIMS_HOST) and urlsplit(url).path.startswith('/dashboard/')


def visible(locator):
    try:
        for item in locator.all()[:12]:
            if item.is_visible():
                return item
        return None
    except Exception:
        return None


def ready_button(locator):
    """Use a unique real button; nested captions and hidden copies are ignored."""
    try:
        matches = [item for item in locator.all()[:12]
                   if item.is_visible() and item.is_enabled()]
        return matches[0] if len(matches) == 1 else None
    except Exception:
        return None


class LoginFlow:
    def __init__(self, username, password, emit, clock=time.monotonic):
        self.username = username
        self._password = password
        self.emit = emit
        self.clock = clock
        self.last_action = clock()
        self.portal_clicked = False
        self.portal_attempts = 0
        self.portal_last_attempt = None
        self.portal_reloaded = False
        self.email_attempted = False
        self.password_attempted = False
        self.connected = False
        self.last_event = None
        self.account_session = None

    def notice(self, event):
        if event != self.last_event:
            self.last_event = event
            self.emit(event)

    def clear_secret(self):
        self._password = None

    def tick(self, pages):
        pages = [p for p in pages if not p.is_closed()]
        if self.connected:
            if self.account_session is not None:self.account_session.observe()
            return
        if (pages and all(p.url in ('','about:blank') for p in pages) and
                not (self.portal_attempts or self.email_attempted or self.password_attempted)):
            self.notice('portal_open_manual_required')
            return
        # A dashboard URL alone is insufficient; the requested account and menu
        # must be visible before telling the GUI that authentication succeeded.
        for page in pages:
            if is_dashboard(page.url):
                account = visible(page.get_by_text(re.compile(r'^\s*' + re.escape(self.username) + r'\s*$', re.I)))
                students = visible(page.get_by_text('الطلاب', exact=True))
                if account and students:
                    from account_session import AccountSession
                    self.account_session=AccountSession(page,self.username,clock=self.clock)
                    self.connected = True
                    self.clear_secret()
                    self.notice('authenticated')
                    return
                self.notice('verify_account')
                return
        # Support redirects in the same tab and Microsoft sign-in popup tabs.
        for page in reversed(pages):
            if exact_https_host(page.url, MICROSOFT_HOST):
                if not self.email_attempted:
                    email = visible(page.get_by_placeholder('Email or phone', exact=True))
                    if email is None:
                        email = visible(page.locator('input[type="email"]'))
                    next_button = visible(page.get_by_role('button', name=re.compile(r'^(Next|التالي)$', re.I)))
                    if email is not None and next_button is not None:
                        self.email_attempted = True  # Never retry submission in a loop.
                        if not exact_https_host(page.url, MICROSOFT_HOST):
                            return
                        email.fill(self.username, timeout=2000)
                        if not exact_https_host(page.url, MICROSOFT_HOST):
                            return
                        next_button.click(timeout=2000)
                        self.last_action = self.clock()
                        self.notice('email_submitted')
                        return
                if not self.password_attempted:
                    password = visible(page.locator('input[type="password"]'))
                    sign_in = visible(page.get_by_role('button', name=re.compile(r'^(Sign in|تسجيل الدخول)$', re.I)))
                    if password is not None and sign_in is not None:
                        self.password_attempted = True
                        if not exact_https_host(page.url, MICROSOFT_HOST):
                            return
                        try:
                            password.fill(self._password, timeout=2000)
                        finally:
                            self.clear_secret()
                        if not exact_https_host(page.url, MICROSOFT_HOST):
                            return
                        sign_in.click(timeout=2000)
                        self.last_action = self.clock()
                        self.notice('password_submitted')
                        return
                if self.clock() - self.last_action > 5:
                    # Account selection, MFA, password errors, consent, and
                    # unfamiliar screens are completed by the user in browser.
                    self.notice('manual_required')
                return
        for page in pages:
            if (exact_https_host(page.url, SIMS_HOST)
                    and urlsplit(page.url).path.rstrip('/') == '/login'):
                # Never restart the public sign-in flow after credentials were
                # submitted; rejection/MFA/consent require user attention.
                if self.email_attempted or self.password_attempted:
                    self.notice('manual_required')
                    return
                if self.portal_attempts >= PORTAL_MAX_ATTEMPTS:
                    if self.clock() - self.portal_last_attempt >= PORTAL_RETRY_SECONDS:
                        self.notice('portal_manual_required')
                    return
                if self.portal_last_attempt is not None and self.clock() - self.portal_last_attempt < PORTAL_RETRY_SECONDS:
                    return
                if self.portal_attempts >= 3 and not self.portal_reloaded:
                    self.portal_reloaded = True
                    self.portal_last_attempt = self.clock()
                    self.last_action = self.clock()
                    self.notice('portal_retry')
                    try:
                        page.bring_to_front()
                        # Reload only the observed public /login page, once.
                        if (exact_https_host(page.url, SIMS_HOST) and
                                urlsplit(page.url).path.rstrip('/') == '/login'):
                            page.reload(wait_until='domcontentloaded', timeout=15000)
                    except Exception:
                        pass
                    return
                # Locate the clickable button by accessible name. This also
                # tolerates bidi marks/spans between the Arabic and Microsoft.
                button = ready_button(page.get_by_role('button', name=PORTAL_LOGIN_NAME))
                if button is None:
                    button = ready_button(page.get_by_role('link', name=PORTAL_LOGIN_NAME))
                if button is not None:
                    self.portal_attempts += 1
                    self.portal_last_attempt = self.clock()
                    self.last_action = self.clock()
                    try:
                        # Only this public portal button may be retried. A
                        # pre-hydration click or temporarily covered button
                        # must not permanently freeze the whole login flow.
                        if not exact_https_host(page.url, SIMS_HOST) or urlsplit(page.url).path.rstrip('/') != '/login':
                            return
                        button.click(timeout=5000)
                    except Exception:
                        self.notice('portal_retry')
                        return
                    self.portal_clicked = True
                    self.notice('microsoft_opening')
                    return
        if self.clock() - self.last_action > 5:
            self.notice('manual_required')
