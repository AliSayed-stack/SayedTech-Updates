import copy
import tempfile
import unittest
import zipfile
from pathlib import Path
from name_transliteration import transliterate_name, suggest_english_names, NAME_PAIRS
from student_excel import HEADERS, validate_record
from student_workflow import write_simple, workbook_rows
from test_students import record


class NameTests(unittest.TestCase):
    def test_common_compound_and_normalization(self):
        for source, expected in [('أَحْمَد', 'Ahmad'), ('مُحَمَّد', 'Mohammad'),
                                 ('عـلي السيد', 'Ali Al Sayed'),
                                 ('عبدالرحمن', 'Abd Al Rahman'),
                                 ('عبد الله', 'Abd Allah'),
                                 ('نور الدين', 'Nour Al Din'),
                                 ('مريم', 'Mariam'), ('مصطفى', 'Mustafa'),
                                 ('Ali أحمد', 'Ali Ahmad')]:
            self.assertEqual(transliterate_name(source), expected)

    def test_blank_invalid_and_unknown(self):
        for value in (None, 123, '', ' ', '=1+1', 'أحمد123', 'أحمد\nمحمد', 'ع'*257):
            self.assertEqual(transliterate_name(value), '')
        value = transliterate_name('بخت')
        self.assertTrue(value.isascii() and value)

    def test_preserve_existing_and_source(self):
        data = {a: 'أحمد' for a, e in NAME_PAIRS}
        data.update({e: '  ' for a, e in NAME_PAIRS})
        data['field-firstNameEn'] = 'Ahmed'
        data['field-middleNameEn'] = 123  # retain invalid input for validation
        original = copy.deepcopy(data)
        result = suggest_english_names(data)
        self.assertEqual(data, original)
        self.assertEqual(result['field-firstNameEn'], 'Ahmed')
        self.assertEqual(result['field-middleNameEn'], 123)
        self.assertEqual(result['field-motherNameEn'], 'Ahmad')

    def test_export_fills_all_four_but_import_does_not_invent(self):
        data = record()
        for a, e in NAME_PAIRS:
            data[a] = 'أحمد'; data[e] = ''
        original = copy.deepcopy(data)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'simple.xlsx'
            write_simple([data], path, 'test.xlsx', '0'*64)
            with zipfile.ZipFile(path) as z:
                # First worksheet name is read from actual template metadata.
                import xml.etree.ElementTree as ET
                from student_excel import NS
                name = ET.fromstring(z.read('xl/workbook.xml')).find('m:sheets/m:sheet', NS).get('name')
                rows = workbook_rows(z, name)
                self.assertIn('Ahmad', str(rows))
                sheet = z.read('xl/worksheets/sheet1.xml').decode()
                self.assertEqual(sheet.count('>Ahmad<'), 4)
        self.assertEqual(data, original)
        clean, errors = validate_record(data)
        self.assertTrue(errors)
        self.assertEqual(clean['field-firstNameEn'], '')


if __name__ == '__main__':
    unittest.main()
