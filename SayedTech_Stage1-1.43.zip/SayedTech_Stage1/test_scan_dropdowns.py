import copy
import tempfile
import threading
import unittest
import zipfile
from pathlib import Path
from openpyxl import load_workbook
from scan_dropdowns import attach_scan_dropdowns,repair_scan_dropdowns,dropdown_options,OPTIONS_SHEET,PREFIX
from student_scan import export_students
from student_excel import ExcelInputError
import test_manual_sections as fixtures


class ScanDropdownTests(unittest.TestCase):
    def check_lists(self,path,last=501):
        book=load_workbook(path);sheet=book['الطلاب']
        headers={c.value:c.column_letter for c in sheet[1]}
        self.assertEqual(book[OPTIONS_SHEET].sheet_state,'hidden')
        for header,expected in dropdown_options().items():
            address=headers[header]+'2'
            validations=[v for v in sheet.data_validations.dataValidation if address in v]
            self.assertEqual(len(validations),1,header)
            validation=validations[0]
            self.assertEqual(validation.type,'list');self.assertFalse(validation.showDropDown)
            self.assertIn(headers[header]+str(last),validation)
            definition=book.defined_names[validation.formula1]
            title,reference=next(definition.destinations)
            values=[c.value for row in book[title][reference] for c in row]
            self.assertEqual(values,expected)
        # Original lists also use Excel-supported names instead of cross-sheet direct ranges.
        for validation in sheet.data_validations.dataValidation:
            self.assertFalse(validation.showDropDown)
            if validation.formula1.startswith('SayedSourceList_'):
                self.assertIn(validation.formula1,book.defined_names)
        book.close()

    def test_export_all_lists_and_extended_range(self):
        _,data=fixtures.ManualWorkbookTests().data()
        data['records']=[copy.deepcopy(data['records'][0]) for _ in range(501)]
        data['inventory']=501
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'scan.xlsx';export_students(data,path,threading.Event())
            self.check_lists(path,502)

    def test_existing_export_repair_preserves_payload_and_is_repeatable(self):
        _,data=fixtures.ManualWorkbookTests().data()
        with tempfile.TemporaryDirectory() as folder:
            old=Path(folder)/'old.xlsx';new=Path(folder)/'fixed.xlsx'
            export_students(data,old,threading.Event())
            # Reproduce the older export with missing tail menus and hidden arrows.
            with zipfile.ZipFile(old) as z:parts={n:z.read(n) for n in z.namelist()}
            import xml.etree.ElementTree as ET
            root=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
            ns='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
            validations=root.find(ns+'dataValidations')
            for v in list(validations):
                if v.find(ns+'formula1').text.startswith(PREFIX):validations.remove(v)
                else:v.set('showDropDown','1')
            parts['xl/worksheets/sheet1.xml']=ET.tostring(root)
            with zipfile.ZipFile(old,'w') as z:
                for name,value in parts.items():z.writestr(name,value)
            before=old.read_bytes();repair_scan_dropdowns(old,new)
            self.assertEqual(old.read_bytes(),before);self.check_lists(new)
            with zipfile.ZipFile(new) as z:fixed={n:z.read(n) for n in z.namelist()}
            after=ET.fromstring(fixed['xl/worksheets/sheet1.xml'])
            self.assertEqual(ET.tostring(root.find(ns+'sheetData')),ET.tostring(after.find(ns+'sheetData')))
            for key,value in parts.items():
                if key not in ('xl/worksheets/sheet1.xml','xl/workbook.xml','xl/_rels/workbook.xml.rels','[Content_Types].xml'):
                    self.assertEqual(value,fixed[key],key)
            attach_scan_dropdowns(fixed)
            again=Path(folder)/'again.xlsx'
            with zipfile.ZipFile(again,'w') as z:
                for name,value in fixed.items():z.writestr(name,value)
            self.check_lists(again)
            with self.assertRaises(ExcelInputError):repair_scan_dropdowns(old,old)
            with self.assertRaises(ExcelInputError):repair_scan_dropdowns(old,new)


if __name__=='__main__':unittest.main()
