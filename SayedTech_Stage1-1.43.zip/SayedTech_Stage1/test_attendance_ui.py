"""Real Qt attendance queue, grade/checkbox scope and app routing checks."""
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication,QWidget,QTableWidget
    from attendance_dialog import AttendanceDialog,AttendanceExportDialog
    from attendance_excel import write_attendance
    from test_attendance import PUPIL,USERNAME
    from test_detailed_batch_ui import Signal
    from app import STYLE,Window
    from login_controller import LoginController
    QT=True
except ImportError:QT=False


class Controller:
    def __init__(self):self.event=Signal();self.attendance_result=Signal();self.requests=[]
    def attendance(self,*args,**kwargs):self.requests.append((args,kwargs));return True


@unittest.skipUnless(QT,'Qt unavailable')
class AttendanceUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])

    def setUp(self):
        self.parent=QWidget();self.parent.setStyleSheet(STYLE);self.controller=Controller()
        self.dialog=AttendanceDialog(self.controller,self.parent)
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'attendance.xlsx'
        pupils=[dict(PUPIL,uid=str(i),grade='الأول أساسي' if i<2 else 'الثاني أساسي') for i in range(3)]
        write_attendance(self.path,pupils,USERNAME)
        # These edits emulate the user in Excel; no edited fixture is packaged.
        from openpyxl import load_workbook
        book=load_workbook(self.path)
        for row in (2,3,4):
            book['الحضور'].cell(row,1,'1');book['الحضور'].cell(row,7,'10/25/2026');book['الحضور'].cell(row,9,'سفر')
        book.save(self.path);book.close()
        with patch('attendance_dialog.QFileDialog.getOpenFileName',return_value=(str(self.path),'')):self.dialog.load_file()

    def tearDown(self):
        self.dialog.pending=None;self.dialog.active=False;self.dialog.reject();self.dialog.deleteLater()
        self.parent.deleteLater();self.app.processEvents();self.temp.cleanup()

    def result(self,event,days=1):
        request=self.controller.requests[-1][0][1]
        self.controller.attendance_result.emit(request,event,days);self.app.processEvents()

    def test_grade_checkbox_scope_and_one_pending_request_preserve_successful_rows(self):
        d=self.dialog;d.grade.setCurrentIndex(1);d.table.item(0,0).setCheckState(Qt.Unchecked)
        d.start_import();self.assertEqual(len(self.controller.requests),1)
        self.assertEqual(self.controller.requests[0][1]['record']['excel_row'],3)
        self.assertFalse(d.table.isEnabled());self.assertFalse(d.grade.isEnabled())
        d.start_import();self.assertEqual(len(self.controller.requests),1)
        self.result('attendance_saved',2)
        self.assertEqual(d.completed,{1});self.assertFalse(d.active)
        d.start_import();self.assertEqual(len(self.controller.requests),1)
        d.grade.setCurrentIndex(2);d.start_import()
        self.assertEqual(self.controller.requests[-1][1]['record']['excel_row'],4)

    def test_unknown_save_stops_remaining_students_and_session_loss_ignores_late_result(self):
        d=self.dialog;d.start_import();self.result('attendance_save_unknown')
        self.assertEqual(len(self.controller.requests),1);self.assertEqual(d.completed,set())
        d.start_import();request=self.controller.requests[-1][0][1]
        self.controller.event.emit('disconnected');self.controller.attendance_result.emit(request,'attendance_saved',1)
        self.app.processEvents();self.assertEqual(d.completed,set());self.assertFalse(d.start.isEnabled())

    def test_stop_after_current_and_confirmed_resume_only(self):
        d=self.dialog;d.start_import();d.stop_import();self.result('attendance_saved')
        self.assertEqual(len(self.controller.requests),1);self.assertFalse(d.active)
        d.start_import();self.assertEqual(self.controller.requests[-1][1]['record']['excel_row'],3)

    def test_rtl_and_small_window_keep_actions_accessible_without_growing_offscreen(self):
        d=self.dialog;d.show();self.app.processEvents();d.resize(760,590);self.app.processEvents()
        self.assertEqual(d.size().toTuple(),(760,590));self.assertTrue(d.rect().contains(d.close_button.geometry()))
        self.assertEqual(d.table.layoutDirection(),Qt.RightToLeft)
        self.assertEqual(d.scroll.horizontalScrollBar().maximum(),0)
        d.scroll.ensureWidgetVisible(d.start);self.app.processEvents()
        self.assertTrue(d.start.isVisible())

    def test_both_school_menu_routes_attendance_and_controller_preserves_command(self):
        for shift in ('morning','afternoon'):
            with patch('app.core.read_school',return_value={}):w=Window()
            w.school_shift=shift;w.connected=True
            for operation in ('استخراج','استرداد'):
                with patch.object(w,'open_attendance') as opening:
                    w.operation_buttons['student_attendance',operation].click()
                    opening.assert_called_once_with(operation)
            with patch('attendance_dialog.AttendanceExportDialog') as exporting,patch('attendance_dialog.AttendanceDialog') as importing:
                w.open_attendance('استخراج')
                exporting.return_value.exec.assert_called_once();importing.assert_not_called()
                w.open_attendance('استرداد')
                importing.return_value.exec.assert_called_once()
            w.close();w.deleteLater();self.app.processEvents()
        exporter=AttendanceExportDialog(self.controller,self.parent)
        self.assertFalse(exporter.findChildren(QTableWidget));self.assertFalse(hasattr(self.dialog,'export'))
        for action,event in (('attendance_template','attendance_template_saved'),('attendance_export','attendance_exported')):
            with patch('attendance_dialog.QFileDialog.getSaveFileName',return_value=(str(self.path),'')):exporter.export(action)
            request=self.controller.requests[-1][0][1]
            self.assertEqual(self.controller.requests[-1][0][0],action);self.assertFalse(exporter.close_button.isEnabled())
            self.controller.attendance_result.emit('f'*32,event,3);self.assertIsNotNone(exporter.pending)
            self.controller.attendance_result.emit(request,event,3);self.assertIsNone(exporter.pending)
            self.assertTrue(exporter.close_button.isEnabled());self.assertIn(str(self.path),exporter.status.text())
        exporter.reject();exporter.deleteLater();self.app.processEvents()
        controller=LoginController()
        class Process:
            def write(self,value):self.value=value;return len(value)
        process=Process();controller.process=process
        with patch.object(controller,'running',return_value=True):
            self.assertTrue(controller.attendance('attendance_import','a'*32,record=self.dialog.rows[0],batch_id='b'*32))
        import json
        command=json.loads(process.value);self.assertEqual(command['action'],'attendance_import')
        self.assertEqual(command['record']['excel_row'],2)

    def test_worker_results_allow_only_fixed_events_valid_request_ids_and_integer_counts(self):
        import json
        controller=LoginController();received=[]
        controller.attendance_result.connect(lambda *args:received.append(args))
        base={'event':'attendance_saved','request_id':'a'*32,'days':2}
        messages=[base,dict(base,event='attendance_untrusted'),dict(base,request_id='wrong'),
                  dict(base,days=True),dict(base,days=5001)]
        class Process:
            def readAllStandardOutput(self):return ('\n'.join(json.dumps(v) for v in messages)+'\n').encode()
        controller.process=Process();controller._read_output()
        self.assertEqual(received,[('a'*32,'attendance_saved',2)])


if __name__=='__main__':unittest.main()
