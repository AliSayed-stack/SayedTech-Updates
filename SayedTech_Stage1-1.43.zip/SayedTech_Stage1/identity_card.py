"""Identity card columns and the site's explicit document choices."""
from student_excel import FIELDS, ExcelInputError,normalize_date
from datetime import date, timedelta

CARD_COLUMNS = ['نوع المستند (بطاقة التعريف)', 'رقم الوثيقة (بطاقة التعريف)', 'تاريخ الانتهاء (بطاقة التعريف)']
DOCUMENT_TYPES = {
    'هوية':'identity', 'بطاقة الطالب الموحدة':'unified_student_card',
    'ملف':'file', 'جواز سفر':'passport', 'سجل مدني':'civil_registry',
    'رقم اللجوء':'refugee_number', 'بطاقة إقامة سارية':'valid_residency_card',
    'سجل جنائي':'criminal_record', 'رقم تعريف موحد':'compiler_unique_id',
    'بطاقة الأمم المتحدة سارية':'valid_un_card', 'إيصال إقامة':'residency_receipt',
    'لا توجد وثائق':'no_documents',
}
REGISTRY_COLUMN = next(f['label'] for f in FIELDS if f['id']=='field-registryNumber')

def document_number(value):
    if value is None:return ''
    if isinstance(value,int) and not isinstance(value,bool):return str(value)
    if not isinstance(value,str):raise ExcelInputError('رقم الوثيقة يجب أن يكون نصاً؛ احفظ الأصفار الأولى كما هي.')
    value=value.strip()
    if len(value)>128 or any(ord(c)<32 for c in value):raise ExcelInputError('رقم الوثيقة غير صالح.')
    return value

def card_from_row(row):
    number=row.get(CARD_COLUMNS[1],'')
    if number is None or not str(number).strip():number=row.get(REGISTRY_COLUMN,'')
    # Validate at the time this section is requested, not while importing phones.
    return {'type':row.get(CARD_COLUMNS[0],''), 'number':number,
            'expiry':row.get(CARD_COLUMNS[2],'')}

def validate_card(card):
    kind=str(card.get('type','') or '').strip()
    if kind not in DOCUMENT_TYPES:raise ExcelInputError('اختر نوع المستند في Excel.')
    if kind=='لا توجد وثائق':return kind,'',''
    number=document_number(card.get('number',''))
    if not number and kind!='لا توجد وثائق':raise ExcelInputError('أكمل رقم الوثيقة أو رقم السجل في Excel.')
    expiry=card.get('expiry','')
    if expiry is not None and str(expiry).strip():
        expiry=normalize_date(expiry,allow_future=True)
    else:expiry=''
    return kind,number,expiry
