"""Regressions for export compatibility and parent-dependent address lists."""
import io
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
import xml.etree.ElementTree as ET

import core
from address_excel import attach_address_lists, HEADERS, SHEET
from student_detailed import PREP_HEADERS, convert_to_detailed, read_table
from student_unified import UNIFIED_HEADERS
from student_workflow import workbook_rows, column
from student_excel import NS


def read_parts(name):
    with zipfile.ZipFile(core.ASSET_BASE / 'assets' / name) as z:
        return {n: z.read(n) for n in z.namelist()}


def archive(parts):
    data = io.BytesIO()
    with zipfile.ZipFile(data, 'w') as z:
        for n, value in parts.items(): z.writestr(n, value)
    data.seek(0)
    return zipfile.ZipFile(data)


class AddressExportTests(unittest.TestCase):
    def test_existing_cells_tables_formats_and_other_dropdowns_are_preserved(self):
        for name, headers in [('student_unified.xlsx', UNIFIED_HEADERS),
                              ('student_detailed_prepared.xlsx', PREP_HEADERS)]:
            with self.subTest(name=name):
                parts = read_parts(name)
                before = dict(parts)
                old = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
                attach_address_lists(parts, headers, 501)
                new = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
                for tag in ('sheetData', 'cols', 'sheetViews', 'tableParts'):
                    a, b = old.find('m:' + tag, NS), new.find('m:' + tag, NS)
                    self.assertEqual(None if a is None else ET.tostring(a), None if b is None else ET.tostring(b))
                old_dv = old.findall('m:dataValidations/m:dataValidation', NS)
                new_dv = new.findall('m:dataValidations/m:dataValidation', NS)
                self.assertEqual([ET.tostring(v) for v in old_dv], [ET.tostring(v) for v in new_dv[:len(old_dv)]])
                self.assertEqual(len(new_dv) - len(old_dv), 4)
                old_styles, new_styles = (ET.fromstring(p['xl/styles.xml']) for p in (before, parts))
                for tag in ('cellXfs', 'fonts', 'fills', 'borders', 'numFmts'):
                    a, b = old_styles.find('m:' + tag, NS), new_styles.find('m:' + tag, NS)
                    self.assertEqual(None if a is None else ET.tostring(a), None if b is None else ET.tostring(b))
                for key in before:
                    if key.startswith(('xl/tables/', 'xl/worksheets/_rels/')):
                        self.assertEqual(before[key], parts[key])

    def test_catalog_values_are_preserved_and_all_parent_ranges_match(self):
        parts = read_parts('student_unified.xlsx')
        attach_address_lists(parts, UNIFIED_HEADERS, 501)
        with archive(parts) as z:
            rows = dict((n, r) for n, r, _ in workbook_rows(z, SHEET))
        with zipfile.ZipFile(core.ASSET_BASE / 'assets/student_with_addresses.xlsx') as z:
            original = dict((n, r) for n, r, _ in workbook_rows(z, SHEET))
        for n in rows:
            if n >= 7: self.assertEqual(rows[n], original[n])
        import re
        for n, row in rows.items():
            if n < 8: continue
            for ref_col, value_col, parent_col, expected in [
                ('H', 'L', None, None), ('N', 'C', 'B', row.get('L'))]:
                if not row.get(ref_col): continue
                ref = row[ref_col]
                m = re.fullmatch(r"'قوائم العناوين'!\$([A-Z]+)\$(\d+):\$\1\$(\d+)", ref)
                self.assertIsNotNone(m)
                self.assertEqual(m[1], value_col)
                for i in range(int(m[2]), int(m[3]) + 1):
                    self.assertTrue(rows[i].get(value_col))
                    if parent_col:
                        self.assertEqual(rows[i]['A'] + '__' + rows[i][parent_col], row['K'])
                    else:
                        self.assertTrue(rows[i]['K'].startswith(row['F'] + '__'))

    def test_adding_twice_does_not_duplicate_sheets_names_or_validation(self):
        parts = read_parts('student_unified.xlsx')
        attach_address_lists(parts, UNIFIED_HEADERS, 501)
        attach_address_lists(parts, UNIFIED_HEADERS, 501)
        book = ET.fromstring(parts['xl/workbook.xml'])
        self.assertEqual(sum(s.get('name') == SHEET for s in book.findall('m:sheets/m:sheet', NS)), 1)
        names = [n.get('name') for n in book.findall('m:definedNames/m:definedName', NS)]
        self.assertEqual(len(names), len(set(names)))
        sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
        dv = sheet.findall('m:dataValidations/m:dataValidation', NS)
        self.assertEqual(len(dv), len({d.get('sqref') for d in dv}))

    def test_conversion_extends_lists_beyond_500_for_both_export_paths(self):
        raw = dict.fromkeys(PREP_HEADERS, '')
        raw.update({'السنة في القاعدة': '20252026', 'بلد السكن': 'لبنان',
                    'محافظة السكن': 'الشمال', 'قضاء السكن': 'زغرتا',
                    'منطقة / بلدة السكن': 'بلدة من المصدر', 'الشارع': 'شارع تجريبي',
                    'رقم الهاتف (LivingPhone)': '03123456'})
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / 'source.xlsx'
            with zipfile.ZipFile(source, 'w') as z: z.writestr('source', 'fixture')
            untouched = source.read_bytes()
            for unified in (False, True):
                out = Path(folder) / ('unified.xlsx' if unified else 'detailed.xlsx')
                with patch('student_detailed.prepared_rows', return_value=[[raw[h] for h in PREP_HEADERS]] * 620), \
                     patch('student_promotion.source_results', return_value={}):
                    self.assertEqual(convert_to_detailed(source, out, unified=unified), 620)
                self.assertEqual(source.read_bytes(), untouched)
                with zipfile.ZipFile(out) as z:
                    records = read_table(z, 'الطلاب' if unified else 'المفصّل')
                    self.assertEqual(len(records), 620)
                    for r in (records[0], records[-1]):
                        for h in HEADERS + ('الشارع', 'رقم الهاتف (LivingPhone)'):
                            self.assertEqual(r[h], raw[h])
                    sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                    dvs = {d.get('sqref'): d.findtext('m:formula1', '', NS)
                           for d in sheet.findall('m:dataValidations/m:dataValidation', NS)}
                    headers = UNIFIED_HEADERS if unified else PREP_HEADERS
                    for h in HEADERS:
                        c = column(headers.index(h) + 1)
                        formula = dvs[c + '2:' + c + '621']
                        self.assertLessEqual(len(formula), 255)
                    cf = sheet.findall('m:conditionalFormatting/m:cfRule/m:formula', NS)
                    self.assertEqual(sum('ST_Address' in f.text for f in cf), 4)


if __name__ == '__main__': unittest.main()
