"""Offline duplicated/nested-label DOM and read-only site grade sync."""
import json
from pathlib import Path
import subprocess
import threading
import unittest
from unittest.mock import patch
from lxml import html
from student_scan import LIST_SCRIPT,StudentBrowser,ScanError,MANAGEMENT
from detail_scope import apply_site_grade
from detailed_import import start_detail_import,DetailError
from test_scan_grade_trigger import TriggerPage
from test_detail_scope import TrackingPage

GRADE='الثاني أساسي'


def wrapped_page():
    page=TriggerPage()
    outer=html.Element('div');outer.append(html.fromstring('<span>الصف</span>'))
    field=page.root.xpath('//div[@class="field"]')[0]
    field.xpath('.//span')[0].text='الصف'
    outer.append(field)
    for label,caption in (('فرع الصف','جميع الفروع'),('لغة التدريس','جميع لغات التدريس'),('الشعبة','جميع الشعب')):
        container=html.Element('div')
        container.append(html.fromstring('<div><span>'+label+'</span></div>'))
        container.append(html.fromstring('<button type="button"><span class="truncate">'+caption+'</span><svg class="lucide-chevron-down"></svg></button>'))
        outer.append(container)
    page.root.append(outer)
    return page


def snapshot(page,script=LIST_SCRIPT):
    def tree(e):return dict(tag=e.tag,attrs=dict(e.attrib),text=e.text or '',tail=e.tail or '',children=[tree(c) for c in e if isinstance(c.tag,str)])
    runner=Path(__file__).parent/'test_fixtures/dom_runner.js'
    r=subprocess.run(['node',str(runner)],input=json.dumps({'tree':tree(page.root),'script':script}),text=True,capture_output=True,check=True)
    return json.loads(r.stdout)


class GradeStructureTests(unittest.TestCase):
    def test_broad_repeated_label_does_not_bind_other_filters_as_grade_buttons(self):
        page=wrapped_page();browser=StudentBrowser(page,page.account,threading.Event())
        with patch('student_scan.time.monotonic',lambda:page.now):browser.select_grade(GRADE)
        self.assertEqual(page.grade,GRADE);self.assertEqual(page.actions,[('trigger',),('grade',GRADE)])

    def test_production_snapshot_deduplicates_controls_and_climbs_label_wrapper(self):
        page=wrapped_page()
        self.assertEqual(snapshot(page)['allFilters'],[1,1,1,1])
        page.trigger.xpath('./span')[0].text=GRADE
        raw=snapshot(page)
        self.assertEqual(raw['gradeFilter'],[GRADE]);self.assertEqual(raw['allFilters'],[0,1,1,1])


class GradeSyncTests(unittest.TestCase):
    def test_request_applies_grade_before_first_roster_read_and_never_inventories_school(self):
        import test_scan as site
        for username in ('test@te.mehe.school','test@te.pm.mehe.school'):
            page=TrackingPage(606,account=username);page.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
            page.number=5
            target='الأول أساسي'
            with patch('student_scan.time.monotonic',site.Clock()),patch.object(StudentBrowser,'inventory',side_effect=AssertionError('No inventory for scope sync')):
                self.assertEqual(start_detail_import(page,{'search_grade':target},'scope_grade',username,threading.Event()),'detail_grade_ready')
            self.assertEqual(page.grade,target)
            self.assertTrue(page.inventories);self.assertEqual({g for g,_ in page.inventories},{target})
            self.assertEqual({n for _,n in page.inventories},{1})
            self.assertFalse(any(a[0] in ('opened','fill') for a in page.actions))

    def test_existing_pupil_draft_is_not_discarded_for_filter_change(self):
        page=TrackingPage(3);page.url='https://new-sims.mehe.gov.lb'+MANAGEMENT+'/draft/edit'
        with self.assertRaises(DetailError):start_detail_import(page,{'search_grade':GRADE},'scope_grade',page.account,threading.Event())
        self.assertEqual(page.actions,[])

    def test_missing_options_and_account_guards_have_distinct_fixed_results(self):
        for reason,event in (('grade_filter','detail_grade_trigger'),('grade_options','detail_grade_options'),
                             ('filters_active','detail_grade_filters'),('search_active','detail_grade_filters'),
                             ('row_count','detail_grade_rows'),('headers_changed','detail_grade_rows')):
            page=TrackingPage(3)
            with patch.object(StudentBrowser,'prepare',side_effect=ScanError('scan_prepare',reason)),self.assertRaises(DetailError) as caught:
                apply_site_grade(page,{'search_grade':GRADE},page.account,threading.Event())
            self.assertEqual(caught.exception.code,event)
        page=TrackingPage(3);cancel=threading.Event();cancel.set()
        with self.assertRaises(DetailError) as caught:apply_site_grade(page,{'search_grade':GRADE},page.account,cancel)
        self.assertEqual(caught.exception.code,'detail_account');self.assertEqual(page.actions,[])


if __name__=='__main__':unittest.main()
