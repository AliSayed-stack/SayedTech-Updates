import unittest
try:
    from PySide6.QtWidgets import QApplication,QPushButton,QStyle
    from PySide6.QtCore import Qt,QPoint
    from PySide6.QtTest import QTest
    from detailed_dialog import DetailedImportDialog
    QT=True
except ImportError:
    QT=False


class Signal:
    def __init__(self):self.slots=[]
    def connect(self,slot):self.slots.append(slot)
    def disconnect(self,slot):self.slots.remove(slot)
    def emit(self,*args):
        for slot in list(self.slots):slot(*args)


class Controller:
    def __init__(self):
        self.student_result=Signal();self.detail_diagnostic=Signal();self.event=Signal();self.requests=[];self.scope_requests=[];self.ack_scope=True
    def fill_details(self,*args):
        if args[1]=='scope_grade':
            self.scope_requests.append(args)
            if self.ack_scope:self.student_result.emit(args[2],'detail_grade_ready','')
        else:self.requests.append(args)
        return True


@unittest.skipUnless(QT,'Qt is not installed in this Python environment')
class BatchDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])

    def setUp(self):
        self.controller=Controller()
        rows=[{'excel_row':i,'values':{'field-firstName':'اسم اختبار','field-middleName':'أب اختبار','field-lastName':'شهرة اختبار'},
               'address':{},'phone':'03123456','manual':{'الهواتف / رقم الهاتف':'03123456'}} for i in (2,8)]
        self.dialog=DetailedImportDialog(rows,self.controller,None)

    def tearDown(self):
        self.dialog.scope_request=None;self.dialog.single_pending=None;self.dialog.batch.disconnect();self.dialog.reject();self.dialog.deleteLater();self.qt.processEvents()

    def test_grade_change_applies_site_filter_before_any_student_request(self):
        self.controller.ack_scope=False
        for row in self.dialog.rows:row['values']['field-enrollment-promoted-class']='الثاني أساسي'
        self.dialog.grade_combo.addItem('الثاني أساسي','الثاني أساسي')
        self.dialog.grade_combo.setCurrentIndex(1)
        row,mode,request=self.controller.scope_requests[-1]
        self.assertEqual((row,mode),({'search_grade':'الثاني أساسي'},'scope_grade'))
        self.assertEqual(self.controller.requests,[]);self.assertFalse(self.dialog.import_button.isEnabled())
        self.dialog.start_batch(False);self.dialog.start_selected('manual_save:الهواتف')
        self.assertEqual(self.controller.requests,[])
        self.controller.student_result.emit('stale','detail_grade_ready','')
        self.assertIsNotNone(self.dialog.scope_request)
        self.controller.student_result.emit(request,'detail_grade_ready','')
        self.assertIsNone(self.dialog.scope_request);self.assertTrue(self.dialog.import_button.isEnabled())
        self.assertIn('تم تحديد الثاني أساسي',self.dialog.status.text())
        self.dialog.import_button.click()
        self.assertEqual(self.controller.requests[-1][0]['search_grade'],'الثاني أساسي')

    def test_birth_mismatch_shows_excel_and_site_dates_for_current_request_only(self):
        self.dialog.import_button.click();request=self.controller.requests[-1][2]
        detail={'expected_birth':'2015-02-03','observed_birth':'2015-03-02'}
        self.controller.detail_diagnostic.emit('stale',detail)
        self.assertEqual(self.dialog.birth_diagnostics,{})
        self.controller.detail_diagnostic.emit(request,detail)
        self.controller.student_result.emit(request,'detail_birth_mismatch','')
        self.assertIn('تاريخ Excel: 02/03/2015',self.dialog.status.text())
        self.assertIn('تاريخ الموقع: 03/02/2015',self.dialog.status.text())
        self.assertEqual(self.dialog.birth_diagnostics,{})
        self.assertEqual(len(self.controller.requests),1);self.assertFalse(self.dialog.batch.active)

    def test_grade_failure_and_session_loss_release_pending_without_starting_import(self):
        self.controller.ack_scope=False
        self.dialog.grade_combo.addItem('الثاني أساسي','الثاني أساسي')
        self.dialog.grade_combo.setCurrentIndex(1)
        request=self.controller.scope_requests[-1][2]
        self.controller.student_result.emit(request,'detail_grade_options','')
        self.assertIsNone(self.dialog.scope_request);self.assertIn('الصف المطلوب',self.dialog.status.text())
        self.assertEqual(self.controller.requests,[])
        self.dialog.grade_combo.setCurrentIndex(0)
        self.assertIsNone(self.controller.scope_requests[-1][0]['search_grade'])
        self.controller.event.emit('browser_closed')
        self.assertIsNone(self.dialog.scope_request);self.assertFalse(self.dialog.import_button.isEnabled())

    def result(self,event):
        request=self.controller.requests[-1][2]
        self.controller.student_result.emit(request,event,'');self.qt.processEvents()

    def test_batch_actions_coexist_with_section_save_and_process_all_rows(self):
        titles=[button.text() for button in self.dialog.findChildren(QPushButton)]
        self.assertNotIn('تعبئة القسم المحدد فقط',titles)
        self.assertIn('تعبئة وحفظ القسم المحدد',titles)
        self.assertIn('إرسال الطالب المحدد للمراجعة',titles)
        self.assertEqual(self.dialog.manual_sections.itemText(0),'عناوين السكن')
        self.dialog.import_button.click()
        self.assertEqual(self.controller.requests[0][1],'details_import')
        self.assertEqual(self.controller.requests[0][0]['excel_row'],2)
        self.assertFalse(self.dialog.import_review_button.isEnabled())
        self.result('detail_import_saved')
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],8)
        self.result('detail_import_saved')
        self.assertTrue(self.dialog.import_review_button.isEnabled())
        self.assertIn('2/2',self.dialog.status.text())

    def test_selected_section_saves_only_selected_row_and_excludes_batch_during_request(self):
        self.dialog.table.setCurrentCell(1,0)
        self.dialog.manual_sections.setCurrentIndex(1)
        self.dialog.manual_save_button.click()
        row,mode,request=self.controller.requests[0]
        self.assertEqual(row['excel_row'],8)
        self.assertEqual(mode,'manual_save:الهواتف')
        self.assertFalse(self.dialog.import_button.isEnabled())
        self.dialog.start_batch(True)
        self.assertEqual(len(self.controller.requests),1)
        self.result('detail_saved')
        self.assertEqual(len(self.controller.requests),1)
        self.assertIsNone(self.dialog.single_pending)
        self.assertTrue(self.dialog.import_button.isEnabled())
        self.assertEqual(self.dialog.batch.completed['details_import'],set())
        self.assertIn('حُفظ القسم',self.dialog.status.text())
        self.dialog.manual_sections.setCurrentIndex(self.dialog.manual_sections.count()-1)
        self.assertFalse(self.dialog.manual_save_button.isEnabled())

    def test_separate_review_button_targets_only_selected_student(self):
        self.dialog.table.setCurrentCell(1,0);self.dialog.review_button.click()
        row,mode,request=self.controller.requests[0]
        self.assertEqual(row['excel_row'],8);self.assertEqual(mode,'review_send')
        self.result('detail_review_sent')
        self.assertEqual(len(self.controller.requests),1)
        self.assertEqual(self.dialog.batch.completed['details_import_review'],set())

    def test_grade_limits_preview_batch_and_single_requests_without_losing_other_rows(self):
        from detail_scope import grade_choices
        grades=['الأول أساسي','الثالث ثانوي']
        for row,grade in zip(self.dialog.rows,grades):row['values']['field-enrollment-promoted-class']=grade
        for grade in grade_choices(self.dialog.rows):self.dialog.grade_combo.addItem(grade,grade)
        self.dialog.grade_combo.setCurrentIndex(2)
        self.assertTrue(self.dialog.table.isRowHidden(0))
        self.assertFalse(self.dialog.table.isRowHidden(1))
        self.dialog.manual_save_button.click()
        self.assertEqual(self.controller.requests[-1][0]['search_grade'],grades[1])
        self.assertFalse(self.dialog.grade_combo.isEnabled())
        self.result('detail_saved')
        self.dialog.import_button.click()
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],8)
        self.assertEqual(self.controller.requests[-1][0]['search_grade'],grades[1])
        self.result('detail_import_saved')
        self.assertIn('1/1',self.dialog.status.text())
        count=len(self.controller.requests)
        self.dialog.grade_combo.setCurrentIndex(1);self.dialog.import_review_button.click()
        self.assertEqual(len(self.controller.requests),count+1)
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],2)
        self.assertEqual(self.controller.requests[-1][0]['search_grade'],grades[0])
        self.assertNotIn('search_grade',self.dialog.rows[0])

    def test_review_choice_and_stop_after_current_pupil(self):
        self.dialog.import_review_button.click()
        self.assertEqual(self.controller.requests[0][1],'details_import_review')
        self.dialog.stop_button.click();self.result('detail_import_review_sent')
        self.assertEqual(len(self.controller.requests),1)
        self.assertFalse(self.dialog.batch.active)
        self.dialog.import_review_button.click()
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],8)

    def test_failure_does_not_start_next_and_session_loss_ignores_queued_advance(self):
        self.dialog.import_button.click();self.result('detail_save_unknown')
        self.assertEqual(len(self.controller.requests),1)
        self.assertTrue(self.dialog.import_button.isEnabled())
        self.dialog.import_button.click()
        request=self.controller.requests[-1][2]
        self.controller.student_result.emit(request,'detail_import_saved','')
        self.controller.event.emit('disconnected')
        self.qt.processEvents()
        self.assertEqual(len(self.controller.requests),2)
        self.assertIn('انتهت جلسة',self.dialog.status.text())

    def test_unchecked_pupil_is_never_dispatched_by_either_batch_action(self):
        for review,event in ((False,'detail_import_saved'),(True,'detail_import_review_sent')):
            with self.subTest(review=review):
                self.dialog.table.item(0,self.dialog.select_column).setCheckState(Qt.Unchecked)
                self.dialog.start_batch(review)
                row,mode,_=self.controller.requests[-1]
                self.assertEqual(row['excel_row'],8)
                self.assertEqual(mode,'details_import_review' if review else 'details_import')
                count=len(self.controller.requests);self.result(event)
                self.assertEqual(len(self.controller.requests),count)
                self.assertIn('1/1',self.dialog.status.text())
                self.assertNotIn(0,self.dialog.batch.completed[mode])

    def test_no_checked_pupils_blocks_batch_and_unchecked_current_pupil_blocks_single_actions(self):
        for i in range(len(self.dialog.rows)):
            self.dialog.table.item(i,self.dialog.select_column).setCheckState(Qt.Unchecked)
        self.dialog.import_button.click();self.dialog.import_review_button.click()
        self.assertEqual(self.controller.requests,[])
        self.dialog.manual_save_button.click();self.dialog.review_button.click()
        self.assertEqual(self.controller.requests,[])
        self.dialog.table.item(0,self.dialog.select_column).setCheckState(Qt.Checked)
        self.dialog.manual_save_button.click()
        self.assertEqual(self.controller.requests[0][0]['excel_row'],2)

    def test_checkboxes_keep_state_across_grades_and_checked_hidden_rows_do_not_run(self):
        grades=['الأول أساسي','الثالث ثانوي']
        for row,grade in zip(self.dialog.rows,grades):row['values']['field-enrollment-promoted-class']=grade
        for grade in grades:self.dialog.grade_combo.addItem(grade,grade)
        self.dialog.table.item(1,self.dialog.select_column).setCheckState(Qt.Unchecked)
        self.dialog.grade_combo.setCurrentIndex(2);self.dialog.import_button.click()
        self.assertEqual(self.controller.requests,[])
        self.dialog.grade_combo.setCurrentIndex(1);self.dialog.import_button.click()
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],2)
        self.result('detail_import_saved')
        self.dialog.grade_combo.setCurrentIndex(2)
        self.assertEqual(self.dialog.table.item(1,self.dialog.select_column).checkState(),Qt.Unchecked)

    def test_checkbox_can_be_toggled_with_mouse_and_keyboard_without_editing_data(self):
        self.dialog.show();self.qt.processEvents()
        table=self.dialog.table;item=table.item(0,self.dialog.select_column)
        rect=table.visualItemRect(item)
        QTest.mouseClick(table.viewport(),Qt.LeftButton,Qt.NoModifier,QPoint(rect.right()-10,rect.center().y()))
        self.assertEqual(item.checkState(),Qt.Unchecked)
        table.setCurrentCell(0,self.dialog.select_column)
        QTest.keyClick(table,Qt.Key_Space)
        self.assertEqual(item.checkState(),Qt.Checked)
        self.assertEqual(self.dialog.rows[0]['excel_row'],2)
        self.assertNotIn('checked',self.dialog.rows[0])

    def test_rtl_starts_with_checkbox_on_right_and_aligns_table_and_combo_text(self):
        self.dialog.show();self.qt.processEvents()
        table=self.dialog.table;header=table.horizontalHeader()
        self.assertEqual(self.dialog.layoutDirection(),Qt.RightToLeft)
        self.assertEqual(table.layoutDirection(),Qt.RightToLeft)
        self.assertEqual(header.visualIndex(self.dialog.select_column),0)
        self.assertGreater(header.sectionViewportPosition(0),header.sectionViewportPosition(1))
        self.assertEqual(table.horizontalScrollBar().value(),table.horizontalScrollBar().minimum())
        for combo in (self.dialog.grade_combo,self.dialog.manual_sections):
            self.assertEqual(combo.layoutDirection(),Qt.RightToLeft)
            self.assertEqual(combo.view().layoutDirection(),Qt.RightToLeft)
            self.assertTrue(combo.itemData(0,Qt.TextAlignmentRole)&Qt.AlignRight)
            self.assertTrue(QStyle.visualAlignment(Qt.RightToLeft,combo.itemData(0,Qt.TextAlignmentRole))&Qt.AlignRight)
        for column in range(1,table.columnCount()):
            self.assertTrue(table.item(0,column).textAlignment()&Qt.AlignRight)
            self.assertTrue(QStyle.visualAlignment(Qt.RightToLeft,Qt.AlignmentFlag(table.item(0,column).textAlignment()))&Qt.AlignRight)


if __name__=='__main__':unittest.main()
