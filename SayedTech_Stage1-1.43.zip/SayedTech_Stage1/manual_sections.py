"""Fixed Excel columns and explicit per-section draft entry for existing pupils."""
import re
import time
from pathlib import Path
from student_excel import FIELDS, ADDRESS_HEADERS, ExcelInputError, normalize_date
from student_workflow import workbook_rows, selection_value

MAP_SHEET='ربط الأعمدة اليدوية'
SELECT='اختيار للاسترداد اليدوي'
SECTIONS=('الهواتف','البريد الإلكتروني','الأقارب','بطاقات التعريف','المستندات','حالة التسجيل')
IMPORT_SECTIONS=('عناوين السكن',)+SECTIONS


def section_summary(record,title):
    if title=='المستندات' and 'documents' in record:
        return '؛ '.join(str(i)+': '+str(d.get('المستندات / نوع المستند',''))+
                        (' / '+str(d['المستندات / رقم الوثيقة']) if d.get('المستندات / رقم الوثيقة') else '')
                        for i,d in enumerate(record['documents'],1))
    if title=='عناوين السكن':
        return '؛ '.join(label+': '+str(record.get('address',{}).get(label,''))
                         for label in ADDRESS_HEADERS if record.get('address',{}).get(label) not in ('',None))
    manual=record.get('manual',{})
    return '؛ '.join((s['group']+' / ' if s['group'] else '')+s['label']+': '+str(manual[s['header']])
                     for s in SPECS if s['section']==title and manual.get(s['header']) not in ('',None))


def spec(section,label,kind='text',group=''):
    return {'section':section,'label':label,'kind':kind,'group':group,
            'header':' / '.join(x for x in (section,group,label) if x)}


MOTHER_SURNAME='شهرة الأم'
SPECS=[spec('الهواتف','النوع','select'),spec('الهواتف','رمز الدولة','select'),
       spec('الهواتف','رقم الهاتف'),spec('الهواتف','الأساسية','checkbox'),
       spec('البريد الإلكتروني','البريد الإلكتروني','email'),spec('البريد الإلكتروني','النوع','select'),
       spec('البريد الإلكتروني','الأساسية','checkbox')]
mother=spec('الأقارب','الشهرة (بالعربية)','text','الأقارب #2');mother['header']=MOTHER_SURNAME
SPECS.append(mother)
for title in ('بطاقات التعريف','المستندات'):
    SPECS.extend([spec(title,'نوع المستند','select'),spec(title,'رقم الوثيقة'),spec(title,'تاريخ الإصدار','date')])
    if title=='بطاقات التعريف':SPECS.append(spec(title,'تاريخ الإنتهاء','date'))
    else:SPECS.extend([spec(title,'ملاحظة'),spec(title,'جرى التسليم','checkbox'),spec(title,'طباعة على اللائحة','checkbox')])
SPECS.extend([spec('حالة التسجيل','الحالة الحالية','display'),spec('حالة التسجيل','ملاحظة (اختياري)')])
TAIL_HEADERS=[SELECT]+[s['header'] for s in SPECS if s['header']!=MOTHER_SURNAME]
HEADERS=[SELECT]+[s['header'] for s in SPECS]
DOCUMENT_OPTIONS={
    'بطاقة هوية':'id_card','إخراج قيد فردي':'individual_civil_extract','طلب استرحام وغيره':'mercy_request',
    'إفادة سكن':'residence_certificate','شهادة صحية':'medical_certificate',
    'إفادة مدرسية مصدقة ومبرزة':'certified_school_certificate','تعميم رقم 8/2001':'circular_8_2001',
    'معادلة':'equivalence','نسخة مصدقة عن الهوية':'certified_id_copy','إفادة (شهادة رسمية)':'official_certificate',
    'مجلس تحكيمي':'arbitration_council','بيان قيد عائلي':'family_civil_record','إعفاء':'exemption',
    'بطاقة تلقيح':'vaccination_card','بطاقة علامات':'marks_card'}


def norm(value):
    value=re.sub('[\u064b-\u065f\u0670\u0640\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',str(value))
    return ' '.join(re.sub(r'\s*\*\s*$','',value).translate(str.maketrans('أإآى٠١٢٣٤٥٦٧٨٩','اااي0123456789')).split())


def manual_date(value):
    """Shared month-first/year-first input; retain explicit legacy DD-MM-YYYY."""
    try:return normalize_date(value,allow_future=True)
    except (ValueError,TypeError,OverflowError):
        from datetime import datetime
        if isinstance(value,str):
            text=value.strip().translate(str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789'))
            if re.fullmatch(r'[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}',text):
                return datetime.strptime(text,'%d-%m-%Y').date().isoformat()
        raise ValueError('date') from None


def phone_country_parts(value):
    text=norm(value).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹','0123456789'))
    code=re.search(r'(?<![\d])\+?([0-9]{1,4})(?![\d])',text)
    country=re.search(r'[\(\[]\s*([A-Za-z]{2})\s*[\)\]]',text)
    return (code[1] if code else '',country[1].upper() if country else '')


def phone_country_matches(options,wanted):
    """Match dialing codes despite plus signs, spacing and country captions."""
    direct=[o for o in options if norm(o['label'])==norm(wanted)]
    if direct:return direct
    code,country=phone_country_parts(wanted)
    if not code:return []
    candidates=[];same_country=[]
    for option in options:
        value_code,value_country=phone_country_parts(option['value'])
        label_code,label_country=phone_country_parts(option['label'])
        option_code=value_code or label_code
        option_country=label_country or value_country
        if not option_country and re.fullmatch('[A-Za-z]{2}',option['value']):option_country=option['value'].upper()
        if option_code!=code or (country and option_country and country!=option_country):continue
        candidates.append(option)
        if country and option_country==country:same_country.append(option)
    return same_country or candidates


def label_matches(label,s):
    names={norm(s['label'])}
    if s['header']==MOTHER_SURNAME:names.update(map(norm,('الشهرة','شهرة الأم','الشهرة / اسم العائلة')))
    return norm(label) in names


def observed_values(record):
    """Only uniquely labelled values from a single explicit record are projected."""
    out={}
    for s in SPECS:
        if s['kind']=='file':continue
        matches=[f for f in record.get('fields',[]) if f['section']==s['section'] and
                 norm(f.get('group',''))==norm(s['group']) and label_matches(f['label'],s)]
        # Duplicate observations are harmless only if they have the same value.
        vals={str(f['value']):f['value'] for f in matches}
        if len(vals)==1:out[s['header']]=next(iter(vals.values()))
    return out


def read_manual_rows(z):
    rows=workbook_rows(z,'الطلاب')
    if not rows or rows[0][2]:raise ExcelInputError('عناوين ملف السحب غير صالحة.')
    headers=rows[0][1]
    required={f['label'] for f in FIELDS}|set(HEADERS)|set(ADDRESS_HEADERS)
    if len(set(headers.values()))!=len(headers) or not required.issubset(headers.values()):
        raise ExcelInputError('اختر ملف السحب الجديد الذي يحتوي الأعمدة اليدوية.')
    by_name={v:k for k,v in headers.items()}
    result=[]
    for number,values,formulas in rows[1:]:
        try:selected=selection_value(values.get(by_name[SELECT],''))
        except ValueError:raise ExcelInputError(f'الصف {number}: ضع 1 أو نعم في اختيار الاسترداد اليدوي.') from None
        if not selected:continue
        used={by_name[f['label']] for f in FIELDS}|{by_name[SELECT]}|{by_name[s['header']] for s in SPECS if s['kind']!='display'}|{by_name[h] for h in ADDRESS_HEADERS}
        if used & formulas:raise ExcelInputError(f'الصف {number}: استخدم قيماً ثابتة في الخانات اليدوية وبيانات الهوية.')
        identity={f['id']:values.get(by_name[f['label']],'') for f in FIELDS}
        for k in ('field-firstName','field-middleName','field-lastName'):
            if not isinstance(identity[k],str) or not identity[k].strip():
                raise ExcelInputError(f'الصف {number}: أكمل اسم الطالب والأب والشهرة.')
        try:identity['field-birthDate']=normalize_date(identity['field-birthDate'])
        except (ValueError,TypeError,OverflowError):raise ExcelInputError(f'الصف {number}: راجع تاريخ ولادة الطالب.') from None
        uid=identity.get('field-existingUniqueId','')
        if uid and not isinstance(uid,str):raise ExcelInputError(f'الصف {number}: احفظ الرقم الموحد كنص.')
        manual={s['header']:values.get(by_name[s['header']],'') for s in SPECS}
        address={label:('' if values.get(by_name[label]) is None else values.get(by_name[label],'')) for label in ADDRESS_HEADERS}
        if any(not isinstance(value,str) or len(value)>1000 for value in address.values()):
            raise ExcelInputError(f'الصف {number}: أدخل بيانات عنوان السكن كنص، بحد أقصى 1000 حرف للخانة.')
        for s in SPECS:
            value=manual[s['header']]
            if s['kind']=='display':continue
            if value in ('',None):continue
            if s['kind']=='checkbox':
                try:manual[s['header']]=value if isinstance(value,bool) else selection_value(value)
                except ValueError:raise ExcelInputError(f'الصف {number}: خانة الاختيار تقبل نعم أو لا.') from None
            elif s['kind']=='date':
                try:manual[s['header']]=manual_date(value)
                except (ValueError,TypeError,OverflowError):
                    raise ExcelInputError(f"الصف {number}: راجع «{s['header']}»؛ استخدم YYYY/MM/DD أو YYYY-MM-DD أو MM/DD/YYYY (شهر/يوم/سنة).") from None
            elif not isinstance(value,str) or len(value)>1000:
                raise ExcelInputError(f"الصف {number}: أدخل «{s['header']}» كنص لحفظ الأصفار الأولى.")
        result.append({'excel_row':number,'values':identity,'manual':manual,
                       'address':address,'phone':manual.get('الهواتف / رقم الهاتف',''),'mother_surname':manual.get(MOTHER_SURNAME,''),'identity_card':{}})
    if not result:raise ExcelInputError('ضع 1 في «اختيار للاسترداد اليدوي» للطلاب المطلوبين، واحفظ Excel.')
    return merge_document_rows(result)


def merge_document_rows(rows):
    """One pupil request, many document rows; identity and other data must agree."""
    import copy
    import json
    from detail_scope import row_grade
    doc_headers={s['header'] for s in SPECS if s['section']=='المستندات'}
    def payload(row):return {k:v for k,v in row.get('manual',{}).items() if k in doc_headers and v not in ('',None)}
    def identity(row):
        return tuple(norm(row['values'].get(k,'')) for k in ('field-firstName','field-middleName','field-lastName','field-birthDate'))
    known={};names={}
    for row in rows:
        name=identity(row);key=name+(norm(row_grade(row)),)
        names[name]=names.get(name,0)+1
        uid=norm(row['values'].get('field-existingUniqueId',''))
        if uid:known.setdefault(key,set()).add(uid)
    result=[];seen={};unidentified=set()
    for original in rows:
        row=copy.deepcopy(original);values=row['values']
        uid=norm(values.get('field-existingUniqueId',''))
        name=identity(row);grade=row_grade(row);fallback=name+(norm(grade),)
        linked=uid
        if not uid:
            candidates=known.get(fallback,set())
            if len(candidates)>1:raise ExcelInputError(f"الصف {row['excel_row']}: يوجد أكثر من رقم موحد لنفس الاسم والولادة والصف؛ راجع هوية الطالب.")
            if not grade and names[name]>1:raise ExcelInputError(f"الصف {row['excel_row']}: أكمل صف الطالب لتجميع مستنداته دون رقم موحد.")
            if candidates:linked=next(iter(candidates))
        key=('uid',linked) if linked else ('identity',fallback)
        if not uid:unidentified.add(key)
        if key not in seen:
            seen[key]=row;result.append(row);continue
        first=seen[key]
        if identity(first)!=name:raise ExcelInputError(f"الصف {row['excel_row']}: الرقم الموحد مكرر ببيانات هوية مختلفة.")
        if key in unidentified:
            if not row_grade(first) or not grade:raise ExcelInputError(f"الصف {row['excel_row']}: أكمل صف الطالب لتجميع مستنداته دون رقم موحد.")
            first['search_grade']=row_grade(first)
        documents=first.setdefault('documents',[payload(first)] if payload(first) else [])
        for area in ('values','address','manual'):
            target=first.setdefault(area,{})
            for k,v in row.get(area,{}).items():
                if area=='manual' and k in doc_headers:continue
                if v in ('',None):continue
                if target.get(k) not in ('',None) and norm(target[k])!=norm(v):
                    raise ExcelInputError(f"الصف {row['excel_row']}: بيانات الطالب المكرر متعارضة في «{k}». غيّر خانات المستند فقط.")
                target[k]=v
        doc=payload(row)
        if doc and doc not in documents:documents.append(doc)
        first.setdefault('excel_rows',[first['excel_row']]).append(row['excel_row'])
        first['phone']=first['manual'].get('الهواتف / رقم الهاتف','')
        first['mother_surname']=first['manual'].get(MOTHER_SURNAME,'')
        if len(documents)>50 or len(json.dumps(first,ensure_ascii=False).encode('utf-8'))>30000:
            raise ExcelInputError(f"الصف {row['excel_row']}: مستندات الطالب كبيرة جداً؛ خفّف عددها أو طول الملاحظات.")
    for row in result:
        if 'documents' in row and not row['documents']:row.pop('documents')
        if 'search_grade' in row:row['search_grade']=row_grade(row)
    return result


AUTO_SAVE_SECTIONS=('بطاقات التعريف','المستندات')


def has_section_data(record,title):
    if title=='المستندات' and record.get('documents'):return True
    payload=record.get('manual',{})
    return any(s['section']==title and s['kind'] not in ('display','file') and
               payload.get(s['header']) not in ('',None) for s in SPECS)


def fill_manual_section(page,record,title,guard,*,document_block=None):
    """Fill only the selected section's explicit labels; leave saving to the user."""
    from detailed_import import DetailError
    if title not in SECTIONS:raise DetailError('detail_input')
    payload=record.get('manual',{})
    chosen=[(s,payload.get(s['header'])) for s in SPECS if s['section']==title and payload.get(s['header']) not in ('',None) and s['kind']!='display']
    if not chosen:raise DetailError('detail_input')
    # Reject malformed document dates before Add can leave an empty draft.
    normalized=[]
    for s,value in chosen:
        if s['kind']=='date':
            try:value=manual_date(value)
            except (ValueError,TypeError,OverflowError):raise DetailError('detail_input',s['header']) from None
        normalized.append((s,value))
    chosen=normalized
    guard()
    mode=page.get_by_role('radio',name='مفصّل',exact=True)
    if mode.count()!=1 or not mode.is_enabled():raise DetailError('detail_options')
    mode.click(timeout=5000);guard()
    from detail_dom import tab_locator
    tab=tab_locator(page,title)
    if tab.count()!=1 or not tab.is_enabled():raise DetailError('detail_options')
    tab.click(timeout=5000);guard()
    scope=page.locator('section').filter(has=page.get_by_role('heading',name=title,exact=True))
    scope.wait_for(state='visible',timeout=5000)
    if scope.count()!=1:raise DetailError('detail_options')
    if document_block is not None:
        if title!='المستندات' or document_block.count()!=1 or not document_block.is_visible():raise DetailError('detail_options')
        scope=document_block
    empty=scope.get_by_text('لم يُعثر على أية سجلات',exact=True)
    added=False
    if title!='الأقارب' and empty.count()==1 and empty.is_visible():
        add=scope.get_by_role('button',name='إضافة',exact=True)
        if add.count()!=1 or not add.is_enabled():raise DetailError('detail_options')
        guard();add.click(timeout=3000);guard();added=True
    plans=[]
    for s,value in chosen:
        block=scope
        if s['group']:
            number=s['group'][-1]
            heading=scope.get_by_text(re.compile(r'^\s*الأقارب\s*#?\s*['+number+('١' if number=='1' else '٢')+r']\s*$'))
            if heading.count()!=1:raise DetailError('detail_options')
            block=heading.locator('xpath=ancestor::*[.//input[@maxlength="256"][@required]][1]')
            if block.count()!=1:raise DetailError('detail_options')
            other='2' if number=='1' else '1'
            if block.get_by_text(re.compile(r'^\s*الأقارب\s*#?\s*['+other+('٢' if other=='2' else '١')+r']\s*$')).count():
                raise DetailError('detail_options')
        names=[s['label']]
        if s['header']==MOTHER_SURNAME:names.extend(['الشهرة','شهرة الأم','الشهرة / اسم العائلة'])
        pattern=re.compile(r'^\s*(?:'+'|'.join(re.escape(n) for n in names)+r')\s*\*?\s*$')
        deadline=time.monotonic()+8
        country_absent_since=None;skip_missing_country=False
        while True:
            guard()
            if s['header']==MOTHER_SURNAME:
                from detailed_import import mother_surname_field
                field=mother_surname_field(scope)
            else:field=block.locator('input[type="file"]') if s['kind']=='file' else block.get_by_label(pattern)
            if field.count()!=1 and s['kind']!='file':
                caption=block.get_by_text(pattern)
                if caption.count()==1:
                    field=caption.locator('xpath=ancestor::*[.//input or .//select or .//textarea][1]').locator('input,select,textarea')
            if field.count()!=1 and s['header']=='الهواتف / رمز الدولة':
                # Recognize the country-code select independently of React ids
                # or labels, while still requiring exactly one control.
                field=block.locator('xpath=.//select[option[@value="961" or @value="+961"]]')
            if field.count()==0 and s['header']=='الهواتف / رمز الدولة' and phone_country_parts(value)[0]=='961':
                # The current local-phone form has only a type select and an
                # eight-digit number. Older Excel files retain the country code.
                # Wait for a stable, fully rendered local layout before skipping.
                number=block.locator('xpath=.//input[@maxlength="8" and @inputmode="numeric"]')
                phone_type=block.locator('xpath=.//select[option[@value="mobile"] and option[@value="landline"]]')
                local_only=(block.get_by_text(pattern).count()==0 and block.locator('xpath=.//select').count()==1
                            and number.count()==1 and number.is_visible() and number.is_enabled()
                            and phone_type.count()==1 and phone_type.is_visible() and phone_type.is_enabled())
                now=time.monotonic()
                if local_only:
                    if country_absent_since is None:country_absent_since=now
                    elif now-country_absent_since>=.35:skip_missing_country=True;break
                else:country_absent_since=None
            else:country_absent_since=None
            ready=field.count()==1 and field.is_visible() and field.is_enabled()
            if ready:
                meta=field.evaluate('(e)=>({tag:e.tagName,type:e.type,readonly:e.readOnly,value:e.value,checked:e.checked,options:Array.from(e.options||[],o=>({value:o.value,label:o.textContent.trim(),disabled:o.disabled}))})')
                if meta.get('readonly'):raise DetailError('detail_options',s['header'])
                if meta.get('tag')=='SELECT':
                    available=[o for o in meta['options'] if not o['disabled'] and o['value']]
                    if s['header']=='الهواتف / رمز الدولة':matches=phone_country_matches(available,value)
                    else:
                        matches=[o for o in available if norm(o['label'])==norm(value)]
                        if not matches:matches=[o for o in available if norm(o['value'])==norm(value)]
                    values={o['value'] for o in matches}
                    ready=len(values)==1
                    if ready:selected_value=next(iter(values))
                if ready:break
            if time.monotonic()>=deadline:raise DetailError('detail_options',s['header'])
            page.wait_for_timeout(100)
        if skip_missing_country:continue
        if s['kind']=='file':
            path=Path(str(value)).expanduser()
            if not path.is_absolute() or not path.is_file():raise DetailError('detail_input')
            if meta.get('value'):raise DetailError('detail_existing')
            plans.append((field,'file',str(path)));continue
        if meta.get('type')=='checkbox':
            if not isinstance(value,bool):
                try:value=selection_value(value)
                except ValueError:raise DetailError('detail_input') from None
            plans.append((field,'checkbox',value));continue
        if meta.get('tag')=='SELECT':
            if not added and meta.get('value') and meta['value']!=selected_value:raise DetailError('detail_existing',s['header'])
            plans.append((field,'select',selected_value));continue
        if meta.get('tag') not in ('INPUT','TEXTAREA') or meta.get('type') in ('file','password','hidden'):
            raise DetailError('detail_options')
        if not isinstance(value,str):raise DetailError('detail_input')
        if s['kind']=='date':
            if meta.get('value'):
                try:same_date=manual_date(meta['value'])==value
                except (ValueError,TypeError,OverflowError):same_date=False
                if not same_date:raise DetailError('detail_existing',s['header'])
            plans.append((field,'date',value));continue
        if meta.get('value') and norm(meta['value'])!=norm(value):raise DetailError('detail_existing',s['header'])
        plans.append((field,'text',value))
    # Validate all bindings before writing any field in this section.
    if not plans:raise DetailError('detail_input','الهواتف / رقم الهاتف' if title=='الهواتف' else '')
    for field,kind,value in plans:
        guard()
        if kind=='file':field.set_input_files(value,timeout=3000)
        elif kind=='checkbox':field.set_checked(value,timeout=3000)
        elif kind=='select':field.select_option(value=value,timeout=3000)
        else:field.fill(value,timeout=3000)
        guard()
        if kind=='checkbox':valid=field.is_checked()==value
        elif kind=='file':valid=field.evaluate('(e)=>e.files.length')==1
        elif kind=='date':
            try:valid=manual_date(field.input_value())==value
            except (ValueError,TypeError,OverflowError):valid=False
        else:valid=field.input_value()==value
        if not valid:raise DetailError('detail_options')
    return 'detail_filled'
