"""Excel-native dropdowns for extracted records; repair without rescanning."""
import io
import json
import os
import re
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath
import core
from identity_card import DOCUMENT_TYPES
from identity_workbook import Q, RELNS, OFFREL, CT, serialize
from manual_sections import SELECT, SPECS, DOCUMENT_OPTIONS
from student_excel import ExcelInputError
from student_workflow import workbook_rows, column

OPTIONS_SHEET='خيارات الأقسام اليدوية'
OPTIONS_PART='xl/worksheets/sayed_detail_options.xml'
PREFIX='SayedDetail_'


def dropdown_options():
    countries=json.loads((core.ASSET_BASE/'assets/phone_country_options.json').read_text(encoding='utf-8'))
    result={SELECT:['0','1'], 'الهواتف / النوع':['خلوي','أرضي','عمل','طوارئ'],
            'الهواتف / رمز الدولة':countries, 'البريد الإلكتروني / النوع':['شخصي','مدرسي'],
            'بطاقات التعريف / نوع المستند':list(DOCUMENT_TYPES),
            'المستندات / نوع المستند':list(DOCUMENT_OPTIONS)}
    result.update({s['header']:['نعم','لا'] for s in SPECS if s['kind']=='checkbox'})
    return result


def attach_scan_dropdowns(parts):
    """Place selection first and enable lists, retaining values and their headers."""
    from scan_workbook_layout import selection_first
    selection_first(parts)
    book=ET.fromstring(parts['xl/workbook.xml'])
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    sheets=book.find(Q('sheets'))
    student=next((s for s in sheets if s.get('name')=='الطلاب'),None)
    if student is None:raise ExcelInputError('اختر ملف سحب الطلاب.')
    target=next(r.get('Target') for r in rels if r.get('Id')==student.get('{'+OFFREL+'}id'))
    part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if '..' in PurePosixPath(part).parts or part not in parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    with io.BytesIO() as stream:
        with zipfile.ZipFile(stream,'w') as z:
            for key in ('xl/workbook.xml','xl/_rels/workbook.xml.rels',part):z.writestr(key,parts[key])
            if 'xl/sharedStrings.xml' in parts:z.writestr('xl/sharedStrings.xml',parts['xl/sharedStrings.xml'])
        stream.seek(0)
        with zipfile.ZipFile(stream) as z:headers=workbook_rows(z,'الطلاب')[0][1]
    if SELECT not in headers.values():raise ExcelInputError('اختر ملف السحب الذي يحتوي أعمدة الأقسام اليدوية.')
    root=ET.fromstring(parts[part])
    last=max(501,max(int(r.get('r')) for r in root.find(Q('sheetData'))))
    names=book.find(Q('definedNames'))
    if names is None:
        names=ET.Element(Q('definedNames'))
        preceding=book.find(Q('externalReferences'))
        book.insert(list(book).index(preceding if preceding is not None else sheets)+1,names)
    def define(name,formula):
        found=next((n for n in names if n.get('name')==name and n.get('localSheetId') is None),None)
        if found is None:found=ET.SubElement(names,Q('definedName'),name=name)
        found.text=formula
    existing=next((s for s in sheets if s.get('name')==OPTIONS_SHEET),None)
    options_part=OPTIONS_PART
    if existing is not None:
        relation=next((r for r in rels if r.get('Id')==existing.get('{'+OFFREL+'}id')),None)
        # Excel may rename worksheet parts when a user saves their edits.
        target=relation.get('Target','') if relation is not None else ''
        options_part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        managed=any(n.get('name')==PREFIX+'1' and (n.text or '').startswith("'"+OPTIONS_SHEET+"'!") for n in names)
        if relation is None or relation.get('TargetMode')=='External' or '..' in PurePosixPath(options_part).parts or options_part not in parts or not managed:
            raise ExcelInputError('اسم ورقة الخيارات مستخدم في الملف. اختر ملف السحب الأصلي.')
        existing.set('state','hidden')
    else:
        if OPTIONS_PART in parts:raise ExcelInputError('مرجع ورقة الخيارات مستخدم في الملف.')
        ids={r.get('Id') for r in rels};i=1
        while 'rIdSayedOptions'+str(i) in ids:i+=1
        rid='rIdSayedOptions'+str(i)
        ET.SubElement(rels,'{'+RELNS+'}Relationship',Id=rid,Type=OFFREL+'/worksheet',Target='worksheets/sayed_detail_options.xml')
        ET.SubElement(sheets,Q('sheet'),name=OPTIONS_SHEET,sheetId=str(max(int(s.get('sheetId')) for s in sheets)+1),state='hidden',attrib={'{'+OFFREL+'}id':rid})
    options=dropdown_options()
    lookup=ET.Element(Q('worksheet'));body=ET.SubElement(lookup,Q('sheetData'))
    for rownum in range(1,max(map(len,options.values()))+1):
        row=ET.SubElement(body,Q('row'),r=str(rownum))
        for index,values in enumerate(options.values(),1):
            if rownum>len(values):continue
            cell=ET.SubElement(row,Q('c'),r=column(index)+str(rownum),t='inlineStr')
            ET.SubElement(ET.SubElement(cell,Q('is')),Q('t')).text=values[rownum-1]
    validations=root.find(Q('dataValidations'))
    if validations is None:
        validations=ET.Element(Q('dataValidations'))
        # Data validations precede hyperlinks, print options and drawings.
        after={Q(n) for n in ('hyperlinks','printOptions','pageMargins','pageSetup','headerFooter','rowBreaks','colBreaks','customProperties','cellWatches','ignoredErrors','smartTags','drawing','legacyDrawing','legacyDrawingHF','picture','oleObjects','controls','webPublishItems','tableParts','extLst')}
        index=next((i for i,n in enumerate(root) if n.tag in after),len(root))
        root.insert(index,validations)
    for node in list(validations):
        formula=node.find(Q('formula1'))
        if formula is not None and (formula.text or '').startswith(PREFIX):validations.remove(node)
    for index,(header,values) in enumerate(options.items(),1):
        name=PREFIX+str(index)
        define(name,f"'{OPTIONS_SHEET}'!${column(index)}$1:${column(index)}${len(values)}")
        for col,label in headers.items():
            if label!=header:continue
            node=ET.SubElement(validations,Q('dataValidation'),type='list',allowBlank='1',showDropDown='0',sqref=f'{col}2:{col}{last}')
            ET.SubElement(node,Q('formula1')).text=name
    # Excel requires named ranges for direct lists on another worksheet.
    for index,node in enumerate(validations,1):
        if node.get('type')!='list':continue
        node.set('showDropDown','0')
        formula=node.find(Q('formula1'))
        if formula is not None and re.fullmatch(r"=?'[^']+'!\$[A-Z]+\$\d+:\$[A-Z]+\$\d+",formula.text or ''):
            name='SayedSourceList_'+str(index)
            define(name,formula.text.lstrip('='));formula.text=name
    validations.set('count',str(len(validations)))
    types=ET.fromstring(parts['[Content_Types].xml'])
    if not any(n.get('PartName')=='/'+options_part for n in types):
        ET.SubElement(types,'{'+CT+'}Override',PartName='/'+options_part,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
    parts[options_part]=ET.tostring(lookup,encoding='utf-8',xml_declaration=True)
    # Excel adds a calculation chain when an exported workbook is saved.
    # Column relocation invalidates those cell addresses. Let Excel rebuild it.
    from posixpath import normpath
    removed={'xl/calcChain.xml'}
    for relation in list(rels):
        if relation.get('Type','').endswith('/calcChain'):
            target=relation.get('Target','')
            if relation.get('TargetMode')!='External':
                removed.add(normpath(target.lstrip('/') if target.startswith('/') else 'xl/'+target))
            rels.remove(relation)
    for node in list(types):
        if node.get('ContentType','').endswith('spreadsheetml.calcChain+xml') or node.get('PartName','').lstrip('/') in removed:
            removed.add(node.get('PartName','').lstrip('/'));types.remove(node)
    for name in removed:parts.pop(name,None)
    calculation=book.find(Q('calcPr'))
    if calculation is None:
        calculation=ET.Element(Q('calcPr'))
        successors={Q(n) for n in ('oleSize','customWorkbookViews','pivotCaches','smartTagPr','smartTagTypes','webPublishing','fileRecoveryPr','webPublishObjects','extLst')}
        book.insert(next((i for i,n in enumerate(book) if n.tag in successors),len(book)),calculation)
    calculation.set('calcMode','auto')
    calculation.set('fullCalcOnLoad','1');calculation.set('forceFullCalc','1')
    for key,node in ((part,root),('xl/workbook.xml',book),('xl/_rels/workbook.xml.rels',rels),('[Content_Types].xml',types)):
        parts[key]=serialize(node,parts[key])


def repair_scan_dropdowns(source,destination):
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.exists() or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('احفظ نسخة باسم جديد؛ يبقى الملف الأصلي كما هو.')
    if source.stat().st_size>64_000_000:raise ExcelInputError('الملف كبير جداً.')
    with zipfile.ZipFile(source) as z:
        if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128_000_000:raise ExcelInputError('الملف كبير جداً.')
        parts={n:z.read(n) for n in z.namelist()}
    attach_scan_dropdowns(parts)
    fd,tmp=tempfile.mkstemp(suffix='.xlsx',dir=destination.parent);os.close(fd)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        with zipfile.ZipFile(tmp) as z:
            if z.testzip():raise ExcelInputError('تعذّر التحقق من الملف الجديد.')
        os.link(tmp,destination)
    finally:os.unlink(tmp)
    return destination
