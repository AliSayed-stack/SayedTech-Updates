"""Upgrade a saved unified workbook in a separate copy, retaining other parts."""
import os
import re
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from student_excel import NS, ExcelInputError
from student_workflow import column, workbook_rows
from identity_card import CARD_COLUMNS, DOCUMENT_TYPES, REGISTRY_COLUMN

Q=lambda n:'{'+NS['m']+'}'+n
RELNS='http://schemas.openxmlformats.org/package/2006/relationships'
OFFREL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CT='http://schemas.openxmlformats.org/package/2006/content-types'

def serialize(root, original):
    # Excel can declare compatibility prefixes used only in mc:Ignorable.
    # ElementTree drops those declarations unless we retain them explicitly.
    declarations=re.findall(rb'xmlns(?::([\w.-]+))?=["\']([^"\']+)["\']',original)
    data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    start=re.search(rb'<(?!\?)[^>]+>',data)
    if start is not None:
        additions=[]
        added=set()
        for prefix,uri in declarations:
            attr=b'xmlns'+(b':'+prefix if prefix else b'')
            if attr not in added and not re.search(rb'\b'+re.escape(attr)+rb'=',start.group()):
                additions.append(b' '+attr+b'="'+uri+b'"')
                added.add(attr)
        data=data[:start.end()-1]+b''.join(additions)+data[start.end()-1:]
    return data

def attach_card_list(parts, xml=None):
    book=ET.fromstring(parts['xl/workbook.xml'])
    names=book.find(Q('definedNames'))
    if names is not None and any(n.get('name')=='IdentityDocumentTypes' for n in names):return
    sheets=book.find(Q('sheets'))
    if any(s.get('name')=='خيارات بطاقة التعريف' for s in sheets):
        raise ExcelInputError('يوجد اسم ورقة محجوز لخيارات بطاقة التعريف.')
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    ids={r.get('Id') for r in rels};i=1
    while 'rIdCard'+str(i) in ids:i+=1
    rid='rIdCard'+str(i)
    part='xl/worksheets/identity_card_types.xml'
    if part in parts:raise ExcelInputError('مرجع خيارات المستند موجود مسبقاً.')
    ET.SubElement(rels,'{'+RELNS+'}Relationship',Id=rid,Type=OFFREL+'/worksheet',Target='worksheets/identity_card_types.xml')
    ET.SubElement(sheets,Q('sheet'),name='خيارات بطاقة التعريف',sheetId=str(max(int(s.get('sheetId')) for s in sheets)+1),state='hidden',attrib={'{'+OFFREL+'}id':rid})
    if names is None:
        names=ET.Element(Q('definedNames'))
        position=list(book).index(sheets)+1
        # externalReferences precedes definedNames in the workbook schema.
        external=book.find(Q('externalReferences'))
        if external is not None:position=list(book).index(external)+1
        book.insert(position,names)
    ET.SubElement(names,Q('definedName'),name='IdentityDocumentTypes').text="'خيارات بطاقة التعريف'!$A$1:$A$12"
    if xml is None:
        root=ET.Element(Q('worksheet'));body=ET.SubElement(root,Q('sheetData'))
        for i,label in enumerate(DOCUMENT_TYPES,1):
            r=ET.SubElement(body,Q('row'),r=str(i));c=ET.SubElement(r,Q('c'),r='A'+str(i),t='inlineStr')
            ET.SubElement(ET.SubElement(c,Q('is')),Q('t')).text=label
        xml=ET.tostring(root)
    types=ET.fromstring(parts['[Content_Types].xml'])
    ET.SubElement(types,'{'+CT+'}Override',PartName='/'+part,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
    parts[part]=xml
    for key,root in [('xl/workbook.xml',book),('xl/_rels/workbook.xml.rels',rels),('[Content_Types].xml',types)]:parts[key]=serialize(root,parts[key])

def add_identity_columns(source,destination):
    from student_unified import is_unified, UNIFIED_HEADERS_V095
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.exists() or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('احفظ نسخة باسم جديد؛ يبقى الملف الأصلي كما هو.')
    if source.stat().st_size>64_000_000:raise ExcelInputError('الملف كبير جداً.')
    with zipfile.ZipFile(source) as z:
        if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128_000_000:raise ExcelInputError('الملف كبير جداً.')
        if not is_unified(z):raise ExcelInputError('اختر ملف Excel الموحد.')
        rows=workbook_rows(z,'الطلاب')
        headers=rows[0][1]
        if len(headers)!=len(UNIFIED_HEADERS_V095) or set(headers.values())!=set(UNIFIED_HEADERS_V095):
            raise ExcelInputError('اختر الملف الموحد السابق بدون أعمدة بطاقة التعريف، ومع عمود شهرة الأم.')
        parts={n:z.read(n) for n in z.namelist()}
    # Cross-sheet formulas and drawing anchors need Excel-aware relocation.
    # Stop rather than saving a subtly changed personal workbook.
    for name,data in parts.items():
        if name.startswith('xl/worksheets/') and name.endswith('.xml') and ET.fromstring(data).find('.//'+Q('f')) is not None:
            raise ExcelInputError('الملف يحتوي معادلات؛ أرسل نسخة منه لضبط نقل مراجعها قبل إضافة الأعمدة.')
    book=ET.fromstring(parts['xl/workbook.xml'])
    sheet=next(s for s in book.find(Q('sheets')) if s.get('name')=='الطلاب')
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    target=next(r.get('Target') for r in rels if r.get('Id')==sheet.get('{'+OFFREL+'}id'))
    part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if '..' in Path(part).parts or part not in parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    def number(letters):
        result=0
        for c in letters:result=result*26+ord(c)-64
        return result
    index=number(next(c for c,h in headers.items() if h=='نوع السكن'))
    registry=next(c for c,h in headers.items() if h==REGISTRY_COLUMN)
    rowvalues={n:v for n,v,_ in rows}
    def shift(text):
        return re.sub(r'(\$?)([A-Z]{1,3})(\$?\d+)',lambda m:m[1]+column(number(m[2])+ (3 if number(m[2])>index else 0))+m[3],text)
    root=ET.fromstring(parts[part])
    for node in root.iter():
        for key in ('r','ref','sqref','activeCell','topLeftCell'):
            if key in node.attrib:node.set(key,shift(node.get(key)))
        if node.tag==Q('col'):
            for key in ('min','max'):
                value=int(node.get(key));node.set(key,str(value+3 if value>index else value))
        if node.tag==Q('formula') and node.text:node.text=shift(node.text)
    for row in root.find(Q('sheetData')):
        n=int(row.get('r'));new=[]
        neighbour=next((c for c in row if c.get('r')==column(index)+str(n)),None)
        for j,label in enumerate(CARD_COLUMNS,1):
            value=label if n==1 else (rowvalues.get(n,{}).get(registry,'') if j==2 else '')
            c=ET.Element(Q('c'),r=column(index+j)+str(n),t='inlineStr')
            if neighbour is not None and neighbour.get('s') is not None:c.set('s',neighbour.get('s'))
            ET.SubElement(ET.SubElement(c,Q('is')),Q('t')).text=str(value or '')
            new.append(c)
        cells=list(row)+new
        for c in list(row):row.remove(c)
        for c in sorted(cells,key=lambda c:number(re.match('[A-Z]+',c.get('r')).group())):row.append(c)
    cols=root.find(Q('cols'))
    if cols is not None:
        for j in range(1,4):ET.SubElement(cols,Q('col'),min=str(index+j),max=str(index+j),width='27',customWidth='1')
        ordered=sorted(list(cols),key=lambda c:int(c.get('min')))
        for c in list(cols):cols.remove(c)
        for c in ordered:cols.append(c)
    validations=root.find(Q('dataValidations'))
    if validations is None:validations=ET.SubElement(root,Q('dataValidations'))
    last=max(501,max(rowvalues))
    node=ET.SubElement(validations,Q('dataValidation'),type='list',allowBlank='1',sqref=f'{column(index+1)}2:{column(index+1)}{last}')
    ET.SubElement(node,Q('formula1')).text='IdentityDocumentTypes'
    validations.set('count',str(len(validations)))
    parts[part]=serialize(root,parts[part])
    for name,data in list(parts.items()):
        if not name.startswith('xl/tables/') or not name.endswith('.xml'):continue
        table=ET.fromstring(data)
        if table.get('name')!='StudentsInput':continue
        for node in table.iter():
            if 'ref' in node.attrib:node.set('ref',shift(node.get('ref')))
        cols=table.find(Q('tableColumns'))
        for j,label in enumerate(CARD_COLUMNS):cols.insert(index+j,ET.Element(Q('tableColumn'),name=label))
        for i,c in enumerate(cols,1):c.set('id',str(i))
        cols.set('count',str(len(cols)));parts[name]=serialize(table,data)
    attach_card_list(parts)
    # Atomic create with no overwrite; validate the archive before installing.
    fd,tmp=tempfile.mkstemp(suffix='.xlsx',dir=destination.parent);os.close(fd)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        with zipfile.ZipFile(tmp) as z:
            if z.testzip():raise ExcelInputError('تعذّر التحقق من الملف الجديد.')
        os.link(tmp,destination)
    finally:os.unlink(tmp)
    return destination
