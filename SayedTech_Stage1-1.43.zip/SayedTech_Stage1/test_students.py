"""Offline boundary tests for XLSX review and draft filling; no network."""
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile
import xml.etree.ElementTree as ET
import core
from student_excel import FIELDS, HEADERS, BY_ID, ADDRESS_HEADERS, MERGED_HEADERS, validate_record, read_students, ExcelInputError
from student_fill import fill_student, StudentFillError, NEW_STUDENT, MANAGEMENT, SEARCH_RESULTS

def record():
    data={}
    for f in FIELDS:
        if f['type']=='checkbox': value=False
        elif f['type']=='date': value='2015-01-02'
        elif f['options']: value=f['options'][0]['label']
        else: value='TEST'
        data[f['id']]=value
    data.update({'field-existingUniqueId':'000123','field-registryNumber':'000456',
        'field-enrollment-promoted-class':'الثالث ثانوي',
        'field-enrollment-teaching-language':'الإنكليزية','field-enrollment-grade-section':'الشعبة أ'})
    return data

class Element:
    def __init__(self,page,key,option=None):self.page,self.key,self.option=page,key,option
    def count(self):return 1
    def all(self):return [self]
    def is_visible(self):return True
    def is_enabled(self):return True
    def is_disabled(self):return False
    def wait_for(self,**kw):pass
    def input_value(self):return self.page.values.get(self.key,'')
    def is_checked(self):return bool(self.page.values.get(self.key,False))
    def fill(self,value,**kw):
        self.page.actions.append(('fill',self.key,value));self.page.values[self.key]=value
        if self.page.redirect_on_fill:self.page.url='https://evil.example/form'
    def set_checked(self,value,**kw):self.page.values[self.key]=value
    def select_option(self,value,**kw):
        self.page.actions.append(('select',self.key,value));self.page.values[self.key]=value
        if self.key=='field-enrollment-promoted-class':
            self.page.options['field-enrollment-teaching-language']=[('live_en','الإنكليزية')]
        if self.key=='field-enrollment-teaching-language':
            self.page.options['field-enrollment-grade-section']=[('','--اختيار--'),('school_section_id','الشعبة أ')]
    def locator(self,selector):
        if selector!='option':raise AssertionError(selector)
        return Options(self.page,self.key)
    def get_attribute(self,name):return self.option[0]
    def inner_text(self):return self.option[1]

class Options:
    def __init__(self,page,key):self.page,self.key=page,key
    def all(self):return [Element(self.page,self.key,o) for o in self.page.options[self.key]]

class SearchNode:
    def __init__(self,page,kind,index=0):self.page,self.kind,self.index=page,kind,index
    def filter(self,**kwargs):return self
    def count(self):return int(self.page.search_open) if self.kind=='modal' else 1
    def wait_for(self,**kwargs):
        if self.kind=='modal':assert self.page.search_open
    def get_by_label(self,label,exact):
        assert label=='البحث بالرقم الموحد أو الاسم' and exact
        return SearchNode(self.page,'query')
    def fill(self,value,**kwargs):self.page.query=value;self.page.actions.append(('search',value))
    def input_value(self):return self.page.query
    def evaluate(self,script):
        assert script==SEARCH_RESULTS
        self.page.reads+=1
        if self.page.cancel_during_search:self.page.cancelled.set()
        return self.page.search_rows
    def locator(self,selector):
        assert selector=='ul > li > button'
        return SearchNode(self.page,'results')
    def nth(self,index):return SearchNode(self.page,'result',index)
    def inner_text(self):return self.page.search_rows[self.index]['text']
    def click(self,**kwargs):
        self.page.actions.append(('click',self.kind))
        if self.kind=='existing':self.page.search_open=True
        if self.kind=='new':
            self.page.url='https://new-sims.mehe.gov.lb'+NEW_STUDENT
            self.page.values={}
        if self.kind=='result':
            self.page.search_open=False
            self.page.url='https://new-sims.mehe.gov.lb'+NEW_STUDENT
            self.page.values.update(self.page.selected_values)

class Page:
    def __init__(self,account='person@te.mehe.school'):
        self.account=account
        self.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
        self.values={};self.actions=[];self.redirect_on_fill=False
        self.search_open=False;self.query='';self.reads=0;self.clock=0
        self.cancel_during_search=False;self.cancelled=threading.Event()
        self.search_rows=[{'index':0,'visible':True,'enabled':True,'name':'TEST TEST TEST',
            'detail':'000123 · تاريخ الميلاد: 2015-01-02','text':'TEST TEST TEST\n000123 · تاريخ الميلاد: 2015-01-02'}]
        self.selected_values={k:record()[k] for k in ('field-firstName','field-middleName','field-lastName','field-birthDate','field-existingUniqueId')}
        self.options={f['id']:[('','--اختيار--')]+[(o['value'],o['label']) for o in f['options']] for f in FIELDS if f['type']=='select'}
        self.options['field-enrollment-promoted-class']=[('live_secondary_3','الثالث ثانوي')]
    def get_by_text(self,pattern):
        if not pattern.search(self.account):return type('Empty',(),{'all':lambda s:[]})()
        return Element(self,'account')
    def locator(self,selector):
        if selector=='.print-area-modal':return SearchNode(self,'modal')
        return Element(self,selector.removeprefix('#'))
    def wait_for_timeout(self,*args):
        # Stable-result waiting is patched in selection tests, while baseline
        # tests use the actual bounded clock (without waiting 15 seconds).
        import time
        time.sleep(.1)
    def get_by_role(self,role,name,exact=False):
        if role=='heading' and name=='طالب موجود':return SearchNode(self,'heading')
        if role=='button' and name=='إنشاء':return SearchNode(self,'create')
        if role=='button' and hasattr(name,'search') and name.search('طالب موجود'):return SearchNode(self,'existing')
        if role=='button' and hasattr(name,'search') and name.search('طالب جديد'):return SearchNode(self,'new')
        raise AssertionError('Unexpected button click: saving is forbidden')

class StudentTests(unittest.TestCase):
    def test_manual_new_student_uses_blank_form_and_never_searches(self):
        page=Page();data=record();data['field-existingUniqueId']=''
        fill_student(page,data,'person@te.mehe.school',threading.Event(),entry_kind='طالب جديد')
        self.assertIn(('click','new'),page.actions)
        self.assertFalse(any(action=='search' for action,*_ in page.actions))
        self.assertEqual(page.values['field-firstName'],data['field-firstName'])
        page=Page();data['field-existingUniqueId']='000123'
        with self.assertRaises(StudentFillError):
            fill_student(page,data,'person@te.mehe.school',threading.Event(),entry_kind='طالب جديد')
        self.assertEqual(page.actions,[])
    def test_placeholder_unified_number_zero_is_absent(self):
        data=record();data['field-existingUniqueId']='0'
        clean,errors=validate_record(data)
        self.assertEqual(errors,[])
        self.assertEqual(clean['field-existingUniqueId'],'')
        data['field-existingUniqueId']='000123'
        self.assertEqual(validate_record(data)[0]['field-existingUniqueId'],'000123')

    def test_defaults_fill_only_blank_parent_fields_without_mutating_input(self):
        data=record();data.update({'isFatherDeceased':'','isMotherDeceased':None,'field-motherNationality':'  '})
        clean,errors=validate_record(data)
        self.assertEqual(errors,[])
        self.assertFalse(clean['isFatherDeceased']);self.assertFalse(clean['isMotherDeceased'])
        self.assertEqual(clean['field-motherNationality'],'سوريا')
        self.assertEqual(data['isFatherDeceased'],'')
        data.update({'isFatherDeceased':'نعم','isMotherDeceased':True,'field-motherNationality':'لبنان'})
        clean,errors=validate_record(data)
        self.assertEqual(errors,[])
        self.assertTrue(clean['isFatherDeceased']);self.assertTrue(clean['isMotherDeceased'])
        self.assertEqual(clean['field-motherNationality'],'لبنان')

    def test_each_parent_occupation_is_optional_only_when_that_parent_is_unemployed(self):
        for parent in ('father','mother'):
            sector='field-'+parent+'Sector';occupation='field-'+parent+'Occupation'
            other='field-'+('mother' if parent=='father' else 'father')+'Occupation'
            for unemployed in ('عاطل عن العمل','unemployed'):
                data=record();data[sector]=unemployed;data[occupation]=''
                clean,errors=validate_record(data)
                self.assertEqual(errors,[])
                self.assertEqual(clean[occupation],'')
                data[other]=''
                self.assertTrue(validate_record(data)[1])
            for employed in ('قطاع عام','قطاع خاص','عمل حر'):
                data=record();data[sector]=employed;data[occupation]=''
                self.assertTrue(validate_record(data)[1])
            data=record();data[sector]='عاطل عن العمل';data[occupation]='TEST RETAINED'
            self.assertEqual(validate_record(data)[0][occupation],'TEST RETAINED')

    def test_record_preserves_identifiers_dates_and_dynamic_secondary_class(self):
        clean,errors=validate_record(record())
        self.assertEqual(errors,[])
        self.assertEqual(clean['field-registryNumber'],'000456')
        bad=record();bad['field-existingUniqueId']=123
        self.assertTrue(validate_record(bad)[1])
        bad=record();bad['field-birthDate']='2099-01-01'
        self.assertTrue(validate_record(bad)[1])
        bad=record();bad['field-gender']='unknown'
        self.assertTrue(validate_record(bad)[1])

    def fixture(self,path,formula=False,duplicate=False,numeric_id=False,merged=False,address=False,address_formula=False,bad_header=False):
        ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
        q=lambda n:'{'+ns+'}'+n
        # Disposable XML fixture inside the exported template; never delivered.
        source=core.ASSET_BASE/('assets/student_with_addresses.xlsx' if merged else 'assets/student_simple.xlsx')
        with zipfile.ZipFile(source) as z:
            items={n:z.read(n) for n in z.namelist()}
        sheet=ET.fromstring(items['xl/worksheets/sheet1.xml'])
        body=sheet.find(q('sheetData'))
        for r in list(body):
            if r.get('r')!='1':body.remove(r)
        if bad_header:
            header=body.find(q('row')).find(q('c'))
            header.clear();header.set('r','A1');header.set('t','inlineStr')
            ET.SubElement(ET.SubElement(header,q('is')),q('t')).text='UNRECOGNIZED'
        values=record()
        for rownum in ([2,3] if duplicate else [2]):
            row=ET.SubElement(body,q('row'),r=str(rownum))
            for i,f in enumerate(FIELDS):
                col=chr(65+i) if i<26 else 'AA'
                c=ET.SubElement(row,q('c'),r=f'{col}{rownum}',t='inlineStr')
                text=ET.SubElement(ET.SubElement(c,q('is')),q('t'))
                value=values[f['id']]
                text.text='لا' if value is False else str(value)
                if numeric_id and i==0:
                    c.remove(c.find(q('is')));c.attrib.pop('t');ET.SubElement(c,q('v')).text='123'
                if formula and i==1:ET.SubElement(c,q('f')).text='1+1'
            if merged:
                if address or address_formula:
                    c=ET.SubElement(row,q('c'),r=f'AB{rownum}',t='inlineStr')
                    ET.SubElement(ET.SubElement(c,q('is')),q('t')).text='لبنان' if address else ''
                    if address_formula: ET.SubElement(c,q('f')).text='1+1'
                status=ET.SubElement(row,q('c'),r=f'AI{rownum}',t='e')
                ET.SubElement(status,q('f')).text='1/0'
                ET.SubElement(status,q('v')).text='#DIV/0!'
        if merged:
            # Status-only rows must not turn blank template rows into students.
            row=ET.SubElement(body,q('row'),r='501')
            status=ET.SubElement(row,q('c'),r='AI501',t='str')
            ET.SubElement(status,q('f')).text='"cached"'
            ET.SubElement(status,q('v')).text='أكمل خانات العنوان'
        items['xl/worksheets/sheet1.xml']=ET.tostring(sheet)
        with zipfile.ZipFile(path,'w') as z:
            for n,b in items.items():z.writestr(n,b)

    def test_xlsx_empty_formula_duplicate_and_numeric_identifiers(self):
        with self.assertRaises(ExcelInputError):read_students(core.ASSET_BASE/'assets/student_simple.xlsx')
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'fixture.xlsx'
            self.fixture(path)
            rows=read_students(path)
            self.assertEqual(rows[0]['errors'],[])
            self.assertEqual(rows[0]['values']['field-existingUniqueId'],'000123')
            self.fixture(path,formula=True)
            self.assertTrue(rows:=read_students(path)[0]['errors'])
            self.assertTrue(any('المعادلات' in e for e in rows))
            self.fixture(path,duplicate=True)
            self.assertTrue(all(r['errors'] for r in read_students(path)))
            self.fixture(path,numeric_id=True)
            self.assertTrue(read_students(path)[0]['errors'])

    def test_merged_template_ignores_only_status_and_preserves_basic_import(self):
        with self.assertRaisesRegex(ExcelInputError,'فارغ'):
            read_students(core.ASSET_BASE/'assets/student_with_addresses.xlsx')
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'fixture.xlsx'
            self.fixture(path,merged=True)
            rows=read_students(path)
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['errors'],[])
            self.assertEqual(rows[0]['values']['field-existingUniqueId'],'000123')
            self.assertEqual(set(rows[0]['address']),set(ADDRESS_HEADERS))
            self.fixture(path,merged=True,formula=True)
            self.assertTrue(any('المعادلات' in e for e in read_students(path)[0]['errors']))
            self.fixture(path,merged=True,address_formula=True)
            self.assertTrue(any('المعادلات' in e for e in read_students(path)[0]['errors']))
            self.fixture(path,merged=True,bad_header=True)
            with self.assertRaisesRegex(ExcelInputError,'عناوين'):read_students(path)

    def test_merged_address_is_preserved_for_review_and_blocks_partial_fill(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'fixture.xlsx'
            self.fixture(path,merged=True,address=True)
            row=read_students(path)[0]
            self.assertEqual(row['address']['البلد'],'لبنان')
            self.assertEqual(row['values']['field-registryNumber'],'000456')
            self.assertTrue(any('استرداد العناوين' in e for e in row['errors']))

    def test_fill_uses_live_values_for_secondary_grade_and_never_saves(self):
        page=Page()
        fill_student(page,record(),'person@te.mehe.school',threading.Event())
        self.assertEqual(page.values['field-enrollment-promoted-class'],'live_secondary_3')
        self.assertEqual(page.values['field-enrollment-teaching-language'],'live_en')
        self.assertEqual(page.values['field-registryNumber'],'000456')
        self.assertTrue(page.actions)

    def test_invalid_row_reports_the_specific_field_before_browser_changes(self):
        page=Page();bad=record();bad['field-registryNumber']=123
        with self.assertRaises(StudentFillError) as result:
            fill_student(page,bad,'person@te.mehe.school',threading.Event())
        self.assertEqual(result.exception.code,'student_invalid')
        self.assertEqual(result.exception.field,'field-registryNumber')
        self.assertEqual(page.actions,[])

    def test_existing_draft_wrong_account_and_redirect_refused(self):
        page=Page();page.values['field-firstName']='EXISTING'
        page.url='https://new-sims.mehe.gov.lb'+NEW_STUDENT
        with self.assertRaises(StudentFillError) as cm:fill_student(page,record(),'person@te.mehe.school',threading.Event())
        self.assertEqual(cm.exception.code,'student_open_management')
        self.assertEqual(page.actions,[])
        page=Page()
        with self.assertRaises(StudentFillError):fill_student(page,record(),'wrong@te.mehe.school',threading.Event())
        self.assertEqual(page.actions,[])
        page=Page();page.redirect_on_fill=True
        with self.assertRaises(StudentFillError) as cm:fill_student(page,record(),'person@te.mehe.school',threading.Event())
        self.assertEqual(cm.exception.code,'student_account_required')
        self.assertEqual(sum(a[0]=='fill' for a in page.actions),1)

    def test_duplicate_option_is_not_chosen_arbitrarily(self):
        page=Page()
        page.options['field-enrollment-promoted-class']=[('one','الثالث ثانوي'),('two','الثالث ثانوي')]
        with self.assertRaises(StudentFillError) as cm:fill_student(page,record(),'person@te.mehe.school',threading.Event())
        self.assertEqual(cm.exception.code,'student_options_changed')
        self.assertFalse(any(a[0] in ('fill','select') for a in page.actions))

if __name__=='__main__':unittest.main()
