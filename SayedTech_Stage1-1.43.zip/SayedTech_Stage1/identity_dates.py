"""Strict birth-date identity and bounded, date-only failure diagnostics."""
import re
from student_excel import normalize_date


def identity_birth(value):
    if isinstance(value,str):
        value=re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',value)
        value=value.translate(str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789'))
        # SIMS' visible calendar textbox explicitly declares YYYY/MM/DD.
        # Convert only an unambiguous four-digit-year prefix; keep the
        # workbook's month-first slash convention and strict date validation.
        value=value.strip()
        if re.fullmatch(r'[0-9]{4}/[0-9]{2}/[0-9]{2}',value):
            value=value.replace('/','-')
    return normalize_date(value)


def clean_birth_detail(detail):
    if not isinstance(detail,dict):return {}
    result={}
    for key in ('expected_birth','observed_birth'):
        value=detail.get(key)
        if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):continue
        try:
            if identity_birth(value)==value:result[key]=value
        except (ValueError,TypeError,OverflowError):pass
    return result if len(result)==2 else {}


def birth_difference(expected,observed):
    try:return clean_birth_detail({'expected_birth':identity_birth(expected),'observed_birth':identity_birth(observed)})
    except (ValueError,TypeError,OverflowError):return {}
