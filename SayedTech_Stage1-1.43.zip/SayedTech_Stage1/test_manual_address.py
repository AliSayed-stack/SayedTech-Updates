import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
from detailed_import import fill_details,read_details,DetailError
from manual_sections import IMPORT_SECTIONS,SELECT,section_summary
from student_excel import ExcelInputError
from student_scan import export_students
from test_detailed_import import Page
import test_manual_sections as fixtures


class ManualAddressTests(unittest.TestCase):
    def invoke(self,page,row,mode,username):
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,mode,username,threading.Event())

    def test_manual_address_selects_dependent_options_and_respects_save_choice_both_shifts(self):
        self.assertEqual(IMPORT_SECTIONS[0],'عناوين السكن')
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            for save in (False,True):
                with self.subTest(username=username,save=save):
                    page=Page();page.choices['النوع']='دائم'
                    address=dict(page.choices,الشارع='شارع اختبار',**{'تفاصيل العنوان ١':'بناية اختبار'})
                    row={'values':page.values.copy(),'address':address,'manual':{}}
                    event=self.invoke(page,row,('manual_save:' if save else 'manual:')+'عناوين السكن',username)
                    self.assertEqual(event,'detail_saved' if save else 'detail_filled')
                    selections=[key for action,key in page.actions if action=='select']
                    self.assertEqual(selections,['البلد','المحافظة','القضاء','المنطقة','النوع'])
                    self.assertEqual(page.values['الشارع'],'شارع اختبار')
                    self.assertEqual(page.values['تفاصيل العنوان ١'],'بناية اختبار')
                    self.assertEqual(page.actions.count(('click','حفظ القسم')),int(save))
                    self.assertEqual(page.actions.count(('click','تأكيد')),int(save))
                    self.assertNotIn(('click','إرسال للمراجعة'),page.actions)

    def test_empty_incomplete_and_existing_address_do_not_add_or_save(self):
        for address,existing,expected in (({},False,'detail_no_data'),({'البلد':'لبنان'},False,'detail_input'),
                                          ({'البلد':'لبنان','المحافظة':'الشمال','القضاء':'زغرتا','المنطقة':'بلدة اختبار'},True,'detail_existing')):
            page=Page();page.existing=existing
            row={'values':page.values.copy(),'address':address,'manual':{}}
            if expected=='detail_no_data':self.assertEqual(self.invoke(page,row,'manual_save:عناوين السكن','school@te.mehe.school'),expected)
            else:
                with self.assertRaises(DetailError) as error:self.invoke(page,row,'manual_save:عناوين السكن','school@te.mehe.school')
                self.assertEqual(error.exception.code,expected)
            self.assertNotIn(('click','إضافة'),page.actions)
            self.assertNotIn(('click','حفظ القسم'),page.actions)

    def test_existing_scan_columns_reach_address_preview_and_import(self):
        _,data=fixtures.ManualWorkbookTests().data()
        address={'البلد':'لبنان','المحافظة':'الشمال','القضاء':'زغرتا','المنطقة':'بلدة اختبار',
                 'النوع':'صيفي','الشارع':'شارع اختبار','تفاصيل العنوان ١':'بناية اختبار'}
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'scan.xlsx';export_students(data,path,threading.Event())
            book=load_workbook(path);sheet=book['الطلاب'];headers={c.value:c.column for c in sheet[1]}
            self.assertEqual(len(headers),56)
            sheet.cell(2,headers[SELECT]).value='1'
            for label,value in address.items():sheet.cell(2,headers[label]).value=value
            book.save(path);book.close()
            row=read_details(path)[0]
            self.assertEqual(row['address'],address)
            summary=section_summary(row,'عناوين السكن')
            for label,value in address.items():self.assertIn(label+': '+value,summary)
            book=load_workbook(path);sheet=book['الطلاب'];sheet.cell(2,headers['الشارع']).value='=1+1';book.save(path);book.close()
            with self.assertRaisesRegex(ExcelInputError,'قيماً ثابتة'):read_details(path)


if __name__=='__main__':unittest.main()
