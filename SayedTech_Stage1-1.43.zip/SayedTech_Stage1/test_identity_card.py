import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from identity_card import CARD_COLUMNS, REGISTRY_COLUMN, card_from_row, validate_card
from identity_workbook import add_identity_columns
from student_unified import UNIFIED_HEADERS, UNIFIED_HEADERS_V095, selected_rows
from student_excel import NS, ExcelInputError
import test_student_unified as unified_tests
import test_detailed_import as detail_tests
from detailed_import import read_details, DetailError
from student_workflow import workbook_rows
import xml.etree.ElementTree as ET

class IdentityWorkbookTests(unittest.TestCase):
    def test_new_export_columns_dropdown_and_values(self):
        with tempfile.TemporaryDirectory() as folder:
            path=unified_tests.UnifiedTests().make(folder)
            self.assertEqual(UNIFIED_HEADERS[UNIFIED_HEADERS.index('نوع السكن')+1:][:3],CARD_COLUMNS)
            with zipfile.ZipFile(path) as z:
                rows=workbook_rows(z,'الطلاب')
                values={h:rows[1][1].get(c,'') for c,h in rows[0][1].items()}
                self.assertEqual(str(values[CARD_COLUMNS[1]]),str(values[REGISTRY_COLUMN]))
                root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                self.assertTrue(any(n.text=='IdentityDocumentTypes' for n in root.findall('.//m:formula1',NS)))
                self.assertEqual(len(ET.fromstring(z.read('xl/worksheets/identity_card_types.xml')).findall('.//m:t',NS)),12)
            unified_tests.edit(path,{'اختيار للاستيراد':'1',CARD_COLUMNS[0]:'جواز سفر',CARD_COLUMNS[1]:'001234',CARD_COLUMNS[2]:'2030-12-31'})
            self.assertEqual(validate_card(read_details(path)[0]['identity_card']),('جواز سفر','001234','2030-12-31'))

    def test_upgrade_preserves_original_and_old_values(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch('student_unified.UNIFIED_HEADERS',UNIFIED_HEADERS_V095):
                old=unified_tests.UnifiedTests().make(folder)
            before=old.read_bytes();dest=Path(folder)/'upgraded.xlsx'
            with zipfile.ZipFile(old) as z:
                original={n:z.read(n) for n in z.namelist()};oldrows=workbook_rows(z,'الطلاب')
            add_identity_columns(old,dest)
            self.assertEqual(old.read_bytes(),before)
            with zipfile.ZipFile(dest) as z:
                rows=workbook_rows(z,'الطلاب')
                self.assertEqual(list(rows[0][1].values()),UNIFIED_HEADERS)
                previous={h:oldrows[1][1].get(c,'') for c,h in oldrows[0][1].items()}
                current={h:rows[1][1].get(c,'') for c,h in rows[0][1].items()}
                for h,v in previous.items():self.assertEqual(current[h],v,h)
                self.assertEqual(current[CARD_COLUMNS[1]],str(previous[REGISTRY_COLUMN]))
                for name,data in original.items():
                    if name not in ('xl/workbook.xml','xl/_rels/workbook.xml.rels','[Content_Types].xml','xl/worksheets/sheet1.xml') and not name.startswith('xl/tables/'):
                        self.assertEqual(z.read(name),data,name)
            unified_tests.edit(dest,{'اختيار للاستيراد':'1'})
            with zipfile.ZipFile(dest) as z:selected_rows(z,'detailed')
            with self.assertRaises(ExcelInputError):add_identity_columns(old,dest)
            self.assertEqual(old.read_bytes(),before)

    def test_number_fallback_and_type_not_guessed(self):
        card=card_from_row({REGISTRY_COLUMN:'000567'})
        self.assertEqual(card['number'],'000567')
        with self.assertRaises(ExcelInputError):validate_card(card)
        self.assertEqual(validate_card({'type':'لا توجد وثائق'}),('لا توجد وثائق','',''))
        self.assertEqual(validate_card({'type':'هوية','number':'99','expiry':'2030-12-31'})[2],'2030-12-31')

class IdentityImportTests(unittest.TestCase):
    def run_card(self,section='identity_card',existing=False,disabled=False):
        Page,Element=detail_tests.Page,detail_tests.Element
        page=Page();row=detail_tests.DetailFillTests().setup_record(page)
        page.existing=existing;page.choices['نوع المستند']='جواز سفر'
        row['mother_surname']='الحسين'
        row['identity_card']={'type':'جواز سفر','number':'00123','expiry':'2030-12-31'}
        original=Element.get_by_label
        def label(element,pattern,**kw):
            for key in ('نوع المستند','رقم الوثيقة','تاريخ الإنتهاء'):
                if hasattr(pattern,'search') and pattern.search(key):return Element(element.page,key)
            return original(element,pattern,**kw)
        enabled=Element.is_enabled
        def is_enabled(element):return False if disabled and element.key=='حفظ' else enabled(element)
        with patch.object(Element,'get_by_label',label),patch.object(Element,'is_enabled',is_enabled):
            result=detail_tests.DetailFillTests().fill(page,row,section)
        return page,result
    def test_document_save_uses_card_button_no_upload(self):
        page,result=self.run_card()
        self.assertEqual(result,'detail_saved')
        self.assertEqual(page.values['رقم الوثيقة'],'00123')
        self.assertEqual(page.values['تاريخ الإنتهاء'],'2030-12-31')
        self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertIn(('click','حفظ'),page.actions)
        self.assertNotIn(('click','حفظ القسم'),page.actions)
        self.assertIn(('click','تأكيد'),page.actions)
    def test_combined_adds_card(self):
        page,result=self.run_card('all')
        self.assertEqual(result,'detail_all_saved')
        self.assertEqual(page.actions.count(('click','تأكيد')),4)
        self.assertIn(('click','بطاقات التعريف'),page.actions)
    def test_existing_card_and_disabled_button_stop(self):
        with self.assertRaises(DetailError) as err:self.run_card(existing=True)
        self.assertEqual(err.exception.code,'detail_existing')
        with self.assertRaises(DetailError) as err:self.run_card(disabled=True)
        self.assertEqual(err.exception.code,'detail_card_disabled')

if __name__=='__main__':unittest.main()
