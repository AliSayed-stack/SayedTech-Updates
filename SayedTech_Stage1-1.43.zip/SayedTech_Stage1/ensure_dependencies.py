"""Reuse installed pinned dependencies; install only if missing or different."""
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path
import subprocess
import sys


def ready(path):
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('#'): continue
        name, expected = line.split('==', 1)
        try:
            if version(name) != expected: return False
        except PackageNotFoundError: return False
    return True


def ensure():
    requirements = Path(__file__).with_name('requirements.txt')
    if not ready(requirements):
        if subprocess.run([sys.executable, '-m', 'pip', '--version'],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
            # Some Windows Python distributions create a usable venv without pip.
            # Repair that same venv; do not install packages into the base runtime.
            subprocess.run([sys.executable, '-m', 'ensurepip', '--upgrade'], check=True)
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--only-binary=:all:',
                        '-r', str(requirements)], check=True)


if __name__ == '__main__': ensure()
