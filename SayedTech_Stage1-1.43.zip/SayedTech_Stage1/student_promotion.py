"""Derive next grade once at workbook preparation from the source final result."""
from student_excel import FIELDS
from student_detailed import read_table, normalized_id
from nsldb_reference import TARGET_YEAR, canonical_year

PROMOTION_HEADERS = ['الصف الأصلي في القاعدة', 'النتيجة النهائية في القاعدة', 'ملاحظة الترفيع']
GRADE_HEADER = next(f['label'] for f in FIELDS if f['id'] == 'field-enrollment-promoted-class')
GRADES = ['الروضة الأولى', 'الروضة الثانية', 'الروضة الثالثة'] + [
    g + ' أساسي' for g in ('الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع')
] + ['الأول ثانوي', 'الثاني ثانوي', 'الثالث ثانوي']


def source_results(z):
    codes = {}
    for row in read_table(z, 'قوائم القاعدة'):
        if row.get('جدول المصدر') != 'ResultType': continue
        key = normalized_id(row.get('المعرّف (ID)'))
        codes.setdefault(key, set()).add((str(row.get('الرمز (Code)') or '').strip().upper(),
                                        str(row.get('الاسم') or '').strip()))
    results = {}
    for row in read_table(z, 'تسجيلات القاعدة'):
        def field(name):
            matches = [v for h, v in row.items() if h == name or h.endswith(' (' + name + ')')]
            return matches[0] if len(matches) == 1 else ''
        if canonical_year(field('TermID')) != TARGET_YEAR: continue
        key = tuple(normalized_id(field(n)) for n in ('MEHEID', 'GPersonID'))
        options = codes.get(normalized_id(field('FinalResultID')), {('', 'غير محددة')})
        results.setdefault(key, set()).update(options)
    return results


def apply_promotion(row, results):
    original = str(row.get(GRADE_HEADER) or '').strip()
    key = tuple(normalized_id(row.get(h)) for h in ('معرّف المدرسة في القاعدة', 'معرّف الشخص في القاعدة'))
    options = results.get(key, {('', 'غير محددة')})
    note = ''
    if len(options) != 1:
        result = 'نتائج متعارضة'
        row[GRADE_HEADER] = ''
        note = 'حدّد صف التسجيل يدوياً؛ توجد نتائج مختلفة لنفس الطالب في المصدر'
    else:
        code, name = next(iter(options))
        result = name or code or 'غير محددة'
        if code == 'SUCC':
            if original in GRADES[:-1]:
                row[GRADE_HEADER] = GRADES[GRADES.index(original) + 1]
                note = 'رُفّع صفاً واحداً حسب النتيجة النهائية 2025–2026'
            else:
                row[GRADE_HEADER] = ''
                note = ('ناجح بالثالث ثانوي؛ لا يوجد صف مدرسي أعلى' if original == GRADES[-1]
                        else 'الصف الأصلي غير معروف؛ حدّد صف التسجيل يدوياً')
        elif code == 'USUC':
            note = 'راسب؛ بقي في الصف الأصلي'
        else:
            note = 'لم يُرفّع؛ لا توجد نتيجة نجاح نهائية مؤكدة'
    row.update(zip(PROMOTION_HEADERS, (original, result, note)))
    return row
