"""Local lookup export dialog. No student data is displayed or transmitted."""
from uuid import uuid4
import core
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton,
                               QProgressBar, QFileDialog, QPlainTextEdit)


class CatalogDialog(QDialog):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.request_id = ''
        self.path = ''
        self.pending = False
        self.available = True
        self.setWindowTitle(f'Sayed tech {core.APP_VERSION} | قوائم العناوين')
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(680, 630)
        layout = QVBoxLayout(self)
        intro = QLabel('تجميع قوائم لبنان: المحافظة ← القضاء ← المنطقة')
        intro.setWordWrap(True)
        layout.addWidget(intro)
        instructions = QLabel(
            'في نافذة النظام التي فتحها البرنامج:\n'
            '١. افتح تلميذاً مسجّلاً بالمعلومات المبسّطة، ثم اختر «مفصّل».\n'
            '٢. افتح «عناوين السكن». إذا كان فارغاً اضغط «إضافة» مرة واحدة، دون حفظ.\n'
            '٣. اترك النموذج دون حفظ، ثم اضغط الزر أدناه واختر مكان الملف.\n\n'
            'أثناء التجميع لا تغيّر الصفحة أو القوائم. يبدّل البرنامج اختيارات العنوان '
            'مؤقتاً ويقرأ الخيارات ثم يرجّع الاختيارات الأصلية؛ لا يضغط إضافة أو حفظ. '
            'إذا تعذّر الإرجاع تظهر رسالة واضحة لتخرج من النموذج دون حفظ.\n\n'
            'الملف يحوي أسماء ورموز المناطق وربطها فقط؛ لا يحوي بيانات الطلاب أو حساب الدخول. '
            'أرسله هنا لتجهيز قوائم Excel المترابطة.')
        instructions.setWordWrap(True)
        layout.addWidget(instructions)
        self.status = QLabel('افتح عناوين تلميذ مسجّل أولاً، مع ظهور مجموعة عنوان واحدة فقط. قد يستغرق التجميع عدة دقائق.')
        self.status.setTextFormat(Qt.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(200)
        self.log.setMinimumHeight(80)
        self.log.setMaximumHeight(120)
        self.log.setPlaceholderText('سيظهر هنا القضاء وعدد المناطق المسحوبة منه.')
        layout.addWidget(self.log)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.start_button = QPushButton('بدء تجميع قوائم العناوين')
        self.start_button.clicked.connect(self.start)
        layout.addWidget(self.start_button)
        self.stop_button = QPushButton('إيقاف التجميع')
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop)
        layout.addWidget(self.stop_button)
        self.close_button = QPushButton('إغلاق')
        self.close_button.clicked.connect(self.reject)
        layout.addWidget(self.close_button)
        controller.catalog_result.connect(self.result)
        controller.event.connect(self.session_event)
        self.finished.connect(self.cleanup)

    def set_pending(self, pending):
        self.pending = pending
        self.start_button.setEnabled(not pending and self.available)
        self.close_button.setEnabled(not pending)
        self.stop_button.setEnabled(pending)

    def start(self):
        if self.pending or not self.available:
            return
        path, _ = QFileDialog.getSaveFileName(self, 'حفظ قوائم العناوين',
                                             'SayedTech_Address_Catalog.json', 'JSON (*.json)')
        if not path:
            return
        if not path.lower().endswith('.json'):
            path += '.json'
        self.path, self.request_id = path, uuid4().hex
        self.log.clear()
        self.set_pending(True)
        self.progress.setRange(0, 0)
        self.progress.setFormat('%p%')
        self.status.setText('جارٍ قراءة القوائم وربطها… اترك المتصفح دون تغيير.')
        if not self.controller.collect_catalog(path, self.request_id):
            self.result(self.request_id, 'catalog_failed', 0, 0)

    def stop(self):
        if self.pending:
            self.controller.cancel_catalog(self.request_id)
            self.stop_button.setEnabled(False)
            self.status.setText('جارٍ إيقاف التجميع وإرجاع اختيارات العنوان…')

    def result(self, request_id, event, first, second, detail=None):
        if request_id != self.request_id or not self.pending:
            return
        if event == 'catalog_restoring':
            self.progress.setRange(0, 0)
            self.stop_button.setEnabled(False)
            self.status.setText('جارٍ إرجاع اختيارات العنوان الأصلية… انتظر ولا تغيّر الصفحة.')
            return
        if event == 'catalog_progress':
            detail = detail or {}
            self.progress.setRange(0, second)
            stage = detail.get('stage')
            self.progress.setValue(first if stage == 'province_done' else max(0, first - 1))
            location = ' ← '.join(v for v in (detail.get('governorate'), detail.get('district')) if v)
            if stage == 'read':
                message = f'{location}: تم سحب {detail.get("areas", 0)} منطقة. الأقضية المنجزة: {detail.get("done", 0)}.'
            elif stage == 'retry':
                message = f'{location}: إعادة محاولة تحميل القائمة…'
            elif stage == 'pending':
                message = f'{location}: تعذّرت قراءة القائمة بعد المحاولة الثانية؛ سيكمل الباقي ويعلّمها ناقصة في الملف.'
            elif stage == 'areas':
                message = f'{location}: جارٍ سحب جميع المناطق التابعة لهذا القضاء…'
            elif stage == 'province_done':
                message = f'انتهت قراءة المحافظة {first} من {second}.'
            else:
                message = f'{location}: جارٍ قراءة الأقضية…'
            if stage in {'read', 'retry', 'pending'}: self.log.appendPlainText(message)
            self.status.setText(message)
            return
        if event == 'catalog_restore_required':
            self.available = False
        self.set_pending(False)
        self.progress.setRange(0, 1)
        self.progress.setValue(1 if event in {'catalog_saved', 'catalog_saved_partial'} else 0)
        self.progress.setFormat('انتهت المحاولة مع نواقص' if event == 'catalog_saved_partial' else '%p%')
        detail = detail or {}
        messages = {
            'catalog_saved': f'تم حفظ {first} قضاء و{second} منطقة في:\n{self.path}\nأُعيدت اختيارات العنوان الأصلية دون حفظ الطالب. أرسل الملف هنا، واخرج من النموذج دون حفظ.',
            'catalog_cancelled': 'توقف التجميع. لم يُحفظ ملف جديد، وأُعيدت الاختيارات التي غيّرتها الأداة. اخرج من النموذج دون حفظ.',
            'catalog_prepare': 'افتح تلميذاً مسجّلاً ثم مفصّل ← عناوين السكن. إذا كان فارغاً اضغط إضافة مرة واحدة دون حفظ. يجب ظهور مجموعة عنوان واحدة فقط، ثم أعد المحاولة.',
            'catalog_restore_required': 'توقّفت العملية وتعذّر تأكيد إرجاع اختيارات العنوان. لا تضغط حفظ القسم؛ اخرج من النموذج وتجاهل التغييرات ثم افتحه مجدداً. لم يُحفظ ملف قوائم جديد.',
            'catalog_account_required': 'تعذّر تأكيد الحساب أو انتهت الجلسة. لم يُحفظ ملف جديد.',
            'catalog_options_changed': 'لم تتأكد خيارات أحد الأقضية أو المناطق، أو تغيّرت الصفحة. لم يُحفظ ملف ناقص. اترك النموذج مفتوحاً وأعد المحاولة؛ إذا تكرر الخطأ أرسل صورة القوائم الظاهرة.',
            'catalog_busy': 'المساعد ينفّذ عملية أخرى. انتظر انتهاءها ثم أعد المحاولة.',
            'catalog_failed': 'تعذّر التجميع أو حفظ الملف. راجع المسودة ومكان الحفظ ثم أعد المحاولة.',
            'catalog_saved_partial': f'حُفظت مناطق {first} قضاء ({second} منطقة) في:\n{self.path}\nالملف غير مكتمل: بقيت {detail.get("pending", 0)} قوائم متعذّرة، وأسماؤها وأسبابها موجودة فيه وفي سجل التقدم. أرسل الملف هنا للمراجعة. أُعيدت الاختيارات الأصلية؛ اخرج من النموذج دون حفظ.',
            'catalog_load_timeout': 'انتهت مهلة تحميل قائمة البداية. لم يُحفظ ملف جديد. تأكد من ظهور قوائم العنوان ثم أعد المحاولة.',
            'catalog_invalid_options': 'تعذّرت قراءة رموز قائمة البداية بصورة موثوقة. لم يُحفظ ملف جديد. أرسل صورة الرسالة والقائمة الظاهرة.',
        }
        self.status.setText(messages.get(event, messages['catalog_failed']))

    def session_event(self, event):
        if event in {'invalid_input', 'dependency_missing', 'browser_missing', 'timeout',
                     'failed', 'cancelled', 'browser_closed', 'disconnected'}:
            self.available = False
            self.set_pending(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق هذه النافذة وسجّل الدخول مجدداً.')

    def reject(self):
        if not self.pending:
            super().reject()

    def closeEvent(self, event):
        if self.pending:
            event.ignore()
        else:
            super().closeEvent(event)

    def cleanup(self, *_):
        self.controller.catalog_result.disconnect(self.result)
        self.controller.event.disconnect(self.session_event)
