import unittest
from manual_save import save_manual,send_review
from detailed_import import DetailError


class Node:
    def __init__(self,page,key):self.page,self.key=page,key
    def count(self):return 1
    def is_visible(self):return self.page.sent if self.key=='sent' else True
    def is_enabled(self):return True
    def is_checked(self):return self.page.terminated
    def input_value(self):return self.page.note
    def fill(self,value,**kw):self.page.note=value;self.page.actions.append(('note',value))
    def filter(self,**kw):return self
    def evaluate(self,script):return True
    def wait_for(self,state,**kw):
        if self.key=='dialog':
            if (state=='visible')!=self.page.dialog:raise RuntimeError('dialog state')
        if self.key=='success':
            if (state=='visible')!=self.page.saved:raise RuntimeError('toast state')
        if self.key=='sent' and state=='visible' and not self.page.sent:raise RuntimeError('status never updated')
    def get_by_role(self,role,name,**kw):return Node(self.page,('confirm:' if self.key=='dialog' else '')+name)
    def get_by_text(self,text,**kw):return Node(self.page,'sent')
    def get_by_label(self,text,**kw):return Node(self.page,'note')
    def locator(self,selector):return Node(self.page,'terminate')
    def click(self,**kw):
        self.page.actions.append(('click',self.key))
        if self.key in ('حفظ القسم','حفظ','إرسال للمراجعة'):self.page.dialog=True
        if self.key=='confirm:تأكيد':self.page.dialog=False;self.page.saved=True
        if self.key=='confirm:إرسال للمراجعة':self.page.dialog=False;self.page.sent=True


class Page:
    def __init__(self):self.actions=[];self.dialog=False;self.saved=False;self.sent=False;self.terminated=False;self.note=''
    def get_by_role(self,role,name='',**kw):return Node(self,'success' if role=='alert' else name)
    def locator(self,selector):return Node(self,'dialog' if 'swal2-popup' in selector else 'scope')


class SaveProtocolTests(unittest.TestCase):
    def test_correct_save_button_and_single_confirmation_for_each_section(self):
        for title in ('الهواتف','البريد الإلكتروني','الأقارب','بطاقات التعريف','المستندات'):
            page=Page()
            self.assertEqual(save_manual(page,title,lambda:None),'detail_saved')
            expected='حفظ' if title in ('بطاقات التعريف','المستندات') else 'حفظ القسم'
            self.assertEqual(page.actions,[('click',expected),('click','confirm:تأكيد')])
            self.assertFalse(page.sent)

    def test_current_registration_status_is_never_saved_as_an_input(self):
        page=Page();self.assertEqual(save_manual(page,'حالة التسجيل',lambda:None),'detail_filled')
        self.assertEqual(page.actions,[])

    def test_review_uses_its_own_confirmation_and_checks_new_status(self):
        page=Page()
        self.assertEqual(send_review(page,{'manual':{'حالة التسجيل / ملاحظة (اختياري)':'NOTE'}},lambda:None),'detail_review_sent')
        self.assertEqual(page.note,'NOTE')
        self.assertEqual(page.actions.count(('click','إرسال للمراجعة')),1)
        self.assertEqual(page.actions.count(('click','confirm:إرسال للمراجعة')),1)
        before=page.actions[:]
        self.assertEqual(send_review(page,{},lambda:None),'detail_review_already')
        self.assertNotIn(('click','إرسال للمراجعة'),page.actions[len(before):])

    def test_termination_checkbox_blocks_review_without_clicking_send(self):
        page=Page();page.terminated=True
        with self.assertRaises(DetailError):send_review(page,{},lambda:None)
        self.assertNotIn(('click','إرسال للمراجعة'),page.actions)


if __name__=='__main__':unittest.main()
