"""Native attendance XLSX template filling and header-based selected-row reading."""
import os
from pathlib import Path
import re
import tempfile
import xml.etree.ElementTree as ET
import zipfile
import core
from student_excel import NS,ExcelInputError
from student_workflow import column,workbook_rows,selection_value
from attendance_schema import HEADERS,AttendanceError,account_key,validate_absence

SHEET='الحضور';MARKER='سياق الحضور'


def write_attendance(path,roster,username):
    path=Path(path)
    if path.suffix.lower()!='.xlsx' or (core.ASSET_BASE/'assets').resolve() in path.resolve().parents:
        raise AttendanceError('attendance_input')
    with zipfile.ZipFile(core.ASSET_BASE/'assets/student_attendance.xlsx') as archive:
        parts={name:archive.read(name) for name in archive.namelist()}
    q=lambda s:'{'+NS['m']+'}'+s
    sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml']);body=sheet.find('m:sheetData',NS)
    styles=[c.get('s') for c in body[1]]
    def cell(row,index,value):
        c=ET.SubElement(row,q('c'),r=column(index)+row.get('r'),t='inlineStr')
        if styles[index-1] is not None:c.set('s',styles[index-1])
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]','',str(value))
    for row in list(body)[1:]:body.remove(row)
    last=max(501,len(roster)+1)
    for index in range(2,last+1):
        row=ET.SubElement(body,q('row'),r=str(index),ht='23',customHeight='1')
        pupil=roster[index-2] if index-2<len(roster) else None
        values=(['0',pupil['uid'],pupil['first'],pupil['middle'],pupil['last'],pupil['grade'],'','','','نعم','']
                if pupil else ['']*len(HEADERS))
        for j,value in enumerate(values,1):cell(row,j,value)
    dimension=sheet.find('m:dimension',NS)
    if dimension is None:
        dimension=ET.Element(q('dimension'));sheet.insert(1 if sheet.find('m:sheetPr',NS) is not None else 0,dimension)
    dimension.set('ref',f'A1:K{last}')
    for dv in sheet.findall('m:dataValidations/m:dataValidation',NS):
        dv.set('sqref',re.sub(r'501\b',str(last),dv.get('sqref','')))
    parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
    for name in parts:
        if name.startswith('xl/tables/') and name.endswith('.xml'):
            node=ET.fromstring(parts[name]);node.set('ref',f'A1:K{last}')
            auto=node.find('m:autoFilter',NS)
            if auto is not None:auto.set('ref',f'A1:K{last}')
            parts[name]=ET.tostring(node,encoding='utf-8',xml_declaration=True)
    marker=ET.fromstring(parts['xl/worksheets/sheet2.xml'])
    c=marker.find('.//m:c[@r="B2"]',NS)
    if c is None:
        row=marker.find('.//m:row[@r="2"]',NS)
        c=ET.SubElement(row,q('c'),r='B2')
    for child in list(c):c.remove(child)
    c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=account_key(username)
    parts['xl/worksheets/sheet2.xml']=ET.tostring(marker,encoding='utf-8',xml_declaration=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.xlsx',delete=False) as f:temporary=Path(f.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as archive:
            for name,data in parts.items():archive.writestr(name,data)
        os.replace(temporary,path)
    finally:
        if temporary:temporary.unlink(missing_ok=True)


def read_attendance(path):
    try:
        if Path(path).stat().st_size>64_000_000:raise ValueError('size')
        with zipfile.ZipFile(path) as archive:
            if len(archive.infolist())>1000 or sum(i.file_size for i in archive.infolist())>128_000_000:raise ValueError('size')
            rows=workbook_rows(archive,SHEET);marker=workbook_rows(archive,MARKER)
        if len(marker)<2 or marker[0][1].get('B')!='Sayed tech | حضور الطلاب' or marker[1][2]:raise ValueError('context')
        account=marker[1][1].get('B','')
        headers=rows[0][1]
        if rows[0][2] or len(set(headers.values()))!=len(headers) or not set(HEADERS).issubset(headers.values()):raise ValueError('headers')
        columns={label:letter for letter,label in headers.items()};result=[]
        for number,values,formulas in rows[1:]:
            if columns[HEADERS[0]] in formulas:raise ExcelInputError(f'الصف {number}: الاختيار يجب أن يكون قيمة ثابتة.')
            if not selection_value(values.get(columns[HEADERS[0]],'')):continue
            if formulas&{columns[h] for h in HEADERS}:raise ExcelInputError(f'الصف {number}: استخدم قيماً ثابتة في خانات الحضور.')
            raw=dict(zip(('uid','first','middle','last','grade','start','end','reason','skip','notes'),
                         [values.get(columns[h],'') for h in HEADERS[1:]]),account=account)
            try:record=validate_absence(raw)
            except AttendanceError:raise ExcelInputError(f'الصف {number}: راجع هوية الطالب والتاريخ MM/DD/YYYY والسبب والملاحظات.') from None
            record['excel_row']=number;result.append(record)
        if not result:raise ExcelInputError('ضع 1 أو نعم في أول عمود للغيابات المطلوبة، ثم احفظ Excel.')
        return result
    except ExcelInputError:raise
    except Exception:raise ExcelInputError('اختر نموذج الحضور المستخرج من البرنامج بعد تعبئته.') from None
