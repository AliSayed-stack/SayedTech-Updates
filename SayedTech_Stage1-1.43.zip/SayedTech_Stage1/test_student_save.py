"""No site access or real records: explicit Save and question-confirmation DOM."""
import threading
import unittest
from unittest.mock import patch

from student_save import fill_and_save_student,FORM_STATE,WATCH_SUCCESS,READ_SUCCESS,STOP_SUCCESS
from student_fill import StudentFillError
from student_excel import FIELDS
from test_students import Page as DraftPage,record
from test_scan import Clock


class Node:
    def __init__(self,page,kind):self.page,self.kind=page,kind
    def all(self):
        if self.kind=='dialog':
            if not self.page.open:return []
            if self.page.delay:
                self.page.delay-=1;return []
        return [self]
    def is_visible(self):return True
    def is_enabled(self):return not self.page.disabled
    def get_attribute(self,name):return 'swal2-popup swal2-modal '+self.page.icon
    def locator(self,selector):
        if selector=='#swal2-title':return Node(self.page,'title')
        if selector=='#swal2-html-container':return Node(self.page,'message')
        raise AssertionError(selector)
    def inner_text(self):return self.page.title if self.kind=='title' else self.page.message
    def get_by_role(self,role,name,exact):
        if (role,name,exact)==('button','تأكيد',True):return Node(self.page,'confirm')
        raise AssertionError('Unexpected submission/review action')
    def click(self,**_):
        self.page.actions.append(('click',self.kind))
        if self.kind=='save':
            self.page.open=True
            if self.page.mutate:self.page.values['field-firstName']='CHANGED'
            if self.page.cancel_after_save:self.page.cancelled.set()
            if self.page.save_timeout:raise RuntimeError('TEST TIMEOUT')
        elif self.kind=='confirm':
            if self.page.confirm_timeout:raise RuntimeError('TEST TIMEOUT')
            self.page.open=False
        else:raise AssertionError('Unexpected mutation')


class Page(DraftPage):
    def __init__(self,account='test@te.mehe.school'):
        super().__init__(account)
        self.open=False;self.disabled=False;self.delay=0;self.mutate=False
        self.save_timeout=False;self.confirm_timeout=False;self.cancel_after_save=False
        self.cancelled=threading.Event();self.valid=True
        self.title='هل أنت متأكد؟';self.message='هل تريد المتابعة؟';self.icon='swal2-icon-question'
        self.email_visible=True
        self.success_toast=True;self.watching=False;self.return_failed=False
    def get_by_text(self,pattern):
        if not self.email_visible:return type('Empty',(),{'all':lambda _:[]})()
        return super().get_by_text(pattern)
    def locator(self,selector):
        if selector=='.swal2-popup[role="dialog"]':return Node(self,'dialog')
        return super().locator(selector)
    def get_by_role(self,role,name,exact=False):
        if (role,name,exact)==('button','حفظ القسم',True):return Node(self,'save')
        return super().get_by_role(role,name,exact)
    def goto(self,url,**kwargs):
        self.actions.append(('goto',url))
        if self.return_failed:raise RuntimeError('TEST RETURN FAILURE')
        self.url=url
    def evaluate(self,script,arg=None):
        if script==WATCH_SUCCESS:self.watching=True;return
        if script==READ_SUCCESS:return self.watching and self.success_toast and ('click','confirm') in self.actions
        if script==STOP_SUCCESS:self.watching=False;return
        if script!=FORM_STATE:raise AssertionError(script)
        state=[]
        for f in FIELDS:
            raw=self.values.get(f['id'],'')
            value=raw
            if f['type']=='select':value=next((label for key,label in self.options[f['id']] if key==raw),'') if raw else ''
            state.append({'id':f['id'],'value':value,'raw':raw,'required':f['required'],'valid':self.valid})
        return state


class SaveTests(unittest.TestCase):
    def test_missing_success_never_returns_or_retries_and_return_failure_is_saved(self):
        page=Page();page.success_toast=False
        with patch.object(page,'wait_for_timeout'),self.assertRaises(StudentFillError) as caught:
            self.run_save(page)
        self.assertEqual(caught.exception.code,'student_save_unverified')
        self.assertEqual(page.actions.count(('click','confirm')),1)
        self.assertFalse(any(a[0]=='goto' for a in page.actions))
        self.assertFalse(page.watching)
        page=Page();page.return_failed=True
        with patch.object(page,'wait_for_timeout'),self.assertRaises(StudentFillError) as caught:
            self.run_save(page)
        self.assertEqual(caught.exception.code,'student_saved_return_failed')
        self.assertEqual(page.actions.count(('click','confirm')),1)
        self.assertFalse(page.watching)

    def test_unemployed_parents_allow_blank_disabled_occupation_without_bypassing_site_validity(self):
        for parent in ('father','mother'):
            page=Page();data=record();occupation='field-'+parent+'Occupation'
            data['field-'+parent+'Sector']='عاطل عن العمل';data[occupation]=''
            original_locator=page.locator
            def locator(selector):
                element=original_locator(selector)
                if selector=='#'+occupation:
                    element.is_enabled=lambda:False
                return element
            page.locator=locator
            with patch('student_save.time.monotonic',Clock()):
                result=fill_and_save_student(page,data,page.account,page.cancelled)
            self.assertEqual(result,'student_saved')
            self.assertFalse(any(a[:2]==('fill',occupation) for a in page.actions))
            self.assertEqual([a for a in page.actions if a[0]=='click' and a[1] in ('save','confirm')],[('click','save'),('click','confirm')])
        page=Page();data=record();data['field-fatherSector']='عاطل عن العمل';data['field-fatherOccupation']=''
        page.valid=False
        with self.assertRaises(StudentFillError) as error:
            fill_and_save_student(page,data,page.account,page.cancelled)
        self.assertEqual(error.exception.code,'student_save_blocked')
        self.assertFalse(any(a[0]=='click' and a[1] in ('save','confirm') for a in page.actions))

    def test_reformatted_dates_save_once_but_changed_calendar_date_stops(self):
        for key in ('field-birthDate','field-enrollment-registration-date'):
            for domain in ('te.mehe.school','te.pm.mehe.school'):
                page=Page('test@'+domain);evaluate=page.evaluate
                def formatted(script,arg=None):
                    state=evaluate(script,arg)
                    if script==FORM_STATE:
                        for f in state:
                            if f['id']==key:
                                f['value']=f['value'].replace('-','/')
                                f['raw']=f['raw'].replace('-','/')
                    return state
                page.evaluate=formatted
                self.assertEqual(self.run_save(page),'student_saved')
                self.assertEqual(page.actions.count(('click','save')),1)
                self.assertEqual(page.actions.count(('click','confirm')),1)
                self.assertEqual(page.values[key],record()[key])
        for value in ('2014/01/02','invalid','2099/01/02'):
            page=Page();evaluate=page.evaluate
            def wrong(script,arg=None):
                state=evaluate(script,arg)
                if script==FORM_STATE:
                    for f in state:
                        if f['id']=='field-birthDate':f.update(value=value,raw=value)
                return state
            page.evaluate=wrong
            with self.assertRaises(StudentFillError) as error:self.run_save(page)
            self.assertEqual(error.exception.code,'student_save_blocked')
            self.assertNotIn(('click','save'),page.actions)

    def run_save(self,page,session=None):
        with patch('student_save.time.monotonic',Clock()):
            return fill_and_save_student(page,record(),page.account,page.cancelled,account_session=session)

    def test_both_domains_save_and_confirm_once_without_claiming_server_success(self):
        for domain in ('te.mehe.school','te.pm.mehe.school'):
            with self.subTest(domain=domain):
                page=Page('test@'+domain);page.delay=2
                self.assertEqual(self.run_save(page),'student_saved')
                self.assertEqual([a for a in page.actions if a[0]=='click' and a[1] in ('save','confirm')],[('click','save'),('click','confirm')])

    def test_preexisting_modal_or_invalid_required_fields_never_request_save(self):
        for setting in ('open','disabled','valid'):
            page=Page();setattr(page,setting,False if setting=='valid' else True)
            with self.subTest(setting=setting),self.assertRaises(StudentFillError) as cm:self.run_save(page)
            self.assertEqual(cm.exception.code,'student_save_blocked')
            self.assertFalse(any(a[0]=='click' and a[1] in ('save','confirm') for a in page.actions))

    def test_wrong_question_changed_form_or_cancellation_never_confirms(self):
        for setting,value in (('title','OTHER'),('message','OTHER'),('icon','swal2-icon-warning'),('mutate',True),('cancel_after_save',True)):
            page=Page();setattr(page,setting,value)
            with self.subTest(setting=setting),self.assertRaises(StudentFillError) as cm:self.run_save(page)
            self.assertEqual(cm.exception.code,'student_save_unverified')
            self.assertEqual([a for a in page.actions if a[0]=='click' and a[1] in ('save','confirm')],[('click','save')])

    def test_click_timeout_never_retries_save_or_confirmation(self):
        for setting in ('save_timeout','confirm_timeout'):
            page=Page();setattr(page,setting,True)
            with self.subTest(setting=setting),self.assertRaises(StudentFillError) as cm:self.run_save(page)
            self.assertEqual(cm.exception.code,'student_save_unverified')
            self.assertEqual(page.actions.count(('click','save')),1)
            self.assertEqual(page.actions.count(('click','confirm')),int(setting=='confirm_timeout'))

    def test_bound_account_caption_supported_and_other_account_rejected(self):
        page=Page();page.email_visible=False
        class Session:
            revoked=False
            def allows(self,current,username):return current is page and username==page.account
        self.assertEqual(self.run_save(page,Session()),'student_saved')
        page=Page();page.email_visible=False
        with self.assertRaises(StudentFillError) as cm:self.run_save(page)
        self.assertEqual(cm.exception.code,'student_account_required')
        self.assertEqual(page.actions,[])


if __name__=='__main__':unittest.main()
