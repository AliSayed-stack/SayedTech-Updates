"""Create the versioned source ZIP consumed by the existing updater workflow."""
import ast
from pathlib import Path
import re
import zipfile

ROOT=Path(__file__).resolve().parents[1]
DOCS={'README.md','README_AR.md','README_PORTABLE_AR.txt','UPDATE_GUIDE_AR.md',
      'CHANGELOG_AR.md','DEVELOPMENT.md','WORKSPACE_STATE.md','AGENTS.md',
      'ADD_STUDENT_AR.txt','.gitignore','requirements.txt','requirements-dev.txt','installer.iss'}
ASSET_SUFFIXES={'.xlsx','.json','.svg','.txt','.exe','.dll'}
FIXTURE_SUFFIXES={'.html','.js'}


def source_files():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():continue
        relative=path.relative_to(ROOT)
        if len(relative.parts)==1 and (path.suffix in ('.py','.bat') or path.name in DOCS):yield path
        elif relative.parts[0]=='assets' and path.suffix in ASSET_SUFFIXES:yield path
        elif relative.parts[0]=='test_fixtures' and path.suffix in FIXTURE_SUFFIXES:yield path
        elif relative.parts[0]=='tools' and path.suffix in ('.py','.mjs') and '__pycache__' not in relative.parts:yield path


def main():
    version=re.search(r"^APP_VERSION\s*=\s*['\"]([0-9]+(?:\.[0-9]+){1,2})['\"]",(ROOT/'core.py').read_text(encoding='utf-8'),re.M).group(1)
    output=ROOT.parent/f'SayedTech_Stage1-{version}.zip'
    temporary=output.with_suffix('.zip.tmp')
    files=list(source_files())
    for path in files:
        if path.suffix=='.py':ast.parse(path.read_bytes(),filename=str(path.relative_to(ROOT)))
    try:
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as archive:
            for path in files:archive.write(path,'SayedTech_Stage1/'+path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip():raise RuntimeError('Source archive validation failed')
        temporary.replace(output)
    finally:temporary.unlink(missing_ok=True)
    print(output)
    print(f'Version {version}; {len(files)} source files')


if __name__=='__main__':main()
