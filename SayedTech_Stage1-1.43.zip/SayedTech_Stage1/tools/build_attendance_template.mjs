import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const output=process.argv[2];
const contract=JSON.parse(await fs.readFile(process.argv[3],'utf8'));
const wb=Workbook.create(),sheet=wb.worksheets.add('الحضور');
sheet.getRange('A1:K1').values=[contract.headers];
sheet.getRange('A1:K501').format.font={name:'Arial',size:11,bold:false};
sheet.getRange('A1:K501').format.columnWidth=23;
sheet.getRange('A1:K501').format.rowHeight=23;
sheet.getRange('A1:K1').format={fill:'#18324F',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},wrapText:true,verticalAlignment:'center',rowHeight:48};
sheet.getRange('A2:K2').values=[Array(11).fill('')];
sheet.getRange('A2:F501').setNumberFormat('@');
sheet.getRange('G2:H501').setNumberFormat('mm/dd/yyyy');
sheet.getRange('I2:K501').setNumberFormat('@');
for(const [col,width] of [['A',24],['G',18],['H',18],['I',38],['J',24],['K',33]])sheet.getRange(`${col}:${col}`).format.columnWidth=width;
sheet.tables.add('A1:K501',true,'StudentAttendance');
sheet.freezePanes.freezeRows(1);sheet.showGridLines=false;
const meta=wb.worksheets.add('سياق الحضور');
meta.getRange('A1:B6').values=[['نوع الملف','Sayed tech | حضور الطلاب'],['سياق المدرسة',''],
 ['اختيار الغياب','ضع 1 في أول عمود للطلاب المطلوب تسجيل غيابهم فقط.'],
 ['التواريخ','MM/DD/YYYY أو تاريخ Excel. إلى تاريخ اختياري.'],
 ['العطلة الأسبوعية','نعم: يتبع البرنامج تقويم المدرسة الموجود في الموقع.'],
 ['المصدر','تُستخرج هوية الطلاب من إدارة المدرسة؛ لا تغيّر الأسماء أو الرقم الموحّد.']];
meta.getRange('A1:B6').format.font={name:'Arial',size:11};
meta.getRange('A:A').format.columnWidth=24;meta.getRange('B:B').format.columnWidth=75;
meta.getRange('A1:B6').format.wrapText=true;meta.getRange('A1:B6').format.rowHeight=36;
const reasons=wb.worksheets.add('أسباب الغياب');
reasons.getRange('A1:B1').values=[['الرمز','سبب الغياب']];
reasons.getRange('A2:B23').values=contract.reasons;
reasons.getRange('A1:B23').format.font={name:'Arial',size:11};
reasons.getRange('A:A').format.columnWidth=48;reasons.getRange('B:B').format.columnWidth=70;
reasons.getRange('A1:B23').format.rowHeight=28;reasons.getRange('B1:B23').format.wrapText=true;
sheet.getRange('A2:A501').dataValidation={rule:{type:'list',values:['0','1']}};
sheet.getRange('J2:J501').dataValidation={rule:{type:'list',values:['نعم','لا']}};
sheet.getRange('I2:I501').dataValidation={rule:{type:'list',formula1:`INDIRECT("'أسباب الغياب'!$B$2:$B$23")`}};
wb.recalculate();
await (await SpreadsheetFile.exportXlsx(wb)).save(output);
const image=await wb.render({sheetName:'الحضور',range:'A1:K5',scale:1.5,format:'png'});
await fs.writeFile(output+'.png',new Uint8Array(await image.arrayBuffer()));
console.log('Attendance template saved');
