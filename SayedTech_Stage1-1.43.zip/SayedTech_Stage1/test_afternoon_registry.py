import tempfile
import unittest
from unittest.mock import patch
from student_excel import validate_record, read_students
from test_students import record
from test_student_unified import UnifiedTests, edit
from student_unified import SELECTION
from test_student_save import Page
from student_save import fill_and_save_student
from student_fill import StudentFillError

KEY='field-registryNumber'
PLACE='field-registryPlace'


class AfternoonRegistryTests(unittest.TestCase):
    def test_afternoon_optional_preserves_valid_text_without_altering_source(self):
        for value, expected in (('', ''), ('000123456','000123456'),('123-AB456789',''),(123456,'')):
            raw=record();raw[KEY]=value
            cleaned,errors=validate_record(raw,'afternoon')
            self.assertEqual(errors,[]);self.assertEqual(cleaned[KEY],expected)
            self.assertEqual(raw[KEY],value)
        for value in ('','123-AB456789'):
            raw=record();raw[KEY]=value
            self.assertTrue(validate_record(raw,'morning')[1])

    def test_existing_workbook_import_warns_without_rewriting_excel(self):
        with tempfile.TemporaryDirectory() as folder:
            path=UnifiedTests().make(folder)
            edit(path,{SELECTION:'1','رقم السجل':'123-AB456789','مكان القيد':''})
            before=path.read_bytes()
            row=read_students(path,shift='afternoon')[0]
            self.assertEqual(row['errors'],[])
            self.assertEqual(row['values'][KEY],'')
            self.assertEqual(row['values'][PLACE],'')
            self.assertEqual(len(row['warnings']),1)
            self.assertTrue(read_students(path,shift='morning')[0]['errors'])
            self.assertEqual(path.read_bytes(),before)

    def test_place_optional_preserves_valid_text_without_altering_source(self):
        for value,expected in (('', ''), ('دار كبير','دار كبير'), ('أ'*256,'أ'*256), ('أ'*257,''), (123,''), ('بلدة\nأخرى','')):
            with self.subTest(value=value):
                raw=record();raw[PLACE]=value
                cleaned,errors=validate_record(raw,'afternoon')
                self.assertEqual(errors,[])
                self.assertEqual(cleaned[PLACE],expected)
                self.assertEqual(raw[PLACE],value)
        raw=record();raw[PLACE]=''
        self.assertIn('مكان القيد: مطلوب',validate_record(raw,'morning')[1])
        del raw[PLACE]
        self.assertEqual(validate_record(raw,'afternoon')[1],[])

    def test_save_uses_account_shift_and_respects_native_required(self):
        username='test@te.pm.mehe.school'
        data=record();data[KEY]='123-AB456789';data[PLACE]=''
        page=Page(username)
        evaluate=page.evaluate
        def optional(script,arg=None):
            state=evaluate(script,arg)
            if not isinstance(state,list):return state
            for f in state:
                if f['id'] in (KEY,PLACE):f['required']=False
            return state
        with patch.object(page,'evaluate',optional):
            self.assertEqual(fill_and_save_student(page,data,username,page.cancelled),'student_saved')
        self.assertEqual(page.values[KEY],'')
        self.assertEqual(page.values[PLACE],'')
        page=Page(username)
        evaluate=page.evaluate
        def place_required(script,arg=None):
            state=evaluate(script,arg)
            if not isinstance(state,list):return state
            for f in state:
                if f['id']==KEY:f['required']=False
            return state
        with patch.object(page,'evaluate',place_required), self.assertRaises(StudentFillError) as exc:
            fill_and_save_student(page,data,username,page.cancelled)
        self.assertEqual(exc.exception.code,'student_save_blocked')
        self.assertNotIn(('click','save'),page.actions)


if __name__=='__main__':unittest.main()
