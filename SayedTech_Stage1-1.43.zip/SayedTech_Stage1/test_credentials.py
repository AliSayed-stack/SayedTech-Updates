"""Synthetic CredMan ABI/storage boundaries, no real Windows vault or secrets."""
import ctypes
import unittest
from credential_store import CredentialStore,CredentialError,CREDENTIALW,GENERIC,LOCAL_MACHINE,NOT_FOUND,MAX_BLOB


class Native:
    def __init__(self):
        self.entries={};self.last_error=0;self.freed=0;self.buffer=None;self.struct=None
        self.write_buffer=None;self.write_size=0;self.fail_write=False;self.fail_delete=False
    def CredWriteW(self,pointer,flags):
        value=ctypes.cast(pointer,ctypes.POINTER(CREDENTIALW)).contents
        assert value.Type==GENERIC and value.Persist==LOCAL_MACHINE and flags==0
        assert value.AttributeCount==0 and not value.Attributes
        self.write_buffer=value.CredentialBlob;self.write_size=value.CredentialBlobSize
        if self.fail_write:self.last_error=5;return False
        self.entries[value.TargetName]=(value.UserName,ctypes.string_at(value.CredentialBlob,value.CredentialBlobSize))
        return True
    def CredReadW(self,key,kind,flags,out):
        assert kind==GENERIC and flags==0
        if key not in self.entries:self.last_error=NOT_FOUND;return False
        username,blob=self.entries[key]
        self.buffer=ctypes.create_string_buffer(blob)
        self.struct=CREDENTIALW();self.struct.Type=GENERIC;self.struct.TargetName=key;self.struct.UserName=username
        self.struct.CredentialBlobSize=len(blob);self.struct.CredentialBlob=ctypes.cast(self.buffer,ctypes.POINTER(ctypes.c_ubyte))
        ctypes.cast(out,ctypes.POINTER(ctypes.POINTER(CREDENTIALW)))[0]=ctypes.pointer(self.struct)
        return True
    def CredDeleteW(self,key,kind,flags):
        assert kind==GENERIC and flags==0
        if self.fail_delete:self.last_error=5;return False
        if key not in self.entries:self.last_error=NOT_FOUND;return False
        del self.entries[key];return True
    def CredFree(self,pointer):
        self.freed+=1
        ctypes.memset(self.buffer,0,ctypes.sizeof(self.buffer))


class CredentialTests(unittest.TestCase):
    def test_save_load_replace_delete_and_shift_isolation(self):
        native=Native();store=CredentialStore(native)
        self.assertIsNone(store.load('morning'))
        store.save('morning',' Person@te.mehe.school ','TEST_ONLY_عربي_🔑')
        saved=store.load('morning')
        self.assertEqual(saved,{'username':'person@te.mehe.school','password':'TEST_ONLY_عربي_🔑'})
        self.assertEqual(native.freed,1)
        self.assertIsNone(store.load('afternoon'))
        store.save('afternoon','person@te.pm.mehe.school','TEST_ONLY_PM')
        store.save('morning','other@te.mehe.school','TEST_ONLY_CHANGED')
        self.assertEqual(store.load('morning')['username'],'other@te.mehe.school')
        store.delete('morning');store.delete('morning')
        self.assertIsNone(store.load('morning'))
        self.assertEqual(store.load('afternoon')['password'],'TEST_ONLY_PM')
        self.assertTrue(all(key.startswith('SayedTech/SIMS/') for key in native.entries))

    def test_invalid_domain_shift_and_large_secret_never_write(self):
        native=Native();store=CredentialStore(native)
        for shift,username,password in [('morning','p@te.pm.mehe.school','TEST_ONLY'),
            ('afternoon','p@te.mehe.school','TEST_ONLY'),('bad','p@te.mehe.school','TEST_ONLY'),
            ('morning','p@te.mehe.school','🔑'*1024)]:
            with self.assertRaises(CredentialError):store.save(shift,username,password)
        self.assertEqual(native.entries,{})

    def test_corrupt_or_wrong_domain_blob_is_freed_and_not_returned(self):
        native=Native();store=CredentialStore(native)
        for username,blob in [('p@te.pm.mehe.school',b'T\x00'),('p@te.mehe.school',b'\xff'),
                              ('p@te.mehe.school',b'x'*(MAX_BLOB+1))]:
            native.entries['SayedTech/SIMS/morning']=(username,blob)
            before=native.freed
            with self.assertRaises(CredentialError):store.load('morning')
            self.assertEqual(native.freed,before+1)

    def test_native_failure_is_fixed_text_and_no_plaintext_fallback(self):
        native=Native();native.fail_write=True;store=CredentialStore(native)
        with self.assertRaises(CredentialError) as cm:store.save('morning','p@te.mehe.school','TEST_ONLY_SECRET')
        self.assertNotIn('TEST_ONLY_SECRET',str(cm.exception));self.assertEqual(native.entries,{})
        native.fail_delete=True
        with self.assertRaises(CredentialError):store.delete('morning')
        store.available=False
        with self.assertRaises(CredentialError):store.save('morning','p@te.mehe.school','TEST_ONLY')


if __name__=='__main__':unittest.main()
