import unittest
from unittest.mock import patch
from student_detailed import prepared_rows, PREP_HEADERS
from student_excel import ExcelInputError
from nsldb_reference import DETAILED_HEADERS


class DetailedTests(unittest.TestCase):
    def fixture(self):
        student = dict.fromkeys(DETAILED_HEADERS, '')
        student.update({'السنة في القاعدة':'20252026', 'معرّف المدرسة في القاعدة':'0007',
                        'معرّف الشخص في القاعدة':'123', 'رقم الهاتف (LivingPhone)':'03123456'})
        registration = {'TermID':'20252026','MEHEID':'0007','GPersonID':'123',
                        'LivingRegionID':'1','LivingCasaID':'2','LivingAreaID':'3'}
        lookups = [{'جدول المصدر':table,'المعرّف (ID)':code,'الاسم':name}
                   for table,code,name in [('Regions','1','محافظة اختبار'),('Casa','2','قضاء اختبار'),('Area','3','بلدة اختبار')]]
        return {'الطلاب':[student], 'تسجيلات القاعدة':[registration], 'قوائم القاعدة':lookups}

    def run_fixture(self, data):
        with patch('student_detailed.read_table', side_effect=lambda z,n:data[n]):
            return prepared_rows(None)

    def test_resolved_addresses_original_phone_no_invented_street(self):
        rows = self.run_fixture(self.fixture())
        row = dict(zip(PREP_HEADERS, rows[0]))
        self.assertEqual(row['محافظة السكن'],'محافظة اختبار')
        self.assertEqual(row['قضاء السكن'],'قضاء اختبار')
        self.assertEqual(row['منطقة / بلدة السكن'],'بلدة اختبار')
        self.assertEqual(row['رقم الهاتف (LivingPhone)'],'03123456')
        self.assertEqual(row['نوع الهاتف'],'خلوي')
        self.assertEqual(row['اختيار للاستكمال لاحقاً'],'0')
        self.assertEqual(row['الشارع'],'')
        self.assertEqual(row['بلد السكن'],'لبنان')

    def test_missing_lookup_requests_rescan(self):
        data = self.fixture(); data['قوائم القاعدة'][1]['الاسم']=''
        with self.assertRaisesRegex(ExcelInputError,'أعد'):self.run_fixture(data)

    def test_other_year_and_missing_uid_duplicates_preserved(self):
        data = self.fixture(); student = data['الطلاب'][0]
        data['الطلاب'] += [student.copy(), dict(student, **{'السنة في القاعدة':'20242025'})]
        self.assertEqual(len(self.run_fixture(data)),2)

    def test_missing_address_does_not_invent_and_bad_phone_not_truncated(self):
        data=self.fixture();data['تسجيلات القاعدة'][0]['LivingAreaID']='0'
        data['الطلاب'][0]['رقم الهاتف (LivingPhone)']='009613123456'
        row=dict(zip(PREP_HEADERS,self.run_fixture(data)[0]))
        self.assertEqual(row['منطقة / بلدة السكن'],'')
        self.assertEqual(row['رقم الهاتف (LivingPhone)'],'009613123456')
        self.assertIn('ناقص',row['ملاحظات تجهيز العنوان'])
        self.assertIn('الهاتف',row['ملاحظات تجهيز العنوان'])

    def test_ambiguous_address_stops_before_wrong_assignment(self):
        data=self.fixture();data['تسجيلات القاعدة'].append(dict(data['تسجيلات القاعدة'][0],LivingAreaID='4'))
        with self.assertRaisesRegex(ExcelInputError,'مختلفة'):self.run_fixture(data)


if __name__=='__main__':unittest.main()
