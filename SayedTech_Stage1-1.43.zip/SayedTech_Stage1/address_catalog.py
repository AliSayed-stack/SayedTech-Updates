"""User-run collection of address lookup options, never student records or Save.

Run on the visible address tab of the user-selected student form. Selects
dependent controls, reads their options, then restores the original choices.
Does not click Add, Save, or navigate; never exports the selected student's data.
"""
import json
import os
from pathlib import Path
import re
import tempfile
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit

from login_flow import exact_https_host, SIMS_HOST, visible
from student_fill import MANAGEMENT

LABELS = {'country': 'البلد', 'governorate': 'المحافظة',
          'district': 'القضاء', 'area': 'المنطقة'}
EVENTS = frozenset({'catalog_progress', 'catalog_saved', 'catalog_cancelled',
                    'catalog_prepare', 'catalog_account_required',
                    'catalog_options_changed', 'catalog_failed', 'catalog_busy',
                    'catalog_restoring', 'catalog_restore_required', 'catalog_saved_partial',
                    'catalog_load_timeout', 'catalog_invalid_options'})
RETRYABLE = frozenset({'catalog_load_timeout', 'catalog_invalid_options'})
WAIT_SECONDS = 25
OPTION_SCRIPT = '''(select) => Array.from(select.options, option => ({
    value: option.value, label: option.textContent,
    disabled: option.disabled || (option.parentElement.tagName === 'OPTGROUP' && option.parentElement.disabled)
}))'''


def clean_detail(detail):
    """Only geographic lookup labels and bounded counters may cross the pipe."""
    if not isinstance(detail, dict): return {}
    result = {}
    for key in ('governorate', 'district'):
        value = detail.get(key)
        if isinstance(value, str) and len(value) <= 256:
            result[key] = value
    for key in ('areas', 'done', 'pending', 'attempt'):
        value = detail.get(key)
        if type(value) is int and 0 <= value <= 100000:
            result[key] = value
    if isinstance(detail.get('stage'), str) and detail['stage'] in {'districts', 'areas', 'read', 'retry', 'pending', 'province_done'}:
        result['stage'] = detail['stage']
    if isinstance(detail.get('reason'), str) and detail['reason'] in RETRYABLE:
        result['reason'] = detail['reason']
    return result


class CatalogError(Exception):
    def __init__(self, code, detail=None):
        self.code = code
        self.detail = clean_detail(detail)


def control(page, key, optional=False):
    # React-generated IDs change. Use the actual label/for association instead.
    pattern = re.compile(r'^\s*' + re.escape(LABELS[key]) + r'\s*\*?\s*$')
    matches = [item for item in page.get_by_label(pattern).all() if item.is_visible()]
    if optional and not matches:
        return None
    if len(matches) != 1 or matches[0].evaluate('(el) => el.tagName') != 'SELECT':
        raise CatalogError('catalog_prepare')
    return matches[0]


def raw_options(field):
    # One atomic DOM read avoids thousands of per-option browser round trips
    # for large area/country lists. Only SELECT option metadata is read.
    rows = field.evaluate(OPTION_SCRIPT)
    if not isinstance(rows, list) or len(rows) > 10001:
        raise CatalogError('catalog_invalid_options')
    return rows


def options(page, key):
    field = control(page, key, optional=True)
    if field is None or not field.is_enabled():
        return None
    result = []
    for item in raw_options(field):
        if not isinstance(item, dict) or not isinstance(item.get('value'), str):
            raise CatalogError('catalog_invalid_options')
        value = item['value']
        if not value or item.get('disabled'):
            continue
        name = item.get('label')
        if not isinstance(name, str) or not name.strip() or len(name.strip()) > 256 or len(value) > 128:
            raise CatalogError('catalog_invalid_options')
        name = name.strip()
        result.append((value, name))
    # Identical labels with different source IDs are valid lookup entries.
    # Keep both; never guess which one by label or invent a different name.
    if len({v for v, _ in result}) != len(result):
        raise CatalogError('catalog_invalid_options')
    return tuple(result)


def guard_page(page, username, original_url=None):
    if not exact_https_host(page.url, SIMS_HOST):
        raise CatalogError('catalog_account_required')
    path = urlsplit(page.url).path.rstrip('/')
    if not (path == MANAGEMENT or path.startswith(MANAGEMENT + '/')):
        raise CatalogError('catalog_prepare')
    # Bind collection AND restoration to the same record/tab URL. Do not copy
    # the URL or its record identifiers into the output file or status stream.
    if original_url is not None and page.url != original_url:
        raise CatalogError('catalog_options_changed')
    account = visible(page.get_by_text(re.compile(r'^\s*' + re.escape(username) + r'\s*$', re.I)))
    if account is None:
        raise CatalogError('catalog_account_required')
    tabs = [t for t in page.get_by_role('tab', name='عناوين السكن', exact=True).all() if t.is_visible()]
    if len(tabs) != 1 or tabs[0].get_attribute('aria-selected') != 'true':
        raise CatalogError('catalog_prepare')


def restore_choices(page, username, original_url, original):
    """Restore only geographic selects, even after an operation cancellation.

    Never restore into a different record or account. Await the original
    parent's exact option set before touching each dependent select.
    """
    for key, saved in original.items():
        end = time.monotonic() + 10
        since = None
        while time.monotonic() < end:
            guard_page(page, username, original_url)
            field = control(page, key, optional=True)
            ready = ((field is None or field.input_value() == '') if saved is None else
                     (field is not None and options(page, key) == saved['options']
                      and (field.is_enabled() or field.input_value() == saved['value'])))
            if ready:
                if since is None: since = time.monotonic()
                if time.monotonic() - since >= .7: break
            else:
                since = None
            page.wait_for_timeout(100)
        else:
            raise CatalogError('catalog_restore_required')
        if saved is not None and field.input_value() != saved['value']:
            guard_page(page, username, original_url)
            field.select_option(value=saved['value'], timeout=3000)
    # Parent changes may reset children asynchronously; verify a stable final
    # snapshot instead of claiming restoration immediately after select_option.
    end, since = time.monotonic() + 10, None
    while time.monotonic() < end:
        guard_page(page, username, original_url)
        match = True
        for key, saved in original.items():
            field = control(page, key, optional=True)
            if saved is None:
                match = match and (field is None or field.input_value() == '')
            else:
                match = match and (field is not None and field.input_value() == saved['value']
                                   and options(page, key) == saved['options'])
        if match:
            if since is None: since = time.monotonic()
            if time.monotonic() - since >= .7: return
        else:
            since = None
        page.wait_for_timeout(100)
    raise CatalogError('catalog_restore_required')


def collect_catalog(page, username, cancelled, progress=lambda *_: None, restoring=lambda: None):
    guard_page(page, username)
    original_url = page.url
    original = {}
    for key in LABELS:
        field = control(page, key, optional=key != 'country')
        original[key] = None if field is None else {'value': field.input_value(), 'options': options(page, key)}
    state = {'changed': False}
    context = {}
    try:
        return _collect_catalog(page, username, cancelled, progress, original_url, state, context)
    except CatalogError as exc:
        if not exc.detail: exc.detail = clean_detail(context)
        raise
    finally:
        try:
            if state['changed']:
                restoring()
                restore_choices(page, username, original_url, original)
        except Exception as exc:
            # Never claim an ordinary success/failure while leaving changed
            # selections without an explicit instruction to discard the form.
            raise CatalogError('catalog_restore_required', context) from exc
        finally:
            original.clear()


def _collect_catalog(page, username, cancelled, progress, original_url, state, context):
    """Collect each parent's options. Explicitly mark unresolved parents."""
    expected = {}
    deadline = time.monotonic() + 1200
    position = [0, 0]
    done = 0

    def report(stage, **values):
        context.update(values, stage=stage, done=done)
        progress(*position, clean_detail(context))

    def guard():
        if cancelled.is_set():
            raise CatalogError('catalog_cancelled')
        if time.monotonic() > deadline:
            raise CatalogError('catalog_options_changed')
        guard_page(page, username, original_url)
        for key, value in expected.items():
            if control(page, key).input_value() != value:
                raise CatalogError('catalog_options_changed')

    def settled(key, previous=None, require_change=False):
        # Do not accept the previous parent's stale children. Wait for a new,
        # nonempty, enabled option set which remains stable for 700 ms.
        end = time.monotonic() + WAIT_SECONDS
        stable, since = None, time.monotonic()
        while time.monotonic() < end:
            guard()
            current = options(page, key)
            if current != stable:
                stable, since = current, time.monotonic()
            if (current and (not require_change or current != previous)
                    and time.monotonic() - since >= .7):
                return current
            page.wait_for_timeout(100)
        raise CatalogError('catalog_load_timeout', context)

    def select(key, value, force=False):
        guard()
        field = control(page, key)
        changed = field.input_value() != value
        if changed or force:
            # Changing a parent may reset its child controls immediately.
            order = list(LABELS)
            for child in order[order.index(key):]:
                expected.pop(child, None)
            state['changed'] = True
            field.select_option(value=value, timeout=3000)
        expected[key] = value
        guard()
        return changed

    def before_options(key):
        try: return options(page, key)
        except CatalogError as exc:
            if exc.code in RETRYABLE: return None
            raise

    def read_children(parent, parent_id, child):
        for attempt in (1, 2):
            guard()
            previous = before_options(child)
            if attempt == 2:
                report('retry', attempt=attempt)
                field = control(page, parent)
                blank = any(row.get('value') == '' and not row.get('disabled') for row in raw_options(field))
                if blank and field.input_value():
                    select(parent, '')
                    # Give controlled forms time to clear dependent options.
                    # A cleared/disabled list is evidence of refresh; a stale
                    # unchanged set alone is never accepted for a new parent.
                    until = time.monotonic() + 2
                    while time.monotonic() < until:
                        guard()
                        cleared = before_options(child)
                        if not cleared:
                            previous = cleared
                            break
                        page.wait_for_timeout(100)
            try:
                changed = select(parent, parent_id, force=attempt == 2)
                return settled(child, previous, changed or attempt == 2)
            except CatalogError as exc:
                if exc.code not in RETRYABLE: raise
                if attempt == 2: raise
        raise CatalogError('catalog_load_timeout', context)

    guard()
    countries = settled('country')
    matches = [(v, n) for v, n in countries if n == 'لبنان']
    if len(matches) != 1:
        raise CatalogError('catalog_prepare')
    old_governorates = options(page, 'governorate')
    country_changed = select('country', matches[0][0])
    governorates = settled('governorate', old_governorates, country_changed)
    result = {'format': 'sayedtech-address-catalog', 'version': 2,
              'collected_at': datetime.now(timezone.utc).isoformat(),
              'source': 'SIMS visible address dropdowns',
              'country': {'id': matches[0][0], 'name': matches[0][1]},
              'governorates': [], 'complete': True, 'pending': []}
    for index, (gov_id, gov_name) in enumerate(governorates, 1):
        position[:] = [index, len(governorates)]
        context.clear()
        report('districts', governorate=gov_name)
        guard()
        if options(page, 'governorate') != governorates:
            raise CatalogError('catalog_options_changed')
        gov = {'id': gov_id, 'name': gov_name, 'districts': [], 'status': 'complete'}
        result['governorates'].append(gov)
        try:
            districts = read_children('governorate', gov_id, 'district')
        except CatalogError as exc:
            if exc.code not in RETRYABLE: raise
            gov['status'] = 'pending'
            result['pending'].append({'level': 'governorate', 'governorate_id': gov_id,
                                      'governorate': gov_name, 'reason': exc.code})
            report('pending', reason=exc.code)
            continue
        for district_id, district_name in districts:
            report('areas', district=district_name, areas=0, attempt=1)
            guard()
            if options(page, 'district') != districts:
                raise CatalogError('catalog_options_changed')
            try:
                areas = read_children('district', district_id, 'area')
            except CatalogError as exc:
                if exc.code not in RETRYABLE: raise
                gov['status'] = 'partial'
                gov['districts'].append({'id': district_id, 'name': district_name, 'areas': [], 'status': 'pending'})
                result['pending'].append({'level': 'district', 'governorate_id': gov_id, 'governorate': gov_name,
                                          'district_id': district_id, 'district': district_name, 'reason': exc.code})
                report('pending', reason=exc.code)
                continue
            guard()
            gov['districts'].append({'id': district_id, 'name': district_name,
                                     'areas': [{'id': v, 'name': n} for v, n in areas], 'status': 'complete'})
            done += 1
            report('read', areas=len(areas))
        report('province_done')
    result['complete'] = not result['pending']
    guard()
    return result


def save_catalog(data, path, cancelled):
    """Atomic local export; a failed/cancelled run preserves any existing file."""
    destination = Path(path)
    if not destination.is_absolute() or destination.suffix.lower() != '.json':
        raise CatalogError('catalog_failed')
    temporary = None
    try:
        if cancelled.is_set():
            raise CatalogError('catalog_cancelled')
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=destination.parent, delete=False,
                                         prefix='.sayedtech-', suffix='.tmp') as stream:
            temporary = Path(stream.name)
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        if cancelled.is_set():
            raise CatalogError('catalog_cancelled')
        os.replace(temporary, destination)
    except OSError as exc:
        raise CatalogError('catalog_failed') from exc
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
