"""Offline lookup tests, including delayed dependent dropdowns; no network."""
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from address_catalog import collect_catalog, save_catalog, CatalogError, LABELS, options, clean_detail
from student_fill import NEW_STUDENT, MANAGEMENT

class Group:
    def __init__(self, items): self.items = items
    def all(self): return self.items

class Item:
    def __init__(self, page, key, option=None):
        self.page, self.key, self.option = page, key, option
    def all(self): return [self]
    def is_visible(self): return True
    def is_enabled(self): return True
    def is_disabled(self): return False
    def evaluate(self, expression):
        if 'Array.from(select.options' in expression:
            self.page.bulk_reads += 1
            return [{'value': v, 'label': n, 'disabled': False} for v, n in [('', '--اختيار--')] + self.page.options[self.key]]
        assert expression == '(el) => el.tagName'
        return 'SELECT'
    def get_attribute(self, name):
        if name == 'aria-selected': return 'true'
        assert name == 'value'
        return self.option[0]
    def inner_text(self): return self.option[1]
    def input_value(self): return self.page.selected[self.key]
    def locator(self, selector):
        raise AssertionError('Options must be read atomically, never individually')
    def select_option(self, value, **_):
        self.page.selected[self.key] = value
        self.page.actions.append((self.key, value))
        if self.page.redirect:
            self.page.url = 'https://other.example/form'
        if self.key in {'governorate', 'district'} and not self.page.stale:
            child = 'district' if self.key == 'governorate' else 'area'
            if self.key == 'governorate':
                self.page.options['area'] = []
                self.page.selected['area'] = ''
            choices = self.page.tree[self.key].get(value, [])
            self.page.attempts[value] = self.page.attempts.get(value, 0) + 1
            if value in self.page.fail_once and self.page.attempts[value] == 1:
                choices = []
            self.page.scheduled = (self.page.clock + self.page.delay, child, choices)

class Page:
    def __init__(self,account='test@te.mehe.school'):
        self.account=account
        self.url = 'https://new-sims.mehe.gov.lb' + NEW_STUDENT
        self.clock = 0
        self.bulk_reads = 0
        self.attempts, self.fail_once, self.delay = {}, set(), .5
        self.options = {'country': [('lb', 'لبنان')],
                        'governorate': [('g1', 'محافظة أولى'), ('g2', 'محافظة ثانية')],
                        'district': [], 'area': []}
        self.tree = {'governorate': {'g1': [('d1', 'قضاء أول'), ('d2', 'قضاء ثان')],
                                    'g2': [('d3', 'قضاء ثالث')]},
                     'district': {'d1': [('a1', 'منطقة مشتركة الاسم'), ('a2', 'بلدة ثانية')],
                                  'd2': [('a3', 'منطقة مشتركة الاسم')],
                                  'd3': [('a4', 'بلدة رابعة')]}}
        self.selected = {'country': 'lb', 'governorate': '', 'district': '', 'area': ''}
        self.actions, self.scheduled = [], None
        self.redirect = self.stale = self.ambiguous = False
        self.on_wait = lambda: None
    def get_by_label(self, pattern):
        for key, label in LABELS.items():
            if pattern.search(label + ' *'):
                return Group([Item(self, key)] * (2 if self.ambiguous and key == 'district' else 1))
        raise AssertionError('Unexpected form field')
    def get_by_text(self, pattern):
        return Group([Item(self, 'account')] if pattern.search(self.account) else [])
    def get_by_role(self, role, name, exact):
        # Any button access, including Add or Save, fails this test.
        assert (role, name, exact) == ('tab', 'عناوين السكن', True)
        return Group([Item(self, 'tab')])
    def wait_for_timeout(self, milliseconds):
        self.clock += milliseconds / 1000
        if self.scheduled and self.clock >= self.scheduled[0]:
            _, child, choices = self.scheduled
            self.options[child] = choices
            self.selected[child] = ''
            self.scheduled = None
        self.on_wait()

class CatalogTests(unittest.TestCase):
    def collect(self, page, cancelled=None, username='test@te.mehe.school', progress=lambda *_: None):
        with patch('address_catalog.time.monotonic', side_effect=lambda: page.clock):
            return collect_catalog(page, username, cancelled or threading.Event(), progress)

    def test_all_parent_links_wait_for_delayed_children(self):
        page = Page()
        updates = []
        data = self.collect(page, progress=lambda *args: updates.append(args))
        self.assertEqual(len(data['governorates']), 2)
        self.assertEqual([d['id'] for d in data['governorates'][0]['districts']], ['d1', 'd2'])
        self.assertEqual([a['id'] for a in data['governorates'][1]['districts'][0]['areas']], ['a4'])
        self.assertEqual(data['governorates'][0]['districts'][1]['areas'][0]['id'], 'a3')
        self.assertNotIn('test@', json.dumps(data))
        self.assertEqual({key for key, _ in page.actions}, {'governorate', 'district'})
        read = [detail for _, _, detail in updates if detail['stage'] == 'read']
        self.assertEqual([(d['district'], d['areas'], d['done']) for d in read],
                         [('قضاء أول', 2, 1), ('قضاء ثان', 1, 2), ('قضاء ثالث', 1, 3)])

    def registered_page(self):
        page = Page()
        page.url = 'https://new-sims.mehe.gov.lb' + MANAGEMENT + '/existing-id?tab=address&id=record-id'
        page.selected.update(governorate='g1', district='d2', area='a3')
        page.options['district'] = page.tree['governorate']['g1']
        page.options['area'] = page.tree['district']['d2']
        return page

    def test_registered_student_original_choices_are_restored_and_not_exported(self):
        page = self.registered_page()
        original = dict(page.selected)
        data = self.collect(page)
        self.assertEqual(page.selected, original)
        self.assertIn(('area', 'a3'), page.actions)
        self.assertNotIn('record-id', json.dumps(data))
        self.assertNotIn('existing-id', json.dumps(data))

    def test_unrelated_page_wrong_account_and_redirect_stop_mutations(self):
        page = Page(); page.url = 'https://new-sims.mehe.gov.lb/dashboard/employees'
        with self.assertRaises(CatalogError): self.collect(page)
        self.assertEqual(page.actions, [])
        page = Page()
        with self.assertRaises(CatalogError): self.collect(page, username='wrong@te.mehe.school')
        self.assertEqual(page.actions, [])
        page = Page(); page.redirect = True
        with self.assertRaises(CatalogError) as caught: self.collect(page)
        self.assertEqual(caught.exception.code, 'catalog_restore_required')
        self.assertEqual(len(page.actions), 1)

    def test_stale_children_are_marked_pending_and_duplicate_controls_rejected(self):
        page = Page(); page.stale = True
        page.options['district'] = [('stale', 'قضاء قديم')]
        result = self.collect(page)
        self.assertFalse(result['complete'])
        self.assertEqual(len(result['pending']), 2)
        self.assertTrue(all(g['status'] == 'pending' and not g['districts'] for g in result['governorates']))
        page = Page(); page.ambiguous = True
        with self.assertRaises(CatalogError): self.collect(page)

    def test_source_area_links_preserved_when_different_parents_share_a_reference(self):
        page = Page()
        page.tree['district']['d2'] = [('a1', 'منطقة مشتركة الاسم'), ('a9', 'بلدة مختلفة')]
        result = self.collect(page)
        self.assertTrue(result['complete'])
        self.assertEqual(result['governorates'][0]['districts'][1]['areas'][0]['id'], 'a1')

    def test_cancel_and_manual_parent_change_stop_collection(self):
        page = self.registered_page(); original = dict(page.selected); cancel = threading.Event()
        page.on_wait = lambda: cancel.set() if page.clock >= 2 else None
        with self.assertRaises(CatalogError) as caught: self.collect(page, cancel)
        self.assertEqual(caught.exception.code, 'catalog_cancelled')
        self.assertEqual(page.selected, original)
        page = Page()
        page.on_wait = lambda: page.selected.update(country='changed') if page.clock >= 2 else None
        with self.assertRaises(CatalogError): self.collect(page)

    def test_record_switch_never_restores_into_another_student(self):
        page = self.registered_page()
        actions_at_switch = []
        def switch():
            if page.actions and not actions_at_switch:
                actions_at_switch.append(len(page.actions))
                page.url = page.url.replace('record-id', 'other-record')
        page.on_wait = switch
        with self.assertRaises(CatalogError) as caught: self.collect(page)
        self.assertEqual(caught.exception.code, 'catalog_restore_required')
        self.assertEqual(len(page.actions), actions_at_switch[0])

    def test_invalid_options_marked_pending_and_original_address_restored(self):
        page = self.registered_page()
        original = dict(page.selected)
        page.tree['district']['d3'] = [('invalid', 'خيار'), ('invalid', 'خيار آخر')]
        result = self.collect(page)
        self.assertFalse(result['complete'])
        self.assertEqual(result['pending'][0]['district_id'], 'd3')
        self.assertEqual(result['pending'][0]['reason'], 'catalog_invalid_options')
        self.assertEqual(page.selected, original)

    def test_large_area_list_is_one_atomic_read_and_duplicate_names_are_preserved(self):
        page = Page()
        page.options['area'] = [('a' + str(i), 'منطقة بالاسم نفسه') for i in range(1800)]
        found = options(page, 'area')
        self.assertEqual(len(found), 1800)
        self.assertEqual(page.bulk_reads, 1)
        self.assertEqual(found[-1], ('a1799', 'منطقة بالاسم نفسه'))

    def test_missing_district_areas_do_not_stop_later_districts_and_all_provinces(self):
        page = self.registered_page(); original = dict(page.selected)
        page.tree['district']['d1'] = []
        result = self.collect(page)
        self.assertFalse(result['complete'])
        self.assertEqual(result['pending'][0]['district_id'], 'd1')
        self.assertEqual(result['governorates'][0]['districts'][1]['areas'][0]['id'], 'a3')
        self.assertEqual(result['governorates'][1]['districts'][0]['areas'][0]['id'], 'a4')
        self.assertEqual(page.selected, original)

    def test_first_timeout_retries_and_can_finish_complete(self):
        page = self.registered_page(); original = dict(page.selected)
        page.fail_once.add('d1')
        result = self.collect(page)
        self.assertTrue(result['complete'])
        self.assertEqual(result['pending'], [])
        self.assertGreaterEqual(page.attempts['d1'], 2)
        self.assertEqual(page.selected, original)

    def test_parent_same_area_set_without_observed_refresh_is_not_assumed_complete(self):
        page = Page(); page.stale = True
        page.options['district'] = page.tree['governorate']['g1']
        page.options['area'] = page.tree['district']['d1']
        result = self.collect(page)
        self.assertFalse(result['complete'])
        self.assertTrue(result['pending'])

    def test_status_metadata_is_lookup_only_and_type_bounded(self):
        result = clean_detail({'governorate': 'محافظة', 'district': 'قضاء', 'done': 3,
                               'username': 'PRIVATE', 'url': 'PRIVATE', 'record': {},
                               'stage': {}, 'reason': [], 'areas': True})
        self.assertEqual(result, {'governorate': 'محافظة', 'district': 'قضاء', 'done': 3})

    def test_atomic_export_preserves_previous_file_on_cancel_or_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'catalog.json'
            path.write_text('PREVIOUS')
            cancel = threading.Event(); cancel.set()
            with self.assertRaises(CatalogError): save_catalog({'governorates': []}, path, cancel)
            self.assertEqual(path.read_text(), 'PREVIOUS')
            with patch('address_catalog.os.replace', side_effect=OSError('test')):
                with self.assertRaises(CatalogError): save_catalog({'governorates': []}, path, threading.Event())
            self.assertEqual(path.read_text(), 'PREVIOUS')
            self.assertEqual(list(Path(folder).iterdir()), [path])
            save_catalog({'governorates': []}, path, threading.Event())
            self.assertEqual(json.loads(path.read_text()), {'governorates': []})

if __name__ == '__main__': unittest.main()
