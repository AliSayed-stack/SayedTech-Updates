@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if exist "%~dp0SayedTech.exe" goto packaged
call "%~dp0SETUP_PYTHON_WINDOWS.bat"
if not "%errorlevel%"=="0" goto failure
if not defined SAYED_PYTHON goto failure
"%SAYED_PYTHON%" ensure_dependencies.py
if not "%errorlevel%"=="0" goto failure
"%SAYED_PYTHON%" app.py
if not "%errorlevel%"=="0" goto failure
exit /b 0
:packaged
"%~dp0SayedTech.exe"
exit /b %errorlevel%
:failure
echo Could not start Sayed tech. Review the error above.
pause
exit /b 1
