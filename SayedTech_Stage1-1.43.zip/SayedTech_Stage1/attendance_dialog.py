"""Separate RTL attendance export and import windows for both school shifts."""
from uuid import uuid4
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QComboBox,
 QTableWidget,QTableWidgetItem,QAbstractItemView,QFileDialog,QHeaderView,QScrollArea,QFrame,QWidget,QSizePolicy,QLayout,QStyledItemDelegate)
from attendance_excel import read_attendance
from attendance_schema import REASONS
from student_excel import ExcelInputError
from detailed_dialog import DIALOG_STYLE

MESSAGES={
 'attendance_account':'توقفت العملية: تأكد من حساب المدرسة وأن الملف مستخرج من نفس الحساب.',
 'attendance_identity':'تعذّرت مطابقة هوية الطالب مع السجل وقائمة الحضور. لم يُسجّل الغياب.',
 'attendance_ambiguous':'بقي أكثر من طالب مطابق. راجع الرقم الموحّد؛ لم يُسجّل الغياب.',
 'attendance_options':'تعذّرت قراءة خانة أو قائمة أو الغيابات السابقة. راجع الصفحة والفلاتر والمسودات المفتوحة.',
 'attendance_date':'التاريخ غير صالح أو خارج حدود العام الدراسي في الموقع. راجع القسم المفتوح.',
 'attendance_existing':'توجد غيابات سابقة تتداخل مع الفترة المطلوبة. راجعها قبل إعادة التسجيل.',
 'attendance_save_unknown':'لم يصل تأكيد حفظ واضح. راجع الموقع؛ لا تعاود هذا السجل في الجلسة نفسها.',
 'attendance_uncertain':'سبق طلب حفظ هذا الغياب دون تأكيد. راجع الموقع يدوياً قبل أي إعادة تسجيل.',
 'attendance_input':'راجع التواريخ والسبب وهوية الطالب والملاحظات في Excel.',
 'attendance_failed':'توقفت العملية. راجع الموقع قبل إعادة المحاولة.',
 'attendance_busy':'هناك عملية أخرى قيد التنفيذ؛ انتظر انتهاءها.'}


class AttendanceExportDialog(QDialog):
    def __init__(self,controller,parent=None):
        super().__init__(parent)
        self.controller=controller;self.pending=None;self.available=True;self.path=''
        self.setObjectName('studentAttendance');self.setLayoutDirection(Qt.RightToLeft)
        self.setWindowTitle('Sayed tech | استخراج حضور الطلاب — الدوامان')
        self.setStyleSheet(DIALOG_STYLE.replace('detailedImport','studentAttendance'))
        outer=QVBoxLayout(self);outer.setSizeConstraint(QLayout.SetNoConstraint)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body=QWidget();scroll.setWidget(body);outer.addWidget(scroll,1)
        layout=QVBoxLayout(body);layout.setContentsMargins(0,0,0,0)
        note=QLabel('استخرج نموذجاً بأسماء الطلاب لتعبئة الغياب، أو صدّر الغيابات المسجّلة وفق فلاتر الموقع الحالية. '
                    'بعد تعبئة النموذج وحفظه، افتح «الحضور ← استرداد» لتسجيل الغيابات.')
        note.setWordWrap(True);note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred);layout.addWidget(note)
        self.extract=QPushButton('استخراج نموذج الغياب بأسماء الطلاب')
        self.extract.clicked.connect(lambda:self.export('attendance_template'))
        self.existing=QPushButton('تصدير الغيابات الظاهرة في الموقع')
        self.existing.clicked.connect(lambda:self.export('attendance_export'))
        for button in (self.extract,self.existing):button.setAutoDefault(False);layout.addWidget(button)
        self.status=QLabel('اختر نوع الاستخراج ومكان حفظ ملف Excel.')
        self.status.setWordWrap(True);self.status.setTextFormat(Qt.PlainText)
        self.status.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred);layout.addWidget(self.status);layout.addStretch()
        footer=QHBoxLayout();footer.addStretch();self.close_button=QPushButton('إغلاق')
        self.close_button.clicked.connect(self.reject);footer.addWidget(self.close_button);outer.addLayout(footer)
        controller.attendance_result.connect(self.result);controller.event.connect(self.session);self.finished.connect(self.detach)
        self.resize(780,320)

    def showEvent(self,event):
        super().showEvent(event)
        screen=self.screen()
        if screen:
            area=screen.availableGeometry();frame=self.frameGeometry()
            self.resize(min(780,max(1,area.width()-24-(frame.width()-self.width()))),
                        min(320,max(1,area.height()-24-(frame.height()-self.height()))))
            frame=self.frameGeometry();frame.moveCenter(area.center());self.move(frame.topLeft())

    def set_busy(self,busy):
        for widget in (self.extract,self.existing):widget.setEnabled(not busy and self.available)
        self.close_button.setEnabled(not busy)

    def export(self,action):
        if self.pending or not self.available or action not in ('attendance_template','attendance_export'):return
        path,_=QFileDialog.getSaveFileName(self,'حفظ ملف الحضور','SayedTech_Attendance.xlsx','Excel (*.xlsx)')
        if not path:return
        if not path.lower().endswith('.xlsx'):path+='.xlsx'
        self.path=path;request=uuid4().hex;self.pending=(request,action);self.set_busy(True)
        self.status.setText('جارٍ استخراج نموذج الطلاب…' if action=='attendance_template' else 'جارٍ تصدير الغيابات وفق فلاتر الموقع الحالية…')
        if not self.controller.attendance(action,request,path=path):self.result(request,'attendance_account',0)

    def result(self,request,event,days):
        if not self.pending or request!=self.pending[0]:return
        _,action=self.pending;self.pending=None
        if action=='attendance_template' and event=='attendance_template_saved':
            text=f'اُستخرج نموذج لـ{days} طالباً. عبّئ الغيابات واحفظ Excel، ثم افتح «الحضور ← استرداد».\n'+self.path
        elif action=='attendance_export' and event=='attendance_exported':text='صُدّرت الغيابات الظاهرة.\n'+self.path
        else:text=MESSAGES.get(event,'توقفت العملية. راجع الموقع.')
        self.status.setText(text);self.set_busy(False)

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.available=False;self.pending=None;self.set_busy(False)
            self.status.setText('انتهت جلسة المدرسة. أعد تسجيل الدخول قبل الاستخراج.')

    def detach(self,*args):
        self.controller.attendance_result.disconnect(self.result);self.controller.event.disconnect(self.session)

    def reject(self):
        if self.pending:return
        super().reject()


class AttendanceDialog(QDialog):
    def __init__(self,controller,parent=None):
        super().__init__(parent)
        self.controller=controller;self.rows=[];self.pending=None;self.queue=[];self.completed=set();self.active=False;self.stopping=False
        self.available=True;self.batch_id='';self.path='';self.setObjectName('studentAttendance')
        self.setWindowTitle('Sayed tech | استرداد حضور الطلاب — الدوامان');self.setLayoutDirection(Qt.RightToLeft)
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        self.setStyleSheet(DIALOG_STYLE.replace('detailedImport','studentAttendance'))
        outer=QVBoxLayout(self);outer.setSizeConstraint(QLayout.SetNoConstraint)
        self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        body=QWidget();body.setLayoutDirection(Qt.RightToLeft);self.scroll.setWidget(body);outer.addWidget(self.scroll,1)
        layout=QVBoxLayout(body);layout.setContentsMargins(0,0,0,0)
        note=QLabel('اختر نموذج الحضور بعد تعبئته وحفظه. ضع 1 للغيابات المطلوبة وعبّئ التاريخ MM/DD/YYYY والسبب. '
                    'تُقرأ أيام العطلة من تقويم المدرسة. احفظ أي مسودة مفتوحة قبل البدء. الحفظ مباشر بعد فحص الغيابات السابقة؛ تتوقف العملية عند أي خطأ.')
        note.setWordWrap(True);note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred);layout.addWidget(note)
        self.load=QPushButton('استرداد ملف الحضور من Excel');self.load.clicked.connect(self.load_file)
        self.load.setAutoDefault(False);layout.addWidget(self.load)
        line=QHBoxLayout();line.addWidget(QLabel('صف الاسترداد:'))
        self.grade=QComboBox();self.grade.addItem('كل الصفوف','');self.grade.currentIndexChanged.connect(self.filter_rows)
        self.grade.setItemDelegate(QStyledItemDelegate(self.grade));self.grade.view().setLayoutDirection(Qt.RightToLeft)
        self.grade.setItemData(0,Qt.AlignRight|Qt.AlignAbsolute,Qt.TextAlignmentRole)
        if hasattr(self.grade,'setLabelDrawingMode'):self.grade.setLabelDrawingMode(QComboBox.LabelDrawingMode.UseDelegate)
        line.addWidget(self.grade,1);layout.addLayout(line)
        self.table=QTableWidget(0,9)
        self.table.setHorizontalHeaderLabels(['استرداد','صف Excel','الطالب','الصف','من','إلى','السبب','الملاحظات','النتيجة'])
        self.table.setLayoutDirection(Qt.RightToLeft);self.table.verticalHeader().hide();self.table.setWordWrap(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.setAlternatingRowColors(True);self.table.setMinimumHeight(120)
        self.table.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Expanding)
        for column,width in enumerate((90,100,220,140,115,115,220,220,300)):self.table.setColumnWidth(column,width)
        self.table.horizontalHeader().moveSection(8,3)
        self.table.itemChanged.connect(self.selection_changed);layout.addWidget(self.table,1)
        self.status=QLabel('جاهز. استخدم نفس نموذج الحضور مع حساب المدرسة الذي استُخرج منه.')
        self.status.setWordWrap(True);self.status.setTextFormat(Qt.PlainText)
        self.status.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred);layout.addWidget(self.status)
        self.start=QPushButton('تسجيل وحفظ الغيابات المؤشّر عليها');self.start.clicked.connect(self.start_import);self.start.setAutoDefault(False)
        layout.addWidget(self.start)
        footer=QHBoxLayout();self.stop=QPushButton('إيقاف بعد الطالب الحالي');self.stop.clicked.connect(self.stop_import);self.stop.hide()
        footer.addWidget(self.stop);footer.addStretch();self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject)
        footer.addWidget(self.close_button);outer.addLayout(footer)
        self.controls=[self.load,self.grade,self.start,self.close_button]
        controller.attendance_result.connect(self.result);controller.event.connect(self.session);self.finished.connect(self.detach)
        self.resize(1180,760);self.set_busy(False)

    def showEvent(self,event):
        super().showEvent(event)
        QTimer.singleShot(0,self.fit_screen)

    def fit_screen(self):
        from detailed_dialog import DetailedImportDialog
        DetailedImportDialog.fit_screen(self)

    def set_busy(self,busy):
        for widget in self.controls:widget.setEnabled(not busy and self.available)
        self.start.setEnabled(not busy and self.available and bool(self.rows))
        self.close_button.setEnabled(not busy)
        self.table.setEnabled(not busy);self.stop.setVisible(busy and self.active)

    def load_file(self):
        if self.pending or self.active or not self.available:return
        path,_=QFileDialog.getOpenFileName(self,'اختر نموذج الحضور بعد تعبئته','','Excel (*.xlsx)')
        if not path:return
        try:rows=read_attendance(path)
        except ExcelInputError as exc:self.status.setText(str(exc));return
        self.rows=rows;self.completed=set();self.table.blockSignals(True);self.table.setRowCount(len(rows))
        for i,row in enumerate(rows):
            texts=['',str(row['excel_row']),' '.join(row[k] for k in ('first','middle','last')),row['grade'],
                   row['start'],row['end'],REASONS[row['reason']],row['notes'],'بانتظار التسجيل']
            for j,value in enumerate(texts):
                item=QTableWidgetItem(value);item.setToolTip(value);item.setTextAlignment(Qt.AlignRight|Qt.AlignAbsolute|Qt.AlignVCenter)
                if j==0:item.setFlags(Qt.ItemIsUserCheckable|Qt.ItemIsEnabled|Qt.ItemIsSelectable);item.setCheckState(Qt.Checked)
                self.table.setItem(i,j,item)
        self.table.blockSignals(False);self.grade.clear();self.grade.addItem('كل الصفوف','')
        self.grade.setItemData(0,Qt.AlignRight|Qt.AlignAbsolute,Qt.TextAlignmentRole)
        for grade in dict.fromkeys(r['grade'] for r in rows if r['grade']):
            self.grade.addItem(grade,grade);self.grade.setItemData(self.grade.count()-1,Qt.AlignRight|Qt.AlignAbsolute,Qt.TextAlignmentRole)
        self.path=path;self.set_busy(False);self.filter_rows()

    def checked(self):
        return [i for i in range(len(self.rows)) if not self.table.isRowHidden(i) and self.table.item(i,0).checkState()==Qt.Checked]

    def filter_rows(self,*args):
        if self.pending or self.active:return
        grade=self.grade.currentData()
        for i,row in enumerate(self.rows):self.table.setRowHidden(i,bool(grade and row['grade']!=grade))
        self.status.setText(f'المؤشّر عليهم ضمن الصف: {len(self.checked())}. أزل الإشارة عمّن تريد تخطّيه.')

    def selection_changed(self,item):
        if item.column()==0 and not self.pending:self.filter_rows()

    def start_import(self):
        if self.pending or self.active or not self.available:return
        self.queue=[i for i in self.checked() if i not in self.completed]
        if not self.queue:self.status.setText('لا يوجد غياب محدّد غير منجز. فعّل خانة استرداد للصفوف المطلوبة.');return
        self.batch_id=uuid4().hex;self.active=True;self.stopping=False;self.stop.setEnabled(True);self.dispatch()

    def dispatch(self):
        if not self.active or self.pending:return
        if not self.queue or self.stopping:
            self.active=False;self.set_busy(False);return
        index=self.queue[0];request=uuid4().hex;self.pending=(request,'attendance_import',index);self.set_busy(True)
        self.table.setCurrentCell(index,0);self.table.item(index,8).setText('جارٍ التحقق والتسجيل…')
        self.status.setText(f'جارٍ تسجيل الغياب — صف Excel {self.rows[index]["excel_row"]}.')
        if not self.controller.attendance('attendance_import',request,record=self.rows[index],batch_id=self.batch_id):
            self.result(request,'attendance_account',0)

    def result(self,request,event,days):
        if not self.pending or request!=self.pending[0]:return
        _,action,index=self.pending;self.pending=None
        if event in ('attendance_saved','attendance_already') and action=='attendance_import':
            self.completed.add(index);self.queue.pop(0)
            text=f'تم تسجيل الغياب — {days} أيام دراسية.' if event=='attendance_saved' else 'سبق تأكيد هذا الغياب في الجلسة؛ تُخطّي.'
            self.table.item(index,8).setText(text);self.table.item(index,8).setToolTip(text);self.status.setText(text)
            if self.active and not self.stopping and self.queue:QTimer.singleShot(0,self.dispatch);return
            self.active=False
        else:
            self.active=False;text=MESSAGES.get(event,'توقفت العملية. راجع الموقع.')
            if index is not None:self.table.item(index,8).setText(text);self.table.item(index,8).setToolTip(text)
            self.status.setText(text)
        self.set_busy(False)

    def stop_import(self):
        self.stopping=True;self.stop.setEnabled(False)
        self.status.setText('سيكتمل الغياب الحالي ثم تتوقف العملية.')
        if not self.pending:self.active=False;self.set_busy(False)

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.available=False;self.pending=None;self.active=False;self.set_busy(False)
            self.status.setText('انتهت جلسة المدرسة. أعد تسجيل الدخول قبل متابعة الحضور.')

    def detach(self,*args):
        self.controller.attendance_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.queue=[];self.completed.clear()

    def reject(self):
        if self.pending or self.active:return
        super().reject()
