"""Compact student-sheet dimensions taken from the site-export template.

Only row/column dimensions change. Cell styles, dates, text, validations,
tables and the other sheets stay owned by the existing workbook writers.
"""
import copy
from functools import lru_cache
import xml.etree.ElementTree as ET
import zipfile

import core
from student_excel import NS

ALIASES={
    'بلد السكن':'البلد','محافظة السكن':'المحافظة','قضاء السكن':'القضاء',
    'منطقة / بلدة السكن':'المنطقة','تفاصيل العنوان':'تفاصيل العنوان ١',
    'نوع السكن':'النوع','ملاحظات تجهيز العنوان':'حالة العنوان',
    'ملاحظات المصدر':'حالة العنوان','ملاحظة الترفيع':'حالة العنوان'}


@lru_cache(maxsize=4)
def site_dimensions(template):
    with zipfile.ZipFile(template) as archive:
        sheet=ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
        strings=[]
        if 'xl/sharedStrings.xml' in archive.namelist():
            strings=[''.join(si.itertext()) for si in ET.fromstring(archive.read('xl/sharedStrings.xml'))]
    body=sheet.find('m:sheetData',NS)
    widths={}
    columns=sheet.findall('m:cols/m:col',NS)
    for index,cell in enumerate(body[0],1):
        if cell.get('t')=='s':label=strings[int(cell.find('m:v',NS).text)]
        elif cell.get('t')=='inlineStr':label=''.join(node.text or '' for node in cell.findall('.//m:t',NS))
        else:label=cell.findtext('m:v',default='',namespaces=NS)
        dimension=next(c for c in columns if int(c.get('min'))<=index<=int(c.get('max')))
        widths[label]=dimension.get('width')
    return body[0].get('ht'),body[1].get('ht'),widths


def apply_student_dimensions(sheet,headers):
    header_height,row_height,widths=site_dimensions(core.ASSET_BASE/'assets/student_with_addresses.xlsx')
    q=lambda name:'{'+NS['m']+'}'+name
    body=sheet.find('m:sheetData',NS)
    for row in body:
        row.set('ht',header_height if row.get('r')=='1' else row_height)
        row.set('customHeight','1')
    defaults=sheet.find('m:sheetFormatPr',NS)
    if defaults is not None:defaults.set('defaultRowHeight',row_height)
    columns=sheet.find('m:cols',NS)
    if columns is None:
        columns=ET.Element(q('cols'));sheet.insert(list(sheet).index(body),columns)
    original=list(columns)
    for node in original:columns.remove(node)
    for index,label in enumerate(headers,1):
        previous=next((c for c in original if int(c.get('min'))<=index<=int(c.get('max'))),None)
        node=copy.deepcopy(previous) if previous is not None else ET.Element(q('col'))
        label=ALIASES.get(label,label)
        width=widths.get(label,widths['الرقم الموحد للطالب'])
        if label in ('اختيار للاستيراد','اختيار للاستكمال لاحقاً','شهرة الأم (للمفصّل)'):
            width='22' # Same added-column width used by the site export.
        node.set('min',str(index));node.set('max',str(index))
        node.set('width',width);node.set('customWidth','1')
        columns.append(node)
    for node in original:
        if int(node.get('max'))>len(headers):
            node=copy.deepcopy(node);node.set('min',str(max(int(node.get('min')),len(headers)+1)))
            columns.append(node)
