"""Synthetic afternoon unified registration inputs; native features retained."""
import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile
from openpyxl import load_workbook
from registration_workbook import write_template,translate_names,read_for_simple,KINDS,ENTRY_KIND,MARKER,HOME,EXISTING,TRANSFER,upgrade_route_choices
from student_excel import FIELDS,read_students,ExcelInputError
from detailed_import import read_details
from manual_sections import SELECT
from test_students import record


class RegistrationWorkbookTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'registration.xlsx'
        write_template(self.path)
    def tearDown(self):self.temp.cleanup()

    def fill(self,count=1):
        b=load_workbook(self.path);s=b['الطلاب'];h={c.value:c.column for c in s[1]}
        for n in range(2,count+2):
            values=record();values['field-existingUniqueId']=''
            values.update({'field-firstName':'أحمد','field-middleName':'علي','field-lastName':'سيد','field-motherName':'مريم'})
            for f in FIELDS:s.cell(n,h[f['label']],values[f['id']] if not isinstance(values[f['id']],bool) else 'لا')
            s.cell(n,h[SELECT],'1');s.cell(n,h[ENTRY_KIND],HOME)
        b.save(self.path);b.close();return h

    def test_template_contains_full_native_schema_lists_and_three_registration_routes(self):
        b=load_workbook(self.path);s=b['الطلاب'];headers=[c.value for c in s[1]]
        self.assertEqual(len(headers),57);self.assertEqual(headers[0],SELECT);self.assertEqual(headers[-1],ENTRY_KIND)
        for label in ('الهواتف / رقم الهاتف','البريد الإلكتروني / البريد الإلكتروني','شهرة الأم','المستندات / نوع المستند'):
            self.assertIn(label,headers)
        self.assertIn(MARKER,b.sheetnames);self.assertNotIn('حالة السحب',b.sheetnames)
        self.assertIn(s['BE2'].value,('',None));self.assertEqual(s.row_dimensions[2].height,23)
        self.assertGreater(len(s.data_validations.dataValidation),10)
        self.assertTrue(any(d.sqref.__str__().startswith('BE2:') and all(k in d.formula1 for k in KINDS) for d in s.data_validations.dataValidation))
        self.assertEqual(next(iter(s.tables.values())).ref,'A1:BE501');b.close()

    def test_grade_dropdown_and_old_filled_copy(self):
        from registration_workbook import AFTERNOON_GRADES
        self.assertEqual(AFTERNOON_GRADES[-5:],('السابع أساسي','الثامن أساسي','التاسع أساسي','الأول ثانوي','الثاني ثانوي'))
        b=load_workbook(self.path);s=b['الطلاب'];h={c.value:c.column_letter for c in s[1]};letter=h['صف الطالب']
        matches=[d for d in s.data_validations.dataValidation if str(d.sqref)==f'{letter}2:{letter}501']
        self.assertEqual(len(matches),1);self.assertFalse(matches[0].showDropDown)
        self.assertEqual(matches[0].formula1,'"'+','.join(AFTERNOON_GRADES)+'"')
        s.data_validations.dataValidation.remove(matches[0]);s[f'{letter}2']='الثاني ثانوي';b.save(self.path);b.close()
        original=self.path.read_bytes();target=self.path.with_name('grades.xlsx');upgrade_route_choices(self.path,target)
        self.assertEqual(self.path.read_bytes(),original)
        b=load_workbook(target);s=b['الطلاب'];self.assertEqual(s[f'{letter}2'].value,'الثاني ثانوي')
        self.assertEqual(len([d for d in s.data_validations.dataValidation if str(d.sqref)==f'{letter}2:{letter}501']),1);b.close()

    def test_afternoon_export_defaults_fill_all_input_rows_using_existing_options(self):
        from scan_dropdowns import dropdown_options
        labels={f['id']:f['label'] for f in FIELDS}
        expected={labels['field-maritalStatus']:'أعزب/عزباء',labels['isFatherDeceased']:'لا',
                  labels['isMotherDeceased']:'لا',labels['field-nationality']:'سوريا',
                  labels['field-motherNationality']:'سوريا',labels['field-motherSector']:'عاطل عن العمل',
                  labels['field-enrollment-teaching-language']:'الفرنسية','البلد':'لبنان',
                  'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':dropdown_options()['الهواتف / رمز الدولة'][0],
                  'الهواتف / الأساسية':'نعم'}
        self.assertEqual(expected['الهواتف / رمز الدولة'],'961 (LB)')
        b=load_workbook(self.path);s=b['الطلاب'];headers={c.value:c.column for c in s[1]}
        for n in range(2,502):
            for label,value in expected.items():self.assertEqual(s.cell(n,headers[label]).value,value)
            for label in (SELECT,ENTRY_KIND,labels['field-existingUniqueId'],labels['field-birthDate']):
                self.assertIn(s.cell(n,headers[label]).value,('',None))
        b.close()

    def test_defaults_do_not_replace_employee_values_on_import_or_copy_upgrade(self):
        h=self.fill();b=load_workbook(self.path);s=b['الطلاب'];labels={f['id']:f['label'] for f in FIELDS}
        s.cell(2,h[labels['field-enrollment-teaching-language']],'الإنكليزية')
        s.cell(2,h[labels['field-nationality']],'لبنان')
        s.cell(2,h['البلد'],'سوريا');s.cell(2,h['الهواتف / الأساسية'],'لا')
        b.save(self.path);b.close();original=self.path.read_bytes()
        row=read_for_simple(self.path)[0]
        self.assertEqual(row['values']['field-enrollment-teaching-language'],'الإنكليزية')
        self.assertEqual(row['values']['field-nationality'],'لبنان')
        self.assertEqual(self.path.read_bytes(),original)
        target=self.path.with_name('copy.xlsx');upgrade_route_choices(self.path,target)
        b=load_workbook(target);s=b['الطلاب'];self.assertEqual(s.cell(2,h['البلد']).value,'سوريا')
        self.assertEqual(s.cell(2,h['الهواتف / الأساسية']).value,'لا');b.close()

    def test_simple_ignores_detailed_only_errors_and_does_not_change_file(self):
        h=self.fill();b=load_workbook(self.path);b['الطلاب'].cell(2,h['المستندات / تاريخ الإصدار'],'not a date');b.save(self.path);b.close()
        original=self.path.read_bytes();rows=read_for_simple(self.path)
        self.assertEqual(len(rows),1);self.assertEqual(rows[0]['errors'],[])
        self.assertEqual(rows[0]['entry_kind'],'طالب جديد');self.assertEqual(rows[0]['address'],{})
        self.assertEqual(self.path.read_bytes(),original)
        with self.assertRaises(ExcelInputError):read_details(self.path)

    def test_same_file_routes_simple_and_full_details_without_new_creation(self):
        h=self.fill();b=load_workbook(self.path);s=b['الطلاب']
        s.cell(2,h['الهواتف / رقم الهاتف'],'03123456');s.cell(2,h['الهواتف / النوع'],'خلوي')
        s.cell(2,h['البريد الإلكتروني / البريد الإلكتروني'],'test@example.invalid')
        s.cell(2,h['المستندات / نوع المستند'],'بطاقة هوية');b.save(self.path);b.close()
        original=self.path.read_bytes();simple=read_for_simple(self.path);details=read_details(self.path)
        self.assertEqual(simple[0]['entry_kind'],'طالب جديد')
        self.assertEqual(details[0]['manual']['الهواتف / رقم الهاتف'],'03123456')
        self.assertEqual(details[0]['manual']['البريد الإلكتروني / البريد الإلكتروني'],'test@example.invalid')
        self.assertNotIn('entry_kind',details[0]);self.assertEqual(self.path.read_bytes(),original)

    def test_details_do_not_require_unused_simple_english_or_registration_date(self):
        h=self.fill();b=load_workbook(self.path);s=b['الطلاب']
        for f in FIELDS:
            if f['id'].endswith('NameEn'):s.cell(2,h[f['label']],'')
            if f['id']=='field-enrollment-registration-date':s.cell(2,h[f['label']],'not a date')
        s.cell(2,h['الهواتف / رقم الهاتف'],'03123456');b.save(self.path);b.close()
        self.assertTrue(read_for_simple(self.path)[0]['errors'])
        self.assertEqual(read_details(self.path)[0]['manual']['الهواتف / رقم الهاتف'],'03123456')

    def test_three_types_in_one_file_route_each_selected_row_without_ui_filter(self):
        h=self.fill(3);b=load_workbook(self.path);s=b['الطلاب']
        for n,kind,name in ((2,EXISTING,'أحمد'),(3,TRANSFER,'علي'),(4,HOME,'مريم')):
            s.cell(n,h[ENTRY_KIND],kind);s.cell(n,h['الاسم الأول (بالعربية)'],name)
        uid=next(f['label'] for f in FIELDS if f['id']=='field-existingUniqueId')
        s.cell(2,h[uid],'000123')
        b.save(self.path);b.close();before=self.path.read_bytes()
        rows=read_for_simple(self.path)
        self.assertEqual([r['excel_row'] for r in rows],[2,3,4])
        self.assertEqual([r['entry_kind'] for r in rows],['طالب موجود','طالب موجود','طالب جديد'])
        self.assertEqual([r['values']['field-existingUniqueId'] for r in rows],['000123','',''])
        self.assertTrue(all(not r['errors'] for r in rows))
        self.assertEqual(self.path.read_bytes(),before)
        b=load_workbook(self.path);b['الطلاب'].cell(3,h[uid],'000456');b.save(self.path);b.close()
        transfer=read_for_simple(self.path)[1]
        self.assertEqual(transfer['entry_kind'],'طالب موجود');self.assertEqual(transfer['errors'],[])

    def test_old_route_labels_are_accepted_and_blank_route_is_not_guessed(self):
        h=self.fill(2);b=load_workbook(self.path);s=b['الطلاب']
        s.cell(2,h[ENTRY_KIND],'تلميذ جديد من البيت')
        s.cell(3,h[ENTRY_KIND],'تلميذ من مدرسة أخرى');s.cell(3,h['الاسم الأول (بالعربية)'],'علي')
        b.save(self.path);b.close()
        self.assertEqual([r['entry_kind'] for r in read_for_simple(self.path)],['طالب جديد','طالب موجود'])
        b=load_workbook(self.path);b['الطلاب'].cell(2,h[ENTRY_KIND],'');b.save(self.path);b.close()
        with self.assertRaises(ExcelInputError):read_for_simple(self.path)

    def test_upgrade_changes_only_route_validation_and_preserves_filled_original(self):
        import re
        h=self.fill();b=load_workbook(self.path);s=b['الطلاب']
        s.cell(2,h[ENTRY_KIND],'تلميذ جديد من البيت')
        s.cell(2,h['المستندات / رقم الوثيقة'],'000007')
        for dv in s.data_validations.dataValidation:
            if str(dv.sqref).startswith('BE2:'):dv.formula1='"تلميذ جديد من البيت,تلميذ من مدرسة أخرى"'
        b.save(self.path);b.close();original=self.path.read_bytes()
        with zipfile.ZipFile(self.path) as z:before={n:z.read(n) for n in z.namelist()}
        target=self.path.with_name('upgraded.xlsx');upgrade_route_choices(self.path,target)
        self.assertEqual(self.path.read_bytes(),original)
        with zipfile.ZipFile(target) as z:
            self.assertEqual([n for n in before if before[n]!=z.read(n)],['xl/worksheets/sheet1.xml'])
            body=rb'<(?:\w+:)?sheetData\b.*?</(?:\w+:)?sheetData>'
            self.assertEqual(re.search(body,before['xl/worksheets/sheet1.xml'],re.S)[0],re.search(body,z.read('xl/worksheets/sheet1.xml'),re.S)[0])
        b=load_workbook(target);s=b['الطلاب']
        self.assertTrue(any(str(d.sqref).startswith('BE2:') and all(k in d.formula1 for k in KINDS) for d in s.data_validations.dataValidation));b.close()
        self.assertEqual(read_for_simple(target)[0]['entry_kind'],'طالب جديد')
        with self.assertRaises(ExcelInputError):upgrade_route_choices(self.path,self.path)

    def test_translation_fills_only_blank_english_and_keeps_dates_documents_lists_and_populated_spelling(self):
        h=self.fill();b=load_workbook(self.path);s=b['الطلاب']
        for f in FIELDS:
            if f['id'].endswith('NameEn'):s.cell(2,h[f['label']],'')
        mother_en=next(f['label'] for f in FIELDS if f['id']=='field-motherNameEn')
        s.cell(2,h[mother_en],'CUSTOM');s.cell(2,h['المستندات / رقم الوثيقة'],'00007');b.save(self.path);b.close()
        with zipfile.ZipFile(self.path) as z:before={n:z.read(n) for n in z.namelist()}
        self.assertEqual(translate_names(self.path),3);self.assertEqual(translate_names(self.path),0)
        with zipfile.ZipFile(self.path) as z:
            self.assertEqual([n for n in before if before[n]!=z.read(n)],['xl/worksheets/sheet1.xml'])
        b=load_workbook(self.path);s=b['الطلاب'];self.assertEqual(s.cell(2,h[mother_en]).value,'CUSTOM')
        first_en=next(f['label'] for f in FIELDS if f['id']=='field-firstNameEn')
        self.assertEqual(s.cell(2,h[first_en]).value,'Ahmad');self.assertEqual(s.cell(2,h['المستندات / رقم الوثيقة']).value,'00007');b.close()

    def test_repeated_document_rows_register_once_but_details_keep_documents(self):
        h=self.fill(2);b=load_workbook(self.path);s=b['الطلاب']
        s.cell(2,h['المستندات / نوع المستند'],'بطاقة هوية');s.cell(3,h['المستندات / نوع المستند'],'بطاقة تلقيح');b.save(self.path);b.close()
        self.assertEqual(len(read_for_simple(self.path)),1)
        detailed=read_details(self.path);self.assertEqual(len(detailed),1);self.assertEqual(len(detailed[0]['documents']),2)

    def test_wrong_shift_formula_and_inconsistent_new_uid_are_blocked(self):
        h=self.fill()
        with self.assertRaises(ExcelInputError):read_students(self.path,shift='morning')
        import threading
        from detailed_import import start_detail_import,DetailError
        row=read_details(self.path)[0]
        self.assertEqual(row['required_shift'],'afternoon')
        class NoBrowserCalls:
            def __getattr__(self,key):raise AssertionError('Wrong shift must stop before browser access')
        with self.assertRaises(DetailError):start_detail_import(NoBrowserCalls(),row,'phone','test@te.mehe.school',threading.Event())
        b=load_workbook(self.path);s=b['الطلاب'];uid=next(f['label'] for f in FIELDS if f['id']=='field-existingUniqueId');s.cell(2,h[uid],'000123');b.save(self.path);b.close()
        self.assertTrue(read_for_simple(self.path)[0]['errors'])
        b=load_workbook(self.path);b['الطلاب'].cell(2,h[ENTRY_KIND],'="x"');b.save(self.path);b.close()
        with self.assertRaises(ExcelInputError):read_for_simple(self.path)


if __name__=='__main__':unittest.main()
