"""One native-format workbook for explicit afternoon simple/detail registration."""
import hashlib
import os
import re
from pathlib import Path
import tempfile
import threading
import xml.etree.ElementTree as ET
import zipfile
from student_excel import FIELDS,NS,REL,ExcelInputError,validate_record
from student_workflow import workbook_rows,selection_value,column
from manual_sections import SELECT,norm

MARKER='نموذج التسجيل'
ENTRY_KIND='طريقة تسجيل الطالب'
EXISTING='طالب موجود'
TRANSFER='طالب جديد من مدرسة أخرى'
HOME='طالب جديد من البيت'
KINDS=(EXISTING,TRANSFER,HOME)
SITE_ROUTES={EXISTING:'طالب موجود',TRANSFER:'طالب موجود',HOME:'طالب جديد'}
TYPE='registration_unified_v1'
# Registration schools can extend through secondary year two. Live options remain authoritative.
AFTERNOON_GRADES=('الروضة الثالثة','الأول أساسي','الثاني أساسي','الثالث أساسي','الرابع أساسي','الخامس أساسي','السادس أساسي','السابع أساسي','الثامن أساسي','التاسع أساسي','الأول ثانوي','الثاني ثانوي')


def canonical_kind(value):
    aliases={k:k for k in KINDS}
    aliases.update({'تلميذ جديد من البيت':HOME,'تلميذ من مدرسة أخرى':TRANSFER,
                    'طالب جديد':HOME,'طالب موجود بمدرسة أخرى':TRANSFER})
    return {norm(k):v for k,v in aliases.items()}.get(norm(value or ''))


def afternoon_template_defaults():
    from scan_dropdowns import dropdown_options
    from manual_sections import phone_country_parts
    by_id={f['id']:f for f in FIELDS}
    wanted={'field-maritalStatus':'single','field-nationality':'SY',
            'field-motherNationality':'SY','field-motherSector':'unemployed'}
    defaults={}
    for key,code in wanted.items():
        labels=[o['label'] for o in by_id[key]['options'] if o['value']==code]
        if len(labels)!=1:raise ExcelInputError('تعذّر تأكيد الخيارات الافتراضية في النموذج.')
        defaults[by_id[key]['label']]=labels[0]
    defaults.update({by_id['isFatherDeceased']['label']:'لا',by_id['isMotherDeceased']['label']:'لا',
                     by_id['field-enrollment-teaching-language']['label']:'الفرنسية',
                     'البلد':'لبنان','الهواتف / النوع':'خلوي','الهواتف / الأساسية':'نعم'})
    lebanon=[v for v in dropdown_options()['الهواتف / رمز الدولة'] if phone_country_parts(v)==('961','LB')]
    if len(lebanon)!=1:raise ExcelInputError('تعذّر تأكيد خيار لبنان للهاتف.')
    defaults['الهواتف / رمز الدولة']=lebanon[0]
    return defaults


def is_registration(z):
    data=z.read('xl/workbook.xml')
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():raise ExcelInputError('بنية XML غير مدعومة.')
    return any(s.get('name')==MARKER for s in ET.fromstring(data).findall('m:sheets/m:sheet',NS))


def check_marker(z):
    rows=workbook_rows(z,MARKER)
    if any(f for _,_,f in rows):raise ExcelInputError('مرجع نموذج التسجيل غير صالح.')
    data={v.get('A'):v.get('B') for _,v,_ in rows}
    if data.get('نوع الملف')!=TYPE or data.get('الدوام')!='afternoon':raise ExcelInputError('اختر نموذج التسجيل الموحد لدوام بعد الظهر.')


def _write(parts,path,original_digest=None):
    path=Path(path);temp=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.xlsx',delete=False) as f:temp=Path(f.name)
        with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
            for name,blob in parts.items():z.writestr(name,blob)
        with zipfile.ZipFile(temp) as z:
            if z.testzip():raise ExcelInputError('تعذّر فحص ملف Excel.')
        if original_digest and hashlib.sha256(path.read_bytes()).hexdigest()!=original_digest:
            raise ExcelInputError('تغيّر الملف أثناء العمل؛ أغلق Excel وأعد المحاولة.')
        os.replace(temp,path)
    except OSError:raise ExcelInputError('أغلق ملف Excel واختر مجلداً متاحاً للكتابة.') from None
    finally:
        if temp:temp.unlink(missing_ok=True)


def write_template(path):
    """Reuse the exact scan template/dropdowns; no new runtime XLSX dependency."""
    from student_scan import export_students,empty_result,REPORT_SHEET
    import core
    path=Path(path)
    if path.suffix.lower()!='.xlsx' or (core.ASSET_BASE/'assets').resolve() in path.resolve().parents:
        raise ExcelInputError('احفظ نموذج التسجيل خارج مجلد assets بصيغة xlsx.')
    with tempfile.TemporaryDirectory() as temp:
        native=Path(temp)/'native.xlsx'
        row=empty_result(dict(uid='',first='',middle='',last='',grade='',status='',language='',section=''))
        export_students({'records':[row],'inventory':0,'limit':0,'shift':'afternoon'},native,threading.Event())
        with zipfile.ZipFile(native) as z:
            parts={n:z.read(n) for n in z.namelist()}
            native_headers=workbook_rows(z,'الطلاب')[0][1]
    q=lambda n:'{'+NS['m']+'}'+n
    book=ET.fromstring(parts['xl/workbook.xml']);rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    content=ET.fromstring(parts['[Content_Types].xml']);sheets=book.find('m:sheets',NS)
    for sheet in list(sheets):
        rel=next(r for r in rels if r.get('Id')==sheet.get(REL));target=rel.get('Target')
        part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        if sheet.get('name') in ('الحقول المقروءة','البطاقات الظاهرة'):
            sheets.remove(sheet);rels.remove(rel);parts.pop(part,None)
            for item in list(content):
                if item.get('PartName')=='/'+part:content.remove(item)
        elif sheet.get('name')==REPORT_SHEET:
            sheet.set('name',MARKER)
            marker=ET.Element(q('worksheet'));body=ET.SubElement(marker,q('sheetData'))
            notes=[('نوع الملف',TYPE),('الدوام','afternoon'),
                   ('الاستخدام','ملف واحد للمبسّط والمفصّل. ضع 1 في أول عمود للطلاب المطلوبين.'),
                   ('الترتيب','للطالب الجديد: احفظ التسجيل المبسّط أولاً، ثم استرد الملف نفسه في التسجيل المفصّل.'),
                   ('طريقة التسجيل','آخر عمود: طالب موجود أو جديد من مدرسة أخرى ← طالب موجود؛ جديد من البيت ← طالب جديد. اختر النوع لكل صف.'),
                   ('ترجمة الأسماء','زر ترجمة الأسماء يملأ الإنكليزي الفارغ فقط. راجع التهجئة قبل الاسترداد.')]
            for i,pair in enumerate(notes,1):
                node=ET.SubElement(body,q('row'),r=str(i))
                for j,value in enumerate(pair,1):
                    c=ET.SubElement(node,q('c'),r=column(j)+str(i),t='inlineStr')
                    ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=value
            parts[part]=ET.tostring(marker,encoding='utf-8',xml_declaration=True)
    sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml']);body=sheet.find('m:sheetData',NS)
    header=body.find('m:row',NS);count=len(header)+1;end=column(count);maxrow=len(body)
    for row in body:
        c=ET.SubElement(row,q('c'),r=end+row.get('r'),t='inlineStr',s=row[0].get('s','0'))
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=ENTRY_KIND if row is header else ''
    # Keep the reserved first input row unselected; requested defaults follow.
    first=body.findall('m:row',NS)[1]
    for c in first:
        if c.get('r')=='A2':
            for child in list(c):c.remove(child)
            c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=''
    by_header={label:letter for letter,label in native_headers.items()}
    defaults=afternoon_template_defaults()
    if not set(defaults)<=set(by_header):raise ExcelInputError('أعمدة القيم الافتراضية غير مكتملة.')
    for row in body.findall('m:row',NS)[1:]:
        cells={re.sub(r'[0-9]+$','',c.get('r','')):c for c in row}
        for label,value in defaults.items():
            c=cells[by_header[label]]
            if c.find('m:f',NS) is not None:continue
            existing=c.findtext('m:v','',NS) or ''.join(t.text or '' for t in c.findall('m:is/m:t',NS))
            if str(existing).strip():continue
            for child in list(c):c.remove(child)
            c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=value
    sheet.find('m:dimension',NS).set('ref',f'A1:{end}{maxrow}')
    ET.SubElement(sheet.find('m:cols',NS),q('col'),min=str(count),max=str(count),width='26',customWidth='1')
    validations=sheet.find('m:dataValidations',NS)
    dv=ET.SubElement(validations,q('dataValidation'),type='list',allowBlank='1',showErrorMessage='1',sqref=f'{end}2:{end}{maxrow}')
    ET.SubElement(dv,q('formula1')).text='"'+','.join(KINDS)+'"'
    grade=by_header['صف الطالب']
    dv=ET.SubElement(validations,q('dataValidation'),type='list',allowBlank='1',showDropDown='0',showErrorMessage='1',sqref=f'{grade}2:{grade}{maxrow}')
    ET.SubElement(dv,q('formula1')).text='"'+','.join(AFTERNOON_GRADES)+'"'
    validations.set('count',str(len(validations)))
    for name in list(parts):
        if name.startswith('xl/tables/') and name.endswith('.xml'):
            table=ET.fromstring(parts[name]);columns=table.find('m:tableColumns',NS)
            if columns is not None and any(c.get('name')==SELECT for c in columns):
                ET.SubElement(columns,q('tableColumn'),id=str(count),name=ENTRY_KIND);columns.set('count',str(count))
                table.set('ref',f'A1:{end}{maxrow}')
                af=table.find('m:autoFilter',NS)
                if af is not None:af.set('ref',f'A1:{end}{maxrow}')
                parts[name]=ET.tostring(table,encoding='utf-8',xml_declaration=True)
    af=sheet.find('m:autoFilter',NS)
    if af is not None:af.set('ref',f'A1:{end}{maxrow}')
    parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
    parts['xl/workbook.xml']=ET.tostring(book,encoding='utf-8',xml_declaration=True)
    parts['xl/_rels/workbook.xml.rels']=ET.tostring(rels,encoding='utf-8',xml_declaration=True)
    parts['[Content_Types].xml']=ET.tostring(content,encoding='utf-8',xml_declaration=True)
    instructions=next(s for s in sheets if s.get('name')=='التعليمات')
    link=next(r for r in rels if r.get('Id')==instructions.get(REL));target=link.get('Target')
    part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    info=ET.fromstring(parts[part])
    texts={1:'Sayed tech — التسجيل المبسّط والمفصّل لدوام بعد الظهر',
           3:'ملف واحد لكل البيانات. ضع 1 أو نعم في أول عمود للتلاميذ المطلوبين وحدّد نوع التسجيل في آخر عمود.',
           5:'التواريخ بتاريخ Excel أو MM/DD/YYYY أو yyyy-mm-dd. أرقام الهواتف والوثائق والمعرّفات نصوص لحفظ الأصفار.',
           8:'المبسّط يسترد الخانات الأساسية فقط. بعد حفظ تسجيل التلميذ استعمل نفس الملف لاستكمال خانات المفصّل.',
           9:'طالب موجود أو جديد من مدرسة أخرى: البحث في طالب موجود. جديد من البيت: طالب جديد. راجع تهجئة الأسماء الإنكليزية بعد الترجمة.'}
    for number,text in texts.items():
        c=info.find(f"m:sheetData/m:row[@r='{number}']/m:c[@r='A{number}']",NS)
        if c is not None:
            for child in list(c):c.remove(child)
            c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=text
    parts[part]=ET.tostring(info,encoding='utf-8',xml_declaration=True)
    _write(parts,path)


def read_simple(z,shift):
    check_marker(z)
    if shift!='afternoon':raise ExcelInputError('هذا النموذج مخصص لتسجيل دوام بعد الظهر.')
    rows=workbook_rows(z,'الطلاب');headers=rows[0][1]
    needed={f['label'] for f in FIELDS}|{SELECT,ENTRY_KIND}
    if rows[0][2] or len(set(headers.values()))!=len(headers) or not needed.issubset(headers.values()):
        raise ExcelInputError('عناوين نموذج التسجيل مختلفة.')
    by_name={v:k for k,v in headers.items()};result=[];seen={}
    for number,cells,formulas in rows[1:]:
        if by_name[SELECT] in formulas:raise ExcelInputError(f'الصف {number}: الاختيار يدوي دون معادلات.')
        try:chosen=selection_value(cells.get(by_name[SELECT],''))
        except ValueError:raise ExcelInputError(f'الصف {number}: ضع 1 أو نعم في أول عمود.') from None
        if not chosen:continue
        if by_name[ENTRY_KIND] in formulas:raise ExcelInputError(f'الصف {number}: طريقة التسجيل اختيار ثابت دون معادلة.')
        kind=canonical_kind(cells.get(by_name[ENTRY_KIND],''))
        if kind is None:raise ExcelInputError(f'الصف {number}: اختر طريقة تسجيل الطالب في آخر عمود: طالب موجود، أو طالب جديد من مدرسة أخرى، أو طالب جديد من البيت.')
        if formulas & {by_name[h] for h in needed}:raise ExcelInputError(f'الصف {number}: خانات المبسّط قيم ثابتة دون معادلات.')
        values,errors=validate_record({f['id']:cells.get(by_name[f['label']],'') for f in FIELDS},shift)
        if kind==HOME and values.get('field-existingUniqueId'):errors.append('راجع طريقة التسجيل: التلميذ الجديد لا يحمل رقماً موحداً سابقاً')
        route=SITE_ROUTES[kind]
        item={'excel_row':number,'values':values,'errors':errors,'address':{},'workflow':True,'registration_unified':True,'entry_kind':route}
        uid=values.get('field-existingUniqueId','')
        key=('uid',uid) if uid else tuple(values.get(k,'') for k in ('field-firstName','field-middleName','field-lastName','field-birthDate','field-enrollment-promoted-class'))
        if key in seen:
            previous=seen[key]
            if previous['values']==values and previous['entry_kind']==route:
                previous.setdefault('excel_rows',[previous['excel_row']]).append(number);continue
            previous['errors'].append('الطالب مكرر ببيانات مبسّطة مختلفة');errors.append('الطالب مكرر ببيانات مبسّطة مختلفة')
        else:seen[key]=item
        result.append(item)
    if not result:
        raise ExcelInputError('ضع 1 أو نعم في أول عمود للطلاب المطلوبين واحفظ الملف.')
    return result


def read_for_simple(path):
    from student_excel import read_students
    path=Path(path)
    if not path.is_file() or path.stat().st_size>64_000_000:raise ExcelInputError('اختر ملف التسجيل الموحد صالحاً.')
    with zipfile.ZipFile(path) as z:
        if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128_000_000:raise ExcelInputError('ملف Excel كبير جداً.')
        if is_registration(z):return read_simple(z,'afternoon')
    # Older unified inputs retain their explicit per-row route and validation.
    rows=read_students(path,shift='afternoon')
    if any(row.get('entry_kind') not in ('طالب جديد','طالب موجود') for row in rows):
        raise ExcelInputError('اختر الملف الموحد الذي يحتوي طريقة تسجيل الطالب لكل صف.')
    return rows


def upgrade_route_choices(source,destination):
    """Update only route-list validation in a separate copy of a filled file."""
    from student_unified import is_unified
    from xml.sax.saxutils import escape
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.exists() or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('احفظ النسخة باسم جديد؛ يبقى الملف السابق كما هو.')
    if not source.is_file() or source.stat().st_size>64_000_000:raise ExcelInputError('اختر ملفاً موحداً صالحاً.')
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    with zipfile.ZipFile(source) as z:
        if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128_000_000:raise ExcelInputError('ملف Excel كبير جداً.')
        registration=is_registration(z)
        if registration:check_marker(z)
        elif not is_unified(z):raise ExcelInputError('اختر الملف الموحد الذي يحتوي طريقة تسجيل الطالب.')
        rows=workbook_rows(z,'الطلاب');parts={n:z.read(n) for n in z.namelist()}
    columns=[k for k,v in rows[0][1].items() if v==ENTRY_KIND]
    if len(columns)!=1 or rows[0][2]:raise ExcelInputError('عمود طريقة تسجيل الطالب غير موجود أو مكرر.')
    letter=columns[0]
    book=ET.fromstring(parts['xl/workbook.xml']);rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    sheet=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')=='الطلاب')
    links=[r for r in rels if r.get('Id')==sheet.get(REL) and r.get('TargetMode')!='External']
    if len(links)!=1:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    target=links[0].get('Target','');part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if '..' in Path(part).parts or part not in parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    xml=parts[part].decode('utf-8');changed=0
    pattern=r'<(?P<prefix>(?:[\w.-]+:)?)dataValidation\b(?P<attrs>[^>]*)>.*?</(?P=prefix)dataValidation\s*>'
    def replace(match):
        nonlocal changed
        if not re.search(r'''\btype\s*=\s*(["'])list\1''',match['attrs']):return match[0]
        ref=re.search(r'''\bsqref\s*=\s*(["'])(.*?)\1''',match['attrs'])
        if ref is None:return match[0]
        tokens=ref[2].split()
        address=rf'\$?{letter}\$?[1-9][0-9]*(?::\$?{letter}\$?[1-9][0-9]*)?'
        if not tokens or not all(re.fullmatch(address,t) for t in tokens):return match[0]
        formula=escape('"'+','.join(KINDS)+'"')
        value,count=re.subn(r'(<(?:[\w.-]+:)?formula1\b[^>]*>).*?(</(?:[\w.-]+:)?formula1\s*>)',
                            lambda m:m[1]+formula+m[2],match[0],count=1,flags=re.S)
        if count!=1:raise ExcelInputError('قائمة طريقة التسجيل غير صالحة.')
        changed+=1;return value
    xml=re.sub(pattern,replace,xml,flags=re.S)
    if not changed:raise ExcelInputError('لم يُعثر على قائمة طريقة التسجيل؛ استخرج نموذج التسجيل الجديد.')
    if registration:
        grades=[k for k,v in rows[0][1].items() if v=='صف الطالب']
        if len(grades)!=1:raise ExcelInputError('عمود صف الطالب غير موجود أو مكرر.')
        grade=grades[0]
        # Patch validations only: no cell or namespace reserialization in filled files.
        def remove_grade(match):
            ref=re.search(r'''\bsqref\s*=\s*(["'])(.*?)\1''',match['attrs'])
            tokens=ref[2].split() if ref else []
            address=rf'\$?{grade}\$?[1-9][0-9]*(?::\$?{grade}\$?[1-9][0-9]*)?'
            if tokens and all(re.fullmatch(address,t) for t in tokens):return ''
            if any(re.fullmatch(address,t) for t in tokens):raise ExcelInputError('قائمة الصف مشتركة مع أعمدة أخرى؛ استخرج النموذج الجديد.')
            return match[0]
        xml=re.sub(pattern,remove_grade,xml,flags=re.S)
        def insert_grade(match):
            prefix=match['prefix'];body=match['body']
            last=max(501,max(n for n,_,_ in rows))
            node=f'<{prefix}dataValidation type="list" allowBlank="1" showDropDown="0" showErrorMessage="1" sqref="{grade}2:{grade}{last}"><{prefix}formula1>'+escape('"'+','.join(AFTERNOON_GRADES)+'"')+f'</{prefix}formula1></{prefix}dataValidation>'
            count=len(re.findall(r'<(?:[\w.-]+:)?dataValidation\b',body))+1
            attrs=re.sub(r'''\s+count\s*=\s*(["']).*?\1''','',match['attrs'])
            return f'<{prefix}dataValidations{attrs} count="{count}">'+body+node+f'</{prefix}dataValidations>'
        xml,n=re.subn(r'<(?P<prefix>(?:[\w.-]+:)?)dataValidations\b(?P<attrs>[^>]*)>(?P<body>.*?)</(?P=prefix)dataValidations\s*>',insert_grade,xml,flags=re.S)
        if n!=1:raise ExcelInputError('قوائم النموذج غير مكتملة.')
    ET.fromstring(xml)
    parts[part]=xml.encode('utf-8')
    if hashlib.sha256(source.read_bytes()).hexdigest()!=digest:raise ExcelInputError('تغيّر الملف؛ أغلق Excel وأعد المحاولة.')
    _write(parts,destination)


def translate_names(path):
    """Explicit local spelling suggestions only; preserve all populated cells."""
    from name_transliteration import NAME_PAIRS,suggest_english_names
    from student_unified import _insert_translations,is_unified
    path=Path(path)
    if not path.is_file() or path.stat().st_size>64_000_000:raise ExcelInputError('اختر ملف Excel صالحاً.')
    original=hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128_000_000:raise ExcelInputError('ملف Excel كبير جداً.')
        if is_registration(z):check_marker(z)
        elif not is_unified(z):raise ExcelInputError('اختر ملف التسجيل الموحد.')
        rows=workbook_rows(z,'الطلاب');parts={n:z.read(n) for n in z.namelist()}
    headers={v:k for k,v in rows[0][1].items()};by_id={f['id']:headers.get(f['label']) for f in FIELDS}
    if rows[0][2] or any(not by_id[k] for pair in NAME_PAIRS for k in pair):raise ExcelInputError('خانات الأسماء غير مكتملة.')
    proposals={}
    for number,cells,formulas in rows[1:]:
        raw={k:cells.get(by_id[k],'') for pair in NAME_PAIRS for k in pair}
        proposed=suggest_english_names(raw)
        for arabic,english in NAME_PAIRS:
            if by_id[arabic] in formulas or by_id[english] in formulas:
                raise ExcelInputError(f'الصف {number}: الأسماء قيم ثابتة دون معادلات.')
            if not str(raw[english] or '').strip() and proposed.get(english):proposals[number,by_id[english]]=proposed[english]
    if not proposals:return 0
    book=ET.fromstring(parts['xl/workbook.xml']);rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    sheet=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')=='الطلاب')
    links=[r for r in rels if r.get('Id')==sheet.get(REL) and r.get('TargetMode')!='External']
    if len(links)!=1:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    target=links[0].get('Target','');part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if '..' in Path(part).parts or part not in parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    parts[part]=_insert_translations(parts[part],proposals)
    _write(parts,path,original)
    return len(proposals)
