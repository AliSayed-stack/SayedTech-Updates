"""Real Qt layout checks with the inherited main-window theme and long data."""
import unittest
try:
    from PySide6.QtCore import QPoint
    from PySide6.QtWidgets import QApplication,QWidget
    from app import STYLE
    from detailed_dialog import DetailedImportDialog
    from test_detailed_batch_ui import Controller
    QT=True
except ImportError:
    QT=False


@unittest.skipUnless(QT,'Qt is not installed in this Python environment')
class DetailedLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])

    def setUp(self):
        self.parent=QWidget();self.parent.setStyleSheet(STYLE)
        self.controller=Controller()
        self.rows=[{'excel_row':i,'values':{'field-firstName':'اسم اختبار','field-middleName':'أب اختبار',
                   'field-lastName':'شهرة اختبار','field-enrollment-promoted-class':'السادس أساسي'},
                   'address':{'البلد':'لبنان','المحافظة':'الشمال','القضاء':'زغرتا','المنطقة':'بلدة اختبار طويلة '*25},
                   'phone':'03123456','manual':{'الهواتف / رقم الهاتف':'03123456'}} for i in range(2,26)]
        self.dialog=DetailedImportDialog(self.rows,self.controller,self.parent)
        self.dialog.show();self.settle()

    def settle(self):
        for _ in range(5):self.qt.processEvents()

    def tearDown(self):
        self.dialog.single_pending=None;self.dialog.batch.disconnect()
        self.dialog.reject();self.dialog.deleteLater();self.parent.deleteLater();self.settle()

    def inside_viewport(self,widget):
        viewport=self.dialog.body_scroll.viewport()
        origin=widget.mapTo(viewport,QPoint(0,0))
        return viewport.rect().contains(origin) and viewport.rect().contains(origin+QPoint(widget.width()-1,widget.height()-1))

    def test_table_and_all_actions_fit_normal_and_small_desktop_windows(self):
        for width,height,min_table in ((1180,780,350),(1100,740,320),(1060,550,200),(760,590,200)):
            with self.subTest(size=(width,height)):
                self.dialog.resize(width,height);self.settle()
                self.assertEqual(self.dialog.size().toTuple(),(width,height))
                self.assertGreaterEqual(self.dialog.table.height(),min_table)
                self.assertEqual(self.dialog.body_scroll.verticalScrollBar().maximum(),0)
                self.assertEqual(self.dialog.body_scroll.horizontalScrollBar().maximum(),0)
                for button in (self.dialog.import_button,self.dialog.import_review_button,
                               self.dialog.manual_save_button,self.dialog.review_button):
                    self.assertTrue(self.inside_viewport(button),button.text())
                    self.assertLessEqual(button.fontMetrics().horizontalAdvance(button.text())+20,button.width())
                self.assertLessEqual(self.dialog.close_button.geometry().bottom(),height)

    def test_very_small_window_scrolls_to_actions_and_keeps_close_accessible(self):
        self.dialog.resize(560,460);self.settle()
        self.assertEqual(self.dialog.size().toTuple(),(560,460))
        self.assertGreaterEqual(self.dialog.table.height(),210)
        bar=self.dialog.body_scroll.verticalScrollBar()
        self.assertGreater(bar.maximum(),0)
        bar.setValue(bar.maximum());self.settle()
        self.assertTrue(self.inside_viewport(self.dialog.import_button))
        self.assertTrue(self.inside_viewport(self.dialog.import_review_button))
        self.assertTrue(self.dialog.rect().contains(self.dialog.close_button.geometry()))
        self.assertEqual(self.dialog.body_scroll.horizontalScrollBar().maximum(),0)

    def test_initial_window_including_frame_fits_available_screen(self):
        self.assertTrue(self.dialog.screen().availableGeometry().contains(self.dialog.frameGeometry()))

    def test_long_summaries_and_errors_do_not_expand_window_or_hide_results_column(self):
        self.dialog.resize(1060,550);self.settle()
        size=self.dialog.size()
        self.dialog.status.setText(self.dialog.result_text('detail_management',''))
        self.dialog.row_result(0,self.dialog.result_text('detail_save_unknown',''))
        self.settle()
        self.assertEqual(self.dialog.size(),size)
        self.assertEqual(self.dialog.table.horizontalHeader().visualIndex(self.dialog.result_column),3)
        self.assertLessEqual(max(self.dialog.table.columnWidth(i) for i in range(self.dialog.table.columnCount())),300)
        self.assertTrue(self.dialog.table.item(0,self.dialog.result_column).toolTip())

    def test_help_is_collapsed_initially_and_does_not_resize_native_window(self):
        self.dialog.resize(760,590);self.settle();size=self.dialog.size()
        self.assertTrue(self.dialog.help_scroll.isHidden())
        self.dialog.help_button.click();self.settle()
        self.assertFalse(self.dialog.help_scroll.isHidden());self.assertEqual(self.dialog.size(),size)
        self.dialog.help_button.click();self.settle()
        self.assertTrue(self.dialog.help_scroll.isHidden())
        self.assertEqual(self.dialog.body_scroll.verticalScrollBar().maximum(),0)


if __name__=='__main__':unittest.main()
