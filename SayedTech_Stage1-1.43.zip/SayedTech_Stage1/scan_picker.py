"""Local roster selection: no pupil form, save or review actions."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QComboBox,QLineEdit,
    QTableWidget,QTableWidgetItem,QPushButton,QLabel,QHeaderView,QAbstractItemView)


def pupil_order(row):
    from student_scan import grade_rank,normalized,ScanError
    try:rank=grade_rank(row.get('grade',''))
    except ScanError as exc:
        if exc.code!='scan_unknown_grade':raise
        rank=1000
    return (rank,)+tuple(normalized(row.get(k,'')) for k in ('first','middle','last'))


class ScanPicker(QDialog):
    def __init__(self,choices,status_only=False,parent=None,*,ordered=False):
        super().__init__(parent)
        self.choices=choices;self.status_only=status_only;self.selection=None
        self.order=list(range(len(choices['roster'])))
        if ordered:self.order.sort(key=lambda i:pupil_order(choices['roster'][i]))
        self.setWindowTitle('اختيار حالة التسجيل' if status_only else 'اختيار التلاميذ للسحب')
        self.setLayoutDirection(Qt.RightToLeft);self.resize(900,600)
        self.setStyleSheet('QPushButton,QComboBox {padding:6px 10px;}')
        layout=QVBoxLayout(self)
        self.status=QComboBox();self.status.addItem('كل حالات التسجيل','')
        for status in sorted({r['status'] for r in choices['roster'] if r['status'].strip()}):self.status.addItem(status,status)
        self.grade=QComboBox();self.grade.addItem('كل الصفوف','')
        grades={r['grade'] for r in choices['roster']}
        if ordered:
            from student_scan import normalized
            grades=sorted(grades,key=lambda g:(pupil_order({'grade':g}),normalized(g)))
        else:grades=sorted(grades)
        for grade in grades:self.grade.addItem(grade,grade)
        self.search=QLineEdit();self.search.setPlaceholderText('بحث بالاسم أو الرقم الموحد')
        filters=QHBoxLayout();filters.addWidget(self.status)
        if not status_only:filters.addWidget(self.grade);filters.addWidget(self.search)
        layout.addLayout(filters)
        self.table=QTableWidget(len(choices['roster']),5)
        self.table.setHorizontalHeaderLabels(['اختيار','الرقم الموحد','التلميذ','الصف','حالة التسجيل'])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch)
        for i,source_index in enumerate(self.order):
            row=choices['roster'][source_index]
            values=['',row['uid'],' '.join(row[k] for k in ('first','middle','last')),row['grade'],row['status']]
            for j,value in enumerate(values):
                item=QTableWidgetItem(value);item.setToolTip(value)
                item.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
                if j==0:
                    item.setFlags(Qt.ItemIsEnabled|Qt.ItemIsUserCheckable)
                    item.setCheckState(Qt.Unchecked)
                self.table.setItem(i,j,item)
        self.table.setColumnHidden(0,status_only);layout.addWidget(self.table,1)
        controls=QHBoxLayout()
        if not status_only:
            for caption,state in (('تحديد الظاهر',Qt.Checked),('إلغاء تحديد الظاهر',Qt.Unchecked)):
                button=QPushButton(caption);button.clicked.connect(lambda _=False,s=state:self.check_visible(s));controls.addWidget(button)
        self.count=QLabel();controls.addWidget(self.count);layout.addLayout(controls)
        self.message=QLabel('السحب يشمل التلاميذ المحددين والظاهرين ضمن البحث والمرشحات الحالية فقط.' if not status_only else 'اختر حالة واحدة؛ يُسحب جميع التلاميذ الذين يحملونها وقت بدء السحب.')
        self.message.setWordWrap(True);layout.addWidget(self.message)
        buttons=QHBoxLayout();cancel=QPushButton('إلغاء');cancel.clicked.connect(self.reject)
        apply=QPushButton('اعتماد الاختيار');apply.clicked.connect(self.apply_selection)
        buttons.addWidget(cancel);buttons.addWidget(apply);layout.addLayout(buttons)
        self.status.currentIndexChanged.connect(self.filter_rows);self.grade.currentIndexChanged.connect(self.filter_rows)
        self.search.textChanged.connect(self.filter_rows);self.table.itemChanged.connect(self.update_count)
        self.filter_rows()
        screen=self.screen().availableGeometry();self.resize(min(900,screen.width()-40),min(600,screen.height()-60))

    def filter_rows(self,*_):
        from student_scan import normalized
        status,grade=self.status.currentData(),self.grade.currentData();query=normalized(self.search.text())
        for i,source_index in enumerate(self.order):
            row=self.choices['roster'][source_index]
            text=normalized(' '.join(row[k] for k in ('uid','first','middle','last')))
            visible=(not status or row['status']==status) and (self.status_only or not grade or row['grade']==grade) and (self.status_only or query in text)
            self.table.setRowHidden(i,not visible)
        self.update_count()

    def indexes(self):
        return [self.order[i] for i in range(self.table.rowCount()) if not self.table.isRowHidden(i) and
                (self.status_only or self.table.item(i,0).checkState()==Qt.Checked)]

    def update_count(self,*_):self.count.setText(f'المشمولون: {len(self.indexes())}')

    def check_visible(self,state):
        self.table.blockSignals(True)
        for i in range(self.table.rowCount()):
            if not self.table.isRowHidden(i):self.table.item(i,0).setCheckState(state)
        self.table.blockSignals(False);self.update_count()

    def apply_selection(self):
        if self.status_only:
            if not self.status.currentData():self.message.setText('اختر حالة التسجيل أولاً.');return
            self.selection={'status':self.status.currentData()}
        else:
            indexes=self.indexes()
            if not indexes:self.message.setText('حدّد تلميذاً واحداً على الأقل.');return
            self.selection={'signature':self.choices['signature'],'indexes':indexes}
        self.accept()
