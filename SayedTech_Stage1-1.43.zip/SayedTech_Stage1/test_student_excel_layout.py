"""Compact database/unified output preserves cells and all native Excel features."""
from contextlib import closing
from datetime import datetime
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

from openpyxl import load_workbook
import core
from student_excel import NS
from student_excel_layout import apply_student_dimensions
from nsldb_reference import map_records,write_reference,source_sheets,TARGET_YEAR,canonical_year
from student_detailed import convert_to_detailed
import test_nsldb as fixtures


class CompactStudentExcelTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name)
        self.tables=fixtures.tables();self.records=map_records(self.tables)
        self.source_data=source_sheets(self.tables,threading.Event())
        self.site=load_workbook(core.ASSET_BASE/'assets/student_with_addresses.xlsx')
        self.reference=self.site.worksheets[0]

    def tearDown(self):self.site.close();self.tmp.cleanup()

    def output(self,name,mode='detailed',academic=False):
        path=self.folder/name
        records=self.records if not academic else [r for r in self.records if canonical_year(r['metadata'][2])==TARGET_YEAR]
        with patch('nsldb_reference.datetime') as clock:
            clock.now.return_value=datetime(2026,10,24,0,0)
            write_reference(records,path,'TEST.sdf','0'*64,[],source_data=self.source_data,
                            mode=mode,academic_year=TARGET_YEAR if academic else None)
        return path

    def assert_compact(self,path):
        with closing(load_workbook(path)) as book:
            sheet=book.worksheets[0]
            self.assertEqual(sheet.row_dimensions[1].height,self.reference.row_dimensions[1].height)
            self.assertEqual(sheet.sheet_format.defaultRowHeight,self.reference.row_dimensions[2].height)
            for row in list(sheet.rows)[1:]:
                self.assertEqual(sheet.row_dimensions[row[0].row].height,self.reference.row_dimensions[2].height)
                for cell in row:
                    self.assertEqual(cell.font.sz,11)
                    self.assertFalse(cell.font.b)
            reference={cell.value:self.reference.column_dimensions[cell.column_letter].width for cell in self.reference[1] if cell.value}
            for cell in sheet[1]:
                if cell.value in reference:
                    self.assertEqual(sheet.column_dimensions[cell.column_letter].width,reference[cell.value],cell.value)

    def unchanged_except_dimensions(self,before,after):
        with zipfile.ZipFile(before) as old,zipfile.ZipFile(after) as new:
            self.assertEqual(old.namelist(),new.namelist())
            self.assertIsNone(new.testzip())
            for name in old.namelist():
                if name!='xl/worksheets/sheet1.xml':
                    self.assertEqual(old.read(name),new.read(name),name)
            def without_dimensions(data):
                sheet=ET.fromstring(data);sheet.remove(sheet.find('m:cols',NS))
                sheet.find('m:sheetFormatPr',NS).attrib.pop('defaultRowHeight',None)
                for row in sheet.findall('m:sheetData/m:row',NS):
                    for attribute in ('ht','customHeight'):row.attrib.pop(attribute,None)
                return ET.tostring(sheet)
            self.assertEqual(without_dimensions(old.read('xl/worksheets/sheet1.xml')),
                             without_dimensions(new.read('xl/worksheets/sheet1.xml')))

    def test_all_database_modes_and_school_year_use_site_dimensions_without_changing_other_content(self):
        self.records[0]['details'][-1]='\n'.join('ملاحظة اختبار كاملة' for _ in range(40))
        for mode,academic in (('simple',False),('reference',False),('detailed',False),('detailed',True)):
            with self.subTest(mode=mode,academic=academic):
                with patch('student_excel_layout.apply_student_dimensions',lambda *_:None):
                    old=self.output('before.xlsx',mode,academic)
                new=self.output('after.xlsx',mode,academic)
                self.assert_compact(new);self.unchanged_except_dimensions(old,new)

    def test_unified_and_legacy_detail_match_common_field_and_address_widths_without_changing_data(self):
        source=self.output('source.xlsx')
        for unified in (False,True):
            with self.subTest(unified=unified):
                old=self.folder/'old.xlsx';new=self.folder/'new.xlsx'
                with patch('student_excel_layout.apply_student_dimensions',lambda *_:None):
                    convert_to_detailed(source,old,unified=unified)
                convert_to_detailed(source,new,unified=unified)
                self.assert_compact(new);self.unchanged_except_dimensions(old,new)
                with closing(load_workbook(new)) as book:
                    sheet=book.worksheets[0];by_name={c.value:c.column_letter for c in sheet[1]}
                    for source_name,site_name in (('بلد السكن','البلد'),('تفاصيل العنوان','تفاصيل العنوان ١'),('نوع السكن','النوع')):
                        site_cell=next(c for c in self.reference[1] if c.value==site_name)
                        self.assertEqual(sheet.column_dimensions[by_name[source_name]].width,
                                         self.reference.column_dimensions[site_cell.column_letter].width)

    def test_dimension_only_helper_preserves_row_visibility_and_spanned_column_flags(self):
        q=lambda n:'{'+NS['m']+'}'+n
        sheet=ET.Element(q('worksheet'));ET.SubElement(sheet,q('sheetFormatPr'),defaultRowHeight='15')
        cols=ET.SubElement(sheet,q('cols'))
        ET.SubElement(cols,q('col'),min='1',max='3',width='65',hidden='1',outlineLevel='1')
        body=ET.SubElement(sheet,q('sheetData'))
        ET.SubElement(body,q('row'),r='1',ht='65')
        ET.SubElement(body,q('row'),r='2',ht='400',hidden='1')
        apply_student_dimensions(sheet,['بلد السكن','تفاصيل العنوان'])
        columns=sheet.findall('m:cols/m:col',NS)
        self.assertEqual([c.get('width') for c in columns],['17','50','65'])
        self.assertTrue(all(c.get('hidden')=='1' and c.get('outlineLevel')=='1' for c in columns))
        self.assertEqual(body[1].get('hidden'),'1');self.assertEqual(body[1].get('ht'),'23')


if __name__=='__main__':unittest.main()
