"""Exercise the actual import locators against the supplied/adapted HTML tree."""
import re
from pathlib import Path
from lxml import html
import unittest
from manual_sections import fill_manual_section,MOTHER_SURNAME

ROOT=Path(__file__).parent/'test_fixtures'


class Locator:
    def __init__(self,page,nodes):self.page,self.nodes=page,nodes
    def count(self):return len(self.nodes)
    def wait_for(self,**kw):
        if not self.nodes:raise RuntimeError('missing fixture field')
    def is_visible(self):return bool(self.nodes)
    def is_enabled(self):return self.count()==1 and self.nodes[0].get('disabled') is None
    def filter(self,has=None,**kw):return Locator(self.page,[n for n in self.nodes if any(x is n or n in x.iterancestors() for x in has.nodes)])
    def locator(self,selector):
        if selector.startswith('xpath='):xpath=selector[6:]
        elif selector=='input[type="file"]':xpath='.//input[@type="file"]'
        elif selector.startswith('#'):xpath='.//*[@id="'+selector[1:]+'"]'
        elif selector=='input,select,textarea':xpath='.//*[self::input or self::select or self::textarea]'
        else:raise AssertionError(selector)
        found=[]
        for n in self.nodes:
            for e in n.xpath(xpath):
                if e not in found:found.append(e)
        return Locator(self.page,found)
    def get_by_role(self,role,name,**kw):
        found=[]
        for n in self.nodes:
            for e in n.iterdescendants():
                if ((role=='heading' and e.tag in ('h1','h2','h3','h4')) or (role=='button' and e.tag=='button')) and e.text_content().strip()==name:found.append(e)
        return Locator(self.page,found)
    def get_by_text(self,pattern,**kw):
        match=lambda e: bool(pattern.search(e.text_content().strip())) if hasattr(pattern,'search') else e.text_content().strip()==pattern
        found=[]
        for n in self.nodes:
            found.extend(e for e in n.iterdescendants() if match(e) and not any(match(c) for c in e if isinstance(c.tag,str)))
        return Locator(self.page,found)
    def get_by_label(self,pattern):
        found=[]
        for n in self.nodes:
            for label in n.xpath('.//label[@for]'):
                text=label.text_content().strip()
                if (pattern.search(text) if hasattr(pattern,'search') else text==pattern):
                    found.extend(n.xpath('.//*[@id=$id]',id=label.get('for')))
        return Locator(self.page,found)
    def input_value(self):
        n=self.nodes[0]
        if n.tag=='select':
            opts=n.xpath('.//option[@selected]') or n.xpath('.//option')[:1]
            return opts[0].get('value','') if opts else ''
        return n.text or '' if n.tag=='textarea' else n.get('value','')
    def evaluate(self,script):
        n=self.nodes[0]
        return dict(tag=n.tag.upper(),type=n.get('type','text'),readonly=n.get('readonly') is not None,
                    value=self.input_value(),checked=n.get('checked') is not None,
                    options=[dict(value=o.get('value',''),label=o.text_content().strip(),disabled=o.get('disabled') is not None) for o in n.xpath('.//option')])
    def click(self,**kw):
        self.page.actions.append(('click',self.nodes[0].text_content().strip()))
        if hasattr(self.page,'after_click'):self.page.after_click(self.nodes[0])
    def fill(self,value,**kw):
        n=self.nodes[0]
        if n.tag=='textarea':n.text=value
        else:n.set('value',value)
        self.page.actions.append(('fill',n.get('id',''),value))
    def select_option(self,value,**kw):
        for o in self.nodes[0].xpath('.//option'):
            o.attrib.pop('selected',None)
            if o.get('value')==value:o.set('selected','')
        self.page.actions.append(('select',value))
    def set_checked(self,value,**kw):
        n=self.nodes[0];n.attrib.pop('checked',None)
        if value:n.set('checked','')
        self.page.actions.append(('check',value))
    def is_checked(self):return self.nodes[0].get('checked') is not None


class Page(Locator):
    def __init__(self,name):
        self.doc=html.fromstring((ROOT/name).read_text());self.actions=[]
        super().__init__(self,[self.doc])
    def locator(self,selector):
        if selector=='section':return Locator(self,self.doc.xpath('.//section'))
        return super().locator(selector)
    def get_by_role(self,role,name,**kw):
        if role in ('tab','radio'):return Locator(self,[html.fromstring('<button>'+name+'</button>')])
        return super().get_by_role(role,name,**kw)


class SiteBindingsTests(unittest.TestCase):
    def test_dynamic_phone_email_mother_and_document_fields_bind_to_their_section(self):
        cases=[('phones_site.html','الهواتف',{'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True}),
               ('email_site.html','البريد الإلكتروني',{'البريد الإلكتروني / البريد الإلكتروني':'fixture@example.invalid','البريد الإلكتروني / النوع':'مدرسي','البريد الإلكتروني / الأساسية':True}),
               ('relatives_scan_site.html','الأقارب',{MOTHER_SURNAME:'MOTHER_SURNAME'}),
               ('identity_site.html','بطاقات التعريف',{'بطاقات التعريف / نوع المستند':'جواز سفر','بطاقات التعريف / رقم الوثيقة':'001234','بطاقات التعريف / تاريخ الإصدار':'2020-01-02','بطاقات التعريف / تاريخ الإنتهاء':'2030-01-02'}),
               ('documents_site.html','المستندات',{'المستندات / نوع المستند':'بطاقة تلقيح','المستندات / رقم الوثيقة':'00007','المستندات / ملاحظة':'TEST NOTE','المستندات / جرى التسليم':True,'المستندات / طباعة على اللائحة':False}),
               ('registration_site.html','حالة التسجيل',{'حالة التسجيل / الحالة الحالية':'قيد الانتظار','حالة التسجيل / ملاحظة (اختياري)':'TEST NOTE'})]
        for name,title,payload in cases:
            with self.subTest(title=title):
                page=Page(name)
                # The importer must follow labels after a React id changes.
                for n in page.doc.xpath('.//*[@id]'):
                    old=n.get('id');n.set('id','changed_'+old)
                    for l in page.doc.xpath('.//label[@for=$id]',id=old):l.set('for','changed_'+old)
                self.assertEqual(fill_manual_section(page,{'manual':payload},title,lambda:None),'detail_filled')
                self.assertTrue(any(a[0] in ('fill','check','select') for a in page.actions))
                self.assertFalse(any(a[0]=='click' and a[1] in ('حفظ','حفظ القسم','إرسال للمراجعة') for a in page.actions))
                if title=='حالة التسجيل':
                    terminate=page.doc.xpath('.//input[@id="changed_terminate-registration"]')[0]
                    self.assertIsNone(terminate.get('checked'))


if __name__=='__main__':unittest.main()
