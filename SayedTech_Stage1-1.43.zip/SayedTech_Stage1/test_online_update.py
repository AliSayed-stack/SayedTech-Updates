import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile

import online_update
import update_apply
from update_apply import apply_source


class Response(io.BytesIO):
    def geturl(self):return 'https://example.org/latest.json'


class UpdateTests(unittest.TestCase):
    def source_archive(self, path, version='0.65'):
        with ZipFile(path, 'w') as z:
            z.writestr('SayedTech_Stage1/core.py', "APP_VERSION = '"+version+"'\n")
            z.writestr('SayedTech_Stage1/START_WINDOWS.bat', '@echo off\n')
            z.writestr('SayedTech_Stage1/feature.py', 'new')

    def test_https_version_and_manifest_validation(self):
        with self.assertRaises(online_update.UpdateError):online_update.https_url('http://example.org/latest.json')
        manifest = {'version': '0.65', 'source': {'url': 'https://example.org/release.zip', 'sha256': 'a'*64}}
        with patch.object(online_update, '_open_https', return_value=Response(json.dumps(manifest).encode())):
            release=online_update.check_release('https://example.org/latest.json','0.64')
        self.assertEqual(release['version'],'0.65')
        self.assertEqual(release['kind'],'source')
        manifest['version']='0.64'
        with patch.object(online_update, '_open_https', return_value=Response(json.dumps(manifest).encode())):
            self.assertIsNone(online_update.check_release('https://example.org/latest.json','0.64'))

    def test_download_verifies_digest_and_extracts_safe_source(self):
        with tempfile.TemporaryDirectory() as work:
            root=Path(work);archive=root/'release.zip';self.source_archive(archive)
            contents=archive.read_bytes()
            release={'kind':'source','url':'https://example.org/release.zip','sha256':hashlib.sha256(contents).hexdigest(),'version':'0.65'}
            with patch.object(online_update,'settings_path',return_value=root/'settings.json'), \
                 patch.object(online_update,'_open_https',return_value=Response(contents)):
                stage=online_update.download_release(release)
            self.assertTrue((stage/'extracted/SayedTech_Stage1/feature.py').is_file())
            release['sha256']='0'*64
            with patch.object(online_update,'settings_path',return_value=root/'settings.json'), \
                 patch.object(online_update,'_open_https',return_value=Response(contents)):
                with self.assertRaisesRegex(online_update.UpdateError,'التحقق'):online_update.download_release(release)

    def test_download_retries_windows_tls_when_python_transfer_fails(self):
        with tempfile.TemporaryDirectory() as work:
            root=Path(work);archive=root/'release.zip';self.source_archive(archive)
            contents=archive.read_bytes()
            release={'kind':'source','url':'https://github.com/example/release.zip',
                     'sha256':hashlib.sha256(contents).hexdigest(),'version':'0.65'}
            def powershell_retry(url, destination, first_error):
                destination.write_bytes(contents)
            with patch.object(online_update,'settings_path',return_value=root/'settings.json'), \
                 patch.object(online_update,'_open_https',side_effect=OSError('synthetic Python TLS failure')), \
                 patch.object(online_update,'_powershell_download',side_effect=powershell_retry) as retry, \
                 patch.object(online_update.sys,'platform','win32'):
                stage=online_update.download_release(release)
            retry.assert_called_once()
            self.assertTrue((stage/'extracted/SayedTech_Stage1/feature.py').is_file())

    def test_apply_keeps_local_environment_and_replaces_source(self):
        with tempfile.TemporaryDirectory() as work:
            root=Path(work);staged=root/'stage';target=root/'app'
            staged.mkdir();target.mkdir()
            for folder in (staged,target):(folder/'START_WINDOWS.bat').write_text('start')
            (staged/'core.py').write_text('new')
            (target/'core.py').write_text('old')
            (target/'.venv').mkdir();(target/'.venv/python.exe').write_text('local')
            apply_source(staged,target,root/'backup')
            self.assertEqual((target/'core.py').read_text(),'new')
            self.assertEqual((target/'.venv/python.exe').read_text(),'local')

    def test_archive_refuses_traversal(self):
        with tempfile.TemporaryDirectory() as work:
            root=Path(work);archive=root/'bad.zip'
            with ZipFile(archive,'w') as z:
                z.writestr('SayedTech_Stage1/../escape.py','bad')
            with self.assertRaises(online_update.UpdateError):online_update.extract_source(archive,root/'out','0.65')
            self.assertFalse((root/'escape.py').exists())

    def test_failed_second_replacement_restores_first_file(self):
        with tempfile.TemporaryDirectory() as work:
            root=Path(work);staged=root/'stage';target=root/'app'
            staged.mkdir();target.mkdir()
            for folder in (staged,target):
                (folder/'START_WINDOWS.bat').write_text('start')
                (folder/'a.py').write_text('new' if folder == staged else 'old')
            original=update_apply.os.replace
            calls=0
            def fail_second(source,destination):
                nonlocal calls
                calls+=1
                if calls == 2:raise OSError('synthetic failure')
                return original(source,destination)
            with patch.object(update_apply.os,'replace',side_effect=fail_second):
                with self.assertRaises(OSError):apply_source(staged,target,root/'backup')
            self.assertEqual((target/'START_WINDOWS.bat').read_text(),'start')
            self.assertEqual((target/'a.py').read_text(),'old')
