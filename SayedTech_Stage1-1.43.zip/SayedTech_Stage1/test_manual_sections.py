import copy
from collections import Counter
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile
from openpyxl import load_workbook

from manual_sections import SPECS, HEADERS, SELECT, SECTIONS,MOTHER_SURNAME,TAIL_HEADERS, observed_values, fill_manual_section
from student_scan import TABS, FORM_SCRIPT, TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT, collect_students, export_students
from detailed_import import read_details, DetailError
from student_excel import ExcelInputError
from test_scan import Page,Clock


class FastPage(Page):
    def __init__(self):
        super().__init__(1);self.fast_reads=Counter();self.fast_waits=0
    def wait_for_timeout(self,*args):
        if self.view=='record' and self.mode=='detailed' and self.tab in TABS[3:]:self.fast_waits+=1
    def evaluate(self,script,*args):
        if script==SETTLED_TAB_SCRIPT and args[0] in TABS[3:]:
            title=args[0];self.fast_reads[title]+=1
            if title=='المستندات':return {'found':True,'loading':True}
            label,value={'الهواتف':('رقم الهاتف','03123456'),
                         'البريد الإلكتروني':('البريد الإلكتروني','school@example.invalid'),
                         'بطاقات التعريف':('رقم الوثيقة','00123'),
                         'الأقارب':('الشهرة (بالعربية)','MOTHER'),
                         'حالة التسجيل':('الحالة الحالية','قيد الانتظار')}[title]
            return {'found':True,'text':label+'\n'+value,'fields':[
                dict(id='',label=label,value=value,group='الأقارب #2' if title=='الأقارب' else '',required=False,kind='display')]}
        return super().evaluate(script,*args)


class ManualWorkbookTests(unittest.TestCase):
    def data(self):
        page=FastPage()
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        return page,data

    def test_one_read_no_wait_or_write_after_address_and_existing_values_project(self):
        page,data=self.data()
        self.assertEqual(page.fast_reads,Counter({t:1 for t in SECTIONS}))
        self.assertEqual(page.fast_waits,0)
        values=observed_values(data['records'][0])
        self.assertEqual(values['الهواتف / رقم الهاتف'],'03123456')
        self.assertEqual(values['بطاقات التعريف / رقم الوثيقة'],'00123')
        self.assertEqual(values[MOTHER_SURNAME],'MOTHER')
        self.assertFalse(any('حفظ' in str(a) or 'إضافة' in str(a) or a[0] in ('fill','select') for a in page.actions))

    def test_export_edit_and_import_same_scan_preserves_ids_and_selected_rows(self):
        _,data=self.data()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'scan.xlsx';export_students(data,path,threading.Event())
            book=load_workbook(path);sheet=book['الطلاب']
            headers={c.value:c.column for c in sheet[1]}
            self.assertEqual(sheet['A1'].value,SELECT)
            self.assertEqual([c.value for c in sheet[1]][37:],TAIL_HEADERS[1:])
            self.assertEqual(sheet.cell(2,headers['الهواتف / رقم الهاتف']).value,'03123456')
            self.assertEqual(sheet.cell(2,headers['بطاقات التعريف / رقم الوثيقة']).value,'00123')
            self.assertNotIn('المستندات / مسار الملف',headers)
            self.assertNotIn('بطاقات التعريف / مسار الملف',headers)
            with self.assertRaises(ExcelInputError):read_details(path)
            sheet.cell(2,headers[SELECT]).value='1'
            sheet.cell(2,headers['البريد الإلكتروني / البريد الإلكتروني']).value='manual@example.invalid'
            book.save(path);book.close()
            row=read_details(path)[0]
            self.assertEqual(row['manual']['البريد الإلكتروني / البريد الإلكتروني'],'manual@example.invalid')
            self.assertEqual(row['manual']['الهواتف / رقم الهاتف'],'03123456')
            self.assertEqual(row['values']['field-existingUniqueId'],data['records'][0]['item']['uid'])
            book=load_workbook(path);sheet=book['الطلاب']
            sheet.cell(2,headers['الهواتف / رقم الهاتف']).value='=1+1'
            book.save(path);book.close()
            with self.assertRaisesRegex(ExcelInputError,'قيماً ثابتة'):read_details(path)

    def test_ambiguous_multiple_saved_records_never_choose_arbitrary_phone(self):
        r={'fields':[dict(section='الهواتف',label='رقم الهاتف',value=v,group='') for v in ('03123456','03123457')]}
        self.assertNotIn('الهواتف / رقم الهاتف',observed_values(r))


class Control:
    def __init__(self,page,key):self.page,self.key=page,key
    def count(self):return 0 if self.key=='empty' else 1
    def is_visible(self):return True
    def is_enabled(self):return True
    def wait_for(self,**kw):pass
    def click(self,**kw):self.page.actions.append(('click',self.key))
    def filter(self,**kw):return self
    def get_by_text(self,*a,**kw):return Control(self.page,'empty')
    def get_by_role(self,role,name,**kw):return Control(self.page,name)
    def get_by_label(self,pattern):
        names=[s['label'] for s in SPECS if s['section']==self.page.title]
        return Control(self.page,next(n for n in names if pattern.search(n)))
    def evaluate(self,script):
        return dict(tag='SELECT' if self.key in ('النوع','رمز الدولة','نوع المستند','الحالة') else 'INPUT',
                    type='text',readonly=self.page.readonly,value=self.page.values.get(self.key,''),
                    options=[dict(value=v,label=label,disabled=False) for v,label in self.page.options.get(self.key,[])])
    def fill(self,value,**kw):self.page.values[self.key]=value;self.page.actions.append(('fill',self.key,value))
    def select_option(self,value,**kw):self.fill(value,**kw)
    def input_value(self):return self.page.values.get(self.key,'')


class ManualPage:
    def __init__(self,title):
        self.title=title;self.actions=[];self.values={};self.options={};self.readonly=False
    def get_by_role(self,role,name,**kw):return Control(self,name)
    def locator(self,selector):return Control(self,'scope')


class ManualDraftTests(unittest.TestCase):
    def test_email_phone_and_identity_bindings_fill_one_section_without_save(self):
        for title,label,value,options in [('البريد الإلكتروني','البريد الإلكتروني','school@example.invalid',{}),
                   ('الهواتف','رقم الهاتف','03123456',{}),
                   ('بطاقات التعريف','نوع المستند','هوية',{'نوع المستند':[('identity','هوية')]}),
                   ('حالة التسجيل','ملاحظة (اختياري)','TEST NOTE',{})]:
            page=ManualPage(title);page.options=options
            header=next(s['header'] for s in SPECS if s['section']==title and s['label']==label)
            result=fill_manual_section(page,{'manual':{header:value}},title,lambda:None)
            self.assertEqual(result,'detail_filled')
            self.assertEqual(page.values[label],options[label][0][0] if options else value)
            self.assertFalse(any(a[0]=='click' and ('حفظ' in a[1] or 'إرسال' in a[1]) for a in page.actions))

    def test_existing_conflict_and_readonly_status_stop_before_writes(self):
        page=ManualPage('البريد الإلكتروني');page.values['البريد الإلكتروني']='existing@example.invalid'
        with self.assertRaises(DetailError):
            fill_manual_section(page,{'manual':{'البريد الإلكتروني / البريد الإلكتروني':'other@example.invalid'}},page.title,lambda:None)
        self.assertFalse(any(a[0]=='fill' for a in page.actions))
        page=ManualPage('حالة التسجيل');page.readonly=True
        with self.assertRaises(DetailError):
            fill_manual_section(page,{'manual':{'حالة التسجيل / ملاحظة (اختياري)':'NOTE'}},page.title,lambda:None)
        self.assertFalse(any(a[0]=='fill' for a in page.actions))


if __name__=='__main__':unittest.main()
