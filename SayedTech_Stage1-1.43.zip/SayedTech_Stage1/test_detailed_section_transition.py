"""Exercise actual phone bindings after a preceding section's save transition."""
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from lxml import html
from detailed_import import DetailError,fill_details,fill_verified_section
from test_manual_site_bindings import Page as HtmlPage


class TransitionPage(HtmlPage):
    def __init__(self):
        super().__init__('phones_local_site.html')
        self.url='https://new-sims.mehe.gov.lb/dashboard/students/management/verified-student'
        self.clock=0;self.reloaded=0
        self.identity={'field-firstName':'اسم اختبار','field-middleName':'أب اختبار',
                       'field-lastName':'شهرة اختبار','field-birthDate':'2015-01-02',
                       'field-existingUniqueId':'verified-system-id'}
        self.restore_personal()

    def restore_personal(self):
        for key,value in self.identity.items():
            existing=self.doc.xpath('.//input[@id=$id]',id=key)
            if existing:existing[0].set('value',value)
            else:
                field=html.Element('input',id=key,value=value);self.doc.append(field)

    def after_address_save(self):
        # A stale/edit-locked phone form must not be used after the prior save.
        self.doc.xpath('.//input[@maxlength="8"]')[0].set('readonly','')
        for field in self.doc.xpath('.//input[starts-with(@id,"field-")]'):field.getparent().remove(field)

    def goto(self,url,**kwargs):
        self.actions.append(('reload',url));self.url=url;self.reloaded+=1
        self.doc.xpath('.//input[@maxlength="8"]')[0].attrib.pop('readonly',None)
        self.restore_personal()

    def wait_for_timeout(self,ms):self.clock+=ms/1000


class SectionTransitionTests(unittest.TestCase):
    def row(self,page):
        return {'values':dict(page.identity),'address':{'البلد':'لبنان','المحافظة':'الشمال','القضاء':'زغرتا','المنطقة':'بلدة اختبار'},
                'manual':{'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'961 (LB)',
                          'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True}}

    def invoke(self,page,row,review=False):
        session=SimpleNamespace(revoked=False,allows=lambda *_:True)
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock),patch('manual_sections.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,'details_import_review' if review else 'details_import',
                                'school@te.mehe.school',threading.Event(),session)

    def test_automatic_phone_reopens_verified_student_and_fills_real_local_form(self):
        for review in (False,True):
            page=TransitionPage();row=self.row(page)
            def section(page,row,section,guard,**kwargs):
                if section=='address':
                    page.actions.append(('saved','address'));page.after_address_save();return 'detail_saved'
                return fill_verified_section(page,row,section,guard,**kwargs)
            with patch('detailed_import.fill_verified_section',side_effect=section),patch('manual_save.save_manual',return_value='detail_saved') as saved,patch('manual_save.send_review',return_value='detail_review_sent') as sent:
                result=self.invoke(page,row,review)
            self.assertEqual(result,'detail_import_review_sent' if review else 'detail_import_saved')
            self.assertEqual(page.doc.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')
            self.assertIn(('select','mobile'),page.actions)
            self.assertIn(('check',True),page.actions)
            saved.assert_called_once();self.assertEqual(sent.call_count,int(review))
            self.assertGreaterEqual(page.reloaded,1)
            self.assertEqual(row['values']['field-existingUniqueId'],'verified-system-id')

    def test_uncertain_address_save_never_reloads_discards_draft_or_attempts_phone(self):
        page=TransitionPage();row=self.row(page)
        with patch('detailed_import.fill_verified_section',return_value='detail_save_unknown'),patch('manual_save.send_review') as sent,self.assertRaises(DetailError):self.invoke(page,row,True)
        self.assertEqual(page.reloaded,0);sent.assert_not_called()
        self.assertEqual(page.doc.xpath('.//input[@maxlength="8"]')[0].get('value'),'')

    def test_old_excel_uid_is_not_reused_after_roster_verified_current_uid(self):
        page=TransitionPage();row=self.row(page)
        row['values']['field-existingUniqueId']='old-source-id'
        verified_url=page.url;page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        def open_student(*args):page.url=verified_url;return 'verified-system-id'
        def section(page,row,section,guard,**kwargs):
            if section=='address':page.after_address_save();return 'detail_saved'
            return fill_verified_section(page,row,section,guard,**kwargs)
        with patch('detailed_import.open_existing_detail_student',side_effect=open_student) as opened,patch('detailed_import.fill_verified_section',side_effect=section),patch('manual_save.save_manual',return_value='detail_saved'):
            self.assertEqual(self.invoke(page,row),'detail_import_saved')
        opened.assert_called_once()
        self.assertEqual(page.doc.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')
        self.assertEqual(row['values']['field-existingUniqueId'],'old-source-id')

    def test_reload_of_another_student_fails_identity_before_phone_entry(self):
        page=TransitionPage();row=self.row(page);original=page.goto
        def wrong_identity(*args,**kwargs):
            original(*args,**kwargs)
            page.doc.xpath('.//input[@id="field-birthDate"]')[0].set('value','2014-01-02')
        page.goto=wrong_identity
        def section(page,row,section,guard,**kwargs):
            if section=='address':page.after_address_save();return 'detail_saved'
            return fill_verified_section(page,row,section,guard,**kwargs)
        with patch('detailed_import.fill_verified_section',side_effect=section),patch('manual_save.send_review') as sent,self.assertRaises(DetailError) as error:self.invoke(page,row,True)
        self.assertEqual(error.exception.code,'detail_birth_mismatch');sent.assert_not_called()
        self.assertEqual(page.doc.xpath('.//input[@maxlength="8"]')[0].get('value'),'')


if __name__=='__main__':unittest.main()
