"""Visible-UI-only attendance export/import with guarded, confirmed saves."""
from datetime import datetime
import json
import math
import os
from pathlib import Path
import re
import tempfile
import time
from urllib.parse import urlsplit
import zipfile

from attendance_schema import (AttendanceError,REASONS,SUCCESS_TEXT,account_key,
                               validate_absence,resolve_pupil,pupil_option)
from login_flow import exact_https_host,SIMS_HOST,visible
from student_fill import MANAGEMENT
from student_scan import StudentBrowser,ScanError,normalized,is_deleted,canonical_uid

ATTENDANCE='/dashboard/students/attendance'
ABSENCE_LIST_SCRIPT='''() => {
 const tables=[...document.querySelectorAll('table')].filter(e=>e.getClientRects().length);
 return {tables:tables.map(t=>({headers:[...t.querySelectorAll('thead th')].map(x=>x.innerText.trim()),
 rows:[...t.querySelectorAll('tbody tr')].filter(r=>!r.querySelector('td[colspan]')).map(r=>[...r.querySelectorAll('td')].map(c=>c.innerText.trim()))})),
 pagers:[...document.querySelectorAll('p')].filter(e=>e.getClientRects().length&&e.innerText.includes('سجل إجمالاً')).map(e=>e.innerText),
 busy:[...document.querySelectorAll('[aria-busy="true"]')].some(e=>e.getClientRects().length)};
}'''
TABLE_HEADERS=['الطالب','الرقم الموحّد','من','إلى','الأيام','السبب','ملاحظات']


def unique(locator):
    if locator.count()!=1 or not locator.is_visible():raise AttendanceError('attendance_options')
    return locator


def possible_dates(value):
    result=set()
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%m/%d/%Y','%d/%m/%Y','%d-%m-%Y'):
        try:result.add(datetime.strptime(value.strip(),fmt).date().isoformat())
        except (ValueError,AttributeError):pass
    if not result:raise AttendanceError('attendance_options')
    return result


def has_overlap(rows,record):
    start,end=record['start'],record['end'] or record['start']
    for cells in rows:
        if len(cells)!=7:raise AttendanceError('attendance_options')
        # Ambiguous display dates are checked conservatively in both orders;
        # never silently reverse an ambiguous date and add a duplicate absence.
        begins=possible_dates(cells[2]);ends=possible_dates(cells[3] or cells[2])
        if any(a<=end and b>=start for a in begins for b in ends if a<=b):return True
    return False


class AttendanceRunner:
    def __init__(self):
        self.token=None;self.rosters={};self.saved=set();self.uncertain=set()

    def guard(self):
        if self.cancelled.is_set() or not exact_https_host(self.page.url,SIMS_HOST):raise AttendanceError('attendance_account')
        if self.account_session is not None and self.account_session.revoked:raise AttendanceError('attendance_account')
        account=visible(self.page.get_by_text(re.compile(r'^\s*'+re.escape(self.username)+r'\s*$',re.I)))
        if account is None and not (self.account_session and self.account_session.allows(self.page,self.username)):
            raise AttendanceError('attendance_account')
        path=urlsplit(self.page.url).path.rstrip('/')
        if not path.startswith('/dashboard/') or (self.expected_path is not None and path!=self.expected_path):
            raise AttendanceError('attendance_account')

    def bind(self,page,username,cancelled,account_session):
        self.page,self.username,self.cancelled,self.account_session=page,username,cancelled,account_session
        self.expected_path=None
        self.guard()

    def go(self,path):
        self.guard()
        if self.page.locator('.print-area-modal').count() and visible(self.page.locator('.print-area-modal')):
            raise AttendanceError('attendance_options')
        self.expected_path=None
        self.page.goto('https://'+SIMS_HOST+path,wait_until='domcontentloaded',timeout=20000)
        if urlsplit(self.page.url).path.rstrip('/')!=path:raise AttendanceError('attendance_account')
        self.expected_path=path
        self.guard()

    def roster(self,grade=None):
        self.go(MANAGEMENT)
        try:return StudentBrowser(self.page,self.username,self.cancelled,account_session=self.account_session).inventory(lambda *_:None,grade=grade)
        except ScanError as exc:raise AttendanceError('attendance_account' if exc.code=='scan_account_required' else 'attendance_options') from None

    def export_template(self,page,username,cancelled,path,account_session=None):
        self.bind(page,username,cancelled,account_session)
        roster=self.roster()
        if any(not str(r.get('status','')).strip() for r in roster):raise AttendanceError('attendance_options')
        pupils=[r for r in roster if not is_deleted(r)]
        if not pupils:raise AttendanceError('attendance_identity')
        self.guard()
        from attendance_excel import write_attendance
        write_attendance(path,pupils,username)
        self.go(ATTENDANCE)
        return 'attendance_template_saved',len(pupils)

    def export_existing(self,page,username,cancelled,path,account_session=None):
        self.bind(page,username,cancelled,account_session)
        if urlsplit(page.url).path.rstrip('/')!=ATTENDANCE:self.go(ATTENDANCE)
        target=Path(path)
        import core
        if target.suffix.lower()!='.xlsx' or (core.ASSET_BASE/'assets').resolve() in target.resolve().parents:
            raise AttendanceError('attendance_input')
        temporary=None
        try:
            button=unique(page.get_by_role('button',name='تصدير إلى Excel',exact=True))
            self.guard()
            with page.expect_download(timeout=20000) as download:button.click(timeout=5000)
            with tempfile.NamedTemporaryFile(dir=target.parent,suffix='.xlsx',delete=False) as f:temporary=Path(f.name)
            download.value.save_as(str(temporary));self.guard()
            if temporary.stat().st_size>64_000_000:raise AttendanceError('attendance_options')
            with zipfile.ZipFile(temporary) as archive:
                if len(archive.infolist())>1000 or sum(i.file_size for i in archive.infolist())>128_000_000 or archive.testzip():
                    raise AttendanceError('attendance_options')
                if 'xl/workbook.xml' not in archive.namelist():raise AttendanceError('attendance_options')
            os.replace(temporary,target)
            return 'attendance_exported',0
        finally:
            if temporary:temporary.unlink(missing_ok=True)

    def wait(self,read,seconds=10):
        end=time.monotonic()+seconds;last=None;since=None
        while True:
            self.guard()
            try:value=read()
            except AttendanceError:value=None
            if value is not None:
                if value!=last:last=value;since=time.monotonic()
                elif time.monotonic()-since>=.7:return value
            if time.monotonic()>=end:raise AttendanceError('attendance_options')
            self.page.wait_for_timeout(100)

    def scope(self):
        return unique(self.page.locator('.print-area-modal').filter(has=self.page.get_by_role('heading',name='تسجيل غياب',exact=True)))

    def filter_scope(self):
        return unique(self.page.locator('div.rounded-xl').filter(has=self.page.get_by_role('heading',name='تصفية',exact=True)))

    def field_button(self,scope,label):
        caption=unique(scope.get_by_text(label,exact=True))
        return unique(caption.locator('xpath=..').get_by_role('button'))

    def choose(self,scope,label,query,select):
        self.guard();self.field_button(scope,label).click(timeout=5000)
        popup=self.page.locator('div.no-print').filter(has=self.page.locator('div.max-h-60.overflow-y-auto')).filter(has=self.page.get_by_placeholder('بحث',exact=True))
        popup.wait_for(state='visible',timeout=5000);unique(popup)
        search=unique(popup.get_by_placeholder('بحث',exact=True));search.fill(query,timeout=3000)
        def options():
            labels=popup.get_by_role('button').all_inner_texts()
            return select(labels)
        selected=self.wait(options)
        option=unique(popup.get_by_role('button',name=selected,exact=True))
        self.guard();option.click(timeout=5000)
        popup.wait_for(state='hidden',timeout=5000)
        if self.field_button(scope,label).inner_text().strip()!=selected.strip():raise AttendanceError('attendance_options')
        return selected

    def read_absences(self):
        def read():
            data=self.page.evaluate(ABSENCE_LIST_SCRIPT)
            if data.get('busy') or len(data.get('tables',[]))!=1 or len(data.get('pagers',[]))!=1:return None
            table=data['tables'][0]
            if table.get('headers')!=TABLE_HEADERS:return None
            text=data['pagers'][0].translate(str.maketrans('٠١٢٣٤٥٦٧٨٩','0123456789'))
            match=re.fullmatch(r'\s*الصفحة\s+(\d+)\s+من\s+(\d+)\s*[·•]\s*(\d+)\s+سجل إجمالاً\s*',text)
            if not match:return None
            number,pages,total=map(int,match.groups())
            if not 0<=total<=5000 or not 1<=number<=pages or len(table['rows'])>100:return None
            return number,pages,total,table['rows']
        return self.wait(read)

    def check_existing(self,pupil,record):
        scope=self.filter_scope()
        for label in ('الصف','فرع الصف','لغة التدريس','الشعبة','الطالب','سبب الغياب'):
            if not self.field_button(scope,label).inner_text().strip().startswith('كل'):
                raise AttendanceError('attendance_options')
        for label in ('من تاريخ','إلى تاريخ'):
            if unique(scope.get_by_label(label,exact=True)).input_value():raise AttendanceError('attendance_options')
        if unique(self.page.get_by_placeholder('بحث',exact=True)).input_value():raise AttendanceError('attendance_options')
        self.choose(scope,'الطالب',pupil['uid'] or ' '.join((pupil['first'],pupil['last'])),lambda labels:pupil_option(labels,pupil))
        selectors=[]
        for field in self.page.locator('select').all():
            if field.is_visible() and field.locator('option').all_text_contents()==['10 / صفحة','25 / صفحة','50 / صفحة','100 / صفحة']:
                selectors.append(field)
        if len(selectors)!=1:raise AttendanceError('attendance_options')
        selectors[0].select_option('100',timeout=3000)
        number,pages,total,rows=self.read_absences()
        if number!=1 or pages!=max(1,math.ceil(total/100)):raise AttendanceError('attendance_options')
        count=0;previous=None
        for index in range(1,pages+1):
            if number!=index or len(rows)!=min(100,max(0,total-count)):raise AttendanceError('attendance_options')
            fingerprint=json.dumps(rows,ensure_ascii=False)
            if previous==fingerprint and rows:raise AttendanceError('attendance_options')
            for cells in rows:
                if len(cells)!=7 or (pupil['uid'] and canonical_uid(cells[1])!=pupil['uid']):raise AttendanceError('attendance_identity')
                names={normalized(' '.join(pupil[k] for k in keys)) for keys in (('first','last'),('first','middle','last'))}
                if normalized(cells[0].splitlines()[0]) not in names:raise AttendanceError('attendance_identity')
            if has_overlap(rows,record):raise AttendanceError('attendance_existing')
            count+=len(rows);previous=fingerprint
            if index<pages:
                self.guard();unique(self.page.get_by_role('button',name='التالي',exact=True)).click(timeout=5000)
                expected=index+1
                def moved():
                    state=self.read_absences()
                    return state if state[0]==expected and state[1:3]==(pages,total) else None
                number,_,_,rows=self.wait(moved)
        if count!=total:raise AttendanceError('attendance_options')

    def import_one(self,page,username,cancelled,raw,token,account_session=None):
        self.bind(page,username,cancelled,account_session)
        record=validate_absence(raw)
        if record['account']!=account_key(username):raise AttendanceError('attendance_account')
        if token!=self.token:self.token=token;self.rosters={}
        grade=record['grade'].strip() or None
        if grade not in self.rosters:self.rosters[grade]=self.roster(grade)
        pupil=resolve_pupil(self.rosters[grade],record)
        key=(account_key(username),pupil['uid'],pupil['first'],pupil['middle'],pupil['last'],record['start'],record['end'] or record['start'],record['reason'],record['skip'],record['notes'])
        if key in self.saved:return 'attendance_already',0
        if any(old[:5]==key[:5] and old[5]<=key[6] and old[6]>=key[5] for old in self.uncertain):
            raise AttendanceError('attendance_uncertain')
        self.go(ATTENDANCE)
        self.check_existing(pupil,record)
        unique(self.page.get_by_role('button',name='تسجيل غياب',exact=True)).click(timeout=5000)
        self.page.locator('.print-area-modal').wait_for(state='visible',timeout=5000)
        scope=self.scope()
        self.choose(scope,'الطالب',pupil['uid'] or ' '.join((pupil['first'],pupil['last'])),lambda labels:pupil_option(labels,pupil))
        start=unique(scope.get_by_label(re.compile(r'^تاريخ الغياب \(من\)\s*\*?\s*$')))
        end=unique(scope.get_by_label('إلى تاريخ',exact=True))
        for field,value in ((start,record['start']),(end,record['end'])):
            lower,upper=field.get_attribute('min'),field.get_attribute('max')
            if not lower or not upper or (value and not lower<=value<=upper):raise AttendanceError('attendance_date')
            if field.input_value():raise AttendanceError('attendance_options')
        self.guard();start.fill(record['start'],timeout=3000)
        if record['end']:end.fill(record['end'],timeout=3000)
        full=record['reason']+' — '+REASONS[record['reason']]
        def reason(labels):
            matches=[label for label in labels if label.strip()==full]
            if len(matches)!=1:raise AttendanceError('attendance_options')
            return matches[0]
        self.choose(scope,'سبب الغياب',record['reason'],reason)
        skip=unique(scope.locator('#record-absence-skip-weekends'))
        self.guard();skip.set_checked(record['skip'],timeout=3000)
        notes=unique(scope.get_by_label('ملاحظات',exact=True))
        if notes.input_value():raise AttendanceError('attendance_options')
        notes.fill(record['notes'],timeout=3000)
        if (start.input_value()!=record['start'] or end.input_value()!=record['end'] or
                skip.is_checked()!=record['skip'] or notes.input_value()!=record['notes']):raise AttendanceError('attendance_options')
        # Old success notifications cannot acknowledge this save. Clear only
        # their presentation through the actual close buttons before clicking.
        alerts=page.locator('.Toastify__toast--success[role="alert"]').filter(has_text=SUCCESS_TEXT)
        for alert in alerts.all():
            if alert.is_visible():unique(alert.get_by_role('button',name='close',exact=True)).click(timeout=3000)
        alerts.wait_for(state='hidden',timeout=5000)
        button=unique(scope.get_by_role('button',name='حفظ',exact=True))
        if not button.is_enabled():raise AttendanceError('attendance_input')
        self.guard();self.uncertain.add(key[:7])
        try:
            button.click(timeout=5000)
            alerts.wait_for(state='visible',timeout=10000)
            self.guard()
            message=unique(alerts).inner_text().strip();match=SUCCESS_TEXT.fullmatch(message)
            if not match or int(match[1])<1:raise AttendanceError('attendance_save_unknown')
            scope.wait_for(state='hidden',timeout=5000)
            self.guard()
        except Exception:raise AttendanceError('attendance_save_unknown') from None
        self.uncertain.discard(key[:7]);self.saved.add(key)
        return 'attendance_saved',int(match[1])
