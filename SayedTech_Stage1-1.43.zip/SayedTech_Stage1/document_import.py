"""Serial, card-scoped document entry for one already verified pupil."""
import re
import time
from detailed_import import DetailError
from detail_dom import tab_locator
from manual_sections import SPECS,DOCUMENT_OPTIONS,manual_date,norm,fill_manual_section
from manual_save import scope_for,save_manual

TITLE='المستندات'
DOC_SPECS=[s for s in SPECS if s['section']==TITLE]
# The supplied form's smallest div containing its type select and own Save.
CARD='xpath=.//div[.//select[option[@value="id_card"]]][.//button[normalize-space(.)="حفظ"]][not(.//div[.//select[option[@value="id_card"]]][.//button[normalize-space(.)="حفظ"]])]'


def validated_documents(record):
    source=record.get('documents')
    if not isinstance(source,list) or not 1<=len(source)<=50:raise DetailError('detail_input',TITLE)
    out=[]
    for doc in source:
        if not isinstance(doc,dict) or set(doc)-{s['header'] for s in DOC_SPECS}:raise DetailError('detail_input',TITLE)
        current={}
        for s in DOC_SPECS:
            value=doc.get(s['header'])
            if value in ('',None):continue
            if s['kind']=='date':
                try:value=manual_date(value)
                except (ValueError,TypeError,OverflowError):raise DetailError('detail_input',s['header']) from None
            elif s['kind']=='checkbox':
                if not isinstance(value,bool):raise DetailError('detail_input',s['header'])
            elif not isinstance(value,str) or len(value)>1000:raise DetailError('detail_input',s['header'])
            current[s['header']]=value
        kind=current.get(TITLE+' / نوع المستند','')
        if norm(kind) not in {norm(v) for v in (*DOCUMENT_OPTIONS,*DOCUMENT_OPTIONS.values())}:
            raise DetailError('detail_input',TITLE+' / نوع المستند')
        kinds={norm(k):v for k,v in DOCUMENT_OPTIONS.items()}
        kinds.update({norm(v):v for v in DOCUMENT_OPTIONS.values()})
        def identity(doc):
            return (kinds[norm(doc[TITLE+' / نوع المستند'])],)+tuple(
                norm(doc.get(s['header'],'')) for s in DOC_SPECS
                if s['kind']!='checkbox' and s['label']!='نوع المستند')
        for previous in out:
            if identity(previous)!=identity(current):continue
            for s in DOC_SPECS:
                h=s['header']
                if s['kind']=='checkbox' and h in previous and h in current and previous[h]!=current[h]:
                    raise DetailError('detail_input',h)
        if current not in out:out.append(current)
    return out


def field_for(card,s):
    pattern=re.compile(r'^\s*'+re.escape(s['label'])+r'\s*\*?\s*$')
    field=card.get_by_label(pattern)
    if field.count()!=1:
        caption=card.get_by_text(pattern)
        if caption.count()==1:
            field=caption.locator('xpath=ancestor::*[.//input or .//select or .//textarea][1]').locator('input,select,textarea')
    return field


def metadata(field):
    return field.evaluate('(e)=>({tag:e.tagName,type:e.type,value:e.value,checked:e.checked,options:Array.from(e.options||[],o=>({value:o.value,label:o.textContent.trim()}))})')


def matches(card,doc):
    for s in DOC_SPECS:
        if s['header'] not in doc:continue
        # These are explicitly requested editable flags, not document identity.
        # A partial card may still have them unchecked after an interrupted fill.
        if s['kind']=='checkbox':continue
        field=field_for(card,s)
        if field.count()!=1:return False
        meta=metadata(field);value=doc[s['header']]
        if s['kind']=='date':
            try:same=manual_date(meta['value'])==manual_date(value)
            except (ValueError,TypeError,OverflowError):same=False
        elif meta['tag']=='SELECT':
            same=any(o['value']==meta['value'] and norm(value) in (norm(o['value']),norm(o['label'])) for o in meta['options'])
        else:same=norm(meta['value'])==norm(value)
        if not same:return False
    return True


def blank(card):
    controls=card.locator('input,select,textarea').all()
    if not controls:return False
    return all(meta.get('type')=='checkbox' or not meta.get('value') for meta in map(metadata,controls))


def save_documents(page,record,guard):
    documents=validated_documents(record)  # Validate EVERY date/type before the first Add/Save.
    for doc in documents:
        guard()
        mode=page.get_by_role('radio',name='مفصّل',exact=True)
        if mode.count()!=1 or not mode.is_enabled():raise DetailError('detail_options')
        mode.click(timeout=5000);guard()
        tab=tab_locator(page,TITLE)
        if tab.count()!=1 or not tab.is_enabled():raise DetailError('detail_options')
        tab.click(timeout=5000);guard()
        scope=scope_for(page,TITLE)
        cards=[c for c in scope.locator(CARD).all() if c.is_visible()]
        matched=[c for c in cards if matches(c,doc)]
        if len(matched)>1:raise DetailError('detail_existing',TITLE)
        if matched:card=matched[0]
        else:
            empty=[c for c in cards if blank(c)]
            if len(empty)>1:raise DetailError('detail_existing',TITLE)
            if empty:card=empty[0]
            else:
                add=scope.get_by_role('button',name='إضافة',exact=True)
                if add.count()!=1 or not add.is_enabled():raise DetailError('detail_options',TITLE)
                guard();add.click(timeout=3000);guard()
                end=time.monotonic()+8
                while True:
                    guard()
                    current=[c for c in scope.locator(CARD).all() if c.is_visible()]
                    empty=[c for c in current if blank(c)]
                    if len(current)==len(cards)+1 and len(empty)==1:card=empty[0];break
                    if time.monotonic()>=end:raise DetailError('detail_options',TITLE)
                    page.wait_for_timeout(100)
        fill_manual_section(page,dict(record,manual=doc),TITLE,guard,document_block=card)
        # Save only this card; multiple document Save buttons are expected.
        if save_manual(page,TITLE,guard,document_block=card)!='detail_saved':raise DetailError('detail_save_unknown',TITLE)
        guard()
    return 'detail_saved'
