"""Local full-year workbook to explicitly selected, 27-field simple workbook."""
from datetime import date
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import core
from name_transliteration import suggest_english_names
from student_excel import FIELDS, HEADERS, NS, REL, ExcelInputError, apply_simple_defaults

WORKFLOW_SHEET = 'مسار التسجيل المبسّط'
SELECTION_HEADER = 'مسجّل بمدرستي؟'
WORKFLOW_HEADERS = [SELECTION_HEADER] + HEADERS


def selection_value(value):
    if isinstance(value, bool):
        raise ValueError('selection')
    if isinstance(value, (int, float)) and value in (0, 1):
        return value == 1
    value = str(value).strip()
    if value in ('', '0', 'لا'):
        return False
    if value in ('1', 'نعم'):
        return True
    raise ValueError('selection')


def column(index):
    result = ''
    while index:
        index, remainder = divmod(index - 1, 26)
        result = chr(65 + remainder) + result
    return result


def workbook_rows(z, sheet_name):
    """Read values and flag formulas; never evaluate workbook expressions."""
    def xml(name):
        data = z.read(name)
        if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
            raise ExcelInputError('بنية XML غير مدعومة.')
        return ET.fromstring(data)
    book = xml('xl/workbook.xml')
    properties = book.find('m:workbookPr', NS)
    if properties is not None and properties.get('date1904') in ('1', 'true'):
        raise ExcelInputError('نظام تواريخ 1904 غير مدعوم.')
    sheets = [s for s in book.findall('m:sheets/m:sheet', NS) if s.get('name') == sheet_name]
    if len(sheets) != 1:
        raise ExcelInputError('ورقة ' + sheet_name + ' غير موجودة.')
    targets = [r for r in xml('xl/_rels/workbook.xml.rels') if r.get('Id') == sheets[0].get(REL)]
    if len(targets) != 1 or targets[0].get('TargetMode') == 'External':
        raise ExcelInputError('مرجع ورقة غير صالح.')
    target = targets[0].get('Target', '')
    target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
    if '..' in PurePosixPath(target).parts:
        raise ExcelInputError('مسار غير مدعوم.')
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        shared = [''.join(t.text or '' for t in s.findall('.//m:t', NS)) for s in xml('xl/sharedStrings.xml')]
    result = []
    for row in xml(target).findall('m:sheetData/m:row', NS):
        number = int(row.get('r', '0'))
        if not 1 <= number <= 5001:
            raise ExcelInputError('الحد الأقصى 5000 تسجيل.')
        values, formulas = {}, set()
        for c in row.findall('m:c', NS):
            match = re.fullmatch(r'([A-Z]{1,2})' + str(number), c.get('r', ''))
            if not match or match[1] in values:
                raise ExcelInputError('عنوان خلية غير صالح أو مكرر.')
            letter = match[1]
            if c.find('m:f', NS) is not None:
                formulas.add(letter)
            value = c.findtext('m:v', '', NS)
            kind = c.get('t')
            if kind == 's': value = shared[int(value)]
            elif kind == 'inlineStr': value = ''.join(t.text or '' for t in c.findall('.//m:t', NS))
            elif kind == 'e': raise ExcelInputError(f'خطأ Excel في الصف {number}.')
            elif kind == 'b': value = value == '1'
            elif kind not in ('str', 'd') and value != '': value = float(value)
            values[letter] = value
        result.append((number, values, formulas))
    return result


def convert_to_simple(source, destination):
    from nsldb_reference import (REFERENCE_HEADERS, FULL_REFERENCE_HEADERS, DETAILED_HEADERS,
        REFERENCE_SHEET, canonical_year, TARGET_YEAR)
    source, destination = Path(source), Path(destination)
    assets = (core.ASSET_BASE / 'assets').resolve()
    if source.resolve() == destination.resolve() or assets in destination.resolve().parents or destination.suffix.lower() != '.xlsx':
        raise ExcelInputError('احفظ ملف المبسّط باسم مستقل خارج مجلد assets. يبقى السحب الكامل كما هو.')
    try:
        if not source.is_file() or source.stat().st_size > 64_000_000:
            raise ExcelInputError('اختر ملف سحب Excel بحجم لا يتجاوز 64 ميغابايت.')
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        with zipfile.ZipFile(source) as z:
            if len(z.infolist()) > 1000 or sum(i.file_size for i in z.infolist()) > 128_000_000:
                raise ExcelInputError('ملف Excel كبير جداً.')
            metadata = workbook_rows(z, REFERENCE_SHEET)
            if any(formulas for _, _, formulas in metadata):
                raise ExcelInputError('مرجع المصدر يجب أن يحتوي قيماً ثابتة.')
            rows = workbook_rows(z, 'الطلاب')
        if not rows or rows[0][0] != 1 or rows[0][2]:
            raise ExcelInputError('عناوين المصدر غير صالحة.')
        headers = rows[0][1]
        if not any(len(headers) == len(schema) and set(headers.values()) == set(schema)
                   for schema in (REFERENCE_HEADERS, FULL_REFERENCE_HEADERS, DETAILED_HEADERS)):
            raise ExcelInputError('اختر ملف السحب الكامل من NSLDB.')
        records = []
        year_col = next(c for c, h in headers.items() if h == 'السنة في القاعدة')
        for number, values, formulas in rows[1:]:
            if not any(v != '' for v in values.values()): continue
            if year_col in formulas:
                raise ExcelInputError(f'السنة في الصف {number} يجب أن تكون قيمة ثابتة.')
            if canonical_year(values.get(year_col)) != TARGET_YEAR: continue
            if formulas:
                raise ExcelInputError(f'المعادلات غير مسموحة في بيانات المصدر، الصف {number}.')
            records.append({f['id']: values.get(c, '') for c, label in headers.items() for f in FIELDS if f['label'] == label})
        if not records:
            raise ExcelInputError('لا توجد تسجيلات للعام 2025–2026 في الملف.')
        if hashlib.sha256(source.read_bytes()).hexdigest() != digest:
            raise ExcelInputError('تغيّر ملف المصدر أثناء قراءته. أغلق Excel وأعد التحويل.')
        write_simple(records, destination, source.name, digest)
        return len(records)
    except ExcelInputError:
        raise
    except (OSError, ValueError, KeyError, IndexError, TypeError, zipfile.BadZipFile, ET.ParseError):
        raise ExcelInputError('تعذّر التحويل. اختر ملف السحب الكامل وأغلق ملف الإخراج إذا كان مفتوحاً.') from None


def write_simple(records, destination, source_name, digest):
    """Runtime values in the bundled Artifact Tool-authored workflow template."""
    destination = Path(destination)
    if not 1 <= len(records) <= 5000:
        raise ExcelInputError('يلزم بين تسجيل واحد و5000 تسجيل.')
    q = lambda name: '{' + NS['m'] + '}' + name
    with zipfile.ZipFile(core.ASSET_BASE / 'assets/student_workflow_simple.xlsx') as z:
        parts = {n: z.read(n) for n in z.namelist()}
    sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    body = sheet.find('m:sheetData', NS)
    styles = {re.sub(r'\d+', '', c.get('r')): c.get('s') for r in list(body)[1:] for c in r}
    for row in list(body)[1:]: body.remove(row)
    def cell(row, letter, value, numeric=False):
        c = ET.SubElement(row, q('c'), r=letter + row.get('r'))
        if letter in styles: c.set('s', styles[letter])
        if numeric:
            ET.SubElement(c, q('v')).text = str(value)
        else:
            c.set('t', 'inlineStr')
            ET.SubElement(ET.SubElement(c, q('is')), q('t')).text = re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]', '\ufffd', str(value))
    for index, record in enumerate(records, 2):
        record = suggest_english_names(apply_simple_defaults(record, for_export=True))
        row = ET.SubElement(body, q('row'), r=str(index), ht='28', customHeight='1')
        cell(row, 'A', '0')
        for n, f in enumerate(FIELDS, 2):
            value = record.get(f['id'], '')
            numeric = f['type'] == 'date' and isinstance(value, (int, float)) and not isinstance(value, bool)
            if f['type'] == 'date' and isinstance(value, str) and value:
                try:
                    value = (date.fromisoformat(value) - date(1899, 12, 30)).days
                    numeric = True
                except ValueError: pass
            if isinstance(value, bool): value = 'نعم' if value else 'لا'
            cell(row, column(n), value, numeric)
    last = max(501, len(records) + 1)
    dimension = sheet.find('m:dimension', NS)
    if dimension is not None: dimension.set('ref', f'A1:AB{last}')
    for tag in ('m:dataValidations/m:dataValidation', 'm:conditionalFormatting'):
        for node in sheet.findall(tag, NS):
            node.set('sqref', re.sub(r'(?<=[A-Z])501\b', str(last), node.get('sqref', '')))
    parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet, encoding='utf-8', xml_declaration=True)
    for name in parts:
        if name.startswith('xl/tables/') and name.endswith('.xml'):
            table = ET.fromstring(parts[name])
            if table.get('name') == 'StudentsInput':
                table.set('ref', f'A1:AB{last}')
                auto = table.find('m:autoFilter', NS)
                if auto is not None: auto.set('ref', f'A1:AB{last}')
                parts[name] = ET.tostring(table, encoding='utf-8', xml_declaration=True)
    book = ET.fromstring(parts['xl/workbook.xml'])
    marker = next(s for s in book.findall('m:sheets/m:sheet', NS) if s.get('name') == WORKFLOW_SHEET)
    rels = ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    target = next(r.get('Target') for r in rels if r.get('Id') == marker.get(REL))
    target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
    meta = ET.fromstring(parts[target]); grid = meta.find('m:sheetData', NS)
    for row in list(grid): grid.remove(row)
    for i, pair in enumerate([('نوع الملف', 'simple_workflow'), ('السنة الدراسية', '20252026'),
            ('ملف المصدر', source_name), ('بصمة المصدر', digest), ('عدد التسجيلات', str(len(records)))], 1):
        row = ET.SubElement(grid, q('row'), r=str(i))
        for letter, value in zip(('A', 'B'), pair): cell(row, letter, value)
    parts[target] = ET.tostring(meta, encoding='utf-8', xml_declaration=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, suffix='.xlsx', delete=False) as f:
            temporary = Path(f.name)
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
            for name, value in parts.items(): z.writestr(name, value)
        os.replace(temporary, destination)
    finally:
        if temporary: temporary.unlink(missing_ok=True)
