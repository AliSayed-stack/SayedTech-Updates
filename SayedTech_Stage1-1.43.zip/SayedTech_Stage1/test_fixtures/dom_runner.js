// A structural DOM harness for supplied HTML fixtures; no browser/layout claim.
const fs=require('fs');
const input=JSON.parse(fs.readFileSync(0,'utf8'));
class Element {
 constructor(raw,parent=null){this.tagName=raw.tag.toUpperCase();this.attrs=raw.attrs;this.text=raw.text||'';this.tail=raw.tail||'';this.parentElement=parent;this.children=raw.children.map(r=>new Element(r,this));this.override=undefined;}
 get textContent(){return this.text+this.children.map(c=>c.textContent+c.tail).join('');}
 get innerText(){return this.textContent;}
 get id(){return this.attrs.id||'';}
 get htmlFor(){return this.attrs.for||'';}
 get type(){return this.attrs.type||({SELECT:'select-one',TEXTAREA:'textarea',INPUT:'text'}[this.tagName]||'');}
 get required(){return 'required' in this.attrs;}
 get checked(){return 'checked' in this.attrs;}
 get selectedOptions(){const options=this.querySelectorAll('option');const chosen=options.filter(o=>'selected' in o.attrs);return chosen.length?chosen:options.slice(0,1);}
 get value(){if(this.override!==undefined)return this.override;if(this.tagName==='SELECT')return this.selectedOptions[0]?.attrs.value||'';if(this.tagName==='TEXTAREA')return this.textContent;return this.attrs.value||'';}
 set value(v){this.override=v;}
 get labels(){return document.querySelectorAll('label').filter(l=>l.htmlFor&&l.htmlFor===this.id);}
 get nextElementSibling(){if(!this.parentElement)return null;const peers=this.parentElement.children;return peers[peers.indexOf(this)+1]||null;}
 get classList(){return {contains:name=>(this.attrs.class||'').split(/\s+/).includes(name)};}
 getAttribute(name){return this.attrs[name]??null;}
 getClientRects(){for(let e=this;e;e=e.parentElement)if('hidden' in e.attrs||/display:\s*none/.test(e.attrs.style||''))return [];return [{}];}
 contains(other){for(let p=other.parentElement;p;p=p.parentElement)if(p===this)return true;return false;}
 matches(selector){return selector.split(',').some(raw=>{const s=raw.trim();const m=s.match(/^([a-z0-9-]+)?(?:\[([^=\]]+)(?:=["']?([^"'\]]+)["']?)?\])?$/i);if(!m)throw Error('Unsupported fixture selector '+s);return (!m[1]||this.tagName===m[1].toUpperCase())&&(!m[2]||m[2] in this.attrs&&(m[3]===undefined||this.attrs[m[2]]===m[3]));});}
 querySelectorAll(selector){const result=[];const walk=e=>{for(const c of e.children){if(c.matches(selector))result.push(c);walk(c);}};walk(this);return result;}
 querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
}
global.document=new Element(input.tree);
document.getElementById=id=>document.querySelectorAll('[id]').find(e=>e.id===id)||null;
if(input.delayed){const e=document.getElementById(input.delayed.id);const saved=e.value;e.value='';setTimeout(()=>{e.value=saved;},input.delayed.ms);}
(async()=>{const reader=eval('('+input.script+')');const result=await reader(input.tab);process.stdout.write(JSON.stringify(result));})().catch(e=>{process.stderr.write(e.stack);process.exitCode=1;});
