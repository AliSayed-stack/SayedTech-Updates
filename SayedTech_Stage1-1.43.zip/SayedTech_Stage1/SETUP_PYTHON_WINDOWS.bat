@echo off
rem Called by the launchers inside their SETLOCAL. Do not enable delayed expansion.
rem Python Install Manager can return a negative Windows exit code: test exact zero.
set "SAYED_PYTHON=%~dp0.venv\Scripts\python.exe"
set "SAYED_BASE_EXE="
set "SAYED_BASE_TAG="
set "SAYED_INSTALL_ATTEMPTED="
if not exist "%SAYED_PYTHON%" goto find_python
"%SAYED_PYTHON%" -c "import sys,sysconfig; sys.exit(0 if sys.version_info[:2] in [(3,10),(3,11),(3,12),(3,13)] and sysconfig.get_platform() == 'win-amd64' and not sysconfig.get_config_var('Py_GIL_DISABLED') else 1)" >nul 2>&1
if "%errorlevel%"=="0" goto ensure_pip

:find_python
call :probe "py" "-3.13"
call :probe "py" "-3.12"
call :probe "py" "-3.11"
call :probe "py" "-3.10"
call :probe "py" "-3.13"
call :probe "pymanager" "-3.11"
call :probe "pymanager" "-3.10"
call :probe "pymanager" "-3.12"
call :probe "pymanager" "-3.13"
call :probe "%LocalAppData%\Programs\Python\Python311\python.exe" ""
call :probe "%LocalAppData%\Programs\Python\Python310\python.exe" ""
call :probe "python" ""
call :probe "%LocalAppData%\Programs\Python\Python312\python.exe" ""
call :probe "%LocalAppData%\Programs\Python\Python313\python.exe" ""
if defined SAYED_BASE_EXE goto create_environment
if defined SAYED_INSTALL_ATTEMPTED goto no_python
set "SAYED_INSTALL_ATTEMPTED=1"
pymanager help install >nul 2>&1
if "%errorlevel%"=="0" goto install_with_manager
py help install >nul 2>&1
if "%errorlevel%"=="0" goto install_with_py
goto install_official

:install_official
echo Preparing a compatible Python runtime from python.org...
call "%~dp0INSTALL_PYTHON_RUNTIME.bat"
if not "%errorlevel%"=="0" goto install_failed
goto find_python

:install_with_manager
echo A compatible Python runtime is missing. Installing Python 3.13 using Python Install Manager...
pymanager install 3.13
if not "%errorlevel%"=="0" goto install_failed
goto find_python

:install_with_py
echo A compatible Python runtime is missing. Installing Python 3.13 using Python Install Manager...
py install 3.13
if not "%errorlevel%"=="0" goto install_failed
goto find_python

:probe
if defined SAYED_BASE_EXE exit /b 0
"%~1" %~2 -c "import sys,sysconfig; sys.exit(0 if sys.version_info[:2] in [(3,10),(3,11),(3,12),(3,13)] and sysconfig.get_platform() == 'win-amd64' and not sysconfig.get_config_var('Py_GIL_DISABLED') else 1)" >nul 2>&1
if not "%errorlevel%"=="0" exit /b 0
set "SAYED_BASE_EXE=%~1"
set "SAYED_BASE_TAG=%~2"
exit /b 0

:create_environment
if not exist ".venv" goto create_new
set "SAYED_VENV_BACKUP=.venv-backup-%RANDOM%-%RANDOM%"
if exist "%SAYED_VENV_BACKUP%" goto create_environment
echo Preserving the old environment in %SAYED_VENV_BACKUP%
move ".venv" "%SAYED_VENV_BACKUP%" >nul
if not "%errorlevel%"=="0" goto environment_failed
:create_new
echo Preparing the Sayed tech Python environment...
"%SAYED_BASE_EXE%" %SAYED_BASE_TAG% -m venv .venv
if not "%errorlevel%"=="0" goto environment_failed
if not exist "%SAYED_PYTHON%" goto environment_failed
"%SAYED_PYTHON%" -c "import sys,sysconfig; sys.exit(0 if sys.version_info[:2] in [(3,10),(3,11),(3,12),(3,13)] and sysconfig.get_platform() == 'win-amd64' and not sysconfig.get_config_var('Py_GIL_DISABLED') else 1)" >nul 2>&1
if not "%errorlevel%"=="0" goto environment_failed
goto ensure_pip

:ensure_pip
"%SAYED_PYTHON%" -m pip --version >nul 2>&1
if "%errorlevel%"=="0" exit /b 0
echo Adding pip to the local Sayed tech environment...
"%SAYED_PYTHON%" -m ensurepip --upgrade
if not "%errorlevel%"=="0" goto pip_failed
"%SAYED_PYTHON%" -m pip --version >nul 2>&1
if "%errorlevel%"=="0" exit /b 0
:pip_failed
echo This Python runtime cannot add pip to the local environment.
echo Install standard Python 3.13 64-bit with pip from python.org, then run START_WINDOWS.bat again.
set "SAYED_PYTHON="
exit /b 1

:install_failed
echo Python installation did not finish. Check the connection and the message above.
goto no_python
:environment_failed
echo Could not prepare the local Python environment. Close Sayed tech and check folder write permissions.
set "SAYED_PYTHON="
exit /b 1
:no_python
echo Sayed tech uses Python 3.10 through 3.13, standard Windows x64.
echo If Python Install Manager is available, run: py install 3.13
echo Otherwise install standard Python 3.13 64-bit from https://www.python.org/downloads/windows/
echo Then run START_WINDOWS.bat again. No application data has been deleted.
set "SAYED_PYTHON="
exit /b 1
