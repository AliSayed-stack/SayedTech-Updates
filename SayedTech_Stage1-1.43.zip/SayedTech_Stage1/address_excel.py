"""Attach the existing SIMS address catalog to the app's XLSX exports.

Uses the application's existing OOXML export pipeline; student cells and
column schemas are unchanged. Lookup IDs are never used as student data.
"""
import zipfile
import xml.etree.ElementTree as ET

import core
from student_excel import NS, REL, ExcelInputError
from student_workflow import column, workbook_rows

SHEET = 'قوائم العناوين'
HEADERS = ('بلد السكن', 'محافظة السكن', 'قضاء السكن', 'منطقة / بلدة السكن')
Q = lambda name: '{' + NS['m'] + '}' + name
PKG = 'http://schemas.openxmlformats.org/package/2006/relationships'
CT = 'http://schemas.openxmlformats.org/package/2006/content-types'


def package_xml(root, namespace):
    # OPC readers (including Office) expect default namespaces in package
    # metadata. Avoid ElementTree's generated ns0 prefixes for these parts.
    plain = ET.Element(root.tag.split('}')[-1], dict(root.attrib, xmlns=namespace))
    for node in root:
        ET.SubElement(plain, node.tag.split('}')[-1], dict(node.attrib))
    return ET.tostring(plain, encoding='utf-8', xml_declaration=True)


def attach_address_lists(parts, headers, last_row):
    """Add dependent lists and mark stale child choices, without changing data."""
    if not all(h in headers for h in HEADERS):
        raise ExcelInputError('خانات العنوان غير موجودة في قالب التصدير.')
    with zipfile.ZipFile(core.ASSET_BASE / 'assets/student_with_addresses.xlsx') as z:
        rows = workbook_rows(z, SHEET)
        book = ET.fromstring(z.read('xl/workbook.xml'))
        source = next(s for s in book.findall('m:sheets/m:sheet', NS) if s.get('name') == SHEET)
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = next(r.get('Target') for r in rels if r.get('Id') == source.get(REL))
        path = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        lookup = ET.fromstring(z.read(path))
    if any(formulas for _, _, formulas in rows):
        raise ExcelInputError('قالب قوائم العناوين غير صالح.')
    values = {n: row for n, row, _ in rows}
    gov_rows = [n for n, row, _ in rows if n >= 8 and row.get('F')]
    district_rows = [n for n, row, _ in rows if n >= 8 and row.get('K')]
    area_rows = [n for n, row, _ in rows if n >= 8 and row.get('A') and row.get('B') and row.get('C')]
    if not gov_rows or not district_rows or not area_rows:
        raise ExcelInputError('قوائم العناوين فارغة.')
    if gov_rows != list(range(8, max(gov_rows) + 1)) or district_rows != list(range(8, max(district_rows) + 1)):
        raise ExcelInputError('ترتيب قوائم العناوين غير صالح.')
    # Source styles/shared strings belong to another workbook. Inline all its
    # strings and drop style references rather than copying invalid indices.
    for cell in lookup.findall('.//m:c', NS):
        ref = cell.get('r')
        letters = ''.join(c for c in ref if c.isalpha())
        number = int(''.join(c for c in ref if c.isdigit()))
        value = values.get(number, {}).get(letters, '')
        cell.attrib.pop('s', None)
        for child in list(cell): cell.remove(child)
        cell.set('t', 'inlineStr')
        ET.SubElement(ET.SubElement(cell, Q('is')), Q('t')).text = str(value)
    instructions = {
        3: 'قوائم العناوين للملف الموحّد والمفصّل؛ تبقى بيانات الطلاب في الورقة الأولى.',
        4: 'القوائم المجمّعة تخص لبنان. البلد والشارع والتفاصيل غير الموجودة في المصدر تبقى فارغة.',
        5: 'اختر البلد ثم المحافظة ثم القضاء ثم المنطقة. بعد تغيير اختيار، أعد اختيار الخانات التابعة؛ اللون الأحمر ينبه إلى اختيار غير مطابق للقائمة.',
        6: 'الأسماء والقوائم من قالب النظام السابق؛ التحقق النهائي من الخيارات يتم على صفحة SIMS عند الاسترداد.',
    }
    for number, text in instructions.items():
        cell = lookup.find('.//m:c[@r="A' + str(number) + '"]/m:is/m:t', NS)
        if cell is not None: cell.text = text

    book = ET.fromstring(parts['xl/workbook.xml'])
    sheets = book.find('m:sheets', NS)
    rels = ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    existing = next((s for s in sheets if s.get('name') == SHEET), None)
    if existing is None:
        number = max(int(s.get('sheetId')) for s in sheets) + 1
        index = 1
        while 'xl/worksheets/sheet' + str(index) + '.xml' in parts: index += 1
        path = 'xl/worksheets/sheet' + str(index) + '.xml'
        rid = 'rIdSayedAddress'
        while any(r.get('Id') == rid for r in rels): rid += 'A'
        ET.SubElement(sheets, Q('sheet'), {'name': SHEET, 'sheetId': str(number), REL: rid})
        ET.SubElement(rels, '{' + PKG + '}Relationship', Id=rid,
                      Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet',
                      Target=path[3:])
        types = ET.fromstring(parts['[Content_Types].xml'])
        ET.SubElement(types, '{' + CT + '}Override', PartName='/' + path,
                      ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
        parts['[Content_Types].xml'] = package_xml(types, CT)
    else:
        target = next(r.get('Target') for r in rels if r.get('Id') == existing.get(REL))
        path = target.lstrip('/') if target.startswith('/') else 'xl/' + target
    parts[path] = ET.tostring(lookup, encoding='utf-8', xml_declaration=True)

    names = book.find('m:definedNames', NS)
    if names is None:
        names = ET.Element(Q('definedNames'))
        book.insert(list(book).index(sheets) + 1, names)
    ranges = {
        'ST_AddressCountries': '$R$8', 'ST_AddressBlank': '$R$10',
        'ST_AddressGovs': '$F$8:$F$' + str(max(gov_rows)),
        'ST_AddressDistrictRefs': '$H$8:$H$' + str(max(gov_rows)),
        'ST_AddressAreaKeys': '$K$8:$K$' + str(max(district_rows)),
        'ST_AddressAreaRefs': '$N$8:$N$' + str(max(district_rows)),
        'ST_AddressAllGovs': '$A$8:$A$' + str(max(area_rows)),
        'ST_AddressAllDistricts': '$B$8:$B$' + str(max(area_rows)),
        'ST_AddressAllAreas': '$C$8:$C$' + str(max(area_rows)),
    }
    for item in list(names):
        if item.get('name') in ranges: names.remove(item)
    for name, ref in ranges.items():
        ET.SubElement(names, Q('definedName'), name=name).text = "'" + SHEET + "'!" + ref
    parts['xl/workbook.xml'] = ET.tostring(book, encoding='utf-8', xml_declaration=True)
    parts['xl/_rels/workbook.xml.rels'] = package_xml(rels, PKG)

    sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    cols = [column(headers.index(h) + 1) for h in HEADERS]
    country, gov, district, area = ['$' + c + '2' for c in cols]
    empty = "'" + SHEET + "'!$R$10"
    district_list = 'INDIRECT(IFERROR(INDEX(ST_AddressDistrictRefs,MATCH(' + gov + ',ST_AddressGovs,0)),"' + empty + '"))'
    area_list = 'INDIRECT(IFERROR(INDEX(ST_AddressAreaRefs,MATCH(' + gov + '&"__"&' + district + ',ST_AddressAreaKeys,0)),"' + empty + '"))'
    formulas = [
        'ST_AddressCountries',
        'IF(' + country + '="لبنان",ST_AddressGovs,ST_AddressBlank)',
        'IF(' + country + '="لبنان",' + district_list + ',ST_AddressBlank)',
        'IF(' + country + '="لبنان",' + area_list + ',ST_AddressBlank)',
    ]
    validations = sheet.find('m:dataValidations', NS)
    if validations is None:
        # OOXML order: conditionalFormatting, dataValidations, hyperlinks, ...
        validations = ET.Element(Q('dataValidations'))
        after = {'sheetPr','dimension','sheetViews','sheetFormatPr','cols','sheetData',
                 'sheetCalcPr','sheetProtection','protectedRanges','scenarios','autoFilter',
                 'sortState','dataConsolidate','customSheetViews','mergeCells','phoneticPr','conditionalFormatting'}
        position = next((i for i, n in enumerate(sheet) if n.tag.split('}')[-1] not in after), len(sheet))
        sheet.insert(position, validations)
    targets = {c + '2:' + c + str(last_row) for c in cols}
    for item in list(validations):
        if item.get('sqref') in targets: validations.remove(item)
    for col, formula in zip(cols, formulas):
        node = ET.SubElement(validations, Q('dataValidation'), type='list',
            sqref=col + '2:' + col + str(last_row), allowBlank='1', showDropDown='0',
            showErrorMessage='1', errorStyle='stop', errorTitle='راجع العنوان',
            error='اختر من القائمة التابعة للمحافظة والقضاء المحددين.',
            showInputMessage='1', promptTitle='عناوين السكن',
            prompt='اختر بالترتيب: البلد، المحافظة، القضاء، المنطقة. أعد اختيار الخانات التابعة عند تغيير الأصل.')
        ET.SubElement(node, Q('formula1')).text = formula
    validations.set('count', str(len(validations)))

    styles = ET.fromstring(parts['xl/styles.xml'])
    dxfs = styles.find('m:dxfs', NS)
    if dxfs is None:
        dxfs = ET.Element(Q('dxfs'))
        tail = styles.find('m:tableStyles', NS)
        styles.insert(list(styles).index(tail) if tail is not None else len(styles), dxfs)
    color_style = ET.Element(Q('dxf'))
    font = ET.SubElement(color_style, Q('font'))
    ET.SubElement(font, Q('color'), rgb='FF9C0006')
    fill = ET.SubElement(color_style, Q('fill'))
    pattern = ET.SubElement(fill, Q('patternFill'), patternType='solid')
    ET.SubElement(pattern, Q('fgColor'), rgb='FFFFC7CE')
    ET.SubElement(pattern, Q('bgColor'), indexed='64')
    match = next((i for i, d in enumerate(dxfs) if ET.tostring(d) == ET.tostring(color_style)), None)
    if match is None: match = len(dxfs); dxfs.append(color_style)
    dxfs.set('count', str(len(dxfs)))
    for node in list(sheet):
        if node.tag == Q('conditionalFormatting') and node.get('sqref') in targets:
            # Only replace rules previously generated by this helper.
            if all('ST_Address' in (r.findtext('m:formula', '', NS)) for r in node): sheet.remove(node)
    priority = max([int(r.get('priority', '0')) for r in sheet.findall('m:conditionalFormatting/m:cfRule', NS)] + [0])
    invalid = [
        'COUNTIF(ST_AddressCountries,' + country + ')=0',
        'OR(' + country + '<>"لبنان",COUNTIF(ST_AddressGovs,' + gov + ')=0)',
        'OR(' + country + '<>"لبنان",COUNTIF(ST_AddressAreaKeys,' + gov + '&"__"&' + district + ')=0)',
        'OR(' + country + '<>"لبنان",COUNTIFS(ST_AddressAllGovs,' + gov + ',ST_AddressAllDistricts,' + district + ',ST_AddressAllAreas,' + area + ')=0)',
    ]
    for offset, (col, formula) in enumerate(zip(cols, invalid), 1):
        cf = ET.Element(Q('conditionalFormatting'), sqref=col + '2:' + col + str(last_row))
        rule = ET.SubElement(cf, Q('cfRule'), type='expression', dxfId=str(match), priority=str(priority + offset))
        ET.SubElement(rule, Q('formula')).text = 'AND($' + col + '2<>"",' + formula + ')'
        sheet.insert(list(sheet).index(validations), cf)
    parts['xl/styles.xml'] = ET.tostring(styles, encoding='utf-8', xml_declaration=True)
    parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet, encoding='utf-8', xml_declaration=True)
