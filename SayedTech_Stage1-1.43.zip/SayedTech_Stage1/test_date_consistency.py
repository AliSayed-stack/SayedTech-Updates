"""The same explicit calendar date is read consistently across input sections."""
from datetime import date,timedelta
import unittest
from student_excel import normalize_date
from manual_sections import manual_date
from identity_card import validate_card
from attendance_schema import absence_date
from student_fill import search_birth_date


class DateConsistencyTests(unittest.TestCase):
    def test_all_input_paths_share_iso_year_first_slashes_and_month_first_slashes(self):
        serial=(date(2015,4,5)-date(1899,12,30)).days
        for raw in ('2015-04-05','2015/04/05','04/05/2015','4/5/2015','٢٠١٥/٠٤/٠٥',serial):
            with self.subTest(raw=raw):
                self.assertEqual(normalize_date(raw),'2015-04-05')
                self.assertEqual(manual_date(raw),'2015-04-05')
                self.assertEqual(absence_date(raw),'2015-04-05')
                self.assertEqual(validate_card({'type':'هوية','number':'0001','expiry':raw})[2],'2015-04-05')
                self.assertEqual(search_birth_date(raw),'2015-04-05')
        self.assertEqual(manual_date('4/15/2015'),'2015-04-15')
        self.assertEqual(manual_date('03/02/2015'),'2015-03-02')

    def test_future_rules_remain_specific_to_the_field(self):
        future=date.today()+timedelta(days=400)
        for raw in (future.isoformat(),future.strftime('%Y/%m/%d'),future.strftime('%m/%d/%Y')):
            with self.assertRaises(ValueError):normalize_date(raw)
            self.assertEqual(manual_date(raw),future.isoformat())
            self.assertEqual(absence_date(raw),future.isoformat())
            self.assertEqual(validate_card({'type':'هوية','number':'0001','expiry':raw})[2],future.isoformat())
        self.assertEqual(manual_date('15-04-2031'),'2031-04-15')

    def test_invalid_and_ambiguous_day_first_slash_inputs_are_not_guessed(self):
        for parser in (normalize_date,manual_date,absence_date):
            for raw in ('2015/02/30','02/30/2015','13/02/2015',True,60):
                with self.subTest(parser=parser.__name__,raw=raw),self.assertRaises(ValueError):parser(raw)


if __name__=='__main__':unittest.main()
