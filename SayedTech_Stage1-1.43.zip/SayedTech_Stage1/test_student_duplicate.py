"""Duplicate prevention using a synthetic school roster; no live writes."""
import threading
import unittest
from unittest.mock import patch

from student_duplicate import DuplicateGuard
from student_fill import StudentFillError
from student_scan import ScanError, StudentBrowser
from test_scan import Clock, Page as RosterPage
from test_students import record
from test_student_save import Page as DraftPage
from student_save import fill_and_save_student


class FixtureBrowser:
    rows=[]
    date='2015-01-02'
    failure=None
    instances=[]

    def __init__(self,*args,**kwargs):
        self.reads=[]
        type(self).instances.append(self)

    def inventory(self,progress):
        if self.failure:raise self.failure
        return [dict(r) for r in self.rows]

    def read_birth_date(self,row):
        self.reads.append(row['uid'])
        return self.date


def roster(uid='000123',status='قيد الانتظار',first='TEST'):
    return {'uid':uid,'first':first,'middle':'TEST','last':'TEST','status':status}


class DuplicateTests(unittest.TestCase):
    def setUp(self):
        FixtureBrowser.rows=[];FixtureBrowser.date='2015-01-02'
        FixtureBrowser.failure=None;FixtureBrowser.instances=[]
        self.guard=DuplicateGuard(FixtureBrowser)
        self.data=record();self.cancelled=threading.Event()

    def check(self,token='a'*32):
        return self.guard.check(None,self.data,'test@te.mehe.school',self.cancelled,token)

    def test_active_match_is_skipped_before_any_form_mutation(self):
        FixtureBrowser.rows=[roster()]
        self.assertEqual(self.check(),'registered')
        self.assertEqual(FixtureBrowser.instances[0].reads,['000123'])
        page=DraftPage()
        class Registered:
            def check(self,*args,**kwargs):return 'registered'
        self.assertEqual(fill_and_save_student(page,self.data,page.account,page.cancelled,
                                               duplicate_guard=Registered()),'student_already_registered')
        self.assertEqual(page.actions,[])

    def test_deleted_only_can_proceed_and_active_copy_blocks(self):
        FixtureBrowser.rows=[roster(status='محذوف')]
        self.assertEqual(self.check(),'clear')
        FixtureBrowser.rows.append(roster(status='قيد الانتظار'))
        self.assertEqual(self.check('b'*32),'registered')

    def test_no_unified_id_uses_birth_date_and_mismatch_needs_review(self):
        self.data['field-existingUniqueId']=''
        FixtureBrowser.rows=[roster(uid='')]
        self.assertEqual(self.check(),'registered')
        FixtureBrowser.date='2016-01-02'
        with self.assertRaises(StudentFillError) as cm:self.check('b'*32)
        self.assertEqual(cm.exception.code,'student_duplicate_review')

    def test_zero_from_source_is_missing_id_and_existing_roster_match_is_skipped(self):
        self.data['field-existingUniqueId']='0'
        FixtureBrowser.rows=[roster(uid='SITE-ID')]
        self.assertEqual(self.check(),'registered')
        self.assertEqual(FixtureBrowser.instances[0].reads,['SITE-ID'])

    def test_conflicting_ids_or_names_never_register_automatically(self):
        for n,row in enumerate((roster(uid='OTHER'),roster(first='OTHER'))):
            FixtureBrowser.rows=[row]
            with self.subTest(row=row),self.assertRaises(StudentFillError) as cm:
                self.check(str(n)*32)
            self.assertEqual(cm.exception.code,'student_duplicate_review')

    def test_confirmed_save_updates_batch_roster_and_new_batch_refreshes(self):
        self.assertEqual(self.check(),'clear')
        self.guard.note_saved(self.data)
        self.assertEqual(self.check(),'registered')
        self.assertEqual(len(FixtureBrowser.instances),1)
        self.assertEqual(self.check('b'*32),'clear')
        self.assertEqual(len(FixtureBrowser.instances),2)

    def test_incomplete_roster_fails_closed(self):
        FixtureBrowser.failure=ScanError('scan_changed','row_count')
        with self.assertRaises(StudentFillError) as cm:self.check()
        self.assertEqual(cm.exception.code,'student_duplicate_check_failed')

    def test_actual_roster_reader_checks_birth_without_save(self):
        page=RosterPage(1)
        browser=StudentBrowser(page,'test@te.mehe.school',self.cancelled)
        with patch('student_scan.time.monotonic',Clock()):
            items=browser.inventory(lambda *_:None)
            birth=browser.read_birth_date(items[0])
        self.assertEqual(birth,'2015-01-02')
        self.assertEqual(page.view,'list')
        self.assertFalse(any(a[0] in ('save','fill') for a in page.actions))

    def test_detail_reader_keeps_only_verified_birth_open(self):
        for requested,expected_view in (('2015-01-02','record'),('2014-01-02','list')):
            page=RosterPage(1)
            browser=StudentBrowser(page,'test@te.mehe.school',self.cancelled)
            with patch('student_scan.time.monotonic',Clock()):
                items=browser.inventory(lambda *_:None)
                birth=browser.read_birth_date(items[0],keep_open_if_birth=requested)
            self.assertEqual(birth,'2015-01-02')
            self.assertEqual(page.view,expected_view)
            self.assertEqual(sum(a[:2]==('click','row') for a in page.actions),1)

    def test_full_paginated_roster_is_checked_before_registration(self):
        page=RosterPage(105)
        for i,row in enumerate(page.records):row['first']=f'OTHER{i}'
        page.records[101]['first']='TEST'
        page.records[101]['uid']='000123'
        with patch('student_scan.time.monotonic',Clock()):
            result=DuplicateGuard().check(page,self.data,'test@te.mehe.school',
                                          self.cancelled,'d'*32)
        self.assertEqual(result,'registered')
        self.assertEqual(page.view,'list')
        self.assertTrue(any(a[:2]==('click','button') for a in page.actions))
        self.assertFalse(any(a[0] in ('save','fill') for a in page.actions))


if __name__=='__main__':unittest.main()
