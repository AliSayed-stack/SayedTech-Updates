"""Launch installed Chrome/Edge with app-owned, persistent profiles."""
import os
from pathlib import Path
import shutil
import sys

BROWSERS = ('edge', 'chrome')
BLANK_PAGES = ('', 'about:blank')
LOGIN_URL = 'https://new-sims.mehe.gov.lb/login'


def open_login_page(context, cancelled, notify):
    """Navigate an app-owned blank tab; never replay an active login flow."""
    notify('opening')
    restored=[p for p in context.pages if not p.is_closed()]
    # A newly launched persistent context normally supplies one blank tab.
    # Reuse only that blank shell; restored site/account tabs get a fresh page.
    page=restored[0] if len(restored)==1 and restored[0].url in BLANK_PAGES else context.new_page()
    for old_page in restored:
        if old_page is not page:
            try:old_page.close()
            except Exception:pass
    for attempt in range(2):
        if cancelled.is_set():return None
        pages=[p for p in context.pages if not p.is_closed()]
        active=[p for p in pages if p.url not in BLANK_PAGES]
        if active:return active[0]
        if page.is_closed():return None
        if attempt:notify('portal_retry')
        try:page.goto(LOGIN_URL,wait_until='domcontentloaded',timeout=20000)
        except Exception:notify('manual_required')
        if cancelled.is_set():return None
        # A timeout/redirect can leave a usable portal or Microsoft popup.
        # Once any page leaves blank, LoginFlow owns all further interaction.
        active=[p for p in context.pages if not p.is_closed() and p.url not in BLANK_PAGES]
        if active:return active[0]
    if page.is_closed():return None
    notify('portal_open_manual_required')
    return page


def profile_directory(name, shift='morning'):
    if name not in BROWSERS or shift not in ('morning', 'afternoon'):
        raise ValueError('Unsupported browser profile')
    if os.name == 'nt':
        root = Path(os.environ.get('LOCALAPPDATA') or Path.home()/'AppData'/'Local')
    elif sys.platform == 'darwin':
        root = Path.home()/'Library'/'Application Support'
    else:
        root = Path(os.environ.get('XDG_DATA_HOME') or Path.home()/'.local'/'share')
    path = root/'SayedTech'/'BrowserProfiles'/f'{name}-{shift}'
    path.mkdir(parents=True, exist_ok=True)
    return path


def installed_executable(name):
    if name not in BROWSERS:
        raise ValueError('Unsupported browser')
    exe = 'msedge.exe' if name == 'edge' else 'chrome.exe'
    if os.name == 'nt':
        try:
            import winreg
            for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
                    try:
                        with winreg.OpenKey(hive, rf'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe}', 0, winreg.KEY_READ|view) as key:
                            candidate=Path(winreg.QueryValue(key,None).strip('"'))
                            if candidate.is_file():return candidate
                    except OSError:pass
        except ImportError:pass
        locations = {
            'chrome':('Google/Chrome/Application/chrome.exe',),
            'edge':('Microsoft/Edge/Application/msedge.exe',),
        }
        for base in (os.environ.get('PROGRAMFILES'),os.environ.get('PROGRAMFILES(X86)'),os.environ.get('LOCALAPPDATA')):
            if base:
                candidate=Path(base)/locations[name][0]
                if candidate.is_file():return candidate
    else:
        commands=('google-chrome','google-chrome-stable','chrome') if name=='chrome' else ('microsoft-edge','microsoft-edge-stable','msedge')
        for command in commands:
            found=shutil.which(command)
            if found:return Path(found)
        if sys.platform=='darwin':
            candidate=Path('/Applications')/('Google Chrome.app/Contents/MacOS/Google Chrome' if name=='chrome' else 'Microsoft Edge.app/Contents/MacOS/Microsoft Edge')
            if candidate.is_file():return candidate
    return None


def launch_browser(playwright, name, *, shift='morning', headless=False):
    if name not in BROWSERS:
        raise ValueError('Choose installed Google Chrome or Microsoft Edge')
    executable=installed_executable(name)
    if executable is None:
        raise FileNotFoundError('Install Google Chrome or Microsoft Edge first')
    # Persistent context keeps only this app's browser session. It never opens
    # or reads the employee's regular browser profile.
    return playwright.chromium.launch_persistent_context(
        user_data_dir=str(profile_directory(name,shift)),
        channel='msedge' if name=='edge' else 'chrome',
        headless=headless,
        args=['--new-window', '--start-maximized', '--no-first-run'] if not headless else [],
        accept_downloads=False,
        no_viewport=not headless,
    )
