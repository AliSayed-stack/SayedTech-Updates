import unittest
from unittest.mock import patch
from lxml import html
from manual_sections import fill_manual_section,manual_date,phone_country_matches
from detailed_import import DetailError
from test_manual_site_bindings import Page


class DelayedPage(Page):
    """The supplied form appears after Add; select options load later."""
    def __init__(self,name,missing=False):
        super().__init__(name)
        self.clock=0;self.added_at=None;self.loaded=False;self.options_loaded=False;self.missing=missing
        self.section=self.doc.xpath('.//section')[0]
        self.form=self.section.xpath('./div')[-1]
        for e in self.form.xpath('.//input'):
            e.set('value','');e.attrib.pop('checked',None)
        self.option_sets=[]
        for select in self.form.xpath('.//select'):
            options=list(select)
            for o in options:o.attrib.pop('selected',None)
            self.option_sets.append((select,options))
            for option in list(select):select.remove(option)
            select.append(html.fromstring('<option value="">--اختيار--</option>'))
        self.section.remove(self.form)
        self.empty=html.fromstring('<div><p>لم يُعثر على أية سجلات</p><button data-add="yes">إضافة</button></div>')
        self.section.append(self.empty)
    def after_click(self,node):
        if node.get('data-add')=='yes':self.added_at=self.clock
    def wait_for_timeout(self,ms):
        self.clock+=ms/1000
        if self.added_at is None:return
        if not self.loaded and not self.missing and self.clock-self.added_at>=.4:
            self.section.replace(self.empty,self.form);self.loaded=True
            for e in self.form.xpath('.//*[@id]'):
                old=e.get('id');e.set('id','new_'+old)
                for label in self.form.xpath('.//label[@for=$id]',id=old):label.set('for','new_'+old)
        if self.loaded and not self.options_loaded and self.clock-self.added_at>=.8:
            for select,options in self.option_sets:
                for option in list(select):select.remove(option)
                for option in options:select.append(option)
            self.options_loaded=True


class DynamicManualFormsTests(unittest.TestCase):
    def invoke(self,page,payload,title):
        with patch('manual_sections.time.monotonic',side_effect=lambda:page.clock):
            return fill_manual_section(page,{'manual':payload},title,lambda:None)

    def test_phone_add_waits_for_form_and_options_and_accepts_numeric_country_code(self):
        page=DelayedPage('phones_site.html')
        payload={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'+961',
                 'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True}
        self.assertEqual(self.invoke(page,payload,'الهواتف'),'detail_filled')
        self.assertGreaterEqual(page.clock,.8)
        self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertIn(('select','961'),page.actions)
        self.assertIn(('select','mobile'),page.actions)
        self.assertIn(('check',True),page.actions)
        self.assertEqual(page.form.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')

    def test_supplied_local_phone_form_without_country_accepts_existing_excel_country(self):
        page=DelayedPage('phones_local_site.html')
        payload={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'961 (LB)',
                 'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True}
        self.assertEqual(self.invoke(page,payload,'الهواتف'),'detail_filled')
        self.assertIn(('select','mobile'),page.actions)
        self.assertEqual(page.form.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')
        self.assertIn(('check',True),page.actions)
        self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertLess(page.clock,2)

    def test_local_layout_does_not_ignore_a_present_unmatched_country_select(self):
        page=DelayedPage('phones_site.html')
        country,options=page.option_sets[1]
        page.option_sets[1]=(country,[html.fromstring('<option value="">--اختيار--</option>'),html.fromstring('<option value="+971">+971 (AE)</option>')])
        payload={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'961 (LB)','الهواتف / رقم الهاتف':'03123456'}
        with self.assertRaises(DetailError) as error:self.invoke(page,payload,'الهواتف')
        self.assertEqual(error.exception.field,'الهواتف / رمز الدولة')
        self.assertFalse(any(a[0] in ('fill','select') for a in page.actions))

    def test_local_layout_keeps_foreign_country_mismatch_and_country_only_payload_blocked(self):
        for payload,field in [({'الهواتف / رمز الدولة':'+971','الهواتف / رقم الهاتف':'03123456'},'الهواتف / رمز الدولة'),
                               ({'الهواتف / رمز الدولة':'961 (LB)'},'الهواتف / رقم الهاتف')]:
            page=DelayedPage('phones_local_site.html')
            with self.assertRaises(DetailError) as error:self.invoke(page,payload,'الهواتف')
            self.assertEqual(error.exception.field,field)
            self.assertFalse(any(a[0] in ('fill','select') for a in page.actions))

    def test_country_caption_variants_do_not_block_the_entire_phone_form(self):
        for value,label in [('961','+961 (LB)'),('+961','961(LB)'),('LB','لبنان (+961)')]:
            with self.subTest(value=value,label=label):
                page=DelayedPage('phones_site.html')
                country,options=page.option_sets[1]
                for option in options:
                    if option.get('value')=='961':option.set('value',value);option.text=label
                payload={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'961 (LB)',
                         'الهواتف / رقم الهاتف':'03123456','الهواتف / الأساسية':True}
                self.assertEqual(self.invoke(page,payload,'الهواتف'),'detail_filled')
                self.assertIn(('select',value),page.actions)
                self.assertEqual(page.actions.count(('click','إضافة')),1)
                self.assertEqual(page.form.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')

    def test_country_select_without_matching_label_is_found_from_its_options(self):
        page=DelayedPage('phones_site.html')
        label=page.form.xpath('.//label[contains(text(),"رمز الدولة")]')[0]
        label.text='رمز الاتصال الدولي';label.attrib.pop('for',None)
        payload={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':'961 (LB)','الهواتف / رقم الهاتف':'03123456'}
        self.assertEqual(self.invoke(page,payload,'الهواتف'),'detail_filled')
        self.assertIn(('select','961'),page.actions)
        self.assertEqual(page.form.xpath('.//input[@maxlength="8"]')[0].get('value'),'03123456')

    def test_dialing_codes_do_not_choose_another_country_or_an_ambiguous_value(self):
        options=[{'value':'us','label':'+1 (US)'},{'value':'ca','label':'+1 (CA)'},
                 {'value':'961','label':'+961 (LB)'},{'value':'971','label':'+971 (AE)'}]
        self.assertEqual([o['value'] for o in phone_country_matches(options,'١ (CA)')],['ca'])
        self.assertEqual(phone_country_matches(options,'961 (US)'),[])
        self.assertEqual(phone_country_matches(options,'12'),[])
        self.assertEqual({o['value'] for o in phone_country_matches(options,'+1')},{'us','ca'})

    def test_document_add_then_fills_all_fields_with_month_day_date(self):
        page=DelayedPage('documents_site.html')
        payload={'المستندات / نوع المستند':'بطاقة تلقيح','المستندات / تاريخ الإصدار':'10/8/2026',
                 'المستندات / رقم الوثيقة':'00007','المستندات / ملاحظة':'TEST NOTE',
                 'المستندات / جرى التسليم':True,'المستندات / طباعة على اللائحة':False}
        self.assertEqual(self.invoke(page,payload,'المستندات'),'detail_filled')
        self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertIn(('select','vaccination_card'),page.actions)
        self.assertEqual(page.form.xpath('.//input[@type="date"]')[0].get('value'),'2026-10-08')
        self.assertIn(('check',True),page.actions);self.assertIn(('check',False),page.actions)
        self.assertFalse(any(a[0]=='click' and a[1] in ('حفظ','حفظ القسم') for a in page.actions))

    def test_missing_control_reports_fixed_header_and_never_adds_twice(self):
        page=DelayedPage('phones_site.html',missing=True)
        with self.assertRaises(DetailError) as error:self.invoke(page,{'الهواتف / رقم الهاتف':'03123456'},'الهواتف')
        self.assertEqual(error.exception.field,'الهواتف / رقم الهاتف')
        self.assertEqual(page.actions.count(('click','إضافة')),1)
        self.assertFalse(any(a[0]=='fill' for a in page.actions))

    def test_invalid_date_is_reported_before_add_and_future_expiry_is_allowed(self):
        page=DelayedPage('documents_site.html')
        with self.assertRaises(DetailError) as error:self.invoke(page,{'المستندات / تاريخ الإصدار':'31/2/2026'},'المستندات')
        self.assertEqual(error.exception.field,'المستندات / تاريخ الإصدار');self.assertEqual(page.actions,[])
        self.assertEqual(manual_date('١٠/٨/٢٠٣١'),'2031-10-08')


if __name__=='__main__':unittest.main()
