"""Offscreen Qt tests of custom extraction choices and pending/session gates."""
import unittest
from unittest.mock import patch
try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication,QDialog,QWidget
    from scan_picker import ScanPicker
    from student_scan_dialog import StudentScanDialog
    from test_detailed_batch_ui import Signal
    from test_scan import Page
    from scan_selection import roster_choices
    QT=True
except ImportError:QT=False


class Controller:
    def __init__(self):self.scan_result=Signal();self.event=Signal();self.requests=[]
    def list_scan_roster(self,r):self.requests.append(('roster',r));return True
    def list_scan_grades(self,r):self.requests.append(('grades',r));return True
    def scan_students(self,*args,**kwargs):self.requests.append(('scan',args,kwargs));return True
    def cancel_scan(self,r):self.requests.append(('cancel',r))


@unittest.skipUnless(QT,'Qt unavailable')
class ScanPickerUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])

    def choices(self):
        page=Page(6)
        for i,row in enumerate(page.records):row['status']='قيد الانتظار' if i%2 else 'مقدّم للمراجعة'
        return roster_choices(page.records,page.account)

    def test_picker_uses_checked_visible_rows_and_keeps_no_uid_rows_separate(self):
        choices=self.choices();choices['roster'][0]['uid']='';choices['roster'][1]['uid']=''
        p=ScanPicker(choices);p.check_visible(Qt.Checked)
        p.status.setCurrentIndex(p.status.findData('قيد الانتظار'))
        self.assertEqual(p.indexes(),[1,3,5])
        p.apply_selection();self.assertEqual(p.selection['indexes'],[1,3,5])
        self.assertEqual(p.selection['signature'],choices['signature']);p.deleteLater()

    def test_status_picker_requires_a_real_status_and_filters_live_preview(self):
        p=ScanPicker(self.choices(),True);p.apply_selection();self.assertIsNone(p.selection)
        p.status.setCurrentIndex(p.status.findData('مقدّم للمراجعة'))
        self.assertEqual(p.indexes(),[0,2,4]);p.apply_selection()
        self.assertEqual(p.selection,{'status':'مقدّم للمراجعة'});p.deleteLater()

    def test_both_shifts_offer_four_scopes_without_trial_and_all_students_is_default(self):
        for shift in ('morning','afternoon'):
            parent=QWidget();parent.school_shift=shift;c=Controller();d=StudentScanDialog(c,parent)
            self.assertEqual([d.scope.itemData(i) for i in range(d.scope.count())],[0,'grade','selected','status'])
            with patch('student_scan_dialog.QFileDialog.getSaveFileName',return_value=('/tmp/synthetic.xlsx','')):d.start()
            self.assertEqual(c.requests[-1],('scan',('/tmp/synthetic.xlsx',0,d.request_id,None),{'selection':None}))
            d.set_pending(False);d.reject();d.deleteLater();parent.deleteLater()

    def test_custom_dispatch_waits_for_choice_and_ignores_stale_or_session_lost_roster(self):
        parent=QWidget();parent.school_shift='morning';c=Controller();d=StudentScanDialog(c,parent)
        d.scope.setCurrentIndex(d.scope.findData('selected'));d.start();self.assertEqual(c.requests,[])
        d.load_choices();request=d.choice_request;self.assertTrue(d.pending);self.assertFalse(d.start_button.isEnabled())
        c.scan_result.emit('f'*32,'scan_roster',0,0,self.choices());self.assertTrue(d.pending)
        def choose(p):p.selection={'signature':p.choices['signature'],'indexes':[1]};return QDialog.Accepted
        with patch('scan_picker.ScanPicker.exec',choose):c.scan_result.emit(request,'scan_roster',0,0,self.choices())
        self.assertFalse(d.pending);self.assertEqual(d.selection_spec['indexes'],[1])
        with patch('student_scan_dialog.QFileDialog.getSaveFileName',return_value=('/tmp/synthetic.xlsx','')):d.start()
        self.assertEqual(c.requests[-1][2]['selection']['indexes'],[1])
        d.set_pending(False);d.load_choices();request=d.choice_request
        c.event.emit('disconnected');c.scan_result.emit(request,'scan_roster',0,0,self.choices())
        self.assertIsNone(d.selection_spec);self.assertFalse(d.start_button.isEnabled())
        d.reject();d.deleteLater();parent.deleteLater()

    def test_loading_grades_locks_other_actions_until_correlated_response(self):
        parent=QWidget();c=Controller();d=StudentScanDialog(c,parent)
        d.scope.setCurrentIndex(d.scope.findData('grade'));d.load_grades()
        self.assertTrue(d.pending);d.start();self.assertEqual(len(c.requests),1)
        c.scan_result.emit(d.grades_request,'scan_grades',0,0,{'grades':['الأول أساسي']})
        self.assertFalse(d.pending);self.assertTrue(d.start_button.isEnabled())
        d.reject();d.deleteLater();parent.deleteLater()

    def test_ordered_picker_sorts_grades_and_names_without_changing_selected_identity(self):
        import copy
        from scan_selection import select_records,roster_choices
        rows=self.choices()['roster']
        grades=('الثالث ثانوي','الروضة الثانية','الأول أساسي','الروضة الأولى','الثالث ثانوي','الأول أساسي')
        names=('زياد','مريم','زياد','سارة','أحمد','أحمد')
        for row,grade,name in zip(rows,grades,names):row.update(grade=grade,first=name)
        rows[5]['uid']=''
        choices=roster_choices(rows,'test@te.mehe.school');original=copy.deepcopy(choices)
        p=ScanPicker(choices,ordered=True)
        self.assertEqual(p.order,[3,1,5,2,4,0])
        self.assertEqual([p.grade.itemData(i) for i in range(p.grade.count())],['','الروضة الأولى','الروضة الثانية','الأول أساسي','الثالث ثانوي'])
        for display,source in enumerate(p.order):self.assertEqual(p.table.item(display,1).text(),rows[source]['uid'])
        p.table.item(2,0).setCheckState(Qt.Checked);p.table.item(5,0).setCheckState(Qt.Checked)
        p.grade.setCurrentIndex(p.grade.findData('الأول أساسي'));self.assertEqual(p.indexes(),[5])
        p.grade.setCurrentIndex(0);p.search.setText('احمد');self.assertEqual(p.indexes(),[5])
        p.search.clear();p.apply_selection()
        selected=select_records(rows,p.selection,'test@te.mehe.school')
        self.assertEqual([r['first'] for r in selected],['زياد','أحمد'])
        self.assertEqual(choices,original);p.deleteLater()

    def test_only_morning_manual_selection_requests_the_ordered_view(self):
        for shift,mode in (('morning','selected'),('morning','status'),('afternoon','selected')):
            parent=QWidget();parent.school_shift=shift;c=Controller();d=StudentScanDialog(c,parent)
            d.scope.setCurrentIndex(d.scope.findData(mode));d.load_choices()
            with patch('scan_picker.ScanPicker') as picker:
                picker.return_value.exec.return_value=QDialog.Rejected
                c.scan_result.emit(d.choice_request,'scan_roster',0,0,self.choices())
                self.assertEqual(picker.call_args.kwargs['ordered'],shift=='morning' and mode=='selected')
            d.reject();d.deleteLater();parent.deleteLater()


if __name__=='__main__':unittest.main()
