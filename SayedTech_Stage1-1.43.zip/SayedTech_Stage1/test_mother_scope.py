"""DOM fixtures with duplicate father/mother fields and changing input ids."""
import re
import unittest
from pathlib import Path
from lxml import html
from detailed_import import mother_surname_field, DetailError

class DOM:
    def __init__(self, nodes): self.nodes=nodes
    def count(self): return len(self.nodes)
    def locator(self, selector):
        found=[]
        for node in self.nodes:
            if selector.startswith('xpath='): items=node.xpath(selector[6:])
            elif selector=='input': items=node.xpath('.//input')
            else: items=node.xpath('.//input[@maxlength="256"][@required]')
            for item in items:
                if item not in found: found.append(item)
        return DOM(found)
    def get_by_text(self, pattern):
        # Leaf-most matching text element, as with Playwright text locators.
        found=[]
        for node in self.nodes:
            for item in node.iterdescendants():
                if pattern.search(item.text_content()) and not any(pattern.search(c.text_content()) for c in item):
                    found.append(item)
        return DOM(found)
    def get_by_label(self, pattern):
        found=[]
        for node in self.nodes:
            for label in node.xpath('.//label[@for]'):
                if pattern.search(label.text_content()):
                    found.extend(node.xpath('.//input[@id=$target]',target=label.get('for')))
        return DOM(found)

def fixture(mother, father=True):
    first='<div><h3>الأقارب #1</h3><label>الشهرة</label><input id="father" maxlength="256" required="" value="الأب"/></div>' if father else ''
    return DOM([html.fromstring('<section>'+first+mother+'</section>')])

class MotherScopeTests(unittest.TestCase):
    def test_actual_site_card_with_guardian_checkbox_and_arabic_label(self):
        source=Path(__file__).with_name('test_fixtures').joinpath('relative2.html').read_text()
        for new_id in ('_r_2g_','_r_session_changed_'):
            card=source.replace('_r_2g_',new_id)
            scope=fixture(card)
            field=mother_surname_field(scope)
            self.assertEqual(field.nodes[0].get('id'),new_id)
            self.assertNotEqual(field.nodes[0].get('type'),'checkbox')

    def test_selects_mother_among_identical_required_inputs(self):
        for title in ('الأقارب #2','الأقارب #٢','الأقارب 2'):
            scope=fixture('<div><h3>'+title+'</h3><div><label>الشهرة *</label><input id="_r_2g_" maxlength="256" required=""/></div><div><label>الاسم</label><input maxlength="256" required=""/></div></div>')
            self.assertEqual(mother_surname_field(scope).nodes[0].get('id'),'_r_2g_')
    def test_associated_label_and_changing_id(self):
        scope=fixture('<div><h3>الأقارب #2</h3><label for="new-id">الشهرة</label><input id="new-id" maxlength="256" required=""/></div>')
        self.assertEqual(mother_surname_field(scope).nodes[0].get('id'),'new-id')
    def test_unique_unlabelled_input_only_in_mother(self):
        scope=fixture('<div><h3>الأقارب #2</h3><input id="mother" maxlength="256" required=""/></div>')
        self.assertEqual(mother_surname_field(scope).nodes[0].get('id'),'mother')
    def test_missing_or_ambiguous_mother_never_uses_father(self):
        for fragment in ('', '<div><h3>الأقارب #2</h3><input maxlength="256" required=""/><input maxlength="256" required=""/></div>', '<h3>الأقارب #2</h3>'):
            with self.assertRaises(DetailError): mother_surname_field(fixture(fragment))
    def test_duplicate_mother_blocks_rejected(self):
        block='<div><h3>الأقارب #2</h3><input maxlength="256" required=""/></div>'
        with self.assertRaises(DetailError): mother_surname_field(fixture(block+block))

if __name__=='__main__': unittest.main()
