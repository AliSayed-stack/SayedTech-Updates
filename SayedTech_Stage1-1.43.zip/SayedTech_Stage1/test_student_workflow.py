"""Offline year isolation, conversion, and first-column enrollment selection."""
import copy
import hashlib
from pathlib import Path
import tempfile
import threading
import unittest
import xml.etree.ElementTree as ET
import zipfile

from nsldb_reference import (tables_for_year, map_records, source_sheets, write_reference,
    canonical_year, TARGET_YEAR, ReferenceError)
from student_workflow import convert_to_simple, write_simple, workbook_rows, WORKFLOW_HEADERS
from student_excel import read_students, ExcelInputError, NS
from test_nsldb import tables
from test_students import record


def selections(path, values, formula_row=None):
    """Disposable user-edit simulation, not an authored workbook deliverable."""
    with zipfile.ZipFile(path) as z: parts={n:z.read(n) for n in z.namelist()}
    q=lambda n:'{'+NS['m']+'}'+n
    s=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    for row in s.findall('m:sheetData/m:row',NS)[1:]:
        number=int(row.get('r'))
        if number not in values:continue
        c=next(c for c in row if c.get('r')=='A'+str(number))
        for child in list(c):c.remove(child)
        value=values[number]
        if isinstance(value,int):
            c.attrib.pop('t',None);ET.SubElement(c,q('v')).text=str(value)
        else:
            c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=value
        if number==formula_row:ET.SubElement(c,q('f')).text='1'
    parts['xl/worksheets/sheet1.xml']=ET.tostring(s)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,v in parts.items():z.writestr(n,v)


class StudentWorkflowTests(unittest.TestCase):
    def test_import_accepts_blank_unemployed_parent_occupation_and_rechecks_changed_sector(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'simple.xlsx';data=record()
            for parent in ('father','mother'):
                data['field-'+parent+'Sector']='عاطل عن العمل'
                data['field-'+parent+'Occupation']=''
            write_simple([data],path,'TEST.xlsx','0'*64);selections(path,{2:1})
            self.assertEqual(read_students(path)[0]['errors'],[])
            data['field-fatherSector']='قطاع خاص'
            write_simple([data],path,'TEST.xlsx','0'*64);selections(path,{2:1})
            errors=read_students(path)[0]['errors']
            self.assertTrue(any('مهنة الأب' in e for e in errors))
            self.assertFalse(any('مهنة الأم' in e for e in errors))

    def test_year_filter_applies_to_every_related_school_person_table(self):
        t=tables()
        t['StudentSchool'][1]['TermID']='20252026'
        t['GPerson'].append({'GPersonID':999,'FirstName':'OTHER','LastName':'YEAR'})
        other=copy.deepcopy(t['StudentSchool'][0]);other['GPersonID']=999;t['StudentSchool'].append(other)
        papers=[{'GPersonID':p,'MEHEID':school,'TermID':year,'Code':str(i)}
            for i,(p,school,year) in enumerate([(101,'TEST SCHOOL','2025-2026'),(101,'TEST SCHOOL','2024 / 2025'),
                (999,'TEST SCHOOL','20252026'),(101,'OTHER SCHOOL','20252026')])]
        for name in ('BRCStatement','StudentCurriculum','StudentJustification','StudentSupplement','StudentDocs'):
            t[name]=copy.deepcopy(papers)
        filtered=tables_for_year(t)
        self.assertEqual(len(filtered['StudentSchool']),3)
        self.assertEqual(len(filtered['GPerson']),1)
        for name in ('BRCStatement','StudentCurriculum','StudentJustification','StudentSupplement','StudentDocs'):
            self.assertEqual(len(filtered[name]),1)
            self.assertEqual(filtered[name][0]['Code'],'0')
        self.assertEqual(len(t['StudentSchool']),5)
        self.assertTrue(all(canonical_year(r['metadata'][2])==TARGET_YEAR for r in map_records(filtered)))
        with self.assertRaisesRegex(ReferenceError,'year'):tables_for_year(t,'20242025')
        for r in t['StudentSchool']:r['TermID']='20242025'
        with self.assertRaisesRegex(ReferenceError,'year_empty'):tables_for_year(t)

    def test_conversion_filters_old_full_exports_keeps_27_fields_and_no_selections(self):
        with tempfile.TemporaryDirectory() as d:
            full=Path(d)/'full.xlsx';simple=Path(d)/'simple.xlsx'
            t=tables();write_reference(map_records(t),full,'TEST.sdf','0'*64,[],source_data=source_sheets(t,threading.Event()),mode='detailed')
            before=hashlib.sha256(full.read_bytes()).digest()
            self.assertEqual(convert_to_simple(full,simple),3)
            self.assertEqual(hashlib.sha256(full.read_bytes()).digest(),before)
            with zipfile.ZipFile(simple) as z:
                rows=workbook_rows(z,'الطلاب')
                self.assertEqual(list(rows[0][1].values()),WORKFLOW_HEADERS)
                self.assertEqual(len(rows),4)
                self.assertTrue(all(r[1]['A']=='0' and len(r[1])==28 for r in rows[1:]))
                self.assertEqual(rows[1][1]['B'],'000001')
                self.assertNotIn('رقم الهاتف (LivingPhone)',rows[0][1].values())
            with self.assertRaisesRegex(ExcelInputError,'لم تختر'):read_students(simple)
            with self.assertRaises(ExcelInputError):convert_to_simple(full,full)
            self.assertEqual(hashlib.sha256(full.read_bytes()).digest(),before)

    def test_first_column_accepts_numeric_or_text_choices_and_only_selected_are_read(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'simple.xlsx'
            records=[]
            for i in range(6):
                r=record();r['field-existingUniqueId']=f'000{i}';records.append(r)
            records[0]['field-firstName']='' # unselected and invalid must never be submitted
            write_simple(records,path,'TEST.xlsx','0'*64)
            selections(path,{2:0,3:1,4:'لا',5:'نعم',6:'1',7:'0'})
            rows=read_students(path)
            self.assertEqual([r['excel_row'] for r in rows],[3,5,6])
            self.assertTrue(all(r['workflow'] and not r['errors'] for r in rows))
            self.assertEqual(rows[0]['values']['field-existingUniqueId'],'0001')
            self.assertEqual(rows[0]['values']['field-birthDate'],'2015-01-02')
            selections(path,{2:'2'})
            with self.assertRaisesRegex(ExcelInputError,'أول عمود'):read_students(path)
            selections(path,{2:1},formula_row=2)
            with self.assertRaisesRegex(ExcelInputError,'معادلات'):read_students(path)

    def test_empty_parent_defaults_are_filled_but_other_required_fields_stay_for_review(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'simple.xlsx';r=record()
            r['isFatherDeceased']='';r['isMotherDeceased']='';r['field-motherNationality']='';r['field-firstNameEn']='';r['field-firstName']=''
            write_simple([r],path,'TEST.xlsx','0'*64);selections(path,{2:'نعم'})
            rows=read_students(path)
            self.assertFalse(rows[0]['values']['isFatherDeceased'])
            self.assertFalse(rows[0]['values']['isMotherDeceased'])
            self.assertEqual(rows[0]['values']['field-motherNationality'],'سوريا')
            self.assertTrue(any('مطلوب' in e for e in rows[0]['errors']))

    def test_simple_export_writes_defaults_and_preserves_explicit_parent_values(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'simple.xlsx';blank=record();explicit=record()
            for key in ('isFatherDeceased','isMotherDeceased','field-motherNationality'):blank[key]=''
            explicit.update({'isFatherDeceased':'نعم','isMotherDeceased':True,'field-motherNationality':'لبنان'})
            write_simple([blank,explicit],path,'TEST.xlsx','0'*64)
            with zipfile.ZipFile(path) as z:
                rows=workbook_rows(z,'الطلاب')
                self.assertEqual([rows[1][1][c] for c in ('R','W','X')],['لا','لا','سوريا'])
                self.assertEqual([rows[2][1][c] for c in ('R','W','X')],['نعم','نعم','لبنان'])
                self.assertTrue(all(r[1]['A']=='0' for r in rows[1:]))


if __name__=='__main__':unittest.main()
