"""Site sections populate existing columns without widening the workbook."""
import unittest
from student_scan import StudentBrowser, TABS


def field(label,value,id='generated',group=''):
    return dict(id=id,label=label,value=value,group=group,required=False,kind='text')


class MappingTests(unittest.TestCase):
    def setUp(self):
        self.row=dict(values={'field-firstName':'STUDENT','field-nationality':'لبنان'},
                      read_ids=[],address={},fields=[])

    def test_dynamic_ids_and_display_values_map_to_existing_fields(self):
        StudentBrowser.capture(self.row,TABS[1],[field('مكان القيد *','زغرتا'),field('رقم السجل','00123')])
        self.assertEqual(self.row['values']['field-registryPlace'],'زغرتا')
        self.assertEqual(self.row['values']['field-registryNumber'],'00123')
        StudentBrowser.capture(self.row,TABS[8],[field('لغة التدريس','الفرنسية'),field('الشعبة','الشعبة ب')])
        self.assertEqual(self.row['values']['field-enrollment-teaching-language'],'الفرنسية')
        self.assertEqual(self.row['values']['field-enrollment-grade-section'],'الشعبة ب')

    def test_relatives_are_scoped_and_never_overwrite_student(self):
        fields=[field('الاسم الأول (بالعربية)','FATHER',group='الأقارب #1'),
                field('الاسم الأول (بالعربية)','MOTHER',group='الأقارب #2'),
                field('الجنسية','سوريا',group='الأقارب #2'),
                field('الشهرة (بالعربية)','SURNAME',group='الأقارب #2')]
        StudentBrowser.capture(self.row,TABS[5],fields)
        self.assertEqual(self.row['values']['field-middleName'],'FATHER')
        self.assertEqual(self.row['values']['field-motherName'],'MOTHER')
        self.assertEqual(self.row['values']['field-motherNationality'],'سوريا')
        self.assertEqual(self.row['values']['field-nationality'],'لبنان')
        self.assertEqual(self.row['values']['field-firstName'],'STUDENT')
        self.assertNotIn('field-lastName',self.row['values'])

    def test_relationship_overrides_card_ordinal_and_duplicate_values_remain_unmapped(self):
        StudentBrowser.capture(self.row,TABS[5],[field('نوع العلاقة','الأخ',group='الأقارب #2'),
             field('الاسم الأول (بالعربية)','BROTHER',group='الأقارب #2')])
        self.assertNotIn('field-motherName',self.row['values'])
        StudentBrowser.capture(self.row,TABS[1],[field('الجنسية','سوريا'),field('الجنسية','لبنان')])
        self.assertEqual(self.row['values']['field-nationality'],'لبنان')

    def test_phone_type_and_document_number_do_not_become_address_or_registry(self):
        StudentBrowser.capture(self.row,TABS[3],[field('النوع','خلوي'),field('رقم الهاتف','03123456')])
        StudentBrowser.capture(self.row,TABS[6],[field('رقم الوثيقة','001234')])
        self.assertEqual(self.row['address'],{})
        self.assertNotIn('field-registryNumber',self.row['values'])
        StudentBrowser.capture(self.row,TABS[2],[field('النوع','سكن أساسي')])
        self.assertEqual(self.row['address']['النوع'],'سكن أساسي')


if __name__=='__main__':unittest.main()
