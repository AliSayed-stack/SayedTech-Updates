"""Explicit per-student simple-form save; confirmation is attempted only once.

Uses the supplied Save section, SweetAlert confirmation and fresh success toast.
Only the exact success message permits returning to management and continuing.
"""
import re
import time
import uuid
from urllib.parse import urlsplit

from login_flow import exact_https_host,SIMS_HOST,visible
from student_excel import FIELDS,BY_ID,OCCUPATION_SECTORS,validate_record,field_is_required,shift_for_username,normalize_date
from student_fill import fill_student,StudentFillError,NEW_STUDENT,MANAGEMENT

WATCH_SUCCESS = r'''key => {
 const selector='.Toastify__toast--success[role="alert"]';
 const seen=new WeakSet(document.querySelectorAll(selector));
 const state={clicked:false,success:false};
 const inspect=()=>document.querySelectorAll(selector).forEach(e=>{
   if(!state.clicked){seen.add(e);return;}
   if(seen.has(e)||!e.getClientRects().length) return;
   const copy=e.cloneNode(true);
   copy.querySelectorAll('button,svg,.Toastify__toast-icon,.Toastify__progress-bar--wrp').forEach(n=>n.remove());
   if(state.clicked && copy.textContent.trim()==='تم حفظ السجل الأساسي للطالب بنجاح.') state.success=true;
 });
 const clicked=e=>{if(e.target.closest('.swal2-confirm'))state.clicked=true;};
 document.addEventListener('click',clicked,true);
 const observer=new MutationObserver(inspect);
 observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true});
 state.cleanup=()=>{observer.disconnect();document.removeEventListener('click',clicked,true);};
 window[key]=state;
}'''
READ_SUCCESS = 'key => window[key]?.success === true'
STOP_SUCCESS = 'key => {window[key]?.cleanup();delete window[key];}'

FORM_STATE = r'''() => [...document.querySelectorAll('input,select,textarea')]
 .filter(e=>e.getClientRects().length && !['hidden','file','password','submit','button'].includes(e.type))
 .map(e=>({id:e.id, value:e.type==='checkbox'?e.checked:e.tagName==='SELECT'?
   (e.value?e.selectedOptions[0]?.textContent.trim()||'':''):e.value,
   raw:e.value, valid:e.validity.valid, required:e.required || e.getAttribute('aria-required')==='true'}))'''


def fill_and_save_student(page,record,username,cancelled,account_session=None,
                          duplicate_guard=None,batch_id=None,entry_kind='طالب موجود'):
    record,errors=validate_record(record,shift_for_username(username))
    if errors:
        from student_excel import first_invalid_field
        raise StudentFillError('student_invalid',first_invalid_field(errors))
    attempted=False
    saved=False
    watch='__sayed_save_'+uuid.uuid4().hex
    def guard(require_draft=True):
        if cancelled.is_set():raise StudentFillError('student_cancelled')
        if not exact_https_host(page.url,SIMS_HOST):raise StudentFillError('student_account_required')
        account=visible(page.get_by_text(re.compile(r'^\s*'+re.escape(username)+r'\s*$',re.I)))
        if account_session is not None and account_session.revoked:raise StudentFillError('student_account_required')
        if account is None and not (account_session is not None and account_session.allows(page,username)):
            raise StudentFillError('student_account_required')
        if require_draft and urlsplit(page.url).path.rstrip('/')!=NEW_STUDENT:
            raise StudentFillError('student_open_management')

    def popups():
        return [p for p in page.locator('.swal2-popup[role="dialog"]').all() if p.is_visible()]

    def snapshot():
        guard()
        state=page.evaluate(FORM_STATE)
        if not isinstance(state,list) or len(state)>500:raise StudentFillError('student_save_blocked')
        for field in state:
            if not isinstance(field,dict) or not field.get('valid'):
                raise StudentFillError('student_save_blocked')
            spec = BY_ID.get(field.get('id'))
            if spec and spec['type']=='date' and field.get('value') not in ('',None):
                # Custom site date inputs can render YYYY/MM/DD after ISO filling.
                # Canonicalize only this in-memory comparison; never rewrite the form.
                try:
                    field['value']=normalize_date(field['value'])
                    if 'raw' in field:field['raw']=normalize_date(field['raw'])
                except (ValueError,TypeError,OverflowError):
                    raise StudentFillError('student_save_blocked',spec['id']) from None
            required = field.get('required')
            if field.get('id') in OCCUPATION_SECTORS and not field_is_required(spec, record):
                required = False
            if required and field.get('value') in ('',None,False):
                raise StudentFillError('student_save_blocked')
        for field in FIELDS:
            matches=[f for f in state if f.get('id')==field['id']]
            expected=record.get(field['id'],'')
            if not matches and expected in ('',False):continue
            if len(matches)!=1 or matches[0].get('value')!=expected:
                raise StudentFillError('student_save_blocked',field['id'])
        # Only the original form fields are compared: a modal's own controls
        # cannot masquerade as the student form or change the bound snapshot.
        return [f for f in state if f.get('id') in {x['id'] for x in FIELDS}]

    try:
        guard(False)
        if popups():raise StudentFillError('student_save_blocked')
        if duplicate_guard is not None:
            verdict=duplicate_guard.check(page,record,username,cancelled,batch_id,account_session)
            if verdict=='registered':return 'student_already_registered'
        record=fill_student(page,record,username,cancelled,account_session=account_session,entry_kind=entry_kind)
        guard()
        draft_url=page.url
        before=snapshot()
        buttons=[b for b in page.get_by_role('button',name='حفظ القسم',exact=True).all() if b.is_visible()]
        if len(buttons)!=1 or not buttons[0].is_enabled():raise StudentFillError('student_save_blocked')
        if page.url!=draft_url or snapshot()!=before:raise StudentFillError('student_save_blocked')
        # A click can reach the site even when Playwright times out. From here,
        # every ambiguous failure is locked for manual verification, with no retry.
        attempted=True
        buttons[0].click(timeout=7000)
        end=time.monotonic()+15
        while True:
            guard()
            if page.url!=draft_url:raise StudentFillError('student_save_unverified')
            dialogs=popups()
            if len(dialogs)==1:break
            if len(dialogs)>1 or time.monotonic()>end:raise StudentFillError('student_save_unverified')
            page.wait_for_timeout(100)
        dialog=dialogs[0]
        if ('swal2-icon-question' not in (dialog.get_attribute('class') or '').split() or
            dialog.locator('#swal2-title').inner_text().strip()!='هل أنت متأكد؟' or
            dialog.locator('#swal2-html-container').inner_text().strip()!='هل تريد المتابعة؟'):
            raise StudentFillError('student_save_unverified')
        confirm=[b for b in dialog.get_by_role('button',name='تأكيد',exact=True).all() if b.is_visible()]
        if len(confirm)!=1 or not confirm[0].is_enabled():raise StudentFillError('student_save_unverified')
        guard()
        if page.url!=draft_url or snapshot()!=before:raise StudentFillError('student_save_unverified')
        page.evaluate(WATCH_SUCCESS,watch)
        confirm[0].click(timeout=7000)
        end=time.monotonic()+20
        while True:
            guard(False)
            if page.evaluate(READ_SUCCESS,watch):
                saved=True
                break
            if time.monotonic()>=end:raise StudentFillError('student_save_unverified')
            page.wait_for_timeout(100)
        page.evaluate(STOP_SUCCESS,watch)
        if duplicate_guard is not None:duplicate_guard.note_saved(record)
        guard(False)
        page.goto('https://'+SIMS_HOST+MANAGEMENT,wait_until='domcontentloaded',timeout=20000)
        guard(False)
        page.get_by_role('button',name='إنشاء',exact=True).wait_for(state='visible',timeout=10000)
        if urlsplit(page.url).path.rstrip('/')!=MANAGEMENT:
            raise StudentFillError('student_saved_return_failed')
        return 'student_saved'
    except Exception as exc:
        if saved:raise StudentFillError('student_saved_return_failed') from None
        if attempted:raise StudentFillError('student_save_unverified') from None
        if isinstance(exc,StudentFillError):raise
        raise StudentFillError('student_failed') from None
    finally:
        try:page.evaluate(STOP_SUCCESS,watch)
        except Exception:pass
