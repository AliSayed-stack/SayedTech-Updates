import tempfile
import threading
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch
from openpyxl import load_workbook
from detailed_import import read_details
from manual_sections import SELECT
from scan_dropdowns import repair_scan_dropdowns
from student_scan import export_students
import test_manual_sections as fixtures


class SelectionFirstTests(unittest.TestCase):
    def test_excel_saved_calculation_chain_is_rebuilt_for_old_and_new_layouts(self):
        from identity_workbook import Q,RELNS,OFFREL,CT
        _,data=fixtures.ManualWorkbookTests().data()
        data['records'][0]['unread_tabs']=[]
        for already_first in (False,True):
            with self.subTest(already_first=already_first),tempfile.TemporaryDirectory() as folder:
                old=Path(folder)/'excel_saved.xlsx';new=Path(folder)/'fixed.xlsx'
                if already_first:export_students(data,old,threading.Event())
                else:
                    with patch('scan_workbook_layout.selection_first'):export_students(data,old,threading.Event())
                with zipfile.ZipFile(old) as z:parts={n:z.read(n) for n in z.namelist()}
                original=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
                count=len(list(original.iter(Q('f'))))
                self.assertGreater(count,0)
                # Excel writes this part on save; it retains old cell coordinates.
                parts['xl/calcChain.xml']=f'<calcChain xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><c r="AJ2" i="1"/></calcChain>'.encode()
                relationships=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
                ET.SubElement(relationships,'{'+RELNS+'}Relationship',Id='rIdCalcChain',Type=OFFREL+'/calcChain',Target='calcChain.xml')
                parts['xl/_rels/workbook.xml.rels']=ET.tostring(relationships)
                types=ET.fromstring(parts['[Content_Types].xml'])
                ET.SubElement(types,'{'+CT+'}Override',PartName='/xl/calcChain.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml')
                parts['[Content_Types].xml']=ET.tostring(types)
                with zipfile.ZipFile(old,'w') as z:
                    for name,value in parts.items():z.writestr(name,value)
                repair_scan_dropdowns(old,new)
                with zipfile.ZipFile(new) as z:
                    self.assertNotIn('xl/calcChain.xml',z.namelist())
                    self.assertFalse(any(r.get('Type','').endswith('/calcChain') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))))
                    self.assertFalse(any('calcChain' in r.get('PartName','') for r in ET.fromstring(z.read('[Content_Types].xml'))))
                    calculation=ET.fromstring(z.read('xl/workbook.xml')).find(Q('calcPr'))
                    self.assertEqual(calculation.get('calcMode'),'auto')
                    self.assertEqual(calculation.get('fullCalcOnLoad'),'1')
                    self.assertEqual(calculation.get('forceFullCalc'),'1')
                    fixed=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                    self.assertEqual(len(list(fixed.iter(Q('f')))),count)
                book=load_workbook(new);sheet=book['الطلاب']
                self.assertIn('AD2:AJ2',sheet['AK2'].value)
                self.assertEqual(sheet['B2'].value,data['records'][0]['item']['uid']);book.close()

    def test_old_export_moves_to_a_preserving_values_styles_and_import(self):
        _,data=fixtures.ManualWorkbookTests().data()
        data['records'][0]['unread_tabs']=[]
        with tempfile.TemporaryDirectory() as folder:
            old=Path(folder)/'old.xlsx';new=Path(folder)/'new.xlsx'
            with patch('scan_workbook_layout.selection_first'):
                export_students(data,old,threading.Event())
            book=load_workbook(old);sheet=book['الطلاب']
            self.assertEqual(sheet['AK1'].value,SELECT)
            sheet['AK2']='1'
            headers={c.value:c.column for c in sheet[1]}
            sheet.cell(2,headers['الهواتف / رقم الهاتف']).value='03123499'
            expected={h:(sheet.cell(2,c).value,sheet.cell(2,c).style_id) for h,c in headers.items()}
            book.save(old);book.close();original=old.read_bytes()
            repair_scan_dropdowns(old,new)
            self.assertEqual(old.read_bytes(),original)
            book=load_workbook(new);sheet=book['الطلاب']
            self.assertEqual(sheet['A1'].value,SELECT);self.assertEqual(sheet['A2'].value,'1')
            self.assertEqual(len(sheet[1]),56)
            self.assertEqual(sheet.freeze_panes,'D2')
            for cell in sheet[1]:
                value,style=expected[cell.value]
                if cell.value!='حالة العنوان':
                    actual=sheet.cell(2,cell.column).value
                    self.assertEqual('' if actual is None else actual,'' if value is None else value,cell.value)
                self.assertEqual(sheet.cell(2,cell.column).style_id,style,cell.value)
            self.assertIn('AD2:AJ2',sheet['AK2'].value)
            self.assertEqual(next(iter(sheet.tables.values())).tableColumns[0].name,SELECT)
            self.assertTrue(any('A2' in v for v in sheet.data_validations.dataValidation))
            book.close()
            row=read_details(new)[0]
            self.assertEqual(row['values']['field-existingUniqueId'],data['records'][0]['item']['uid'])
            self.assertEqual(row['manual']['الهواتف / رقم الهاتف'],'03123499')
            # Older exports still import if the user has not moved their column.
            self.assertEqual(read_details(old)[0]['values'],row['values'])


if __name__=='__main__':unittest.main()
