"""SIMS uses common.saved ('تم الحفظ بنجاح') and advances the tab on success."""
import threading
import unittest
import json
import subprocess
from unittest.mock import patch
from detailed_import import DetailError,fill_details
from manual_save import save_manual
from test_detailed_import import Page,Element
from detail_dom import SAVE_SUCCESS_TEXT


class Toast(Element):
    def __init__(self,page,pattern=None):super().__init__(page,'toast');self.pattern=pattern
    def filter(self,has_text=None,**kwargs):return Toast(self.page,has_text)
    def count(self):
        return int(self.page.saved and bool(self.pattern and self.pattern.search(self.page.message)))
    def wait_for(self,state,**kwargs):
        if (state=='visible')!=bool(self.count()):raise TimeoutError('expected save notification not found')


class SaveNode(Element):
    def get_by_role(self,role,name='',**kwargs):return SaveNode(self.page,name)
    def wait_for(self,state,**kwargs):
        if self.key=='dialog' and (state=='visible')!=self.page.dialog:raise TimeoutError('dialog state')
    def click(self,**kwargs):
        super().click(**kwargs)
        if self.key in ('حفظ','حفظ القسم'):self.page.dialog=True
        if self.key=='تأكيد':
            self.page.dialog=False;self.page.saved=True
            self.page.active_tab='الهواتف'


class SavePage(Page):
    def __init__(self,message='تم الحفظ بنجاح'):
        super().__init__();self.message=message;self.saved=False;self.dialog=False;self.active_tab='عناوين السكن'
    def get_by_role(self,role,name='',**kwargs):return Toast(self) if role=='alert' else SaveNode(self,name)
    def locator(self,selector):
        if 'swal2-popup' in selector:return SaveNode(self,'dialog')
        if selector=='section':return SaveNode(self,'scope')
        return super().locator(selector)
    def goto(self,url,**kwargs):super().goto(url,**kwargs);self.saved=False;self.active_tab='المعلومات الشخصية'


class SaveTextTests(unittest.TestCase):
    def test_arabic_success_pattern_has_same_behavior_in_browser_javascript(self):
        samples=['تم الحفظ بنجاح','تم الحفظ بنجاح.','تم حفظ القسم بنجاح',
                 'تم حفظ بيانات الطالب بنجاح.','لم يتم الحفظ بنجاح','تعذر الحفظ','تم الحذف بنجاح','']
        expected=[True,True,True,True,False,False,False,False]
        script='const fs=require("fs");const p=JSON.parse(fs.readFileSync(0,"utf8"));const re=new RegExp(p.pattern);process.stdout.write(JSON.stringify(p.samples.map(s=>re.test(s))));'
        result=subprocess.run(['node','-e',script],input=json.dumps({'pattern':SAVE_SUCCESS_TEXT.pattern,'samples':samples}),text=True,capture_output=True,check=True)
        self.assertEqual(json.loads(result.stdout),expected)
        self.assertEqual([bool(SAVE_SUCCESS_TEXT.search(s)) for s in samples],expected)

    def invoke(self,page,row,mode):
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,mode,'school@te.mehe.school',threading.Event())

    def test_current_site_address_success_is_detected_after_automatic_tab_advance(self):
        page=SavePage();row={'values':page.values.copy(),'address':dict(page.choices)}
        self.assertEqual(self.invoke(page,row,'address'),'detail_saved')
        self.assertEqual(page.active_tab,'الهواتف')
        self.assertEqual(page.actions.count(('click','حفظ القسم')),1)
        self.assertEqual(page.actions.count(('click','تأكيد')),1)

    def test_both_current_and_legacy_success_text_for_all_manual_save_sections(self):
        for message in ('تم الحفظ بنجاح','تم الحفظ بنجاح.','تم حفظ القسم بنجاح','تم حفظ بيانات الطالب بنجاح.'):
            for title in ('الهواتف','البريد الإلكتروني','الأقارب','بطاقات التعريف','المستندات'):
                with self.subTest(message=message,title=title):
                    page=SavePage(message)
                    self.assertEqual(save_manual(page,title,lambda:None),'detail_saved')
                    self.assertEqual(page.actions.count(('click','تأكيد')),1)

    def test_automatic_import_does_not_stop_at_phone_after_saved_address(self):
        page=SavePage();row={'values':page.values.copy(),'address':dict(page.choices),
                            'manual':{'الهواتف / رقم الهاتف':'03123456'}}
        def fill(page,row,title,guard):
            guard();page.actions.append(('filled',title));page.values['رقم الهاتف']=row['manual']['الهواتف / رقم الهاتف']
            return 'detail_filled'
        with patch('manual_sections.fill_manual_section',side_effect=fill):
            self.assertEqual(self.invoke(page,row,'details_import'),'detail_import_saved')
        self.assertEqual(page.values['رقم الهاتف'],'03123456')
        self.assertEqual(page.actions.count(('filled','الهواتف')),1)
        self.assertEqual(page.actions.count(('click','تأكيد')),2)

    def test_error_or_absent_acknowledgement_never_advances_or_retries_save(self):
        for message in ('لم يتم الحفظ بنجاح','تعذر الحفظ','تم الحذف بنجاح',''):
            page=SavePage(message);row={'values':page.values.copy(),'address':dict(page.choices),
                                      'manual':{'الهواتف / رقم الهاتف':'03123456'}}
            with patch('manual_sections.fill_manual_section') as fill,patch('manual_save.send_review') as review,self.assertRaises(DetailError):
                self.invoke(page,row,'details_import_review')
            fill.assert_not_called();review.assert_not_called()
            self.assertEqual(page.actions.count(('click','تأكيد')),1)
            self.assertFalse(any(action=='goto' for action,_ in page.actions))


if __name__=='__main__':unittest.main()
