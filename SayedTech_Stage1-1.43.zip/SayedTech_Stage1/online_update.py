"""HTTPS release lookup and verified download; no school data is transmitted."""
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import zipfile

VERSION = re.compile(r'^[0-9]+(?:\.[0-9]+){1,2}$')
SHA256 = re.compile(r'^[0-9a-f]{64}$')
MAX_MANIFEST = 65536
MAX_PACKAGE = 650 * 1024 * 1024


class UpdateError(Exception):
    pass


def settings_path():
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'SayedTech' / 'update_source.json'


def https_url(url):
    if not isinstance(url, str):
        raise UpdateError('رابط التحديث غير صالح.')
    parsed = urllib.parse.urlsplit(url.strip())
    if parsed.scheme.lower() != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise UpdateError('استخدم رابط HTTPS مباشر للتحديث.')
    return url.strip()


def source_url():
    from core import ASSET_BASE
    for path in (settings_path(), ASSET_BASE / 'assets' / 'update_source.json'):
        try:
            url = json.loads(path.read_text(encoding='utf-8')).get('manifest_url', '')
        except (OSError, ValueError, AttributeError):
            continue
        if url:
            return https_url(url)
    return ''


def save_source_url(url):
    url = https_url(url)
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.new')
    try:
        temporary.write_text(json.dumps({'manifest_url': url}), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def newer(remote, current):
    if not VERSION.fullmatch(remote) or not VERSION.fullmatch(current):
        raise UpdateError('رقم النسخة المنشورة غير صالح.')
    def parts(value):
        return tuple(int(x) for x in value.split('.')) + (0,) * (3 - value.count('.') - 1)
    return parts(remote) > parts(current)


def _open_https(url):
    response = urllib.request.urlopen(urllib.request.Request(https_url(url), headers={'User-Agent': 'SayedTech-Updater'}), timeout=25)
    try:
        https_url(response.geturl())
    except Exception:
        response.close()
        raise
    return response


def check_release(manifest_url, current_version, frozen=False):
    try:
        with _open_https(manifest_url) as response:
            raw = response.read(MAX_MANIFEST + 1)
        if len(raw) > MAX_MANIFEST:
            raise UpdateError('ملف معلومات التحديث كبير جداً.')
        manifest = json.loads(raw.decode('utf-8'))
        version = manifest['version']
        if not newer(version, current_version):
            return None
        key = 'installer' if frozen else 'source'
        if key not in manifest:
            raise UpdateError('النسخة المنشورة لا تحتوي ملف تحديث مناسباً لهذا النوع من البرنامج.')
        package = manifest[key]
        url = https_url(package['url'])
        digest = package['sha256']
        if not isinstance(digest, str) or not SHA256.fullmatch(digest):
            raise UpdateError('بصمة ملف التحديث غير صالحة.')
        return {'version': version, 'url': url, 'sha256': digest, 'kind': key}
    except UpdateError:
        raise
    except (OSError, ValueError, KeyError, TypeError, UnicodeError) as exc:
        raise UpdateError('تعذّر قراءة معلومات التحديث من الرابط.') from exc


def download_release(release):
    parent = settings_path().parent / 'updates'
    parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='SayedTech-', dir=parent))
    filename = 'SayedTech-Setup.exe' if release['kind'] == 'installer' else 'SayedTech_Stage1.zip'
    package = stage / filename
    digest = hashlib.sha256()
    size = 0
    try:
        try:
            with _open_https(release['url']) as response, package.open('wb') as target:
                while chunk := response.read(1024 * 1024):
                    size += len(chunk)
                    if size > MAX_PACKAGE:
                        raise UpdateError('ملف التحديث كبير جداً.')
                    digest.update(chunk)
                    target.write(chunk)
        except (OSError, http.client.HTTPException, ssl.SSLError) as first_error:
            package.unlink(missing_ok=True)
            # Frozen Windows builds can have different certificate/network handling
            # than the system browser. Retry GitHub release assets through Windows TLS.
            _powershell_download(release['url'], package, first_error)
            size = package.stat().st_size
            if size > MAX_PACKAGE:
                raise UpdateError('ملف التحديث كبير جداً.')
            digest = hashlib.sha256()
            with package.open('rb') as stream:
                while chunk := stream.read(1024 * 1024):
                    digest.update(chunk)
        if not size or digest.hexdigest() != release['sha256']:
            raise UpdateError('فشل التحقق من ملف التحديث. لم يُثبّت أي شيء.')
        if release['kind'] == 'source':
            extract_source(package, stage / 'extracted', release['version'])
        else:
            with package.open('rb') as stream:
                if stream.read(2) != b'MZ':
                    raise UpdateError('ملف التثبيت غير صالح.')
        return stage
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise


def _powershell_download(url, destination, first_error):
    """Retry a failed Python HTTPS transfer with Windows' native TLS stack."""
    parsed = urllib.parse.urlsplit(https_url(url))
    if sys.platform != 'win32' or parsed.hostname not in {
        'github.com', 'release-assets.githubusercontent.com',
    }:
        raise UpdateError(f'تعذّر تنزيل ملف التحديث: {first_error}') from first_error
    powershell = shutil.which('powershell.exe') or shutil.which('powershell')
    if not powershell:
        raise UpdateError(f'تعذّر تنزيل ملف التحديث: {first_error}') from first_error
    def ps_quote(value):
        return "'" + str(value).replace("'", "''") + "'"
    script = (
        "$ProgressPreference='SilentlyContinue'; "
        "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; "
        f"Invoke-WebRequest -UseBasicParsing -Uri {ps_quote(url)} "
        f"-OutFile {ps_quote(destination)} -TimeoutSec 900"
    )
    try:
        result = subprocess.run(
            [powershell, '-NoProfile', '-NonInteractive', '-Command', script],
            capture_output=True, text=True, timeout=960, check=False,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise UpdateError(f'تعذّر تنزيل ملف التحديث عبر اتصال Windows: {exc}') from exc
    if result.returncode != 0 or not destination.is_file():
        detail = (result.stderr or result.stdout or str(first_error)).strip()
        raise UpdateError(f'تعذّر تنزيل ملف التحديث عبر اتصال Windows: {detail[-500:]}')


def extract_source(package, output, expected_version):
    output.mkdir()
    total = 0
    with zipfile.ZipFile(package) as archive:
        names = set()
        for item in archive.infolist():
            path = Path(item.filename.replace('\\', '/'))
            if (item.is_dir() or not item.filename.startswith('SayedTech_Stage1/')
                or path.is_absolute() or '..' in path.parts or len(path.parts) < 2
                or any(x in {'.venv', 'dist', '__pycache__'} for x in path.parts)
                or (item.external_attr >> 16) & 0o170000 == 0o120000
                or item.filename in names):
                raise UpdateError('بنية ملف التحديث غير صالحة.')
            names.add(item.filename)
            total += item.file_size
            if total > MAX_PACKAGE or len(names) > 2000:
                raise UpdateError('محتوى التحديث كبير جداً.')
            destination = output.joinpath(*path.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item) as source, destination.open('wb') as target:
                shutil.copyfileobj(source, target)
    root = output / 'SayedTech_Stage1'
    if not (root / 'START_WINDOWS.bat').is_file():
        raise UpdateError('ملف تشغيل التحديث مفقود.')
    core_text = (root / 'core.py').read_text(encoding='utf-8')
    if not re.search(r"^APP_VERSION\s*=\s*['\"]" + re.escape(expected_version) + r"['\"]", core_text, re.M):
        raise UpdateError('رقم النسخة داخل الحزمة لا يطابق الإعلان.')
    return root


def begin_install(stage, kind, app_root, app_pid):
    if sys.platform != 'win32':
        raise UpdateError('التثبيت التلقائي مدعوم على Windows.')
    if kind == 'installer':
        os.startfile(str(stage / 'SayedTech-Setup.exe'))
        return
    from update_apply import launch_detached
    launch_detached(stage, app_root, app_pid)
