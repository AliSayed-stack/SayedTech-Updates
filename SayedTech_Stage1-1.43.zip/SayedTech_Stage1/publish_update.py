"""Owner tool: generate latest.json next to finished, hosted release files."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

from online_update import https_url, VERSION


def fingerprint(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def generate(version, source_path, source_url, installer_path=None, installer_url=None):
    if not VERSION.fullmatch(version):
        raise ValueError('Invalid version.')
    with zipfile.ZipFile(source_path) as z:
        text = z.read('SayedTech_Stage1/core.py').decode('utf-8')
        if not re.search(r"^APP_VERSION\s*=\s*['\"]" + re.escape(version) + r"['\"]", text, re.M):
            raise ValueError('Source ZIP version does not match.')
    result = {'version': version, 'source': {'url': https_url(source_url), 'sha256': fingerprint(source_path)}}
    if (installer_path is None) != (installer_url is None):
        raise ValueError('Provide both installer path and HTTPS URL, or neither.')
    if installer_path:
        with Path(installer_path).open('rb') as stream:
            if stream.read(2) != b'MZ':
                raise ValueError('Installer is not a Windows EXE.')
        result['installer'] = {'url': https_url(installer_url), 'sha256': fingerprint(installer_path)}
    return result


def main():
    parser = argparse.ArgumentParser(description='Create latest.json after uploading a release to HTTPS hosting.')
    parser.add_argument('--version', required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--source-url', required=True)
    parser.add_argument('--installer', type=Path)
    parser.add_argument('--installer-url')
    parser.add_argument('--output', type=Path, default=Path('latest.json'))
    args = parser.parse_args()
    content = generate(args.version, args.source, args.source_url, args.installer, args.installer_url)
    args.output.write_text(json.dumps(content, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(args.output.resolve())


if __name__ == '__main__':main()
