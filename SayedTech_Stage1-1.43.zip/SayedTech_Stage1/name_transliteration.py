"""Offline spelling suggestions for review in the simple export, never on import."""
import re
import unicodedata

NAME_PAIRS = tuple(('field-' + name, 'field-' + name + 'En')
                   for name in ('firstName', 'lastName', 'middleName', 'motherName'))


def normalized(text):
    text = unicodedata.normalize('NFKC', text)
    text = ''.join(c for c in text if not unicodedata.combining(c) and c != 'ـ')
    return text.translate(str.maketrans({'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي'}))


# Conventional suggestions, not an assertion of passport spelling.
_NAMES = '''أحمد=Ahmad|محمد=Mohammad|محمود=Mahmoud|حمد=Hamad|حامد=Hamed|حميد=Hamid|حمود=Hammoud|مصطفى=Mustafa|علي=Ali|عمر=Omar|عمرو=Amr|عثمان=Othman|حسن=Hassan|حسين=Hussein|حسان=Hassan|حسام=Houssam|خالد=Khaled|خليل=Khalil|ابراهيم=Ibrahim|اسماعيل=Ismail|اسحاق=Ishaq|يوسف=Youssef|يونس=Younes|يعقوب=Yacoub|ادم=Adam|نوح=Nouh|موسى=Moussa|عيسى=Issa|يحيى=Yahya|زكريا=Zakaria|سليمان=Sleiman|داود=Daoud|ايوب=Ayoub|بلال=Bilal|باسل=Bassel|بسام=Bassam|بشار=Bashar|بشير=Bashir|ماهر=Maher|سامر=Samer|سمير=Samir|سامي=Sami|وسام=Wissam|وسيم=Wassim|وليد=Walid|وائل=Wael|رامي=Rami|رامز=Ramez|فادي=Fadi|فؤاد=Fouad|فراس=Firas|فارس=Fares|فريد=Farid|فايز=Fayez|فيصل=Faisal|طارق=Tarek|طلال=Talal|زياد=Ziad|زيد=Zaid|زاهر=Zaher|زهير=Zouheir|جمال=Jamal|جلال=Jalal|جواد=Jawad|جهاد=Jihad|نادر=Nader|نبيل=Nabil|ناصر=Nasser|نزار=Nizar|ناجي=Naji|هادي=Hadi|هاني=Hani|هشام=Hisham|هيثم=Haitham|عادل=Adel|عامر=Amer|عمار=Ammar|عماد=Imad|عصام=Issam|عاصم=Assem|علاء=Alaa|اياد=Iyad|ايمن=Ayman|انس=Anas|انور=Anwar|ادهم=Adham|اكرم=Akram|امجد=Amjad|امير=Amir|امين=Amin|اسامة=Osama|كريم=Karim|كمال=Kamal|كامل=Kamel|لؤي=Louay|قصي=Qusai|قاسم=Qassem|قصي=Qusai|قتيبة=Qutaiba|معاذ=Moaz|مالك=Malek|مروان=Marwan|معتز=Moataz|مهند=Mohannad|رشيد=Rashid|رضوان=Radwan|رضا=Rida|ربيع=Rabih|رائد=Raed|راشد=Rashed|سعيد=Said|سعد=Saad|سليم=Salim|سالم=Salem|صالح=Saleh|صلاح=Salah|صابر=Saber|صبحي=Sobhi|شادي=Shadi|شريف=Sharif|شربل=Charbel|جورج=George|الياس=Elias|فاطمة=Fatima|عائشة=Aisha|خديجة=Khadija|مريم=Mariam|زينب=Zainab|رقية=Ruqayya|حفصة=Hafsa|اسماء=Asmaa|اسراء=Israa|ايمان=Iman|امل=Amal|امال=Amal|امينة=Amina|اميرة=Amira|اية=Aya|ايات=Ayat|الاء=Alaa|اسيل=Aseel|احلام=Ahlam|ابتسام=Ibtisam|انعام=Inaam|حنان=Hanan|حلا=Hala|حليمة=Halima|حنين=Haneen|حياة=Hayat|هدى=Huda|هبة=Hiba|هلا=Hala|هناء=Hanaa|هند=Hind|هيام=Hiyam|هاجر=Hajar|سارة=Sara|سلمى=Salma|سلوى=Salwa|سمر=Samar|سميرة=Samira|سامية=Samia|سهى=Suha|سهام=Siham|سحر=Sahar|سناء=Sanaa|سعاد=Souad|سوسن=Sawsan|سيرين=Sirine|سلاف=Sulaf|شهد=Shahd|شام=Sham|شيماء=Shaimaa|شيرين=Shirin|صباح=Sabah|صفاء=Safaa|صفية=Safiya|ضحى=Duha|عبير=Abeer|علا=Ola|عليا=Alia|عفاف=Afaf|غادة=Ghada|غنى=Ghina|غنوة=Ghinwa|فرح=Farah|فدوى=Fadwa|فداء=Fidaa|فيروز=Fairouz|كوثر=Kawthar|لينا=Lina|لين=Leen|ليان=Layan|ليلى=Layla|لمى=Lama|لميس=Lamis|لانا=Lana|لبنى=Lubna|منى=Mona|مها=Maha|منال=Manal|ميس=Mays|ميساء=Maysaa|ملاك=Malak|ملك=Malak|مرح=Marah|مرام=Maram|ناديا=Nadia|نادية=Nadia|ندى=Nada|نور=Nour|نورا=Noura|نوال=Nawal|نجوى=Najwa|نسرين=Nisrine|نجاح=Najah|نجلاء=Najlaa|نعيمة=Naima|نهى=Nuha|نرمين=Nermin|ياسمين=Yasmin|يارا=Yara|يسرى=Yusra|ريم=Reem|ريما=Rima|رنا=Rana|رانيا=Rania|رغد=Raghad|رهف=Rahaf|روان=Rawan|روعة=Rawaa|رولا=Rola|رند=Rand|زينة=Zeina|زين=Zain|زهرة=Zahra|زهراء=Zahraa|سيد=Sayed|شيخ=Sheikh|احمد=Ahmad|عبد=Abd|الله=Allah|رحمن=Rahman|رحيم=Rahim|كريم=Karim|عزيز=Aziz|رزاق=Razzaq|فتاح=Fattah|قادر=Qader|لطيف=Latif|مجيد=Majid|وهاب=Wahhab|حكيم=Hakim|دين=Din|نصر=Nasr|نجار=Najjar|حداد=Haddad|حلاق=Hallaq|خطيب=Khatib|درويش=Darwish|صالح=Saleh|سليمان=Sleiman|خوري=Khoury|عوض=Awad|عباس=Abbas|عبيد=Obeid|شاهين=Shahin|عليان=Alian|ابو=Abou|ام=Umm|بن=Bin|بنت=Bint'''
COMMON = {normalized(key): value for key, value in
          (entry.split('=') for entry in _NAMES.split('|'))}
LETTERS = dict(zip('ابتثجحخدذرزسشصضطظعغفقكلمنهويءؤئة',
                   ('a','b','t','th','j','h','kh','d','dh','r','z','s','sh','s','d','t','z',
                    'a','gh','f','q','k','l','m','n','h','w','y',"'",'ou','i','a')))


def word_spelling(word):
    key = normalized(word)
    if key in COMMON:
        return COMMON[key]
    if key.startswith('عبد') and len(key) > 3:
        return 'Abd ' + word_spelling(key[3:])
    if key.startswith('ال') and len(key) > 2:
        return 'Al ' + word_spelling(key[2:])
    if key.endswith('الدين') and len(key) > 5:
        return word_spelling(key[:-5]) + ' Al Din'
    if not all(c in LETTERS for c in key):
        return ''
    return ''.join(LETTERS[c] for c in key).capitalize()


def transliterate_name(value):
    if not isinstance(value, str) or len(value) > 256:
        return ''
    text = normalized(value).strip()
    if not text or any(unicodedata.category(c).startswith('C') for c in text):
        return ''
    # Keep ordinary Latin segments; unsupported input stays blank for review.
    pieces = re.split(r'([\s\-]+)', text)
    result = []
    for piece in pieces:
        if not piece:
            continue
        if re.fullmatch(r'[\s\-]+', piece):
            result.append(' ' if piece.isspace() else piece)
        elif re.fullmatch(r"[A-Za-z]+(?:'[A-Za-z]+)*", piece):
            result.append(piece)
        else:
            spelling = word_spelling(piece)
            if not spelling:
                return ''
            result.append(spelling)
    output = ''.join(result)
    return output if len(output) <= 256 else ''


def suggest_english_names(record):
    result = dict(record)
    for arabic, english in NAME_PAIRS:
        existing = result.get(english)
        if existing is None or (isinstance(existing, str) and not existing.strip()):
            result[english] = transliterate_name(result.get(arabic))
    return result
