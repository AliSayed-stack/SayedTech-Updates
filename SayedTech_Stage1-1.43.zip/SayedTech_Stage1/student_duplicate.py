"""Read-only school-roster check before a simple registration request."""
import uuid

from student_excel import validate_record, shift_for_username, first_invalid_field
from student_fill import StudentFillError
from student_scan import StudentBrowser, ScanError, canonical_uid, is_deleted, normalized


def _name(values):
    return tuple(normalized(values.get(key, '')) for key in
                 ('field-firstName', 'field-middleName', 'field-lastName'))


def _row_name(row):
    return tuple(normalized(row.get(key, '')) for key in ('first', 'middle', 'last'))


class DuplicateGuard:
    def __init__(self, browser_factory=StudentBrowser):
        self.browser_factory=browser_factory
        self.batch_id=None
        self.roster=[]
        self.browser=None

    def check(self, page, raw, username, cancelled, batch_id=None, account_session=None):
        data, errors=validate_record(raw,shift_for_username(username))
        if errors: raise StudentFillError('student_invalid',first_invalid_field(errors))
        # A new batch (including each manual one-off request) rereads the live
        # roster. A confirmed save is added to the in-memory roster immediately.
        token=batch_id if isinstance(batch_id,str) and len(batch_id)==32 else uuid.uuid4().hex
        if self.batch_id!=token:
            self.batch_id=None
            try:
                browser=self.browser_factory(page,username,cancelled,account_session=account_session)
                try: roster=browser.inventory(lambda *_:None)
                except ScanError as exc:
                    if exc.code!='scan_empty':raise
                    state=browser.move(1)
                    if state['total']!=0:raise
                    roster=[]
            except ScanError as exc:
                raise StudentFillError('student_duplicate_check_failed') from exc
            except Exception:
                raise StudentFillError('student_duplicate_check_failed') from None
            if any('status' not in row for row in roster):
                raise StudentFillError('student_duplicate_check_failed')
            self.roster=roster
            self.browser=browser
            self.batch_id=token
        uid=canonical_uid(data.get('field-existingUniqueId',''))
        name=_name(data)
        if not all(name):raise StudentFillError('student_duplicate_review')
        candidates=[row for row in self.roster if not is_deleted(row) and
                    ((uid and row['uid']==uid) or _row_name(row)==name)]
        if not candidates:return 'clear'
        # A shared ID with a conflicting name, or the same name with a
        # conflicting nonblank ID, needs a person to resolve it.
        for row in candidates:
            if uid and row['uid']==uid and _row_name(row)!=name:
                raise StudentFillError('student_duplicate_review')
            if uid and row['uid'] and row['uid']!=uid and _row_name(row)==name:
                raise StudentFillError('student_duplicate_review')
        # The management table does not show birth dates. Open only plausible
        # rows to confirm the date, even when their unified IDs agree.
        for row in candidates:
            if _row_name(row)!=name:continue
            try: dob=row['birthDate'] if row.get('_saved') else self.browser.read_birth_date(row)
            except Exception:
                raise StudentFillError('student_duplicate_review') from None
            if not dob:raise StudentFillError('student_duplicate_review')
            if dob==data['field-birthDate']:return 'registered'
            # The same full name with a different date is not proof that the
            # roster row is a different person; stop for human review.
            raise StudentFillError('student_duplicate_review')
        return 'clear'

    def note_saved(self, data):
        self.roster.append({'uid':canonical_uid(data.get('field-existingUniqueId','')),
            'first':data['field-firstName'],'middle':data['field-middleName'],
            'last':data['field-lastName'],'status':'قيد الانتظار',
            'birthDate':data['field-birthDate'],'_saved':True})
