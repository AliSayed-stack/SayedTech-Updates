"""Offline smoke checks for the Windows distribution, never accessing school data."""
def configure_browser():
    # Browser binaries are supplied by the user's Chrome/Edge installation.
    return None


def check_browser():
    """Verify the Playwright driver, without requiring a bundled browser."""
    from pathlib import Path
    from playwright._impl._driver import compute_driver_executable
    driver, cli = compute_driver_executable()
    if not Path(driver).is_file() or not Path(cli).is_file():
        raise RuntimeError('Playwright driver files are missing from the login helper')

