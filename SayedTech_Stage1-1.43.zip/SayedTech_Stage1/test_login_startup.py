"""Blank startup, bounded navigation and no replay after an OAuth redirect."""
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock
from browser_launch import open_login_page,LOGIN_URL


def page(url='about:blank'):
    result=SimpleNamespace(url=url,closed=False)
    result.is_closed=lambda:result.closed
    result.close=Mock(side_effect=lambda:setattr(result,'closed',True))
    result.goto=Mock(side_effect=lambda *_args,**_kwargs:setattr(result,'url',LOGIN_URL))
    return result


class StartupTests(unittest.TestCase):
    def setUp(self):self.events=[];self.cancelled=threading.Event()

    def open(self,context):return open_login_page(context,self.cancelled,self.events.append)

    def test_initial_blank_tab_is_reused_and_failed_navigation_retries_once(self):
        tab=page();context=SimpleNamespace(pages=[tab],new_page=Mock(side_effect=AssertionError('blank tab already available')))
        def navigate(*args,**kwargs):
            self.assertEqual(args,(LOGIN_URL,));self.assertEqual(kwargs['timeout'],20000)
            if tab.goto.call_count==1:raise TimeoutError('synthetic blank timeout')
            tab.url=LOGIN_URL
        tab.goto.side_effect=navigate
        self.assertIs(self.open(context),tab);self.assertEqual(tab.goto.call_count,2)
        context.new_page.assert_not_called();tab.close.assert_not_called()
        self.assertIn('portal_retry',self.events);self.assertNotIn('portal_open_manual_required',self.events)

    def test_timeout_after_portal_navigation_does_not_reload_the_login(self):
        tab=page();context=SimpleNamespace(pages=[tab])
        def navigate(*_args,**_kwargs):tab.url=LOGIN_URL;raise TimeoutError('synthetic loading timeout')
        tab.goto.side_effect=navigate
        self.assertIs(self.open(context),tab);self.assertEqual(tab.goto.call_count,1)
        self.assertIn('manual_required',self.events);self.assertNotIn('portal_retry',self.events)

    def test_microsoft_popup_stops_blank_retries_without_replaying_credentials(self):
        tab=page();popup=page('https://login.microsoftonline.com/common/login');context=SimpleNamespace(pages=[tab])
        def navigate(*_args,**_kwargs):context.pages.append(popup);raise RuntimeError('synthetic redirect')
        tab.goto.side_effect=navigate
        self.assertIs(self.open(context),popup);self.assertEqual(tab.goto.call_count,1)
        popup.goto.assert_not_called();self.assertNotIn('portal_retry',self.events)

    def test_two_blank_failures_leave_clear_manual_status_and_no_automatic_login(self):
        tab=page();tab.goto.side_effect=TimeoutError('synthetic network failure');context=SimpleNamespace(pages=[tab])
        self.assertIs(self.open(context),tab);self.assertEqual(tab.goto.call_count,2)
        self.assertEqual(self.events[-1],'portal_open_manual_required')
        self.assertNotIn('authenticated',self.events);tab.close.assert_not_called()

    def test_restored_site_tabs_are_closed_only_after_creating_fresh_page(self):
        for url in ('https://new-sims.mehe.gov.lb/dashboard/analytics','https://login.microsoftonline.com/common/login'):
            old=page(url);fresh=page();context=SimpleNamespace(pages=[old])
            def new_page():context.pages.append(fresh);return fresh
            context.new_page=Mock(side_effect=new_page)
            self.assertIs(self.open(context),fresh)
            context.new_page.assert_called_once();old.close.assert_called_once();old.goto.assert_not_called()

    def test_cancellation_during_navigation_prevents_any_retry(self):
        tab=page();context=SimpleNamespace(pages=[tab])
        def navigate(*_args,**_kwargs):self.cancelled.set();raise TimeoutError('synthetic cancelled load')
        tab.goto.side_effect=navigate
        self.assertIsNone(self.open(context));self.assertEqual(tab.goto.call_count,1)
        self.assertNotIn('portal_retry',self.events)


if __name__=='__main__':unittest.main()
