import copy
import threading
import unittest
from unittest.mock import patch
from detailed_import import fill_details, start_detail_import, open_existing_detail_student, DetailError


class Element:
    def __init__(self,page,key):self.page,self.key=page,key
    def count(self):return 1
    def all(self):return [self]
    def is_visible(self):return self.key!='empty' or not self.page.existing
    def is_enabled(self):return True
    def wait_for(self,**kw):pass
    def input_value(self):return self.page.values.get(self.key,'')
    def click(self,**kw):self.page.actions.append(('click',self.key))
    def fill(self,value,**kw):self.page.values[self.key]=value;self.page.actions.append(('fill',self.key))
    def select_option(self,value,**kw):self.page.values[self.key]=value;self.page.actions.append(('select',self.key))
    def evaluate(self,script):
        label=self.page.choices.get(self.key,'خلوي')
        if 'selectedIndex' in script:return label
        return [{'value':'test','label':label,'disabled':False}]
    def filter(self,**kw):return self
    def locator(self,selector):return Element(self.page,'شهرة الأم')
    def get_by_text(self,*a,**kw):
        if a and hasattr(a[0],'search'):
            result=Element(self.page,'mother-block')
            if a[0].search('الأقارب #1'):result.count=lambda:0
            return result
        return Element(self.page,'empty')
    def get_by_role(self,role,name='',**kw):return Element(self.page,name)
    def get_by_label(self,pattern,**kw):
        if isinstance(pattern,str):return Element(self.page,pattern)
        for label in ['شهرة الأم','البلد','المحافظة','القضاء','المنطقة','رقم الهاتف','النوع','الشارع','تفاصيل العنوان ١']:
            if pattern.search(label):return Element(self.page,label)
        raise AssertionError('unknown label')


class Page:
    def __init__(self):
        self.url='https://new-sims.mehe.gov.lb/dashboard/students/management/existing'
        self.values={'field-firstName':'أحمد','field-middleName':'علي','field-lastName':'السيد','field-birthDate':'2015-01-02'}
        self.actions=[];self.existing=False;self.clock=0
        self.choices={'البلد':'لبنان','المحافظة':'الشمال','القضاء':'زغرتا','المنطقة':'بلدة اختبار'}
    def get_by_text(self,*a,**kw):return Element(self,'account')
    def get_by_role(self,role,name='',**kw):return Element(self,name)
    def locator(self,selector):return Element(self,selector.lstrip('#'))
    def wait_for_timeout(self,ms):self.clock+=ms/1000
    def goto(self,url,**kw):self.actions.append(('goto',url));self.url=url


class DetailFillTests(unittest.TestCase):
    def test_detailed_sections_and_combined_import_for_both_school_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            for section in ('address','phone','relative','all'):
                with self.subTest(username=username,section=section):
                    page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
                    result=self.fill(page,row,section,username)
                    self.assertEqual(result,'detail_all_saved' if section=='all' else 'detail_saved')
                    expected=3 if section=='all' else 1
                    self.assertEqual(page.actions.count(('click','حفظ القسم')),expected)
                    self.assertEqual(page.actions.count(('click','تأكيد')),expected)
                    if section in ('relative','all'):
                        self.assertEqual(page.values['شهرة الأم'],'الحسين')

    def test_combined_skips_existing_sections_and_saves_mother_for_both_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            with self.subTest(username=username):
                page=Page();page.existing=True;row=self.setup_record(page)
                row['mother_surname']='الحسين'
                self.assertEqual(self.fill(page,row,'all',username),'detail_all_partial')
                self.assertEqual(page.values['شهرة الأم'],'الحسين')
                self.assertEqual(page.actions.count(('click','تأكيد')),1)

    def test_return_to_management_for_both_school_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            with self.subTest(username=username):
                page=Page();row=self.setup_record(page)
                with patch('detailed_import.fill_details',return_value='detail_all_saved') as fill:
                    start_detail_import(page,row,'all',username,threading.Event())
                self.assertEqual(page.actions,[('goto','https://new-sims.mehe.gov.lb/dashboard/students/management')])
                self.assertEqual(fill.call_args.args[3],username)

    def test_user_request_returns_from_open_student_to_management_once(self):
        page=Page();record=self.setup_record(page)
        with patch('detailed_import.fill_details',return_value='detail_all_saved') as fill:
            self.assertEqual(start_detail_import(page,record,'all','school@te.pm.mehe.school',threading.Event()),'detail_all_saved')
        self.assertEqual(page.actions,[('goto','https://new-sims.mehe.gov.lb/dashboard/students/management')])
        fill.assert_called_once()
        self.assertEqual(fill.call_args.args[2],'all')

    def test_user_request_from_management_does_not_reload_it(self):
        page=Page();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        with patch('detailed_import.fill_details',return_value='detail_saved'):
            self.assertEqual(start_detail_import(page,{},'phone','school@te.pm.mehe.school',threading.Event()),'detail_saved')
        self.assertEqual(page.actions,[])

    def test_user_request_never_navigates_from_untrusted_page(self):
        page=Page();page.url='https://other.example/dashboard/students/management/new'
        with self.assertRaises(DetailError) as error:
            start_detail_import(page,{},'all','school@te.pm.mehe.school',threading.Event())
        self.assertEqual(error.exception.code,'detail_account')
        self.assertEqual(page.actions,[])

    def setup_record(self,page):
        return {'values':copy.deepcopy(page.values),'phone':'03123456','address':dict(page.choices)}
    def fill(self,page,row,section,username='school@te.pm.mehe.school'):
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,section,username,threading.Event())

    def test_phone_save_and_confirm_both_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            page=Page();row=self.setup_record(page)
            self.assertEqual(self.fill(page,row,'phone',username),'detail_saved')
            self.assertEqual(page.values['رقم الهاتف'],'03123456')
            self.assertIn(('click','حفظ القسم'),page.actions)
            self.assertIn(('click','تأكيد'),page.actions)
            self.assertNotIn(('click','إرسال للمراجعة'),page.actions)

    def test_mother_surname_uses_existing_relatives_form_and_saves(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        self.assertEqual(self.fill(page,row,'relative'),'detail_saved')
        self.assertEqual(page.values['شهرة الأم'],'الحسين')
        self.assertIn(('click','حفظ القسم'),page.actions)
        self.assertNotIn(('click','إضافة'),page.actions)

    def test_mother_surname_does_not_overwrite_existing_value(self):
        page=Page();page.values['شهرة الأم']='غربال'
        row=self.setup_record(page);row['mother_surname']='الحسين'
        with self.assertRaises(DetailError) as exc:self.fill(page,row,'relative')
        self.assertEqual(exc.exception.code,'detail_existing')
        self.assertNotIn(('click','حفظ القسم'),page.actions)

    def test_missing_mother_surname_has_a_specific_error(self):
        page=Page();row=self.setup_record(page);row['mother_surname']=''
        with self.assertRaises(DetailError) as result:self.fill(page,row,'relative')
        self.assertEqual(result.exception.code,'detail_mother_missing')
        self.assertNotIn(('click','حفظ القسم'),page.actions)

    def test_mother_surname_uses_unique_input_shape_when_label_is_missing(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        original=Element.get_by_label
        def without_label(element,pattern,**kw):
            if hasattr(pattern,'search') and pattern.search('شهرة الأم'):
                missing=Element(element.page,'missing')
                missing.count=lambda:0
                return missing
            return original(element,pattern,**kw)
        with patch.object(Element,'get_by_label',without_label):
            self.assertEqual(self.fill(page,row,'relative'),'detail_saved')
        self.assertEqual(page.values['شهرة الأم'],'الحسين')
        self.assertNotIn(('click','إضافة'),page.actions)

    def test_mother_surname_stops_if_unlabelled_input_is_ambiguous(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        with patch.object(Element,'get_by_label',side_effect=lambda *a,**kw: type('Missing',(),{'count':lambda self:0})()), \
             patch.object(Element,'locator',side_effect=lambda *a,**kw: type('Many',(),{'count':lambda self:2})()), \
             self.assertRaises(DetailError) as exc:
            self.fill(page,row,'relative')
        self.assertEqual(exc.exception.code,'detail_mother_field')
        self.assertNotIn(('click','حفظ القسم'),page.actions)

    def test_combined_import_saves_populated_sections_in_order_without_adding_relative(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        self.assertEqual(self.fill(page,row,'all'),'detail_all_saved')
        self.assertEqual([key for action,key in page.actions if action=='click' and key in
                          ('عناوين السكن','الهواتف','الأقارب')],
                         ['عناوين السكن','الهواتف','الأقارب'])
        self.assertEqual(page.actions.count(('click','حفظ القسم')),3)
        self.assertEqual(page.actions.count(('click','تأكيد')),3)
        self.assertEqual(page.actions.count(('click','إضافة')),2)

    def test_combined_import_continues_to_mother_after_existing_address_and_phone(self):
        page=Page();page.existing=True;row=self.setup_record(page);row['mother_surname']='الحسين'
        original=Element.get_by_text
        def existing_other_sections(element,*args,**kw):
            result=original(element,*args,**kw)
            if element.key=='الأقارب' and args and args[0]=='لم يُعثر على أية سجلات':
                result.is_visible=lambda:True
            return result
        # Existing address/phone sections are skipped, then relatives is saved.
        with patch.object(Element,'get_by_text',existing_other_sections):
            self.assertEqual(self.fill(page,row,'all'),'detail_all_partial')
        self.assertEqual(page.values['شهرة الأم'],'الحسين')
        self.assertEqual(page.actions.count(('click','حفظ القسم')),1)

    def test_combined_import_reports_missing_mother_without_claiming_full_success(self):
        page=Page();row=self.setup_record(page);row['mother_surname']=''
        self.assertEqual(self.fill(page,row,'all'),'detail_all_partial')
        self.assertNotIn(('click','الأقارب'),page.actions)

    def test_combined_import_reopens_student_if_save_returns_to_management(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        original=Element.click
        def confirm_returns_to_roster(element,**kw):
            original(element,**kw)
            if element.key=='تأكيد':page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        def reopen(*args):
            page.url='https://new-sims.mehe.gov.lb/dashboard/students/management/existing'
            page.actions.append(('open','matching-student'))
            return ''
        with patch.object(Element,'click',confirm_returns_to_roster), \
             patch('detailed_import.open_existing_detail_student',side_effect=reopen):
            self.assertEqual(self.fill(page,row,'all'),'detail_all_saved')
        self.assertEqual(page.actions.count(('open','matching-student')),2)
        self.assertEqual(page.actions.count(('click','تأكيد')),3)

    def test_combined_import_stops_before_next_section_when_save_is_unconfirmed(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        original=Element.wait_for
        def no_toast(element,**kw):
            if kw.get('state')=='visible' and element.key=='':
                raise TimeoutError('no save acknowledgement')
            return original(element,**kw)
        with patch.object(Element,'wait_for',no_toast),self.assertRaises(DetailError) as exc:
            self.fill(page,row,'all')
        self.assertEqual(exc.exception.code,'detail_save_unknown')
        self.assertEqual(page.actions.count(('click','حفظ القسم')),1)
        self.assertEqual(page.actions.count(('click','تأكيد')),1)
        self.assertNotIn(('click','الهواتف'),page.actions)

    def test_combined_import_never_confirms_an_unexpected_dialog(self):
        page=Page();row=self.setup_record(page);row['mother_surname']='الحسين'
        original=Element.get_by_role
        def different_title(element,role,name='',**kw):
            item=original(element,role,name,**kw)
            if role=='heading' and name=='هل أنت متأكد؟':item.count=lambda:0
            return item
        with patch.object(Element,'get_by_role',different_title),self.assertRaises(DetailError) as exc:
            self.fill(page,row,'all')
        self.assertEqual(exc.exception.code,'detail_options')
        self.assertIn(('click','حفظ القسم'),page.actions)
        self.assertNotIn(('click','تأكيد'),page.actions)
        self.assertNotIn(('click','الهواتف'),page.actions)

    def test_address_dependency_order(self):
        page=Page();row=self.setup_record(page)
        self.assertEqual(self.fill(page,row,'address'),'detail_saved')
        self.assertEqual([key for action,key in page.actions if action=='select'],['البلد','المحافظة','القضاء','المنطقة'])

    def test_formatted_phone_preserves_zero_and_rejects_changed_site_value(self):
        page=Page();row=self.setup_record(page);row['phone']='03-123456'
        self.assertEqual(self.fill(page,row,'phone'),'detail_saved')
        self.assertEqual(page.values['رقم الهاتف'],'03123456')
        self.assertEqual(row['phone'],'03-123456')
        original=Element.fill
        def corrupt(element,value,**kwargs):
            original(element,value,**kwargs)
            if element.key=='رقم الهاتف':element.page.values[element.key]='03123457'
        page=Page();row=self.setup_record(page)
        with patch.object(Element,'fill',corrupt), self.assertRaises(DetailError) as exc:
            self.fill(page,row,'phone')
        self.assertEqual(exc.exception.code,'detail_options')
        self.assertNotIn(('click','حفظ القسم'),page.actions)

    def test_phone_digits_are_never_guessed_or_truncated(self):
        for phone in ('3-123456','00961-3-123456','03-123456 / 70-123456',3123456):
            page=Page();row=self.setup_record(page);row['phone']=phone
            with self.assertRaises(DetailError) as exc:self.fill(page,row,'phone')
            self.assertEqual(exc.exception.code,'detail_input')
            self.assertEqual(page.actions,[])

    def test_wrong_student_stops_before_add(self):
        page=Page();row=self.setup_record(page);row['values']['field-birthDate']='2014-01-02'
        with self.assertRaises(DetailError) as exc:self.fill(page,row,'phone')
        self.assertEqual(exc.exception.code,'detail_birth_mismatch');self.assertEqual(page.actions,[])

    def test_existing_section_and_invalid_phone_never_overwritten(self):
        page=Page();page.existing=True;row=self.setup_record(page)
        with self.assertRaises(DetailError) as exc:self.fill(page,row,'phone')
        self.assertEqual(exc.exception.code,'detail_existing')
        self.assertNotIn(('click','إضافة'),page.actions)
        page=Page();row=self.setup_record(page);row['phone']='009613123456'
        with self.assertRaises(DetailError) as exc:self.fill(page,row,'phone')
        self.assertEqual(exc.exception.code,'detail_input');self.assertEqual(page.actions,[])

    def test_missing_country_not_assumed(self):
        page=Page();row=self.setup_record(page);row['address']['البلد']=''
        with self.assertRaises(DetailError) as exc:self.fill(page,row,'address')
        self.assertEqual(exc.exception.code,'detail_input');self.assertEqual(page.actions,[])

    def test_management_lookup_stops_if_two_students_share_name_and_birth_date(self):
        page=Page();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        record=self.setup_record(page)
        items=[{'uid':str(i),'first':'أحمد','middle':'علي','last':'السيد','status':'قيد الانتظار'}
               for i in (11,12)]
        class Browser:
            def __init__(self,*args,**kwargs):pass
            def inventory(self,progress):return items
            def read_birth_date(self,item):return '2015-01-02'
        with patch('student_scan.StudentBrowser',Browser), self.assertRaises(DetailError) as exc:
            open_existing_detail_student(page,record,'school@te.pm.mehe.school',threading.Event())
        self.assertEqual(exc.exception.code,'detail_ambiguous')
        self.assertEqual(page.actions,[])

    def test_unique_management_match_is_opened_once(self):
        page=Page();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        record=self.setup_record(page)
        item={'uid':'system-id','first':'أحمد','middle':'علي','last':'السيد','status':'قيد الانتظار'}
        class Browser:
            def __init__(self,*args,**kwargs):pass
            def inventory(self,progress):return [item]
            def read_birth_date(self,row,keep_open_if_birth=None):
                self_requested.append(keep_open_if_birth)
                page.url += '/verified-student'
                page.actions.append(('open','verified-student'))
                return '2015-01-02'
            def move(self,*args):raise AssertionError('Must not return to the roster')
        self_requested=[]
        with patch('student_scan.StudentBrowser',Browser):
            self.assertEqual(open_existing_detail_student(page,record,'school@te.pm.mehe.school',threading.Event()),'system-id')
        self.assertEqual(self_requested,['2015-01-02'])
        self.assertEqual(page.actions,[('open','verified-student')])

    def test_management_lookup_checks_birth_before_opening_one_exact_row(self):
        page=Page();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        record=self.setup_record(page);record['values']['field-existingUniqueId']='old-excel-id'
        items=[{'uid':str(i),'first':'أحمد','middle':'علي','last':'السيد','status':'قيد الانتظار',
                'page':1,'index':i-1,'uid_column':0,'grade':'الأول أساسي','language':'الفرنسية',
                'section':'الشعبة أ','branch':'','school':''} for i in (1,2)]
        class Browser:
            def __init__(self,*args,**kwargs):self.inventory_pages={1:[__import__('student_scan').row_key(r) for r in items]}
            def inventory(self,progress):return items
            def read_birth_date(self,item):return '2014-01-02' if item['uid']=='1' else '2015-01-02'
            def move(self,number):return {'rows':items}
            def guard(self):pass
        class Selected:
            def inner_text(self):return '2'
            def click(self,**kwargs):
                page.actions.append(('open','2'))
                page.url += '/student-2'
            def wait_for(self,**kwargs):pass
            def nth(self,n):return self
            def locator(self,selector):return self
        class Table(Selected):
            def is_visible(self):return True
            def all(self):return [self]
            def all_inner_texts(self):return list(__import__('student_scan').TABLE_HEADERS)
            def count(self):return 2
        original=page.locator
        page.locator=lambda selector: Table() if selector=='table' else (Selected() if selector=='#field-firstName' else original(selector))
        with patch('student_scan.StudentBrowser',Browser):
            self.assertEqual(open_existing_detail_student(page,record,'school@te.pm.mehe.school',threading.Event()),'2')
        self.assertEqual(page.actions,[('open','2')])

    def test_address_import_opens_selected_student_and_keeps_system_uid(self):
        page=Page();page.url='https://new-sims.mehe.gov.lb/dashboard/students/management'
        record=self.setup_record(page)
        record['values']['field-existingUniqueId']='older-excel-value'
        def open_record(*args):
            page.url += '/existing-student'
            page.values['field-existingUniqueId']='system-value'
            page.actions.append(('open','matching-student'))
            return 'system-value'
        with patch('detailed_import.open_existing_detail_student',side_effect=open_record), \
             patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            self.assertEqual(fill_details(page,record,'address','school@te.pm.mehe.school',threading.Event()),'detail_saved')
        self.assertEqual(page.actions[0],('open','matching-student'))
        self.assertEqual(page.values['field-existingUniqueId'],'system-value')
        self.assertIn(('click','حفظ القسم'),page.actions)
        self.assertIn(('click','تأكيد'),page.actions)


if __name__=='__main__':unittest.main()
