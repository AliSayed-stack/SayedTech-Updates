"""Grade-restricted existing-student lookup, queue isolation and retry routing."""
import copy
import threading
import unittest
from unittest.mock import patch

from detail_scope import grade_choices,scoped_record
from detailed_batch import DetailedImportBatch
from detailed_import import open_existing_detail_student,DetailError
import test_scan as site
from student_scan import LIST_SCRIPT
from test_students import record

GRADE='الأول أساسي'
OTHER='الثالث ثانوي'


def row(index,grade):
    return {'excel_row':index,'values':{'field-enrollment-promoted-class':grade}}


class GradeQueueTests(unittest.TestCase):
    def test_both_modes_dispatch_only_chosen_grade_with_explicit_search_scope(self):
        for review,event in ((False,'detail_import_saved'),(True,'detail_import_review_sent')):
            rows=[row(2,OTHER),row(3,GRADE),row(4,''),row(5,OTHER),row(6,GRADE)]
            original=copy.deepcopy(rows)
            batch=DetailedImportBatch(rows);batch.start(review,GRADE)
            self.assertEqual((batch.total,batch.position),(2,1))
            first,mode,request=batch.request()
            self.assertEqual((first['excel_row'],first['search_grade']),(3,GRADE))
            batch.result(request,event)
            second,mode,request=batch.request()
            self.assertEqual((second['excel_row'],second['search_grade']),(6,GRADE))
            self.assertEqual(batch.position,2)
            batch.result(request,event)
            self.assertFalse(batch.active);self.assertEqual(batch.done,2)
            self.assertEqual(rows,original)

    def test_retry_and_switch_grade_keep_completion_scoped(self):
        batch=DetailedImportBatch([row(2,GRADE),row(3,OTHER),row(4,GRADE)])
        batch.start(False,GRADE);batch.result(batch.request()[2],'detail_import_saved')
        batch.result(batch.request()[2],'detail_not_found')
        batch.start(False,OTHER)
        self.assertEqual((batch.done,batch.total),(0,1))
        self.assertEqual(batch.request()[0]['excel_row'],3)
        batch.result(batch.pending,'detail_import_saved')
        batch.start(False,GRADE)
        self.assertEqual((batch.done,batch.total),(1,2))
        self.assertEqual(batch.request()[0]['excel_row'],4)

    def test_choices_and_single_requests_do_not_change_excel_records(self):
        rows=[row(2,'  الأول   أساسي '),row(3,GRADE),row(4,OTHER),row(5,'')]
        self.assertEqual(grade_choices(rows),[GRADE,OTHER])
        request=scoped_record(rows[0],GRADE)
        self.assertEqual(request['search_grade'],GRADE)
        self.assertNotIn('search_grade',rows[0])


class TrackingPage(site.Page):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.inventories=[]

    def evaluate(self,script,*args):
        if script==LIST_SCRIPT:self.inventories.append((self.grade,self.number))
        return super().evaluate(script,*args)


class GradeLookupTests(unittest.TestCase):
    def setup_page(self,username):
        page=TrackingPage(306,account=username)
        # Same-name students in other grades are never visited.
        student=next(item for item in page.records if item['grade']==GRADE)
        values=record();values.update({
            'field-firstName':student['first'],'field-middleName':student['middle'],
            'field-lastName':student['last'],'field-existingUniqueId':student['uid'],
            'field-enrollment-promoted-class':GRADE})
        for item in page.records:
            if item['grade']==GRADE and item is not student:item['first']='OTHER'
        return page,{'values':values,'search_grade':GRADE},student

    def test_real_inventory_filters_before_first_read_and_opens_only_chosen_grade_both_shifts(self):
        for username in ('test@te.mehe.school','test@te.pm.mehe.school'):
            page,data,student=self.setup_page(username)
            with patch('student_scan.time.monotonic',site.Clock()):
                uid=open_existing_detail_student(page,data,username,threading.Event())
            self.assertEqual(uid,student['uid'])
            self.assertTrue(page.inventories)
            self.assertEqual({grade for grade,_ in page.inventories},{GRADE})
            self.assertEqual({number for _,number in page.inventories},{1,2})
            opens=[action for action in page.actions if action[0]=='opened']
            self.assertEqual(len(opens),1);self.assertEqual(opens[0][1],GRADE)

    def test_missing_match_never_expands_to_other_grades(self):
        username='test@te.mehe.school';page,data,_=self.setup_page(username)
        for item in page.records:
            if item['grade']==GRADE:item['first']='OTHER'
        with patch('student_scan.time.monotonic',site.Clock()),self.assertRaises(DetailError) as error:
            open_existing_detail_student(page,data,username,threading.Event())
        self.assertEqual(error.exception.code,'detail_not_found')
        self.assertEqual({grade for grade,_ in page.inventories},{GRADE})
        self.assertFalse(any(action[0]=='opened' for action in page.actions))

    def test_missing_grade_or_stale_filter_never_falls_back_to_school_inventory(self):
        for missing in (False,True):
            username='test@te.mehe.school';page,data,_=self.setup_page(username)
            if missing:
                data['search_grade']='الثاني ثانوي'
                data['values']['field-enrollment-promoted-class']='الثاني ثانوي'
            else:page.stale_grade=True
            with patch('student_scan.time.monotonic',site.Clock()),self.assertRaises(DetailError) as error:
                open_existing_detail_student(page,data,username,threading.Event())
            self.assertEqual(error.exception.code,'detail_management')
            self.assertFalse(any(action[0]=='opened' for action in page.actions))
            self.assertFalse(any(grade is None for grade,_ in page.inventories))

    def test_conflicting_scope_is_rejected_before_roster_read(self):
        username='test@te.mehe.school';page,data,_=self.setup_page(username)
        for invalid in ('',OTHER,123):
            data['search_grade']=invalid
            with self.assertRaises(DetailError) as error:
                open_existing_detail_student(page,data,username,threading.Event())
            self.assertEqual(error.exception.code,'detail_input')
        self.assertEqual(page.inventories,[])


if __name__=='__main__':unittest.main()
