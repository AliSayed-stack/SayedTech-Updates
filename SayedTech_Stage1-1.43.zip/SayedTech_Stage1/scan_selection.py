"""Read-only roster choices; bind manual selections to an exact account snapshot."""
import hashlib
import json
import re
from collections import Counter


def clean_selection(value):
    if value is None:return None
    if not isinstance(value,dict):raise ValueError('selection')
    if set(value)=={'status'}:
        status=value['status']
        if not isinstance(status,str) or not status.strip() or len(status)>128:raise ValueError('status')
        return {'status':status.strip()}
    if set(value)!={'signature','indexes'}:raise ValueError('selection')
    signature,indexes=value['signature'],value['indexes']
    if not isinstance(signature,str) or not re.fullmatch('[a-f0-9]{64}',signature):raise ValueError('signature')
    if not isinstance(indexes,list) or not 1<=len(indexes)<=5000:raise ValueError('indexes')
    if any(type(i) is not int or not 0<=i<5000 for i in indexes) or len(set(indexes))!=len(indexes):raise ValueError('indexes')
    return {'signature':signature,'indexes':sorted(indexes)}


def signature(records,username,grade):
    from student_scan import row_key
    payload=[username.strip().casefold(),grade,[row_key(r) for r in records]]
    return hashlib.sha256(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def roster_choices(records,username,grade=None):
    return {'signature':signature(records,username,grade),'roster':[
        {key:row.get(key,'') for key in ('uid','first','middle','last','grade','status')}
        for row in records]}


def clean_choices(detail):
    if not isinstance(detail,dict):return {}
    token=detail.get('signature');rows=detail.get('roster')
    if not isinstance(token,str) or not re.fullmatch('[a-f0-9]{64}',token):return {}
    if not isinstance(rows,list) or not 0<=len(rows)<=5000:return {}
    keys=('uid','first','middle','last','grade','status');clean=[]
    for row in rows:
        if not isinstance(row,dict) or any(not isinstance(row.get(k),str) or len(row[k])>1024 for k in keys):return {}
        clean.append({k:row[k] for k in keys})
    return {'signature':token,'roster':clean}


def select_records(records,selection,username,grade=None):
    from student_scan import ScanError,row_key,normalized
    try:selection=clean_selection(selection)
    except ValueError:raise ScanError('scan_prepare','selection_changed') from None
    if selection is None:return records
    if 'status' in selection:
        return [r for r in records if normalized(r.get('status',''))==normalized(selection['status'])]
    if signature(records,username,grade)!=selection['signature'] or max(selection['indexes'])>=len(records):
        raise ScanError('scan_changed','selection_changed')
    selected=[records[i] for i in selection['indexes']]
    counts=Counter(row_key(r) for r in records)
    if any(counts[row_key(r)]!=1 for r in selected):raise ScanError('scan_changed','selection_changed')
    return selected
