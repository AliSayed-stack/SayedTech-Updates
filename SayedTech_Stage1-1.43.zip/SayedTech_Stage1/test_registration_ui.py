"""Real Qt menu/route dispatch with synthetic local inputs only."""
import unittest
from unittest.mock import patch
try:
    from PySide6.QtWidgets import QApplication
    import app
    from credential_store import CredentialStore
    from test_credentials import Native
    from registration_workbook import KINDS
    QT=True
except ImportError:QT=False


@unittest.skipUnless(QT,'Qt unavailable')
class RegistrationUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])
    def setUp(self):
        with patch('app.CredentialStore',return_value=CredentialStore(Native())),patch('app.core.read_school',return_value={}):self.w=app.Window()
        self.w.school_shift='afternoon';self.w.connected=True
    def tearDown(self):self.w.close();self.w.deleteLater();self.qt.processEvents()

    def test_afternoon_creation_opens_two_modes_and_morning_retains_existing_page(self):
        self.w.show_section('student_create')
        self.assertIs(self.w.section_stack.currentWidget(),self.w.registration_modes_page)
        self.assertFalse(hasattr(self.w,'registration_kind'))
        self.w.school_shift='morning';self.w.show_section('student_create')
        self.assertIs(self.w.section_stack.currentWidget(),self.w.section_pages['student_create'])

    def test_simple_import_passes_exact_requested_route_and_detailed_uses_existing_detail_dialog(self):
        with patch('app.QFileDialog.getOpenFileName',return_value=('/tmp/synthetic.xlsx','')),\
             patch('registration_workbook.read_for_simple',return_value=[{'test':True}]) as read,\
             patch('student_dialog.StudentImportDialog') as dialog:
            self.w.registration_operation('استرداد','registration_simple')
            read.assert_called_once_with('/tmp/synthetic.xlsx')
            dialog.return_value.exec.assert_called_once()
        with patch('app.QFileDialog.getOpenFileName',return_value=('/tmp/synthetic.xlsx','')),\
             patch('detailed_import.read_details',return_value=[{'test':True}]) as read,\
             patch('detailed_dialog.DetailedImportDialog') as dialog:
            self.w.registration_operation('استرداد','registration_detailed');read.assert_called_once()
            dialog.return_value.exec.assert_called_once()

    def test_both_modes_export_same_schema_and_offer_explicit_translation(self):
        for mode in ('registration_simple','registration_detailed'):
            with patch('app.QFileDialog.getSaveFileName',return_value=('/tmp/synthetic.xlsx','')),\
                 patch('registration_workbook.write_template') as write:
                self.w.registration_operation('استخراج',mode)
                write.assert_called_once_with('/tmp/synthetic.xlsx')
            with patch('app.QFileDialog.getOpenFileName',return_value=('/tmp/synthetic.xlsx','')),\
                 patch('registration_workbook.translate_names',return_value=4) as translate:
                self.w.registration_operation('ترجمة',mode);translate.assert_called_once_with('/tmp/synthetic.xlsx')

    def test_upgrade_uses_separate_copy_without_replacing_input(self):
        with patch('app.QFileDialog.getOpenFileName',return_value=('/tmp/filled.xlsx','')),\
             patch('app.QFileDialog.getSaveFileName',return_value=('/tmp/filled_updated.xlsx','')),\
             patch('registration_workbook.upgrade_route_choices') as upgrade:
            self.w.registration_operation('تحديث الخيارات','registration_simple')
            upgrade.assert_called_once_with('/tmp/filled.xlsx','/tmp/filled_updated.xlsx')


if __name__=='__main__':unittest.main()
