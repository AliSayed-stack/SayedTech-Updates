"""Offline Qt, SQL CE and asset smoke check for the packaged application."""

def check_app():
    from PySide6.QtWidgets import QApplication, QWidget
    from PySide6.QtSvgWidgets import QSvgWidget
    from sqlce import SqlceDatabase
    from student_unified import UNIFIED_HEADERS
    from detailed_import import read_details
    from document_import import save_documents
    from attendance_dialog import AttendanceDialog
    from attendance_excel import read_attendance
    import core
    for name in ('student_simple_schema.json', 'student_unified.xlsx','student_attendance.xlsx'):
        if not (core.ASSET_BASE/'assets'/name).is_file(): raise RuntimeError('Missing application asset')
    app = QApplication.instance() or QApplication([])
    widget = QWidget(); widget.show(); app.processEvents(); widget.close()
    if not SqlceDatabase or not UNIFIED_HEADERS or not read_details or not save_documents or not QSvgWidget or not AttendanceDialog or not read_attendance:
        raise RuntimeError('Missing dependency')
