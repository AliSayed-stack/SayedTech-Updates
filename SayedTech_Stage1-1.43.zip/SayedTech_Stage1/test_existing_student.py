"""Imported-student selection with synthetic names and no live site access."""
import copy
import unittest
from unittest.mock import patch

from student_fill import fill_student, StudentFillError
from student_save import fill_and_save_student
from test_students import record
from test_student_save import Page
from test_scan import Clock


class ExistingStudentTests(unittest.TestCase):
    def test_existing_slash_birth_matches_without_writing_and_wrong_date_stops(self):
        for domain in ('te.mehe.school','te.pm.mehe.school'):
            page=Page('test@'+domain);page.selected_values['field-birthDate']='2015/01/02'
            self.assertEqual(self.run_fill(page,save=True),'student_saved')
            self.assertEqual(page.values['field-birthDate'],'2015/01/02')
            self.assertFalse(any(a[:2]==('fill','field-birthDate') for a in page.actions))
        page=Page();page.selected_values['field-birthDate']='2015/02/01'
        self.assert_stops(page,'student_existing_mismatch')

    def test_form_identity_arrives_after_route_without_premature_mismatch(self):
        page=Page();original=page.locator;reads=[0]
        def locator(selector):
            node=original(selector)
            if selector=='#field-firstName':
                value=node.input_value
                def delayed():
                    reads[0]+=1
                    return '' if reads[0]<=4 else value()
                node.input_value=delayed
            return node
        with patch.object(page,'locator',locator):
            self.run_fill(page)
        self.assertGreater(reads[0],4)
        self.assertIn(('click','result'),page.actions)
        self.assertTrue(any(a[0]=='fill' for a in page.actions))

    def test_other_students_identity_remains_blocked_after_wait(self):
        page=Page();page.selected_values['field-firstName']='OTHER'
        self.assert_stops(page,'student_existing_mismatch')
        self.assertFalse(any(a[0]=='fill' for a in page.actions))

    def test_unavailable_create_is_reported_before_any_search_or_save(self):
        page=Page();original=page.get_by_role
        def role(kind,name,exact=False):
            node=original(kind,name,exact)
            if name=='إنشاء':
                def fail(**kwargs):raise RuntimeError('synthetic timeout')
                node.click=fail
            return node
        with patch.object(page,'get_by_role',role):
            self.assert_stops(page,'student_create_unavailable')
        self.assertEqual(page.actions,[])

    def test_field_failure_identifies_field_without_leaking_value(self):
        page=Page();original=page.locator
        def locator(selector):
            node=original(selector)
            if selector=='#field-firstNameEn':
                def fail(*args,**kwargs):raise RuntimeError('private-value')
                node.fill=fail
            return node
        with patch.object(page,'locator',locator),self.assertRaises(StudentFillError) as caught:
            self.run_fill(page,save=True)
        self.assertEqual(caught.exception.code,'student_field_failed')
        self.assertEqual(caught.exception.field,'field-firstNameEn')
        self.assertNotIn(('click','save'),page.actions)

    def run_fill(self,page,data=None,save=False):
        with patch('student_fill.time.monotonic',Clock()), patch.object(page,'wait_for_timeout'):
            action=fill_and_save_student if save else fill_student
            return action(page,data or record(),page.account,page.cancelled)

    def assert_stops(self,page,code,data=None):
        with self.assertRaises(StudentFillError) as caught:self.run_fill(page,data)
        self.assertEqual(caught.exception.code,code)
        self.assertFalse(any(a[0] in ('fill','select') for a in page.actions))
        self.assertFalse(any(a[:2] in (('click','save'),('click','confirm')) for a in page.actions))

    def test_existing_result_selected_for_both_domains_and_save_once(self):
        for domain in ('te.mehe.school','te.pm.mehe.school'):
            page=Page('test@'+domain)
            self.assertEqual(self.run_fill(page,save=True),'student_saved')
            self.assertEqual([a for a in page.actions if a[0]=='click'],
                [('click','create'),('click','existing'),('click','result'),('click','save'),('click','confirm')])
            self.assertIn(('search','TEST TEST TEST'),page.actions)

    def test_no_result_and_wrong_birth_or_name_never_choose(self):
        for change in ('empty','birth','name','id','disabled'):
            page=Page()
            if change=='empty':page.search_rows=[]
            elif change=='birth':page.search_rows[0]['detail']='— · تاريخ الميلاد: 2016-01-02'
            elif change=='name':page.search_rows[0]['name']='OTHER TEST TEST'
            elif change=='id':page.search_rows[0]['detail']='999 · تاريخ الميلاد: 2015-01-02'
            else:page.search_rows[0]['enabled']=False
            with self.subTest(change=change):
                self.assert_stops(page,'student_existing_not_found')
                self.assertNotIn(('click','result'),page.actions)

    def test_search_card_day_month_year_matches_excel_iso_date(self):
        page=Page()
        page.search_rows[0]['detail']='000123 · تاريخ الميلاد: 02-01-2015'
        self.run_fill(page)
        self.assertIn(('click','result'),page.actions)

    def test_search_card_day_month_year_does_not_swap_day_and_month(self):
        page=Page()
        page.search_rows[0]['detail']='000123 · تاريخ الميلاد: 01-02-2015'
        self.assert_stops(page,'student_existing_not_found')
        self.assertNotIn(('click','result'),page.actions)

    def test_duplicate_name_resolved_by_birth_but_same_birth_is_ambiguous(self):
        page=Page();other=copy.deepcopy(page.search_rows[0]);other['index']=1
        page.search_rows.append(other)
        self.assert_stops(page,'student_existing_ambiguous')
        page=Page();other['detail']='— · تاريخ الميلاد: 2016-01-02'
        page.search_rows.append(other)
        self.run_fill(page)
        self.assertEqual(page.actions.count(('click','result')),1)

    def test_mismatched_populated_form_stops_before_overwrite(self):
        page=Page();page.selected_values['field-firstName']='OTHER'
        self.assert_stops(page,'student_existing_mismatch')

    def test_blank_excel_id_preserves_system_id_and_source(self):
        page=Page();data=record();data['field-existingUniqueId']=''
        self.assertEqual(self.run_fill(page,data,save=True),'student_saved')
        self.assertEqual(page.values['field-existingUniqueId'],'000123')
        self.assertEqual(data['field-existingUniqueId'],'')

    def test_placeholder_zero_id_accepts_imported_result_and_keeps_site_id(self):
        page=Page();data=record();data['field-existingUniqueId']='0'
        self.assertEqual(self.run_fill(page,data,save=True),'student_saved')
        self.assertEqual(page.values['field-existingUniqueId'],'000123')
        self.assertEqual(data['field-existingUniqueId'],'0')
        self.assertFalse(any(a[0]=='fill' and a[1]=='field-existingUniqueId' for a in page.actions))

    def test_matching_id_also_stays_untouched(self):
        page=Page()
        self.run_fill(page,save=True)
        self.assertFalse(any(a[0]=='fill' and a[1]=='field-existingUniqueId' for a in page.actions))

    def test_site_id_missing_while_excel_has_id_stops_before_writing(self):
        page=Page();page.selected_values['field-existingUniqueId']=''
        self.assert_stops(page,'student_existing_mismatch')
        self.assertFalse(any(a[0]=='fill' and a[1]=='field-existingUniqueId' for a in page.actions))

    def test_missing_id_on_both_sides_still_matches_name_and_birth(self):
        page=Page();data=record();data['field-existingUniqueId']=''
        page.search_rows[0]['detail']='— · تاريخ الميلاد: 2015-01-02'
        page.selected_values['field-existingUniqueId']=''
        self.run_fill(page,data)
        self.assertIn(('click','result'),page.actions)

    def test_cancel_search_never_selects_or_fills(self):
        page=Page();page.cancel_during_search=True
        self.assert_stops(page,'student_cancelled')
        self.assertNotIn(('click','result'),page.actions)


if __name__=='__main__':unittest.main()
