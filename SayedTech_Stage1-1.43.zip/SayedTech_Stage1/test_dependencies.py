"""A missing pip in an otherwise valid local environment is repaired in place."""
import unittest
from unittest.mock import patch, call
import sys

import ensure_dependencies


class DependencyBootstrapTests(unittest.TestCase):
    @patch.object(ensure_dependencies, 'ready', return_value=False)
    @patch.object(ensure_dependencies.subprocess, 'run')
    def test_missing_pip_bootstraps_before_install(self, run, _ready):
        run.side_effect = [type('Result', (), {'returncode': 1})(), None, None]
        ensure_dependencies.ensure()
        self.assertEqual(run.call_args_list[0].args[0], [sys.executable, '-m', 'pip', '--version'])
        self.assertEqual(run.call_args_list[1], call([sys.executable, '-m', 'ensurepip', '--upgrade'], check=True))
        self.assertEqual(run.call_args_list[2].args[0][:4], [sys.executable, '-m', 'pip', 'install'])

    @patch.object(ensure_dependencies, 'ready', return_value=False)
    @patch.object(ensure_dependencies.subprocess, 'run')
    def test_existing_pip_is_reused(self, run, _ready):
        run.side_effect = [type('Result', (), {'returncode': 0})(), None]
        ensure_dependencies.ensure()
        self.assertEqual(run.call_count, 2)

    @patch.object(ensure_dependencies, 'ready', return_value=True)
    @patch.object(ensure_dependencies.subprocess, 'run')
    def test_ready_environment_needs_no_install(self, run, _ready):
        ensure_dependencies.ensure()
        run.assert_not_called()
