# Sayed tech development instructions

Read `WORKSPACE_STATE.md` and `DEVELOPMENT.md` before changing the app.

- Preserve the Arabic desktop workflow and both school shifts.
- Make focused changes from the current source baseline and retain compatibility with previous exported Excel files.
- Manual import binds headers by name. Selection is the first exported column; mother surname follows the Arabic mother name. The main export has 56 columns.
- NSLDB and unified student outputs use student_excel_layout.apply_student_dimensions, reading the existing site-export template for 23-point body / 48-point header and widths by field name. Do not restore newline-based 48–400-point rows or 36-point conversion rows. This helper changes only dimensions; preserve font/date styles, cells and all native Excel features. Keep the morning site export unchanged.
- Keep runtime Excel handling in the existing ZIP/XML code. `openpyxl` and `lxml` are test dependencies.
- Preserve worksheet/table references, validations, named ranges and namespaces. Invalidate calculation-chain metadata after relocating formula cells.
- Do not use React IDs as stable selectors. Scope controls and buttons to their section and use labels or verified form structure.
- Detailed-import checkbox selection is a local UI filter, initially checked for all Excel-marked rows. Freeze the visible checked original row indexes for each batch; combine with the grade scope for eligibility and counters. Preserve completion when checkboxes/grades change between runs. Do not dispatch unchecked pupils through batch, section-save or review. Keep the checkbox first/rightmost, and use absolute right alignment with RTL so Qt does not mirror it left; preserve data strings and the Excel schema.
- The detailed-import dialog must override large inherited button/combo padding locally, reserve visible height for the table, fit the available screen including its native frame and keep actions reachable with a scrolling body and fixed close/stop footer. Retain both batch choices and all selected-student controls. Test geometry with the actual inherited app stylesheet, narrow windows and Qt scaling; keep result-column logical indexes unchanged when rearranging visually.
- Grade-scoped detail restoration uses detail_scope.py. Carry search_grade on copied request records through single, batch and review routes. StudentBrowser.inventory must receive grade before reading any roster page; never fall back to school-wide inventory on missing students, empty grades or filter errors. Queue completion remains per original row, while progress counts only rows in the selected grade. Preserve the all-grades option and existing Excel schema.
- Automatic detail import must re-enter the verified student after each confirmed save and verify identity again through fill_details before the next section. Reuse the verified URL and current system UID; never reload an unconfirmed draft or scan the whole roster for each section.
- Save-success matching is shared as detail_dom.SAVE_SUCCESS_TEXT. Current SIMS common.saved is «تم الحفظ بنجاح»; the legacy «تم حفظ…بنجاح» is also supported. Do not infer failure in the next section from a previous save-acknowledgement error. Avoid JavaScript word boundaries on Arabic; verify regex parity with Node.
- Simple student Excel date text accepts MM/DD/YYYY (month first), ISO and numeric Excel dates; normalize internally to ISO. Source registration-date slash values use month-first precedence; do not silently reinterpret ambiguous MM/DD as DD/MM. Document manual_date has its own existing day-first convention.
- Local phone forms can omit the country-code select. Retain this behavior and support for the older country-select form.
- Manual ID/document import does not require an attachment; keep unrelated legacy features intact.
- Never operate on the termination checkbox. Review submission requires an explicit user action: either the standalone selected-student review button, or import-with-review after all supplied sections confirm saving. Section save and no-review import must never send. Keep the section selector and selected-section save controls; remove only fill-without-save.
- Never commit student records, credentials, profiles, scan checkpoints or school-session screenshots. Use synthetic test fixtures.
- Keep `core.APP_VERSION`, ZIP filename and release tag consistent. Update the handoff after material changes.
- Run appropriate regression tests. Do not claim Windows or live SIMS verification from offline mocks.

The archive root is `SayedTech_Stage1`. The existing updater consumes `SayedTech_Stage1-X.Y.zip`.
