import unittest
from unittest.mock import patch
try:
    from PySide6.QtWidgets import QApplication,QWidget
    from PySide6.QtCore import QObject,Signal,Qt
    from section_dialog import SectionDialog
    QT=True
except ImportError:
    QT=False;QObject=object;Signal=lambda *args:None
from test_sections import record
class Controller(QObject):
    section_result=Signal(str,str);section_grades=Signal(str,str);event=Signal(str)
    def __init__(self):super().__init__();self.calls=[]
    def sections(self,action,request,**payload):self.calls.append((action,request,payload));return True
@unittest.skipUnless(QT,'Qt unavailable')
class SectionUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def test_all_selected_skip_unchanged_and_process_remaining_serially(self):
        parent=QWidget();c=Controller();d=SectionDialog(c,parent)
        first=dict(record(),excel_row=2);same=dict(first,excel_row=3,id='synthetic-same',target=first['source']);last=dict(first,excel_row=4,id='synthetic-2')
        with patch('section_dialog.QFileDialog.getOpenFileName',return_value=('/tmp/sections.xlsx','')),patch('section_dialog.read_sections',return_value=[first,same,last]):d.load()
        self.assertIn('لا نقل مطلوب',d.table.item(1,6).text());self.assertFalse(d.table.item(1,0).flags()&Qt.ItemIsEnabled)
        # Even programmatic rechecking must not dispatch a no-op row.
        d.table.item(1,0).setCheckState(Qt.Checked);d.start()
        self.assertEqual(len(c.calls),1);self.assertEqual(c.calls[0][2]['record']['id'],first['id'])
        d.result(c.calls[-1][1],'section_saved');self.app.processEvents()
        self.assertEqual(len(c.calls),2);self.assertEqual(c.calls[-1][2]['record']['id'],last['id'])
        d.result(c.calls[-1][1],'section_saved');self.app.processEvents()
        self.assertEqual(len(c.calls),2);self.assertFalse(d.active);self.assertFalse(d.run.isEnabled());d.reject();parent.close()
    def test_all_unchanged_displays_rows_with_no_browser_requests(self):
        parent=QWidget();c=Controller();d=SectionDialog(c,parent);r=dict(record(),excel_row=2);r['target']=r['source']
        with patch('section_dialog.QFileDialog.getOpenFileName',return_value=('/tmp/sections.xlsx','')),patch('section_dialog.read_sections',return_value=[r]):d.load()
        self.assertEqual(d.table.rowCount(),1);self.assertIn('لا يوجد نقل',d.status.text());self.assertFalse(d.run.isEnabled())
        d.start();self.assertEqual(c.calls,[]);d.reject();parent.close()
    def test_export_requires_selected_live_grade_and_ignores_stale_list(self):
        import json
        parent=QWidget();c=Controller();d=SectionDialog(c,parent)
        self.assertFalse(d.export_button.isEnabled());d.grades_button.click()
        request=c.calls[-1][1];self.assertEqual(c.calls[-1][0],'section_grades')
        d.receive_grades('stale',json.dumps(['OTHER']));self.assertEqual(d.grade.count(),1)
        d.receive_grades(request,json.dumps(['الروضة الثالثة','الثاني ثانوي']))
        self.assertFalse(d.export_button.isEnabled());d.grade.setCurrentIndex(2);self.assertTrue(d.export_button.isEnabled())
        with patch('section_dialog.QFileDialog.getSaveFileName',return_value=('/tmp/sections.xlsx','')):d.export()
        self.assertEqual(c.calls[-1][0],'section_export');self.assertEqual(c.calls[-1][2]['grade'],'الثاني ثانوي')
        self.assertFalse(d.grade.isEnabled());d.result(c.calls[-1][1],'section_exported');d.reject();parent.close()
    def test_controller_accepts_only_bounded_unique_correlated_grade_labels(self):
        import json
        from login_controller import LoginController
        c=LoginController();received=[];errors=[]
        c.section_grades.connect(lambda request,raw:received.append((request,json.loads(raw))))
        c.section_result.connect(lambda request,event:errors.append(event))
        request='a'*32
        messages=[dict(event='section_grade_list',request_id=request,grades=['الأول أساسي','الثاني ثانوي']),dict(event='section_grade_list',request_id=request,grades=['duplicate','duplicate']),dict(event='section_grade_list',request_id='wrong',grades=['OTHER'])]
        class Process:
            def readAllStandardOutput(self):return ('\n'.join(json.dumps(v) for v in messages)+'\n').encode()
        c.process=Process();c._read_output()
        self.assertEqual(received,[(request,['الأول أساسي','الثاني ثانوي'])]);self.assertEqual(errors,['section_grades'])
    def test_checked_rows_serial_failure_and_stale_results(self):
        parent=QWidget();c=Controller();d=SectionDialog(c,parent)
        r=dict(record(),excel_row=2);other=dict(r,excel_row=3,id='synthetic-2')
        with patch('section_dialog.QFileDialog.getOpenFileName',return_value=('/tmp/sections.xlsx','')),patch('section_dialog.read_sections',return_value=[r,other]):d.load()
        d.table.item(1,0).setCheckState(Qt.Unchecked);d.start();self.assertEqual(len(c.calls),1)
        self.assertFalse(d.import_button.isEnabled());d.result('stale','section_saved');self.assertIsNotNone(d.pending)
        d.result(c.calls[0][1],'section_unknown');self.app.processEvents();self.assertEqual(len(c.calls),1);self.assertFalse(d.active)
        self.assertTrue(d.run.isEnabled());d.reject();parent.close()
    def test_menu_for_both_shifts_keeps_registration_modes(self):
        import app
        from credential_store import CredentialStore
        from test_credentials import Native
        with patch('app.CredentialStore',return_value=CredentialStore(Native())),patch('app.core.read_school',return_value={}):w=app.Window()
        w.connected=True
        for shift in ('morning','afternoon'):
            w.school_shift=shift
            with patch('section_dialog.SectionDialog') as dialog:w.show_section('student_sections');dialog.return_value.exec.assert_called_once()
        self.assertIn('student_sections',app.SECTIONS['students'][2]);w.close()
