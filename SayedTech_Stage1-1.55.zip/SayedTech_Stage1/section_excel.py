"""Account-bound section transfers, with original enrollment identities."""
import hashlib
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as E
from student_excel import NS,ExcelInputError
from student_workflow import workbook_rows,selection_value,column
from registration_workbook import _write
HEADERS=('اختيار','الصف','لغة التعليم','الشعبة الحالية','اسم الطالب','الشعبة المطلوبة','معرّف التسجيل')

def account_key(username):return hashlib.sha256(username.strip().lower().encode()).hexdigest()

def label_text(value):
    """Same display-text normalization as the browser snapshot, not fuzzy matching."""
    return ' '.join(re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',value).split())

def validate(row,*,allow_same=False):
    keys=('grade','language','source','name','target','id','account')
    if not isinstance(row,dict) or any(not isinstance(row.get(k),str) or not row[k].strip() or len(row[k])>500 for k in keys):raise ExcelInputError('أكمل الصف واللغة والشعبتين واسم الطالب في ملف التشعيب.')
    row=dict(row)
    for key in ('grade','language','source','name','target'):
        row[key]=label_text(row[key])
        if not row[key]:raise ExcelInputError('أكمل الصف واللغة والشعبتين واسم الطالب في ملف التشعيب.')
    if not re.fullmatch('[a-zA-Z0-9-]{1,100}',row['id']) or not re.fullmatch('[a-f0-9]{64}',row['account']):raise ExcelInputError('مرجع التشعيب غير صالح؛ أعد الاستخراج.')
    if not allow_same and row['source']==row['target']:raise ExcelInputError('الشعبة المطلوبة هي الشعبة الحالية.')
    return dict(row)

def write_sections(path,rows,username):
    import core
    if Path(path).suffix.lower()!='.xlsx' or (core.ASSET_BASE/'assets').resolve() in Path(path).resolve().parents:raise ExcelInputError('اختر صيغة xlsx.')
    q=lambda n:'{'+NS['m']+'}'+n
    def sheet(grid):
        root=E.Element(q('worksheet'));views=E.SubElement(root,q('sheetViews'));E.SubElement(views,q('sheetView'),workbookViewId='0',rightToLeft='1')
        cols=E.SubElement(root,q('cols'))
        for i,width in enumerate((10,22,20,20,38,22,40),1):E.SubElement(cols,q('col'),min=str(i),max=str(i),width=str(width),customWidth='1')
        body=E.SubElement(root,q('sheetData'))
        for i,values in enumerate(grid,1):
            r=E.SubElement(body,q('row'),r=str(i),ht='48' if i==1 else '23',customHeight='1')
            for j,value in enumerate(values,1):
                c=E.SubElement(r,q('c'),r=column(j)+str(i),t='inlineStr');E.SubElement(E.SubElement(c,q('is')),q('t')).text=str(value)
        return E.tostring(root,encoding='utf-8',xml_declaration=True)
    grid=[HEADERS]+[['0',r['grade'],r['language'],r['source'],r['name'],'',r['id']] for r in rows]
    parts={'[Content_Types].xml':b'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>',
    '_rels/.rels':b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    'xl/workbook.xml':('<workbook xmlns="'+NS['m']+'" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="التشعيب" sheetId="1" r:id="r1"/><sheet name="سياق التشعيب" sheetId="2" r:id="r2"/></sheets></workbook>').encode(),
    'xl/_rels/workbook.xml.rels':b'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="r2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>',
    'xl/worksheets/sheet1.xml':sheet(grid),'xl/worksheets/sheet2.xml':sheet([['Sayed tech | sections v1',account_key(username)],['الاستخدام','ضع 1 في اختيار وأدخل اسم الشعبة المطلوبة كما في الموقع. لا تعدّل معرّف التسجيل. النقل ضمن نفس الصف واللغة.']])}
    _write(parts,path)

def read_sections(path):
    try:
        if Path(path).stat().st_size>64000000:raise ValueError()
        with zipfile.ZipFile(path) as z:
            if len(z.infolist())>1000 or sum(i.file_size for i in z.infolist())>128000000:raise ValueError()
            rows=workbook_rows(z,'التشعيب');context=workbook_rows(z,'سياق التشعيب')
        if context[0][1].get('A')!='Sayed tech | sections v1' or context[0][2] or rows[0][2] or list(rows[0][1].values())!=list(HEADERS):raise ValueError()
        result=[];seen=set()
        for n,values,formulas in rows[1:]:
            if 'A' in formulas:raise ValueError()
            if not selection_value(values.get('A','')):continue
            if formulas:raise ValueError()
            row=dict(zip(('grade','language','source','name','target','id'),[values.get(column(i),'') for i in range(2,8)]),account=context[0][1].get('B',''),excel_row=n)
            # Selected unchanged rows are displayed as no-ops by the dialog.
            # Keep strict destination validation for actual browser transfers.
            row=validate(row,allow_same=True)
            if row['id'] in seen:raise ExcelInputError(f'الصف {n}: التلميذ محدد أكثر من مرة.')
            seen.add(row['id']);result.append(row)
        if not result:raise ExcelInputError('ضع 1 في اختيار للتلاميذ المطلوب نقلهم.')
        return result
    except ExcelInputError:raise
    except Exception:raise ExcelInputError('اختر ملف التشعيب المستخرج من البرنامج بعد تعبئته.') from None
