"""Reviewed detail rows and guarded draft filling on an existing student."""
import re
import time
import zipfile
from pathlib import Path
from urllib.parse import urlsplit
from student_detailed import read_table, PREP_HEADERS, normalize_phone, DEFAULT_RESIDENCE_COUNTRY
from student_excel import FIELDS, normalize_date, ExcelInputError
from student_workflow import selection_value
from student_fill import MANAGEMENT
from login_flow import exact_https_host, SIMS_HOST, visible
from identity_card import card_from_row, validate_card, DOCUMENT_TYPES
from detail_dom import SAVE_SUCCESS_TEXT

IMPORT_MODES = ('details_import', 'details_import_review')

EVENTS = {'detail_birth_mismatch','detail_grade_ready','detail_grade_trigger','detail_grade_options','detail_grade_rows','detail_grade_filters','detail_import_saved','detail_import_review_sent','detail_import_review_already','detail_no_data','detail_save_blocked','detail_review_sent','detail_review_already','detail_filled', 'detail_saved', 'detail_all_saved', 'detail_all_partial',
          'detail_card_input', 'detail_card_disabled', 'detail_mother_missing', 'detail_mother_field', 'detail_save_unknown', 'detail_identity', 'detail_existing', 'detail_options',
          'detail_input', 'detail_account', 'detail_failed', 'detail_busy',
          'detail_not_found', 'detail_ambiguous', 'detail_management'}


class DetailError(Exception):
    def __init__(self, code, field='',*,detail=None):self.code,self.field,self.detail=code,field,detail


def mother_surname_field(scope):
    """Resolve the surname only inside relative #2, never across the tab."""
    marker = re.compile(r'^\s*الأقارب\s*#?\s*[2٢۲]\s*$')
    heading = scope.get_by_text(marker)
    if heading.count() != 1:
        raise DetailError('detail_mother_field')
    # The title row itself contains a guardian checkbox. Climb past it to
    # the card with required text fields, rather than selecting that row.
    block = heading.locator('xpath=ancestor::*[.//input[@maxlength="256"][@required]][1]')
    # A common ancestor containing both relatives is not a mother-only form.
    father = re.compile(r'^\s*الأقارب\s*#?\s*[1١۱]\s*$')
    if block.count() != 1 or block.get_by_text(father).count():
        raise DetailError('detail_mother_field')
    label = re.compile(r'^\s*(?:الشهرة|شهرة الأم|الشهرة / اسم العائلة)(?:\s*\(بالعربية\))?\s*\*?\s*$')
    field = block.get_by_label(label)
    if field.count() != 1:
        # Some SIMS labels are visual text without a for/id association.
        caption = block.get_by_text(label)
        if caption.count() == 1:
            field = caption.locator('xpath=ancestor::*[.//input][1]').locator('input')
        else:
            field = block.locator('input[maxlength="256"][required]')
    if field.count() != 1:
        raise DetailError('detail_mother_field')
    return field


def read_details(path):
    try:
        if Path(path).stat().st_size > 64_000_000: raise ExcelInputError('الملف كبير جداً.')
        with zipfile.ZipFile(path) as z:
            if len(z.infolist()) > 1000 or sum(i.file_size for i in z.infolist()) > 128_000_000:
                raise ExcelInputError('الملف كبير جداً.')
            from student_unified import is_unified, selected_rows
            from manual_sections import MAP_SHEET, read_manual_rows
            from student_excel import NS
            import xml.etree.ElementTree as ET
            names={s.get('name') for s in ET.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',NS)}
            if MAP_SHEET in names and 'حالة السحب' in names:return read_manual_rows(z)
            unified=is_unified(z)
            data=selected_rows(z,'detailed') if unified else list(enumerate(read_table(z,'المفصّل'),2))
        result = []
        for number, row in data:
            if not unified:
                if set(row) not in (set(PREP_HEADERS),set(PREP_HEADERS[:-1])): raise ExcelInputError('اختر ملف تحويل لمفصّل.')
                try: selected = selection_value(row['اختيار للاستكمال لاحقاً'])
                except ValueError: raise ExcelInputError('عمود الاختيار يقبل 0 أو 1 أو نعم أو لا فقط.')
                if not selected: continue
            from nsldb_reference import canonical_year, TARGET_YEAR
            if (not unified or row.get('طريقة تسجيل الطالب') not in ('طالب جديد','طالب موجود بمدرسة أخرى')) and canonical_year(row['السنة في القاعدة']) != TARGET_YEAR:
                raise ExcelInputError('الاسترداد مخصص لصفوف 2025–2026.')
            values = {f['id']:row.get(f['label'],'') for f in FIELDS}
            try: values['field-birthDate'] = normalize_date(values['field-birthDate'])
            except (ValueError,TypeError,OverflowError): raise ExcelInputError(f'راجع تاريخ الولادة في الصف {number}.')
            for key in ('field-firstName','field-middleName','field-lastName'):
                if not isinstance(values[key],str) or not values[key].strip():
                    raise ExcelInputError(f'أكمل اسم الطالب والأب والشهرة في الصف {number}.')
            address = {k:row[h] for k,h in [('البلد','بلد السكن'),('المحافظة','محافظة السكن'),
                ('القضاء','قضاء السكن'),('المنطقة','منطقة / بلدة السكن'),('الشارع','الشارع'),('تفاصيل العنوان ١','تفاصيل العنوان')]}
            if not str(address['البلد'] or '').strip():address['البلد']=DEFAULT_RESIDENCE_COUNTRY
            address['النوع']=row.get('نوع السكن','')
            phone = normalize_phone(row['رقم الهاتف (LivingPhone)'])
            from student_unified import MOTHER_SURNAME, source_mother_surname
            supplied=row.get(MOTHER_SURNAME,'')
            mother_surname=supplied.strip() if isinstance(supplied,str) else ''
            if not mother_surname:mother_surname=source_mother_surname(row.get('ملاحظات المصدر',''))
            result.append({'excel_row':number,'values':values,'address':address,'phone':phone,
                           'mother_surname':mother_surname, 'identity_card':card_from_row(row)})
        if not result: raise ExcelInputError('ضع 1 أو نعم في أول عمود للطلاب المطلوبين، ثم احفظ الملف.')
        return result
    except ExcelInputError: raise
    except Exception: raise ExcelInputError('تعذّر قراءة المفصّل. اختر ملف التحويل المحفوظ.') from None


def norm(value):
    return re.sub(r'\s+',' ',re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',str(value))).strip()


def open_existing_detail_student(page, record, username, cancelled, account_session=None):
    """Open one roster record after checking its full name and birth date."""
    from student_scan import (StudentBrowser, ScanError, canonical_uid,
                              header_indexes, is_deleted, normalized, row_key)
    values = record['values']
    expected_name = tuple(normalized(values.get(key, '')) for key in
                          ('field-firstName','field-middleName','field-lastName'))
    from identity_dates import identity_birth,birth_difference
    try:expected_birth = identity_birth(values.get('field-birthDate', ''))
    except (ValueError,TypeError,OverflowError):raise DetailError('detail_input') from None
    expected_uid = canonical_uid(values.get('field-existingUniqueId', ''))
    from detail_scope import grade_text,row_grade
    grade=record.get('search_grade')
    if grade is not None and (not isinstance(grade,str) or not grade_text(grade) or len(grade)>128 or row_grade(record)!=grade_text(grade)):
        raise DetailError('detail_input')
    grade=grade_text(grade) if grade is not None else None
    if not all(expected_name) or not expected_birth:
        raise DetailError('detail_input')
    browser = StudentBrowser(page, username, cancelled, account_session=account_session)
    try:
        # Filter the live list before its first inventory page. Never fall back
        # to a school-wide search if this grade is empty or has no match.
        roster = browser.inventory(lambda *_: None,grade=grade) if grade is not None else browser.inventory(lambda *_: None)
        candidates = [row for row in roster if not is_deleted(row) and
                      tuple(normalized(row[k]) for k in ('first','middle','last')) == expected_name]
        if not candidates: raise DetailError('detail_not_found')
        # A unique matching roster row needs only one visit. Verify its birth
        # date and remain on that same form for address entry.
        if len(candidates) == 1:
            item = candidates[0]
            actual_birth=browser.read_birth_date(item, keep_open_if_birth=expected_birth)
            if actual_birth != expected_birth:
                raise DetailError('detail_birth_mismatch',detail=birth_difference(expected_birth,actual_birth))
            return item['uid']
        births=[(row,browser.read_birth_date(row)) for row in candidates]
        matching = [row for row,birth in births if birth == expected_birth]
        if not matching:
            # Report one observed date only when the source candidate itself
            # is identified by UID; never pick the first namesake's date.
            identified=[birth for row,birth in births if expected_uid and row['uid']==expected_uid]
            detail=birth_difference(expected_birth,identified[0]) if len(identified)==1 else None
            raise DetailError('detail_birth_mismatch',detail=detail)
        if len(matching) > 1 and expected_uid:
            matching = [row for row in matching if row['uid'] == expected_uid]
        if len(matching) != 1: raise DetailError('detail_ambiguous')
        item = matching[0]
        state = browser.move(item['page'])
        if [row_key(r) for r in state['rows']] != browser.inventory_pages[item['page']]:
            raise DetailError('detail_management')
        tables = [table for table in page.locator('table').all() if table.is_visible() and
                  header_indexes(table.locator('thead th').all_inner_texts()) is not None]
        if len(tables) != 1: raise DetailError('detail_management')
        rows = tables[0].locator('tbody tr[aria-label="تعديل"]')
        if rows.count() != len(state['rows']): raise DetailError('detail_management')
        chosen = rows.nth(item['index'])
        if canonical_uid(chosen.locator('td').nth(item['uid_column']).inner_text()) != item['uid']:
            raise DetailError('detail_management')
        browser.guard()
        chosen.click(timeout=7000)
        page.locator('#field-firstName').wait_for(state='visible', timeout=15000)
        if not urlsplit(page.url).path.rstrip('/').startswith(MANAGEMENT+'/') or \
                urlsplit(page.url).path.rstrip('/') == MANAGEMENT+'/new':
            raise DetailError('detail_management')
        return item['uid']
    except ScanError as exc:
        raise DetailError('detail_account' if exc.code == 'scan_account_required' else 'detail_management') from None


def start_detail_import(page, record, section, username, cancelled, account_session=None):
    """Start each user request from the roster, even if another tab is open."""
    if section=='scope_grade':
        from detail_scope import apply_site_grade
        return apply_site_grade(page,record,username,cancelled,account_session)
    if cancelled.is_set() or not exact_https_host(page.url,SIMS_HOST) or \
            (account_session is not None and account_session.revoked):
        raise DetailError('detail_account')
    if urlsplit(page.url).path.rstrip('/')!=MANAGEMENT:
        try:
            page.goto('https://'+SIMS_HOST+MANAGEMENT,wait_until='domcontentloaded',timeout=20000)
        except Exception:raise DetailError('detail_management') from None
    if not exact_https_host(page.url,SIMS_HOST) or urlsplit(page.url).path.rstrip('/')!=MANAGEMENT:
        raise DetailError('detail_management')
    return fill_details(page,record,section,username,cancelled,account_session)


def fill_details(page, record, section, username, cancelled, account_session=None, *, auto_save=True, merge_address=False):
    manual_address=section in ('manual:عناوين السكن','manual_save:عناوين السكن')
    if manual_address:
        auto_save=section.startswith('manual_save:')
        section='address'
    from manual_sections import SECTIONS, fill_manual_section
    manual=isinstance(section,str) and (section=='review_send' or any(section.startswith(prefix) and section[len(prefix):] in SECTIONS for prefix in ('manual:','manual_save:')))
    if (section not in ('address','phone','relative','identity_card','all')+IMPORT_MODES and not manual) or not isinstance(record,dict): raise DetailError('detail_input')
    if section=='all':
        address=record.get('address',{})
        sections=[]
        skipped=False
        if any(str(address.get(key,'') or '').strip() for key in ('البلد','المحافظة','القضاء','المنطقة','الشارع','تفاصيل العنوان ١')):
            if all(isinstance(address.get(key),str) and address[key].strip() for key in ('البلد','المحافظة','القضاء','المنطقة')):
                sections.append('address')
            else:skipped=True
        phone=normalize_phone(record.get('phone',''))
        if str(record.get('phone','') or '').strip():
            if isinstance(phone,str) and re.fullmatch(r'[0-9]{8}',phone.strip()):sections.append('phone')
            else:skipped=True
        if str(record.get('mother_surname','') or '').strip():sections.append('relative')
        else:skipped=True
        if str(record.get('identity_card',{}).get('type','') or '').strip():sections.append('identity_card')
        if not sections:raise DetailError('detail_input')
        for item in sections:
            # A section must confirm its own save before opening the next one.
            try:result=fill_details(page,record,item,username,cancelled,account_session,auto_save=True)
            except DetailError as exc:
                if exc.code=='detail_existing':
                    skipped=True
                    continue
                raise
            if result not in ('detail_saved',):raise DetailError('detail_save_unknown')
        return 'detail_all_partial' if skipped else 'detail_all_saved'
    values = record.get('values',{})
    path = urlsplit(page.url).path.rstrip('/')
    system_uid = None
    if path in (MANAGEMENT, '/dashboard/analytics'):
        system_uid = open_existing_detail_student(page, record, username, cancelled, account_session)
    original = page.url
    def guard(*,allow_roster=False):
        if cancelled.is_set(): raise DetailError('detail_account')
        path = urlsplit(page.url).path.rstrip('/')
        returned=allow_roster and path in (MANAGEMENT,'/dashboard/analytics')
        if (page.url != original and not returned) or not exact_https_host(page.url,SIMS_HOST): raise DetailError('detail_account')
        if not returned and (not path.startswith(MANAGEMENT+'/') or path == MANAGEMENT+'/new'): raise DetailError('detail_identity')
        if account_session is not None and account_session.revoked: raise DetailError('detail_account')
        account = visible(page.get_by_text(re.compile(r'^\s*'+re.escape(username)+r'\s*$',re.I)))
        if account is None and not (account_session and account_session.allows(page,username)):
            raise DetailError('detail_account')
    guard()
    # Require visible personal data; do not switch away from another unsaved draft.
    identity = ('field-firstName','field-middleName','field-lastName','field-birthDate')
    uid = system_uid if system_uid is not None else values.get('field-existingUniqueId','')
    deadline = time.monotonic() + 12
    stable, last = None, None
    while True:
        guard()
        try:
            current = tuple(page.locator('#'+key).input_value() for key in identity)
            uid_field = page.locator('#field-existingUniqueId')
            current_uid = uid_field.input_value() if uid_field.count()==1 else ''
            from identity_dates import identity_birth
            matches = (all(values.get(key) and norm(actual)==norm(values[key])
                           for key,actual in zip(identity[:3],current[:3])) and
                       identity_birth(current[3])==identity_birth(values.get('field-birthDate','')) and
                       (not uid or norm(current_uid)==norm(uid)))
        except Exception:
            current, current_uid, matches = (), '', False
        snapshot = (current, current_uid)
        if matches:
            if snapshot != last: stable = time.monotonic()
            if stable is not None and time.monotonic()-stable >= .35: break
        else: stable = None
        last = snapshot
        if time.monotonic() >= deadline:
            from identity_dates import birth_difference
            names_match=len(current)==4 and all(values.get(key) and norm(actual)==norm(values[key]) for key,actual in zip(identity[:3],current[:3]))
            if names_match and (not uid or norm(current_uid)==norm(uid)):
                detail=birth_difference(values.get('field-birthDate',''),current[3])
                if detail:raise DetailError('detail_birth_mismatch',detail=detail)
            raise DetailError('detail_identity')
        page.wait_for_timeout(125)
    if section in IMPORT_MODES:
        # A single-section request starts with fresh personal data. Give every
        # automatic step that same entry path instead of carrying the previous
        # section's post-save form state into the next one. Reuse only the URL
        # and system UID already verified here, avoiding another roster scan.
        verified_record=dict(record,values=dict(values,**{'field-existingUniqueId':current_uid}))
        needs_reload=False
        def run_section(selected):
            nonlocal needs_reload
            guard(allow_roster=True)
            if needs_reload:
                try:page.goto(original,wait_until='domcontentloaded',timeout=20000)
                except Exception:raise DetailError('detail_management') from None
                if page.url!=original or not exact_https_host(page.url,SIMS_HOST):raise DetailError('detail_account')
                try:page.locator('#field-firstName').wait_for(state='visible',timeout=15000)
                except Exception:raise DetailError('detail_identity') from None
                guard()
            result=fill_details(page,verified_record,selected,username,cancelled,account_session,
                                auto_save=True,merge_address=True)
            needs_reload=True
            return result
        return import_detailed_record(page,record,section,guard,run_section)
    return fill_verified_section(page,record,section,guard,auto_save=auto_save,manual_address=manual_address,merge_address=merge_address)


def import_detailed_record(page,record,mode,guard,run_section):
    """Save every supplied section; review is an explicitly chosen final step."""
    from manual_sections import SECTIONS,has_section_data
    plan=[]
    address=record.get('address',{})
    if any(value not in ('',None) for value in address.values()):
        if not all(isinstance(address.get(key),str) and address[key].strip()
                   for key in ('البلد','المحافظة','القضاء','المنطقة')):
            raise DetailError('detail_input')
        plan.append('address')
    if 'manual' in record:
        plan.extend('manual_save:'+title for title in SECTIONS
                    if title!='حالة التسجيل' and has_section_data(record,title))
    else:
        if str(record.get('phone','') or '').strip():plan.append('phone')
        if str(record.get('mother_surname','') or '').strip():plan.append('relative')
        if str(record.get('identity_card',{}).get('type','') or '').strip():plan.append('identity_card')
    if not plan:return 'detail_no_data'
    for section in plan:
        result=run_section(section)
        if result!='detail_saved':raise DetailError('detail_save_unknown')
    guard(allow_roster=True)
    if mode=='details_import_review':
        result=run_section('review_send')
        if result=='detail_review_sent':return 'detail_import_review_sent'
        if result=='detail_review_already':return 'detail_import_review_already'
        raise DetailError('detail_save_unknown')
    return 'detail_import_saved'


def fill_verified_section(page,record,section,guard,*,auto_save=True,manual_address=False,merge_address=False):
    """Reuse one verified student/URL guard throughout a multi-section request."""
    from manual_sections import SECTIONS,fill_manual_section
    manual=section=='review_send' or section.startswith(('manual:','manual_save:'))
    if manual:
        from manual_save import save_manual,send_review
        if section=='review_send':return send_review(page,record,guard)
        title=section.split(':',1)[1]
        if title=='المستندات' and 'documents' in record:
            from document_import import save_documents
            return save_documents(page,record,guard)
        from manual_sections import AUTO_SAVE_SECTIONS,has_section_data
        if title in AUTO_SAVE_SECTIONS and not has_section_data(record,title):return 'detail_no_data'
        result=fill_manual_section(page,record,title,guard)
        return save_manual(page,title,guard) if title in AUTO_SAVE_SECTIONS or section.startswith('manual_save:') else result
    address = record.get('address',{})
    phone = normalize_phone(record.get('phone',''))
    if section=='address':
        if manual_address and not any(str(value or '').strip() for value in address.values()):return 'detail_no_data'
        if any(not isinstance(address.get(k),str) or not address[k].strip() for k in ('البلد','المحافظة','القضاء','المنطقة')):
            raise DetailError('detail_input')
        if address.get('النوع') and address['النوع'] not in ('دائم','صيفي','غير ذلك'):
            raise DetailError('detail_input')
        if any(not isinstance(v,str) or len(v)>1000 for v in address.values()): raise DetailError('detail_input')
    elif section=='phone' and (not isinstance(phone,str) or not re.fullmatch(r'[0-9]{8}',phone.strip())):
        raise DetailError('detail_input')
    elif section=='relative':
        surname=record.get('mother_surname','')
        if not isinstance(surname,str) or not surname.strip() or len(surname)>120:
            raise DetailError('detail_mother_missing')
    elif section=='identity_card':
        try:card_kind,card_number,card_expiry=validate_card(record.get('identity_card',{}))
        except (ExcelInputError,ValueError,TypeError,OverflowError):raise DetailError('detail_card_input') from None
    guard()
    mode=page.get_by_role('radio',name='مفصّل',exact=True)
    if mode.count()!=1 or not mode.is_enabled(): raise DetailError('detail_options')
    mode.click(timeout=5000);guard()
    title={'address':'عناوين السكن','phone':'الهواتف','relative':'الأقارب','identity_card':'بطاقات التعريف'}[section]
    from detail_dom import tab_locator
    tab_locator(page,title).click(timeout=5000);guard()
    # Scope every operation to its section: Add/Save exist on multiple tabs.
    scope=page.locator('section').filter(has=page.get_by_role('heading',name=title,exact=True))
    scope.wait_for(state='visible',timeout=10000);guard()
    if scope.count()!=1: raise DetailError('detail_options')
    original=page.url
    def save_section(button_name='حفظ القسم'):
        success=page.get_by_role('alert').filter(has_text=SAVE_SUCCESS_TEXT)
        try:success.wait_for(state='hidden',timeout=5000)
        except Exception:raise DetailError('detail_save_unknown') from None
        save=scope.get_by_role('button',name=button_name,exact=True)
        if save.count()!=1:raise DetailError('detail_options')
        try:save.wait_for(state='visible',timeout=5000)
        except Exception:raise DetailError('detail_options') from None
        if section=='identity_card':
            deadline=time.monotonic()+8
            while not save.is_enabled() and time.monotonic()<deadline:
                guard();page.wait_for_timeout(100)
        if not save.is_enabled():raise DetailError('detail_card_disabled' if section=='identity_card' else 'detail_options')
        guard();save.click(timeout=5000);guard()
        dialog=page.locator('.swal2-popup.swal2-modal[role="dialog"]')
        try:dialog.wait_for(state='visible',timeout=8000)
        except Exception:raise DetailError('detail_save_unknown') from None
        guard()
        heading=dialog.get_by_role('heading',name='هل أنت متأكد؟',exact=True)
        question=dialog.get_by_text('هل تريد المتابعة؟',exact=True)
        confirm=dialog.get_by_role('button',name='تأكيد',exact=True)
        if heading.count()!=1 or question.count()!=1 or confirm.count()!=1 or not confirm.is_enabled():
            raise DetailError('detail_options')
        confirm.click(timeout=5000)
        # Saving can return legacy single-section requests to the roster.
        # Multi-section requests are guarded again before advancing.
        guard(allow_roster=True)
        if page.url!=original and urlsplit(page.url).path.rstrip('/') not in (MANAGEMENT,'/dashboard/analytics'):
            raise DetailError('detail_account')
        try:dialog.wait_for(state='hidden',timeout=8000)
        except Exception:raise DetailError('detail_save_unknown') from None
        try:
            success.wait_for(state='visible',timeout=8000)
            return 'detail_saved'
        except Exception:
            return 'detail_save_unknown'
    if section=='relative':
        # The relatives form already exists. Never create another relative or
        # overwrite a surname entered by the employee.
        field=mother_surname_field(scope)
        field.wait_for(state='visible',timeout=5000);guard()
        if not field.is_enabled():raise DetailError('detail_options')
        current=field.input_value().strip()
        if current and norm(current)!=norm(surname):raise DetailError('detail_existing')
        if not current:field.fill(surname.strip(),timeout=3000)
        guard()
        if norm(field.input_value())!=norm(surname):raise DetailError('detail_options')
        return save_section()
    empty=scope.get_by_text('لم يُعثر على أية سجلات',exact=True)
    is_empty=empty.count()==1 and empty.is_visible()
    existing_address=section=='address' and merge_address and not is_empty
    if not is_empty and not existing_address:raise DetailError('detail_existing')
    if is_empty:
        guard();scope.get_by_role('button',name='إضافة',exact=True).click(timeout=5000);guard()
    def control(label):
        field=scope.get_by_label(re.compile(r'^\s*'+re.escape(label)+r'\s*\*?\s*$'))
        if field.count()!=1: raise DetailError('detail_options')
        field.wait_for(state='visible',timeout=5000)
        return field
    def choose(label,wanted):
        deadline=time.monotonic()+25
        stable=None;since=0
        while time.monotonic()<deadline:
            guard();field=control(label)
            if field.is_enabled():
                choices=field.evaluate('(el)=>Array.from(el.options||[],o=>({value:o.value,label:o.textContent,disabled:o.disabled}))')
                matches=[o['value'] for o in choices if o['value'] and not o['disabled'] and norm(o['label'])==norm(wanted)]
                if len(matches)>1: raise DetailError('detail_options')
                if len(matches)==1:
                    if stable!=matches[0]:stable=matches[0];since=time.monotonic()
                    elif time.monotonic()-since>=.5:
                        guard();field.select_option(value=matches[0],timeout=3000);return
                else:stable=None
            page.wait_for_timeout(100)
        raise DetailError('detail_options')
    if section=='identity_card':
        choose('نوع المستند',card_kind)
        # SIMS may enable the number only after choosing a document type.
        for label,wanted in (('رقم الوثيقة',card_number),('تاريخ الإنتهاء',card_expiry)):
            if not wanted:continue
            field=control(label);guard()
            if not field.is_enabled():raise DetailError('detail_options')
            if field.input_value().strip():raise DetailError('detail_existing')
            field.fill(wanted,timeout=5000);guard()
            if field.input_value()!=wanted:raise DetailError('detail_options')
        # No upload or issue date is required for the requested workflow.
        return save_section('حفظ') if auto_save else 'detail_filled'
    if section=='address':
        if existing_address:
            # Check every supplied field before filling gaps in an existing row.
            for label in ('البلد','المحافظة','القضاء','المنطقة','النوع','الشارع','تفاصيل العنوان ١'):
                wanted=address.get(label)
                if not wanted:continue
                field=control(label);guard()
                actual=field.input_value().strip()
                if actual and label in ('البلد','المحافظة','القضاء','المنطقة','النوع'):
                    actual=field.evaluate('(el)=>el.options[el.selectedIndex]?.textContent || ""')
                if actual and norm(actual)!=norm(wanted):raise DetailError('detail_existing')
        for label in ('البلد','المحافظة','القضاء','المنطقة'): choose(label,address[label])
        if address.get('النوع'): choose('النوع',address['النوع'])
        for label in ('الشارع','تفاصيل العنوان ١'):
            if address.get(label):
                guard();field=control(label)
                current=field.input_value().strip()
                if current and not (existing_address and norm(current)==norm(address[label])):raise DetailError('detail_existing')
                if not current:field.fill(address[label],timeout=3000)
    else:
        choose('النوع','خلوي');guard()
        field=control('رقم الهاتف')
        if field.input_value().strip():raise DetailError('detail_existing')
        field.fill(phone.strip(),timeout=3000)
    guard()
    if section=='address':
        for label in ('البلد','المحافظة','القضاء','المنطقة','النوع'):
            if label=='النوع' and not address.get(label):continue
            field=control(label)
            actual=field.evaluate('(el)=>el.options[el.selectedIndex]?.textContent || ""')
            if norm(actual)!=norm(address[label]):raise DetailError('detail_options')
    elif control('رقم الهاتف').input_value()!=phone.strip():raise DetailError('detail_options')
    # All section buttons use the same Save -> Confirm -> success check.
    return save_section() if auto_save else 'detail_filled'
