"""Qt process boundary: credentials travel over a pipe, never command arguments."""
import json
import os
import sys
import re
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, QTimer, Signal

EVENTS = frozenset({
    'browser_opening', 'opening', 'portal_open_manual_required', 'microsoft_opening', 'email_submitted', 'password_submitted',
    'manual_required', 'portal_retry', 'portal_manual_required', 'verify_account', 'authenticated', 'invalid_input',
    'dependency_missing', 'browser_missing', 'timeout', 'disconnected',
    'cancelled', 'browser_closed', 'failed',
})


class LoginController(QObject):
    event = Signal(str)
    student_result = Signal(str, str, str)
    catalog_result = Signal(str, str, int, int, object)
    scan_result = Signal(str, str, int, int, object)
    attendance_result = Signal(str,str,int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.process = QProcess(self)
        self.process.started.connect(self._write_input)
        self.process.readyReadStandardOutput.connect(self._read_output)
        self.process.readyReadStandardError.connect(lambda: self.process.readAllStandardError())
        self.process.errorOccurred.connect(self._process_error)
        self.process.finished.connect(self._finished)
        self._pending = None
        self._buffer = ''
        self._terminal_event = False

    def running(self):
        return self.process.state() != QProcess.NotRunning

    def start(self, username, password, browser, shift):
        if self.running():
            return False
        self._pending = (json.dumps({'username': username, 'password': password, 'browser': browser, 'shift': shift}) + '\n').encode('utf-8')
        self._buffer = ''
        self._terminal_event = False
        env = QProcessEnvironment.systemEnvironment()
        env.insert('PYTHONIOENCODING', 'utf-8')
        env.remove('DEBUG')
        env.remove('PWDEBUG')
        self.process.setProcessEnvironment(env)
        if getattr(sys, 'frozen', False):
            program = str(Path(sys.executable).parent / 'helpers' / 'SayedTechLogin' / 'SayedTechLogin.exe')
            args = []
        else:
            program, args = sys.executable, ['-u', str(Path(__file__).with_name('login_worker.py'))]
        self.process.setWorkingDirectory(str(Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent))
        self.process.start(program, args)
        return True

    def _write_input(self):
        pending, self._pending = self._pending, None
        if pending is not None:
            self.process.write(pending)

    def _read_output(self):
        self._buffer += bytes(self.process.readAllStandardOutput()).decode('utf-8', errors='replace')
        while '\n' in self._buffer:
            line, self._buffer = self._buffer.split('\n', 1)
            try:
                result = json.loads(line)
                event = result.get('event')
            except (ValueError, AttributeError):
                continue
            if not isinstance(event, str): continue
            if event in EVENTS:
                if event in {'invalid_input', 'dependency_missing', 'browser_missing', 'timeout', 'disconnected', 'cancelled', 'browser_closed', 'failed'}:
                    self._terminal_event = True
                self.event.emit(event)
            elif event.startswith('attendance_'):
                from attendance_schema import EVENTS as ATTENDANCE_EVENTS
                request_id=result.get('request_id','');days=result.get('days',0)
                if event in ATTENDANCE_EVENTS and isinstance(request_id,str) and re.fullmatch('[a-f0-9]{32}',request_id) and type(days) is int and 0<=days<=5000:
                    self.attendance_result.emit(request_id,event,days)
            elif event.startswith('scan_'):
                from student_scan import EVENTS as SCAN_EVENTS, clean_detail
                request_id=result.get('request_id','')
                first,second=result.get('first',0),result.get('second',0)
                if (event in SCAN_EVENTS and isinstance(request_id,str) and re.fullmatch(r'[a-f0-9]{32}',request_id)
                    and type(first) is int and type(second) is int and 0<=first<=5000 and 0<=second<=5000):
                    self.scan_result.emit(request_id,event,first,second,clean_detail(result.get('detail')))
            elif isinstance(event, str) and event.startswith('catalog_'):
                from address_catalog import EVENTS as CATALOG_EVENTS, clean_detail
                request_id = result.get('request_id', '')
                first, second = result.get('first', 0), result.get('second', 0)
                if (event in CATALOG_EVENTS and isinstance(request_id, str)
                        and re.fullmatch(r'[a-f0-9]{32}', request_id)
                        and type(first) is int and type(second) is int
                        and 0 <= first <= 100000 and 0 <= second <= 100000):
                    self.catalog_result.emit(request_id, event, first, second, clean_detail(result.get('detail')))
            elif event.startswith('detail_'):
                from detailed_import import EVENTS as DETAIL_EVENTS
                request_id=result.get('request_id','')
                if event in DETAIL_EVENTS and isinstance(request_id,str) and re.fullmatch(r'[a-f0-9]{32}',request_id):
                    from manual_sections import HEADERS
                    field=result.get('field','')
                    self.student_result.emit(request_id,event,field if isinstance(field,str) and field in HEADERS else '')
            elif event in {'student_busy','student_invalid','student_cancelled','student_account_required',
                           'student_create_unavailable','student_existing_unavailable','student_search_unavailable',
                           'student_result_unavailable','student_form_unavailable','student_field_failed',
                           'student_saved','student_saved_return_failed','student_already_registered',
                           'student_preflight_clear',
                           'student_duplicate_review','student_duplicate_check_failed',
                           'student_existing_not_found','student_existing_ambiguous','student_search_changed','student_existing_mismatch',
                           'student_open_management','student_form_not_empty','student_options_changed',
                           'student_draft_filled','student_failed','student_save_requested','student_save_unverified','student_save_blocked'}:
                request_id = result.get('request_id','')
                field = result.get('field','')
                if isinstance(request_id,str) and re.fullmatch(r'[a-f0-9]{32}',request_id):
                    from student_excel import BY_ID
                    self.student_result.emit(request_id,event,field if isinstance(field,str) and field in BY_ID else '')
        if len(self._buffer) > 16384:
            self._buffer = ''

    def _process_error(self, error):
        self._pending = None
        if error == QProcess.FailedToStart:
            self._terminal_event = True
            self.event.emit('failed')

    def _finished(self, *_args):
        self._pending = None
        self._read_output()
        if not self._terminal_event:
            self.event.emit('browser_closed')

    def cancel(self):
        self._pending = None
        if self.running():
            self.process.write(b'cancel\n')
            # This timer is scoped to this process object; do not kill a later login.
            pid = self.process.processId()
            QTimer.singleShot(10000, lambda: self.process.kill() if self.running() and self.process.processId() == pid else None)

    def fill_details(self, record, section, request_id):
        if not self.running(): return False
        message=json.dumps({'action':'fill_details','record':record,'section':section,'request_id':request_id},ensure_ascii=False)+'\n'
        if len(message.encode('utf-8'))>32768:return False
        return self.process.write(message.encode('utf-8'))>=0

    def attendance(self,action,request_id,**payload):
        if not self.running() or action not in ('attendance_template','attendance_export','attendance_import'):return False
        message=json.dumps(dict(payload,action=action,request_id=request_id),ensure_ascii=False)+'\n'
        if len(message.encode('utf-8'))>32768:return False
        return self.process.write(message.encode('utf-8'))>=0

    def fill_student(self, record, request_id, save=False, batch_id=None, entry_kind='طالب موجود'):
        if not self.running(): return False
        message = json.dumps({'action':'fill_student','record':record,'request_id':request_id,
                              'save':save,'batch_id':batch_id,'entry_kind':entry_kind},ensure_ascii=False)+'\n'
        if len(message.encode('utf-8')) > 32768: return False
        return self.process.write(message.encode('utf-8')) >= 0

    def check_student(self,record,request_id,batch_id):
        if not self.running():return False
        message=json.dumps({'action':'check_student','record':record,'request_id':request_id,
                            'batch_id':batch_id},ensure_ascii=False)+'\n'
        if len(message.encode('utf-8'))>32768:return False
        return self.process.write(message.encode('utf-8'))>=0

    def collect_catalog(self, path, request_id):
        if not self.running(): return False
        message = json.dumps({'action': 'collect_catalog', 'path': path, 'request_id': request_id}) + '\n'
        if len(message.encode('utf-8')) > 32768: return False
        return self.process.write(message.encode('utf-8')) >= 0

    def cancel_catalog(self, request_id):
        if self.running():
            message = json.dumps({'action': 'cancel_catalog', 'request_id': request_id}) + '\n'
            self.process.write(message.encode('utf-8'))

    def scan_students(self,path,limit,request_id,grade=None):
        if not self.running():return False
        message=json.dumps({'action':'scan_students','path':path,'limit':limit,'grade':grade,'request_id':request_id},ensure_ascii=False)+'\n'
        if len(message.encode('utf-8'))>32768:return False
        return self.process.write(message.encode('utf-8'))>=0

    def list_scan_grades(self,request_id):
        if not self.running():return False
        message=json.dumps({'action':'scan_grades','request_id':request_id})+'\n'
        return self.process.write(message.encode('utf-8'))>=0

    def cancel_scan(self,request_id):
        if self.running():
            self.process.write((json.dumps({'action':'cancel_scan','request_id':request_id})+'\n').encode('utf-8'))

    def shutdown(self):
        self.cancel()
        if self.running() and not self.process.waitForFinished(3000):
            self.process.kill()
            self.process.waitForFinished(1000)
