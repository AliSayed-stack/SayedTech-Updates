"""One editable workbook; each import validates only its own input fields."""
from student_excel import FIELDS, HEADERS, NS, ExcelInputError, validate_record, optional_registry
from student_workflow import workbook_rows, selection_value
from nsldb_reference import REFERENCE_EXTRA, DETAIL_HEADERS, TARGET_YEAR, canonical_year
from student_detailed import ADDRESS_COLUMNS
from name_transliteration import suggest_english_names
import xml.etree.ElementTree as ET
import zipfile
import hashlib
import os
import re
import tempfile
from xml.sax.saxutils import escape
from pathlib import Path
from student_workflow import column
from name_transliteration import NAME_PAIRS

MARKER = 'الملف الموحد'
SELECTION = 'اختيار للاستيراد'
from student_promotion import PROMOTION_HEADERS
OLD_ADDRESS_COLUMNS = ADDRESS_COLUMNS[:-1]
LEGACY_HEADERS = [SELECTION] + HEADERS + REFERENCE_EXTRA[2:] + DETAIL_HEADERS + OLD_ADDRESS_COLUMNS
PREVIOUS_HEADERS = LEGACY_HEADERS + PROMOTION_HEADERS
ENTRY_KIND = 'طريقة تسجيل الطالب'
UNIFIED_HEADERS = PREVIOUS_HEADERS + ['نوع السكن', ENTRY_KIND]


def is_unified(z):
    data=z.read('xl/workbook.xml')
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():raise ExcelInputError('بنية XML غير مدعومة.')
    return any(s.get('name')==MARKER for s in ET.fromstring(data).findall('m:sheets/m:sheet',NS))


def selected_rows(z, purpose):
    marker=workbook_rows(z,MARKER)
    if any(f for _,_,f in marker):raise ExcelInputError('مرجع الملف الموحد غير صالح.')
    info={v.get('A'):v.get('B') for _,v,_ in marker}
    if info.get('نوع الملف')!='unified_students' or str(info.get('السنة الدراسية'))!=TARGET_YEAR:
        raise ExcelInputError('اختر الملف الموحد لعام 2025–2026.')
    rows=workbook_rows(z,'الطلاب')
    if not rows or rows[0][0]!=1 or rows[0][2]:raise ExcelInputError('عناوين الملف غير صالحة.')
    headers=rows[0][1]
    if headers.get('A')!=SELECTION or not any(len(headers)==len(schema) and set(headers.values())==set(schema) for schema in (UNIFIED_HEADERS,PREVIOUS_HEADERS,LEGACY_HEADERS)):
        raise ExcelInputError('عناوين الملف الموحد مختلفة؛ لا تغيّر أسماء الأعمدة.')
    relevant=set(HEADERS) if purpose=='simple' else {
        f['label'] for f in FIELDS if f['id'] in ('field-firstName','field-middleName','field-lastName','field-birthDate','field-existingUniqueId')}
    if purpose=='detailed':relevant.update(ADDRESS_COLUMNS+['رقم الهاتف (LivingPhone)'])
    relevant.update([SELECTION,ENTRY_KIND,'السنة في القاعدة','معرّف المدرسة في القاعدة','معرّف الشخص في القاعدة'])
    selected=[]
    for number,values,formulas in rows[1:]:
        if 'A' in formulas:raise ExcelInputError(f'الصف {number}: الاختيار يدوي دون معادلات.')
        try:chosen=selection_value(values.get('A',''))
        except ValueError:raise ExcelInputError(f'الصف {number}: استخدم 0 أو 1 أو نعم أو لا في أول عمود.') from None
        if not chosen:continue
        if any(headers.get(c) in relevant for c in formulas):
            raise ExcelInputError(f'الصف {number}: البيانات المستخدمة للاستيراد يجب أن تكون قيماً ثابتة.')
        if any(c not in headers and v!='' for c,v in values.items()):raise ExcelInputError('بيانات خارج أعمدة الملف.')
        row={label:values.get(c,'') for c,label in headers.items()}
        kind=str(row.get(ENTRY_KIND,'طالب موجود') or 'طالب موجود').strip()
        if kind not in ('طالب موجود','طالب جديد'):
            raise ExcelInputError(f'الصف {number}: طريقة تسجيل الطالب يجب أن تكون طالب موجود أو طالب جديد.')
        if kind=='طالب موجود' and canonical_year(row['السنة في القاعدة'])!=TARGET_YEAR:
            raise ExcelInputError('الاستيراد مخصص لعام 2025–2026.')
        uid_label=next(f['label'] for f in FIELDS if f['id']=='field-existingUniqueId')
        if kind=='طالب جديد' and (row.get('معرّف الشخص في القاعدة') or row.get('معرّف المدرسة في القاعدة') or row.get(uid_label)):
            raise ExcelInputError(f'الصف {number}: صف الطالب الجديد لا يحمل معرّفاً من القاعدة؛ راجع اختيار طريقة التسجيل.')
        row[ENTRY_KIND]=kind
        selected.append((number,row))
    if not selected:raise ExcelInputError('لم تختر أي طالب. ضع 1 أو نعم في أول عمود واحفظ الملف.')
    return selected


def read_simple_unified(z, shift='morning'):
    result=[];seen={}
    for number,row in selected_rows(z,'simple'):
        raw=suggest_english_names({f['id']:row[f['label']] for f in FIELDS})
        values,errors=validate_record(raw, shift)
        item={'excel_row':number,'values':values,'errors':errors,'address':{},'workflow':True,'unified':True,
              'entry_kind':row[ENTRY_KIND],
              'reference':{label:row[label] for label in REFERENCE_EXTRA[2:]},
              'warnings':optional_registry(raw,shift)[1]}
        # Match existing simple-import behavior for selected nonblank UIDs.
        uid=values.get('field-existingUniqueId')
        if uid:
            if uid in seen:
                errors.append('الرقم الموحد مكرر ضمن الطلاب المختارين')
                seen[uid]['errors'].append('الرقم الموحد مكرر ضمن الطلاب المختارين')
            else:seen[uid]=item
        result.append(item)
    return result


def convert_to_unified(source,destination):
    from student_detailed import convert_to_detailed
    return convert_to_detailed(source,destination,unified=True)


def _insert_translations(sheet_xml, proposals):
    """Edit only target cells, retaining Excel's original XML namespaces verbatim.

    ElementTree drops namespace declarations used only by mc:Ignorable; Excel
    then repairs sheet1.xml and discards student data. Avoid serializing the
    entire worksheet. All cell values come from the ASCII transliterator.
    """
    by_row={}
    for (number,letter),value in proposals.items():
        if not re.fullmatch(r'[A-Z]{1,3}',letter) or not isinstance(value,str) or any(ord(c)<32 for c in value):
            raise ExcelInputError('قيمة ترجمة غير صالحة.')
        by_row.setdefault(number,{})[letter]=value
    seen=set()
    row_pattern=rb'<(?P<tag>(?:[A-Za-z_][\w.-]*:)?row)\b(?P<attrs>[^>]*)>(?P<body>.*?)</(?P=tag)\s*>'

    def replace_row(match):
        attrs=match.group('attrs')
        number_match=re.search(rb'\br=["\'](\d+)["\']',attrs)
        if not number_match:return match.group(0)
        number=int(number_match.group(1))
        if number not in by_row:return match.group(0)
        seen.add(number)
        tag=match.group('tag')
        prefix=tag[:-3]  # "" or the worksheet namespace prefix, e.g. "ns0:"
        cell_tag=prefix+b'c'
        cell_pattern=re.compile(rb'<'+cell_tag+rb'\b(?P<attrs>[^>]*?)(?:/\s*>|>(?P<body>.*?)</'+cell_tag+rb'\s*>)',re.DOTALL)
        body=match.group('body')
        replacements={}
        cells=list(cell_pattern.finditer(body))
        for cell in cells:
            ref_match=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',cell.group('attrs'))
            if not ref_match or int(ref_match.group(2))!=number:continue
            letter=ref_match.group(1).decode('ascii')
            if letter in by_row[number]:
                attributes=re.sub(rb'\s+t=["\'][^"\']*["\']',b'',cell.group('attrs'))
                value=escape(by_row[number][letter]).encode('utf-8')
                replacements[letter]=(b'<'+cell_tag+attributes+b' t="inlineStr"><'+prefix+b'is><'+prefix+b't>'+value+
                                      b'</'+prefix+b't></'+prefix+b'is></'+cell_tag+b'>')
        # Normal Excel templates have each English cell already. Refuse to
        # invent a missing cell here rather than risk changing worksheet order.
        missing=set(by_row[number])-set(replacements)
        if missing:raise ExcelInputError(f'الصف {number}: خلية الترجمة غير موجودة؛ لم يُعدّل الملف.')
        pieces=[];cursor=0
        for cell in cells:
            pieces.append(body[cursor:cell.start()])
            ref=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',cell.group('attrs'))
            letter=ref.group(1).decode('ascii') if ref else ''
            pieces.append(replacements.get(letter,cell.group(0)))
            cursor=cell.end()
        pieces.append(body[cursor:])
        return b'<'+tag+attrs+b'>'+b''.join(pieces)+b'</'+tag+b'>'

    changed=re.sub(row_pattern,replace_row,sheet_xml,flags=re.DOTALL)
    if seen!=set(by_row):raise ExcelInputError('تعذّر إيجاد صفوف الترجمة؛ لم يُعدّل الملف.')
    ET.fromstring(changed)  # Catch malformed XML before replacing the original.
    return changed


def translate_manual_names(path):
    """Fill empty English cells for manual rows in the same workbook on request."""
    path=Path(path)
    if path.suffix.lower()!='.xlsx' or not path.is_file() or path.stat().st_size>64_000_000:
        raise ExcelInputError('اختر الملف الموحد بصيغة xlsx.')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        if not is_unified(z):raise ExcelInputError('اختر الملف الموحد.')
        rows=workbook_rows(z,'الطلاب')
        if not rows or set(rows[0][1].values())!=set(UNIFIED_HEADERS) or len(rows[0][1])!=len(UNIFIED_HEADERS):
            raise ExcelInputError('اختر أحدث ملف موحد.')
        headers=rows[0][1]
        parts={n:z.read(n) for n in z.namelist()}
    by_name={f['id']:f['label'] for f in FIELDS}
    wanted={headers_inv:column_id for column_id,headers_inv in headers.items()}
    proposals={}
    for number,values,formulas in rows[1:]:
        kind=str(values.get(wanted[ENTRY_KIND],'')).strip()
        if kind == 'طالب جديد':
            is_manual=True
        elif not kind:
            # Rows typed directly in Excel may not have the route dropdown set.
            # Imported NSLDB rows carry source identities, so they remain excluded.
            identity_labels=('معرّف الشخص في القاعدة','معرّف المدرسة في القاعدة')
            has_identity=any(str(values.get(wanted.get(label,''),'')).strip()
                             for label in identity_labels if label in wanted)
            has_arabic=any(str(values.get(wanted[by_name[arabic]],'')).strip()
                           for arabic,_ in NAME_PAIRS)
            is_manual=has_arabic and not has_identity
        else:
            is_manual=False
        if not is_manual:continue
        raw={arabic:values.get(wanted[by_name[arabic]],'') for arabic,_ in NAME_PAIRS}
        raw.update({english:values.get(wanted[by_name[english]],'') for _,english in NAME_PAIRS})
        translated=suggest_english_names(raw)
        for _,english in NAME_PAIRS:
            letter=wanted[by_name[english]]
            if letter in formulas:raise ExcelInputError(f'الصف {number}: الترجمة لا تعدّل خلية فيها معادلة.')
            if not values.get(letter) and translated.get(english):
                proposals[(number,letter)]=translated[english]
    if not proposals:return 0
    book=ET.fromstring(parts['xl/workbook.xml'])
    sheet=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')=='الطلاب')
    rel_id=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    target=next(r.get('Target') for r in rels if r.get('Id')==rel_id)
    sheet_path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if sheet_path not in parts or '..' in Path(sheet_path).parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    parts[sheet_path]=_insert_translations(parts[sheet_path],proposals)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.xlsx',delete=False) as file:temporary=Path(file.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        with zipfile.ZipFile(temporary) as z:
            if z.testzip() is not None or len(workbook_rows(z,'الطلاب'))!=len(rows):
                raise ExcelInputError('فشل فحص الملف المترجم؛ بقي الملف الأصلي كما هو.')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
        os.replace(temporary,path)
    except OSError:
        raise ExcelInputError('أغلق ملف Excel وتأكد من صلاحية الكتابة ثم أعد الترجمة.') from None
    finally:
        if temporary and temporary.exists():temporary.unlink()
    return len(proposals)
