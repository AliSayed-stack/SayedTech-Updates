# Development handoff — Sayed tech 1.20

## Recovery

This adds per-pupil checkbox selection and explicit RTL alignment to the responsive detailed restoration dialog. Restore the folder from `SayedTech_Stage1-1.20.zip` or from a development repository. Start with `AGENTS.md`. Continuing development does not require the original temporary execution workspace.

Updater repository: `https://github.com/AliSayed-stack/SayedTech-Updates`. Its workflow takes a versioned ZIP from the root or a published release. Runtime update configuration remains in `assets/update_source.json`.

## Behaviors to retain

- Student export has 56 columns ending at BD. A is `اختيار للاسترداد اليدوي`. Header-based reading accepts the old order and extra obsolete attachment columns.
- `شهرة الأم` follows the Arabic mother name, before the English name, and targets relative #2 only.
- Keep original Excel formats/row heights and lookup lists. Updating a previous extract saves a separate copy.
- Keep the section chooser and selected-student section save. Only fill-without-save is removed. The dialog also has two batch actions for all Excel-selected rows: import with review or without review. Address comes first and uses the existing seven columns. See `detailed_batch.py` for queue state and `test_detailed_batch.py` for regression coverage.
- Manual ID/document sections save and confirm after successful filling without requiring a file upload. Empty sections are not added/saved.
- Current registration status is display-only. The note is applied by send_review only. The batch with-review action sends after all provided sections confirm saving; no-review and selected-section save never invoke it. The explicit standalone review button operates only on the selected student. Termination is untouched. Errors stop the current student and later students. Successful row indexes are retained only while the same dialog is open, independently for each action.
- The current supplied phone form has one type select, an eight-character numeric-mode input, and a primary checkbox; it has no country-code field.
- `fill_manual_section` skips retained Lebanese code 961 only after a stable local layout is confirmed. The older country-select form still binds normally, and an existing unmatched select is not ignored.

## Last functional fix

Versions 1.10/1.11 stopped during phone prevalidation at `الهواتف / رمز الدولة`. The supplied HTML proved that field is absent. Reproduced using `test_fixtures/phones_local_site.html`, then fixed in 1.12. Before cleanup, the final focused regression run passed 54 tests covering both phone forms and other import sections.

## Cleanup

Runtime code and static assets are retained. Development preview images and separate historical CHANGES files were consolidated into `CHANGELOG_AR.md`. Tests and sanitized fixtures remain. `.gitignore` excludes local school data, sessions, environments and generated output. `tools/package_source.py` builds the correctly named source ZIP.

## Baseline 1.12 verification record

Verified on 2026-10-23: full unittest discovery completed 327 tests, with 15 skipped in this environment, zero failures and zero errors. The two legacy test assumptions were updated: scan parity now includes the additional manual-section lists, and XML preservation checks accept equivalent namespace prefixes. Application runtime code, Windows scripts and static assets were byte-compared with the delivered 1.12 archive; all 65 relevant files are unchanged.

The clean ZIP was successfully restored using the app's own source-updater extractor, and update-manifest generation was checked. No Windows installer was compiled here; the packaging tests use synthetic executables. See `DEVELOPMENT.md` for commands and verification limits.

## Version 1.13 change

`detailed_dialog.py` now imports every selected Excel row in order using `DetailedImportBatch`. The worker releases its operation lock before emitting the result, permitting the next request. `fill_details` verifies identity once and uses `fill_verified_section` with the same URL/account guard for all sections. Missing sections are skipped; an unknown save or conflicting value aborts before review. Existing matching addresses are reused without Add. Legacy per-section entry points remain available internally for compatibility. UI columns and source Excel schema are unchanged apart from an in-app result column.

The two import actions are the user's explicit authorization for their respective behavior, including review when selected. Do not restore automatic sending to the no-review path. The queue can stop after the current pupil and resume within the same dialog; it does not persist student records or completion outside that dialog.

## Version 1.13 verification

On 2026-10-23 the focused suite ran 121 tests successfully (103 passed; 18 Qt/UI tests skipped because PySide6 is unavailable). This covered the new batch state machine, review/no-review routing, section ordering, failure and cancellation gates, address reuse, both school shifts, legacy detailed formats, phone/document regressions, identity and mother binding, login policy, core and packaging. All Python sources parse. Qt batch-dialog tests are included for a Qt-equipped environment. The packaging suite used synthetic executables; no native Windows installer or live SIMS session was tested here.

## Version 1.14 correction

The user clarified that only fill-without-save should be removed. Restored the manual section combo, selected-row section-save button, and standalone selected-student review button while retaining both batch actions. `single_pending` isolates the individual request from the batch queue; all conflicting controls disable until its response, and a single-section success never advances or completes batch rows. UI tests cover this routing. No data schema, browser fill/save backend, or batch backend changed from 1.13.

Version 1.14 validation: focused import/queue/save suite completed 56 tests (51 passed, 5 Qt dialog tests skipped because PySide6 is unavailable). Python sources parse. The browser fill/save and batch backends are unchanged from 1.13. No native UI, live SIMS or Windows installer validation was performed here.

## Version 1.15 automatic phone entry

The user reports that selected-section phone filling succeeds while automatic import reaches phones and leaves the number blank. Both called the same field binder, but the automatic path retained the prior section's post-save page state. The exact live-site failure was not observed. Automatic import now reopens the already verified student URL after each confirmed save and calls `fill_details` for the next individual section, including personal identity verification. It passes the current system UID observed during the first verified entry in a copied record; it never replaces the original Excel UID. This avoids another roster inventory for every section. Review also uses a fresh verified entry and remains exclusive to its explicit action. Failed or uncertain saves stop before reload and review.

`test_detailed_section_transition.py` uses the actual supplied local-phone HTML and binder with a synthetic post-save locked/stale form. The prior automatic path reproduced a blank phone failure; the fresh-entry path fills the eight-digit number, type and primary flag. Coverage also checks unknown saves do not discard drafts, wrong birth dates stop entry, and old source UIDs do not override the verified system UID. This is offline regression evidence, not an observation or confirmation of the live SIMS cause. Both field binding and selected-section UI are unchanged.

Version 1.15 validation: 83 focused tests completed successfully (78 passed, 5 Qt UI tests skipped). These cover the new actual-phone HTML transition regression, both-shift routing, queue/save gates, manual and automatic address, phone variants, documents, identity and mother binding. All Python sources parse. No live SIMS, native Qt display or Windows installer was tested.

## Version 1.16 — evidence for the actual stop

The user's Sayed tech 1.15 screenshot reports `detail_save_unknown`, while the browser is on the still-empty phones tab. The previous reload hypothesis did not resolve it. An unauthenticated read of the site's public frontend code on 2026-10-23 confirms that the shared section save awaits the update mutation, emits `toast.success(common.saved)`, returns true, then the address onSaved callback advances to the next step. The Arabic common.saved translation is exactly «تم الحفظ بنجاح». Our two save matchers only accepted «تم حفظ…بنجاح», missing the article in «الحفظ». The site's toast implementation uses role alert, so the selector role itself was correct.

Evidence URLs (public frontend only; no signed-in session or student API was accessed):
- https://new-sims.mehe.gov.lb/_next/static/chunks/1urbjkucinx77.js — shared section save and address onSaved advancement.
- https://new-sims.mehe.gov.lb/_next/static/chunks/3wcp644w05a1n.js — Arabic common.saved translation.
- https://new-sims.mehe.gov.lb/_next/static/chunks/0bogcrm2nj4kt.js — toast role alert.

Both save paths now use `detail_dom.SAVE_SUCCESS_TEXT`. It accepts current and legacy positive save notifications; it rejects errors and delete notifications. Save -> confirmation -> fresh success remains required; a tab change alone is never accepted as success. Phone binding and UI controls are unchanged. `test_save_success_text.py` failed against 1.15 using the actual translated notification and passes after the fix. It covers address auto-advancement, all manual save sections, automatic continuation to phone, failure gates, and Python/JavaScript regex parity. Avoid \b for Arabic in a regex Playwright sends to JavaScript.

Version 1.16 verification: 65 focused tests completed successfully (60 passed; 5 Qt dialog tests skipped because PySide6 is unavailable). This includes the current-site save-message regression, JavaScript regex parity, address/phone continuation, per-section and automatic routes, identity and unconfirmed-save gates. All Python sources parse. No signed-in live SIMS mutation or Windows installer build was performed.

## Version 1.17 — registration-date format

The user's preflight screenshot flags registration date in Excel row 90. They explicitly confirmed that their existing exports use MM/DD/YYYY. `normalize_date` previously accepted only ISO text or numeric Excel dates, rejecting valid MM/DD/YYYY strings. It now accepts the declared month-first text format and normalizes it to ISO for the site. Invalid and future dates still fail. The NSLDB registration mapper `_source_date` previously tried DD/MM before MM/DD, silently reversing ambiguous values; it now prioritizes ISO then MM/DD, retaining unambiguous legacy DD/MM and DD-MM source fallbacks. Input Excel cells are not rewritten and no current date is substituted.

The change is covered by `test_registration_dates.py`: month-first ambiguous values, both shifts, existing text-date workbook reading, source registration mapping, leap dates, bad serials and future-date rejection. Legacy DOB extraction from the raw database and the separate document manual_date convention are unchanged. Existing ISO/numeric date workbooks remain supported. The 1.16 save-success fix and selected-section/batch UI remain intact.

Version 1.17 verification: 75 focused tests completed successfully, covering registration date formats, NSLDB mapping/conversion, simple/unified Excel reading, both school shifts and student field validation. All Python sources parse. No live SIMS mutation or native Windows build was performed.


## Version 1.18 — grade-scoped detail restoration

The user paused the unresolved morning automatic-phone report and requested a class-restricted restoration search to save time. No new phone fix is claimed. The current failure still requires the application's current error/result evidence.

The detailed import dialog now has a top grade combo derived from the marked Excel records. All-grades remains available. Choosing a grade hides unrelated records; batch imports process only those visible records. Single-section save and standalone review use the same chosen scope. `detail_scope.py` normalizes class text and copies `search_grade` into request metadata without changing the underlying source values. The controller/worker preserve that record as before.

`open_existing_detail_student` validates that the scope matches the source row's class, then invokes `StudentBrowser.inventory(...,grade=grade)` directly. That existing implementation chooses the website grade before the first list snapshot and validates that returned rows belong to it. Missing matches, unavailable grades and stale filters fail closed; none retry a whole-school inventory. Existing identity checks remain. Post-save re-entry retains scope metadata and continues using the verified URL/UID. The simple registration duplicate guard remains unchanged; this is existing-student detail restoration.

The batch queue retains original row indexes/completion across grade switches. Eligible rows, current position and done/total counts are scope-specific. Hidden pupils cannot be dispatched via a selected-row action. Grade selection disables while a request is pending. Excel columns, phone binding and save confirmation are unchanged.

Version 1.18 verification: 80 focused tests completed successfully (74 passed; 6 native Qt tests skipped because PySide6 is unavailable). The new regressions use the real StudentBrowser implementation on synthetic paginated tables: a 306-student, three-grade roster inventories only the chosen grade, including both its pages, and opens only the verified target for both school shifts. Missing matches never visit another grade; stale filters and unavailable grade options stop before opening a student. Queue tests cover both review modes, hidden/missing-class rows, switching classes, scoped counters and retry completion without mutating source records. The existing phone HTML bindings, section transition, identity, address and save-message regression suites pass. Native Qt/Windows and live SIMS were not tested.


## Version 1.19 — responsive detailed-import window

The supplied Windows screenshot shows inherited main-app button/combo padding consuming most of the dialog and shrinking the student table to approximately one row. `detailed_dialog.py` now applies a dialog-scoped compact stylesheet; the main app theme is unchanged. The long instructions are collapsed behind a help toggle. The grade filter remains on top, the table has stretch and a 210-logical-pixel minimum, and the result column moves visually beside the student name without changing logical column indexes or Excel. Column widths are bounded and interactive; full cell text stays in tooltips.

Selected-student actions and both explicit batch choices remain visible in separate groups. Layouts reflow into three, two or one columns as space allows. At medium widths the two batch captions shorten while retaining their full tooltips and existing signals. The body scrolls on exceptionally short windows; the close/stop footer stays outside the scroll area. The native frame initially fits QScreen.availableGeometry, excluding taskbar/titlebar space, and supports maximize. Moving to another screen fits it again. No backend import, phone binding, save protocol, grade scope or Excel change was made. The separate morning automatic-phone issue remains unresolved pending current application error evidence.

Version 1.19 verification: installed PySide6-Essentials 6.10.2 for local headless Qt checks (production requirements remain unchanged). All 68 focused tests passed with no skips, including all six previously skipped batch UI tests, new real Qt geometry/reachability tests, grade-scoped lookup, queue routing, section transition and save acknowledgement. Five layout tests also passed at each QT_SCALE_FACTOR 1.25 and 1.5. Rendered synthetic-data windows were visually inspected at 1180x780, 1060x550 and 760x590; controls fit without body scrolling, the table stays at least 210 logical pixels high, and at 560x460 body scrolling reaches all actions while close stays visible. These are Linux/offscreen Qt checks, not a native Windows build or signed-in SIMS test. Synthetic previews are outside the source archive.


## User confirmation after 1.19

The user explicitly reported that the initial test of BOTH automatic detailed-import choices (with review and without review) succeeded. Treat 1.19 as the user-confirmed functional baseline; the earlier unresolved morning report should not be reported as a continuing observed failure. This is initial user verification, not proof for every student or future site state. Preserve its phone/save/identity implementation.

## Version 1.20 — checkboxes and explicit RTL

The user requested a checkbox column to skip pupils already entered and a right-to-left screen. Added the first, rightmost column `استرداد` to the in-app table only. All rows already marked in Excel are checked initially. Unchecking excludes the pupil from BOTH batch choices; single-section and standalone review also refuse unchecked current rows. UI row highlighting remains independent of check state. Changing grade preserves checkbox state, and only visible checked indexes are passed into the queue. No selected pupils produces a message without any controller request. The table is disabled while a request is pending. Checkbox state lives only in the current dialog and never changes the underlying row values or Excel.

`DetailedImportBatch.start(...,selected=None)` accepts an optional original-index selection and freezes a copy for the run. Eligibility combines selection and grade. Counters and next-row advancement use that same eligibility, preserving existing per-mode completion, retries and stop/resume. Empty explicit selection dispatches nothing. Omitted selection retains all-rows behavior for old internal callers.

The table, header, body and combo views explicitly use RTL. Table values and combo items use AlignRight | AlignVCenter | AlignAbsolute: without AlignAbsolute Qt mirrors AlignRight to left in an RTL view. The noneditable combo labels use the delegate drawing mode when supported, so the alignment data also applies to the closed label (not only its popup). RTL scroll position opens on the right; the selection column is followed by Excel row, pupil and the visually moved result column. No string contents are reversed. Result-column indexes are computed dynamically after adding the local checkbox column.

Version 1.20 verification: all 75 focused tests passed with real headless Qt, including checkbox routing in BOTH batch modes, empty selection, individual-action exclusion, selection freezing, cross-grade state, mouse/keyboard checkbox toggles, right-edge column placement, resolved Qt RTL alignment, responsive geometry, existing queue/identity/section transition and save-message regressions. All 16 Qt layout/dialog tests also passed at 150% scaling. Synthetic-data screenshots were inspected; the checked column is rightmost and closed combo labels and table values are aligned to the right. No native Windows build or live SIMS mutation was performed for this UI/queue update. The fill/save backend remains unchanged from user-confirmed 1.19.
