import uuid
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView,QComboBox
from detailed_batch import DetailedImportBatch


class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.batch=DetailedImportBatch(rows);self.single_pending=None
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setLayoutDirection(Qt.RightToLeft);self.resize(1050,620)
        layout=QVBoxLayout(self)
        note=QLabel('تُستورد بيانات كل التلاميذ المعلّمين بـ1 أو نعم في أول عمود في Excel، لمدارس قبل الظهر وبعد الظهر. '
            'يتحقق البرنامج من هوية كل طالب، ثم يعبّئ ويحفظ الأقسام التي فيها بيانات: عناوين السكن والهواتف والبريد الإلكتروني وشهرة الأم وبطاقات التعريف والمستندات. '
            'الخانات الفارغة لا تمسح بيانات الموقع، ولا يلزم مرفق لبطاقات التعريف والمستندات. '
            'لتعبئة قسم واحد، اختر الطالب من الجدول والقسم من القائمة واضغط تعبئة وحفظ القسم المحدد. '
            'استيراد الداتا المفصّلة مع المراجعة أو بدونها يعمل على كل الصفوف المعروضة؛ الإرسال بعد تأكيد حفظ الأقسام. '
            'إذا تعثّرت التعبئة أو الحفظ، تتوقف العملية عند الطالب لمراجعته قبل المتابعة. احفظ أي مسودة مفتوحة في المتصفح قبل البدء.')
        note.setWordWrap(True);layout.addWidget(note)
        from manual_sections import IMPORT_SECTIONS,section_summary
        self.manual_mode=all('manual' in r for r in rows)
        headings=(['صف Excel','الطالب']+list(IMPORT_SECTIONS) if self.manual_mode else
                  ['صف Excel','الطالب','شهرة الأم','البلد','العنوان','الهاتف','نوع المستند','رقم الوثيقة','تاريخ الانتهاء'])
        headings.append('نتيجة الاستيراد')
        self.result_column=len(headings)-1
        self.table=QTableWidget(len(rows),len(headings))
        self.table.setHorizontalHeaderLabels(headings)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[str(row['excel_row']),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                   str(row.get('mother_surname','')),address.get('البلد',''),
                   ' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            card=row.get('identity_card',{})
            texts.extend(str(card.get(k,'') or '') for k in ('type','number','expiry'))
            if self.manual_mode:texts=texts[:2]+[section_summary(row,title) for title in IMPORT_SECTIONS]
            texts.append('بانتظار الاستيراد')
            for j,text in enumerate(texts):
                item=QTableWidgetItem(text);item.setToolTip(text);self.table.setItem(i,j,item)
        self.table.resizeColumnsToContents();layout.addWidget(self.table)
        instruction='اختر طالباً وقسماً للتعبئة والحفظ، أو أحد خياري الاستيراد المجمع.' if self.manual_mode else 'اختر أحد خياري الاستيراد أدناه.'
        self.status=QLabel(f'جاهز لاستيراد {len(rows)} طالباً من Excel. '+instruction)
        self.status.setWordWrap(True);layout.addWidget(self.status)
        self.buttons=[]
        if self.manual_mode:
            section_note=QLabel('تعبئة قسم واحد: اختر الطالب من الجدول ثم القسم من القائمة. حالة التسجيل للقراءة؛ الإرسال له زر مستقل أو خيار الاستيراد مع المراجعة.')
            section_note.setWordWrap(True);layout.addWidget(section_note)
            self.manual_sections=QComboBox()
            for title in IMPORT_SECTIONS:self.manual_sections.addItem(title,'manual_save:'+title)
            layout.addWidget(self.manual_sections)
            self.manual_save_button=QPushButton('تعبئة وحفظ القسم المحدد')
            self.manual_save_button.clicked.connect(self.start_section)
            layout.addWidget(self.manual_save_button)
            self.buttons.extend([self.manual_sections,self.manual_save_button])
            self.manual_sections.currentIndexChanged.connect(self.section_changed)
            self.review_button=QPushButton('إرسال الطالب المحدد للمراجعة')
            self.review_button.clicked.connect(lambda:self.start_selected('review_send'))
            layout.addWidget(self.review_button);self.buttons.append(self.review_button)
        self.import_review_button=QPushButton('استيراد الداتا المفصّلة مع إرسال الطالب للمراجعة')
        self.import_review_button.clicked.connect(lambda:self.start_batch(True))
        self.import_button=QPushButton('استيراد الداتا المفصّلة بدون إرسال الطالب للمراجعة')
        self.import_button.clicked.connect(lambda:self.start_batch(False))
        self.buttons.extend([self.import_review_button,self.import_button])
        for button in (self.import_review_button,self.import_button):layout.addWidget(button)
        self.stop_button=QPushButton('إيقاف بعد الطالب الحالي')
        self.stop_button.clicked.connect(self.stop_batch);self.stop_button.hide();layout.addWidget(self.stop_button)
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);layout.addWidget(self.close_button)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        self.finished.connect(self.detach)
        if rows:self.table.setCurrentCell(0,0)
        self.section_changed()

    def section_changed(self,*args):
        if self.manual_mode and not self.batch.active and not self.single_pending:
            self.manual_save_button.setEnabled(self.manual_sections.currentData()!='manual_save:حالة التسجيل')

    def start_section(self):
        if self.manual_mode:self.start_selected(self.manual_sections.currentData())

    def start_selected(self,section):
        if self.single_pending or self.batch.active or self.batch.pending:return
        index=self.table.currentRow()
        if index<0 or not self.manual_mode:return
        if section=='manual_save:حالة التسجيل':return
        request=uuid.uuid4().hex
        self.single_pending=(request,index)
        self.set_running(True)
        action='إرسال الطالب المحدد للمراجعة' if section=='review_send' else 'تعبئة وحفظ '+self.manual_sections.currentText()
        self.status.setText(f'جارٍ {action} — صف Excel {self.rows[index]["excel_row"]}…')
        if not self.controller.fill_details(self.rows[index],section,request):
            self.result(request,'detail_account','')

    def start_batch(self,with_review):
        if self.single_pending or not self.batch.start(with_review):return
        self.set_running(self.batch.active)
        if self.batch.active:self.dispatch_next()
        else:self.status.setText(f'سبق إنجاز كل الصفوف لهذا الخيار في هذه النافذة: {self.batch.done}/{len(self.rows)}.')

    def set_running(self,running):
        for button in self.buttons+[self.close_button]:button.setEnabled(not running)
        self.table.setEnabled(not running)
        self.stop_button.setVisible(running and self.batch.active);self.stop_button.setEnabled(running and self.batch.active)
        if not running:self.section_changed()

    def row_result(self,index,text):
        item=QTableWidgetItem(text);item.setToolTip(text)
        self.table.setItem(index,self.result_column,item)

    def dispatch_next(self):
        if not self.batch.active:return
        request=self.batch.request()
        if request is None:return
        row,mode,request_id=request
        self.table.setCurrentCell(self.batch.index,0)
        self.row_result(self.batch.index,'جارٍ الاستيراد والحفظ…')
        action='مع الإرسال للمراجعة' if mode=='details_import_review' else 'بدون إرسال للمراجعة'
        self.status.setText(f'جارٍ استيراد الطالب {self.batch.index+1}/{len(self.rows)} — صف Excel {row["excel_row"]} — {action}…')
        if not self.controller.fill_details(row,mode,request_id):
            self.result(request_id,'detail_account','')

    def stop_batch(self):
        self.batch.stop_after_current();self.stop_button.setEnabled(False)
        self.status.setText('سيكتمل الطالب الحالي حسب الخيار المختار ثم تتوقف العملية.')
        if not self.batch.pending:
            self.set_running(False);self.status.setText(f'توقفت العملية حسب طلبك. اكتمل {self.batch.done}/{len(self.rows)}.')

    def result(self,request,event,field):
        if self.single_pending and request==self.single_pending[0]:
            index=self.single_pending[1];self.single_pending=None
            self.set_running(False)
            text=self.result_text(event,field)
            if event=='detail_no_data':text='القسم المحدد فارغ في Excel؛ لم تُضف بيانات ولم يُحفظ.'
            self.row_result(index,text);self.status.setText(text)
            return
        index=self.batch.index
        if not self.batch.result(request,event,field):return
        text=self.result_text(event,field)
        self.row_result(index,text)
        if self.batch.active:
            QTimer.singleShot(0,self.dispatch_next)
        else:
            self.set_running(False)
            prefix=f'اكتمل {self.batch.done}/{len(self.rows)}. '
            if self.batch.stopping:prefix+='توقفت العملية حسب طلبك. '
            self.status.setText(prefix+text+(' يمكنك المتابعة بنفس الخيار؛ تُتخطّى الصفوف التي نجحت في هذه النافذة.' if self.batch.index<len(self.rows) else ''))

    def result_text(self,event,field):
        text={
            'detail_import_saved':'تم استيراد الداتا المفصّلة وحفظها بدون إرسال للمراجعة.',
            'detail_import_review_sent':'تم استيراد الداتا المفصّلة وحفظها وإرسال الطالب للمراجعة.',
            'detail_import_review_already':'حُفظت الداتا المفصّلة؛ الطالب مقدّم للمراجعة مسبقاً.',

            'detail_save_blocked':'زر الحفظ ما زال معطلاً. راجع الحقول المطلوبة في القسم؛ لم يُضغط الحفظ.',
            'detail_no_data':'لا توجد بيانات تفصيلية قابلة للاستيراد في هذا الصف؛ لم يُرسل الطالب للمراجعة.',
            'detail_review_sent':'تم الإرسال للمراجعة، وتأكد ظهور «مقدّم للمراجعة» في الموقع.',
            'detail_review_already':'الطالب مقدّم للمراجعة بالفعل؛ لم يُرسل مرة ثانية.',
            'detail_card_input':'اختر نوع المستند من أعمدة بطاقة التعريف في Excel، وأكمل رقم الوثيقة (أو رقم السجل السابق). تاريخ الانتهاء اختياري ويجب أن يكون تاريخاً صالحاً عند إدخاله.',
            'detail_card_disabled':'زر حفظ بطاقة التعريف ما زال معطلاً في الموقع. راجع الحقول أو رسالة التحقق الظاهرة؛ لم يتم الضغط على الحفظ.',
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_saved':'حُفظ القسم المحدد بنجاح.',
            'detail_all_saved':'حُفظت الأقسام المتاحة من ملف Excel بالتتابع بنجاح.',
            'detail_all_partial':'اكتملت الأقسام التي أمكن تعبئتها. بعض الأقسام موجودة سلفاً أو ناقصة في Excel وتُخطّيت دون استبدالها. راجع عمود شهرة الأم ونتيجة الموقع.',
            'detail_mother_missing':'شهرة الأم فارغة في صف Excel المحدد. عبّئ عمود «شهرة الأم (للمفصّل)» واحفظ الملف ثم أعد استيراده.',
            'detail_mother_field':'شهرة الأم وصلت من Excel، لكن لم أستطع تحديد خانة الشهرة وحدها داخل «الأقارب #2» الخاصة بالأم. ابعث HTML لهذا القسم مع عنوانه والخانة لضبطه.',
            'detail_save_unknown':'تم الضغط على حفظ القسم، لكن لم يصل تأكيد نجاح. راجع القسم المفتوح وما سبقه قبل إعادة المحاولة.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على سجل واحد مطابق للاسم الكامل وتاريخ الولادة في إدارة الطلاب. لم يُدخل عنوان.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'تعذّر الرجوع إلى إدارة الطلاب أو جرد سجلاتها. افتح الإدارة وتأكد أن كل المرشحات «جميع» ودون بحث، ثم أعد المحاولة.',
            'detail_existing':'توجد بيانات مختلفة في الموقع أو أكثر من سجل. توقّف الاستيراد عند الطالب؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار أو مربع التأكيد بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_input':'أكمل بيانات القسم المختار في Excel: العنوان أو الهاتف أو شهرة الأم، ثم احفظ الملف وأعد استرداده.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.')
        from manual_sections import HEADERS
        if field in HEADERS:text+='\nالخانة: '+field
        return text

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.single_pending=None;self.batch.disconnect();self.set_running(False)
            for button in self.buttons:button.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.batch.rows=[];self.table.clearContents()

    def reject(self):
        if self.single_pending or self.batch.active or self.batch.pending:return
        super().reject()
