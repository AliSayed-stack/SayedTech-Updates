import unittest
try:
    from PySide6.QtWidgets import QApplication,QPushButton
    from detailed_dialog import DetailedImportDialog
    QT=True
except ImportError:
    QT=False


class Signal:
    def __init__(self):self.slots=[]
    def connect(self,slot):self.slots.append(slot)
    def disconnect(self,slot):self.slots.remove(slot)
    def emit(self,*args):
        for slot in list(self.slots):slot(*args)


class Controller:
    def __init__(self):self.student_result=Signal();self.event=Signal();self.requests=[]
    def fill_details(self,*args):self.requests.append(args);return True


@unittest.skipUnless(QT,'Qt is not installed in this Python environment')
class BatchDialogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])

    def setUp(self):
        self.controller=Controller()
        rows=[{'excel_row':i,'values':{'field-firstName':'اسم اختبار','field-middleName':'أب اختبار','field-lastName':'شهرة اختبار'},
               'address':{},'phone':'03123456','manual':{'الهواتف / رقم الهاتف':'03123456'}} for i in (2,8)]
        self.dialog=DetailedImportDialog(rows,self.controller,None)

    def tearDown(self):
        self.dialog.single_pending=None;self.dialog.batch.disconnect();self.dialog.reject();self.dialog.deleteLater();self.qt.processEvents()

    def result(self,event):
        request=self.controller.requests[-1][2]
        self.controller.student_result.emit(request,event,'');self.qt.processEvents()

    def test_batch_actions_coexist_with_section_save_and_process_all_rows(self):
        titles=[button.text() for button in self.dialog.findChildren(QPushButton)]
        self.assertNotIn('تعبئة القسم المحدد فقط',titles)
        self.assertIn('تعبئة وحفظ القسم المحدد',titles)
        self.assertIn('إرسال الطالب المحدد للمراجعة',titles)
        self.assertEqual(self.dialog.manual_sections.itemText(0),'عناوين السكن')
        self.dialog.import_button.click()
        self.assertEqual(self.controller.requests[0][1],'details_import')
        self.assertEqual(self.controller.requests[0][0]['excel_row'],2)
        self.assertFalse(self.dialog.import_review_button.isEnabled())
        self.result('detail_import_saved')
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],8)
        self.result('detail_import_saved')
        self.assertTrue(self.dialog.import_review_button.isEnabled())
        self.assertIn('2/2',self.dialog.status.text())

    def test_selected_section_saves_only_selected_row_and_excludes_batch_during_request(self):
        self.dialog.table.setCurrentCell(1,0)
        self.dialog.manual_sections.setCurrentIndex(1)
        self.dialog.manual_save_button.click()
        row,mode,request=self.controller.requests[0]
        self.assertEqual(row['excel_row'],8)
        self.assertEqual(mode,'manual_save:الهواتف')
        self.assertFalse(self.dialog.import_button.isEnabled())
        self.dialog.start_batch(True)
        self.assertEqual(len(self.controller.requests),1)
        self.result('detail_saved')
        self.assertEqual(len(self.controller.requests),1)
        self.assertIsNone(self.dialog.single_pending)
        self.assertTrue(self.dialog.import_button.isEnabled())
        self.assertEqual(self.dialog.batch.completed['details_import'],set())
        self.assertIn('حُفظ القسم',self.dialog.status.text())
        self.dialog.manual_sections.setCurrentIndex(self.dialog.manual_sections.count()-1)
        self.assertFalse(self.dialog.manual_save_button.isEnabled())

    def test_separate_review_button_targets_only_selected_student(self):
        self.dialog.table.setCurrentCell(1,0);self.dialog.review_button.click()
        row,mode,request=self.controller.requests[0]
        self.assertEqual(row['excel_row'],8);self.assertEqual(mode,'review_send')
        self.result('detail_review_sent')
        self.assertEqual(len(self.controller.requests),1)
        self.assertEqual(self.dialog.batch.completed['details_import_review'],set())

    def test_review_choice_and_stop_after_current_pupil(self):
        self.dialog.import_review_button.click()
        self.assertEqual(self.controller.requests[0][1],'details_import_review')
        self.dialog.stop_button.click();self.result('detail_import_review_sent')
        self.assertEqual(len(self.controller.requests),1)
        self.assertFalse(self.dialog.batch.active)
        self.dialog.import_review_button.click()
        self.assertEqual(self.controller.requests[-1][0]['excel_row'],8)

    def test_failure_does_not_start_next_and_session_loss_ignores_queued_advance(self):
        self.dialog.import_button.click();self.result('detail_save_unknown')
        self.assertEqual(len(self.controller.requests),1)
        self.assertTrue(self.dialog.import_button.isEnabled())
        self.dialog.import_button.click()
        request=self.controller.requests[-1][2]
        self.controller.student_result.emit(request,'detail_import_saved','')
        self.controller.event.emit('disconnected')
        self.qt.processEvents()
        self.assertEqual(len(self.controller.requests),2)
        self.assertIn('انتهت جلسة',self.dialog.status.text())


if __name__=='__main__':unittest.main()
