# Sayed tech development instructions

Read `WORKSPACE_STATE.md` and `DEVELOPMENT.md` before changing the app.

- Preserve the Arabic desktop workflow and both school shifts.
- Make focused changes from the current source baseline and retain compatibility with previous exported Excel files.
- Manual import binds headers by name. Selection is the first exported column; mother surname follows the Arabic mother name. The main export has 56 columns.
- Keep runtime Excel handling in the existing ZIP/XML code. `openpyxl` and `lxml` are test dependencies.
- Preserve worksheet/table references, validations, named ranges and namespaces. Invalidate calculation-chain metadata after relocating formula cells.
- Do not use React IDs as stable selectors. Scope controls and buttons to their section and use labels or verified form structure.
- Automatic detail import must re-enter the verified student after each confirmed save and verify identity again through fill_details before the next section. Reuse the verified URL and current system UID; never reload an unconfirmed draft or scan the whole roster for each section.
- Save-success matching is shared as detail_dom.SAVE_SUCCESS_TEXT. Current SIMS common.saved is «تم الحفظ بنجاح»; the legacy «تم حفظ…بنجاح» is also supported. Do not infer failure in the next section from a previous save-acknowledgement error. Avoid JavaScript word boundaries on Arabic; verify regex parity with Node.
- Simple student Excel date text accepts MM/DD/YYYY (month first), ISO and numeric Excel dates; normalize internally to ISO. Source registration-date slash values use month-first precedence; do not silently reinterpret ambiguous MM/DD as DD/MM. Document manual_date has its own existing day-first convention.
- Local phone forms can omit the country-code select. Retain this behavior and support for the older country-select form.
- Manual ID/document import does not require an attachment; keep unrelated legacy features intact.
- Never operate on the termination checkbox. Review submission requires an explicit user action: either the standalone selected-student review button, or import-with-review after all supplied sections confirm saving. Section save and no-review import must never send. Keep the section selector and selected-section save controls; remove only fill-without-save.
- Never commit student records, credentials, profiles, scan checkpoints or school-session screenshots. Use synthetic test fixtures.
- Keep `core.APP_VERSION`, ZIP filename and release tag consistent. Update the handoff after material changes.
- Run appropriate regression tests. Do not claim Windows or live SIMS verification from offline mocks.

The archive root is `SayedTech_Stage1`. The existing updater consumes `SayedTech_Stage1-X.Y.zip`.
