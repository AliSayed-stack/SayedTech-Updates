# Development and verification

## Runtime and setup

Python desktop app targeting Windows 10/11 x64, PySide6 and Playwright using installed Chrome/Edge. Application dependencies are pinned in `requirements.txt`. Use Python 3.12 and the included Windows setup/start scripts.

Offline Excel/HTML regression tests additionally use `requirements-dev.txt`:

```sh
python -m pip install -r requirements-dev.txt
```

Node.js is required by the production JavaScript extraction tests. Their structural DOM adapter is not a live browser.

## Tests

Run from the project directory:

```sh
python -m unittest discover -p "test_*.py" -q
```

Focused manual import regressions:

```sh
python -m unittest test_detailed_batch test_manual_dynamic_forms test_manual_site_bindings test_manual_sections test_manual_auto_save test_manual_save test_manual_address test_detailed_import -q
```

Excel layout and prior-file upgrades:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_detail_dom -q
```

Qt tests skip when PySide6 is unavailable. On a headless system with Qt installed, set `QT_QPA_PLATFORM=offscreen`. Test fixtures contain synthetic values.

## Modules

| Area | Files |
| --- | --- |
| Manual schema, Excel reading and field filling | `manual_sections.py` |
| Identity guards and section routing | `detailed_import.py` |
| Batch detail import UI and queue | `detailed_dialog.py`, `detailed_batch.py` |
| Save/confirm and separate review submission | `manual_save.py` |
| Extraction, snapshots and checkpoints | `student_scan.py`, `detail_dom.py`, `student_checkpoint.py` |
| Column relocation and native Excel lists | `scan_workbook_layout.py`, `scan_dropdowns.py` |
| Browser process event protocol | `login_worker.py`, `login_controller.py` |
| Windows build and update manifest | `build_windows.py`, `publish_update.py` |

## Source packaging

```sh
python tools/package_source.py
```

The ZIP is created beside the project folder using an explicit source allowlist. The script reads `core.APP_VERSION`; it does not change it. The ZIP retains the `SayedTech_Stage1/` root required by the updater.

GitHub's current Windows build workflow lives in the update repository, as documented in `UPDATE_GUIDE_AR.md`. This cleanup does not replace that workflow.

## Verification limits

Local tests cover ZIP/XML structure, supplied/adapted HTML bindings, rendering delays, identity guards and save routing using offline adapters. Passing them does not establish a native Excel opening, a live SIMS session or a compiled Windows installer. Verify the Windows build in GitHub Actions.
