"""Offline account display-name transition, same-session binding and rejection."""
import json
import shutil
import subprocess
import threading
import unittest
from unittest.mock import patch
from account_session import AccountSession,PROFILE_SCRIPT,caption
from login_flow import LoginFlow
from student_scan import StudentBrowser,ScanError,collect_students,MANAGEMENT
from test_scan import Page,Node,Clock


class ProfilePage(Page):
    def __init__(self,total=3,account='test@te.mehe.school'):
        super().__init__(total,account=account)
        self.email_visible=True
        self.profile=account+' مدير النظام'
    def is_closed(self):return False
    def get_by_text(self,text,**kwargs):
        if text=='الطلاب':return Node(self,'students')
        if hasattr(text,'search') and text.search(self.account):
            return Node(self,'account') if self.email_visible else type('Empty',(),{'all':lambda s:[]})()
        return super().get_by_text(text,**kwargs)
    def evaluate(self,script):
        if script==PROFILE_SCRIPT:return self.profile
        return super().evaluate(script)


class AccountSessionTests(unittest.TestCase):
    def login(self,page):
        self.now=[0]
        flow=LoginFlow('test@te.mehe.school','TEST_ONLY',lambda *_:None,clock=lambda:self.now[0])
        flow.tick([page])
        self.assertTrue(flow.connected)
        self.assertIsNone(flow._password)
        return flow

    def test_email_to_display_name_and_full_scan_in_same_verified_page(self):
        page=ProfilePage(3)
        flow=self.login(page)
        self.assertIsNone(flow.account_session.marker)
        page.email_visible=False;page.profile='school-test school-test مدير النظام'
        self.now[0]=1;flow.tick([page])
        self.assertTrue(flow.account_session.allows(page,'test@te.mehe.school'))
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0,account_session=flow.account_session)
        self.assertEqual(len(data['records']),3)
        self.assertFalse(any(a[0] in {'save','fill'} for a in page.actions))

    def test_display_name_alone_cannot_authenticate_or_reuse_another_page(self):
        page=ProfilePage();page.email_visible=False;page.profile='school-test مدير النظام'
        flow=LoginFlow('test@te.mehe.school','TEST_ONLY',lambda *_:None)
        flow.tick([page]);self.assertFalse(flow.connected);self.assertIsNone(flow.account_session)
        page.email_visible=True;flow=self.login(page)
        page.email_visible=False;flow.tick([page])
        other=ProfilePage();other.email_visible=False;other.profile=page.profile
        self.assertFalse(flow.account_session.allows(other,'test@te.mehe.school'))
        self.assertFalse(flow.account_session.allows(page,'wrong@te.mehe.school'))
        with self.assertRaises(ScanError):StudentBrowser(other,'test@te.mehe.school',threading.Event(),flow.account_session).guard()

    def test_profile_change_and_login_redirect_revoke_continuity(self):
        page=ProfilePage();page.profile='school-A مدير النظام';flow=self.login(page)
        page.email_visible=False;page.profile='school-B مدير النظام'
        self.assertFalse(flow.account_session.allows(page,'test@te.mehe.school'))
        self.assertTrue(flow.account_session.revoked)
        page.profile='school-A مدير النظام'
        self.assertFalse(flow.account_session.allows(page,'test@te.mehe.school'))
        page=ProfilePage();page.profile='school-A مدير النظام';flow=self.login(page)
        page.url='https://new-sims.mehe.gov.lb/login';flow.tick([page])
        page.url='https://new-sims.mehe.gov.lb'+MANAGEMENT;page.email_visible=False
        self.assertFalse(flow.account_session.allows(page,'test@te.mehe.school'))

    def test_missing_marker_and_expired_bootstrap_do_not_bind_arbitrary_profile(self):
        page=ProfilePage();flow=self.login(page)
        self.now[0]=31;page.email_visible=False;page.profile='school-A مدير النظام'
        flow.tick([page])
        self.assertIsNone(flow.account_session.marker)
        self.assertFalse(flow.account_session.allows(page,'test@te.mehe.school'))
        self.assertEqual(flow.account_session.reason,'account_profile_missing')
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            StudentBrowser(page,'test@te.mehe.school',threading.Event(),flow.account_session).guard()
        self.assertEqual(cm.exception.reason,'account_profile_missing')

    def test_temporary_card_absence_waits_for_original_caption(self):
        page=ProfilePage();page.profile='school-A مدير النظام';flow=self.login(page)
        page.email_visible=False;page.profile=None
        page.wait_for_timeout=lambda *_:setattr(page,'profile','school-A مدير النظام')
        with patch('student_scan.time.monotonic',Clock()):
            StudentBrowser(page,'test@te.mehe.school',threading.Event(),flow.account_session).guard()
        self.assertFalse(flow.account_session.revoked)

    def test_conflicting_profile_email_cannot_bind_after_verified_login(self):
        page=ProfilePage();flow=self.login(page)
        page.email_visible=False;page.profile='other@te.mehe.school school-A مدير النظام'
        flow.tick([page]);self.assertTrue(flow.account_session.revoked)
        self.assertFalse(flow.account_session.allows(page,'test@te.mehe.school'))

    def test_email_adjacent_to_arabic_role_is_not_a_different_address(self):
        page=ProfilePage();page.profile='test@te.mehe.schoolمدير النظام'
        marker,emails=caption(page)
        self.assertIsNone(marker);self.assertEqual(emails,['test@te.mehe.school'])
        flow=self.login(page)
        page.email_visible=False;page.profile='school-A مدير النظام'
        self.now[0]=1;flow.tick([page])
        self.assertTrue(flow.account_session.allows(page,'test@te.mehe.school'))

    def test_profile_reader_javascript_only_returns_narrow_account_caption(self):
        node=shutil.which('node')
        if node is None:self.skipTest('Node is unavailable')
        harness=r'''
const fs=require('fs');const script=JSON.parse(fs.readFileSync(0,'utf8'));
const card={textContent:'school-test school-test مدير النظام',querySelector:()=>null,parentElement:null};
const role={textContent:'مدير النظام',getClientRects:()=>[{}],children:[],parentElement:card};
global.document={querySelectorAll:()=>[role]};
process.stdout.write(JSON.stringify(eval('('+script+')')()));
'''
        r=subprocess.run([node,'-e',harness],input=json.dumps(PROFILE_SCRIPT),text=True,capture_output=True,check=True)
        self.assertEqual(json.loads(r.stdout),'school-test school-test مدير النظام')
        page=ProfilePage();page.profile='school-test school-test مدير النظام'
        marker,emails=caption(page)
        self.assertIsInstance(marker,bytes);self.assertEqual(len(marker),32);self.assertEqual(emails,[])


if __name__=='__main__':unittest.main()
