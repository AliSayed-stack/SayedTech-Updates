"""Exercise the shared school features with both allowed account domains offline."""
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

from login_flow import LoginFlow, SHIFT_DOMAINS, validate_credentials
from student_scan import collect_students, export_students, grade_rank
from student_fill import fill_student
from student_excel import NS
from address_catalog import collect_catalog
from test_login import Page as LoginPage
from test_account_session import ProfilePage
from test_scan import Clock
from test_students import Page as DraftPage, record
from test_catalog import Page as CatalogPage


class ShiftParityTests(unittest.TestCase):
    def test_login_name_binding_grade_scan_and_excel_for_both_shifts(self):
        for shift,domain in SHIFT_DOMAINS.items():
            with self.subTest(shift=shift):
                username=f'test@{domain}'
                validate_credentials(username,'TEST_ONLY','edge',shift)
                events=[];now=[0]
                flow=LoginFlow(username,'TEST_ONLY',events.append,clock=lambda:now[0])
                email=LoginPage('https://login.microsoftonline.com/login','email',username)
                password=LoginPage('https://login.microsoftonline.com/login','password',username)
                flow.tick([email]);flow.tick([password])
                self.assertEqual(email.actions[0],('fill','email',username))
                self.assertIsNone(flow._password)
                page=ProfilePage(6,account=username)
                # Missing and repeated IDs retain separate records in either shift.
                page.records[0]['uid']='—'
                page.records[1]['uid']=page.records[2]['uid']
                flow.tick([page]);self.assertTrue(flow.connected)
                page.profile='TEST SCHOOL مدير النظام';page.email_visible=False
                now[0]=1;flow.tick([page])
                self.assertTrue(flow.account_session.allows(page,username))
                with patch('student_scan.time.monotonic',Clock()):
                    data=collect_students(page,username,threading.Event(),0,account_session=flow.account_session)
                self.assertEqual(len(data['records']),6)
                self.assertEqual(sum(not r['values']['field-existingUniqueId'] for r in data['records']),1)
                ranks=[grade_rank(r['item']['grade']) for r in data['records']]
                self.assertEqual(ranks,sorted(ranks))
                self.assertTrue(all(a[1] for a in page.actions if a[0]=='opened'))
                with tempfile.TemporaryDirectory() as tmp:
                    path=Path(tmp)/'students.xlsx'
                    export_students(data,path,threading.Event())
                    with zipfile.ZipFile(path) as z:
                        book=ET.fromstring(z.read('xl/workbook.xml'))
                        names={s.get('name') for s in book.findall('m:sheets/m:sheet',NS)}
                        self.assertTrue({'الطلاب','قوائم العناوين','حالة السحب','الحقول المقروءة'}<=names)
                        sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                        self.assertEqual(len(sheet.findall('m:dataValidations/m:dataValidation',NS)),13)
                        self.assertIsNone(z.testzip())

    def test_original_fields_fill_from_current_school_choices_for_both_shifts(self):
        for shift,domain in SHIFT_DOMAINS.items():
            with self.subTest(shift=shift):
                username=f'test@{domain}';page=DraftPage(account=username)
                fill_student(page,record(),username,threading.Event())
                self.assertEqual(page.values['field-existingUniqueId'],'000123')
                self.assertEqual(page.values['field-enrollment-promoted-class'],'live_secondary_3')
                self.assertEqual(page.values['field-enrollment-teaching-language'],'live_en')
                self.assertEqual(page.values['field-enrollment-grade-section'],'school_section_id')
                # Selection is allowed, but draft filling must never save.
                self.assertFalse(any(a[0]=='click' and a[1] in ('save','confirm') for a in page.actions))

    def test_address_parent_links_and_restoration_for_both_shifts(self):
        for shift,domain in SHIFT_DOMAINS.items():
            with self.subTest(shift=shift):
                username=f'test@{domain}';page=CatalogPage(account=username)
                original=dict(page.selected)
                with patch('address_catalog.time.monotonic',side_effect=lambda:page.clock):
                    data=collect_catalog(page,username,threading.Event(),lambda *_:None)
                self.assertEqual(page.selected,original)
                self.assertEqual(len(data['governorates']),2)
                self.assertEqual([a['id'] for a in data['governorates'][1]['districts'][0]['areas']],['a4'])
                self.assertEqual({key for key,_ in page.actions},{'governorate','district'})


if __name__=='__main__':unittest.main()
