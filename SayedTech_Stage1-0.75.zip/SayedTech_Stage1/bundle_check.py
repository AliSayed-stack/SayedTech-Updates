"""Offline smoke checks for the Windows distribution, never accessing school data."""
def configure_browser():
    # Browser binaries are supplied by the user's Chrome/Edge installation.
    return None


def check_browser():
    configure_browser()
    from playwright.sync_api import sync_playwright
    # Starting a real user browser is intentionally excluded from build smoke
    # tests, so packaging never opens a user's private browser profile.
    with sync_playwright():pass

