import uuid
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView

class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.pending=None
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setLayoutDirection(Qt.RightToLeft);self.resize(1050,620)
        layout=QVBoxLayout(self)
        note=QLabel('اختر التلميذ هنا واضغط استرداد عنوانه. من إدارة الطلاب يبحث البرنامج عن اسمه الكامل '
            'وتاريخ ولادته، ويفتح سجله ثم يعبّئ العنوان. إذا كنت داخل ملف تلميذ، يجب أن يكون هو نفسه. '
            'بعد التعبئة راجع العنوان واحفظ القسم من الموقع. لا تُستبدل السجلات الموجودة ولا يُرسل للمراجعة.')
        note.setWordWrap(True);layout.addWidget(note)
        self.table=QTableWidget(len(rows),5)
        self.table.setHorizontalHeaderLabels(['صف Excel','الطالب','البلد','العنوان','الهاتف'])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[str(row['excel_row']),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                address.get('البلد',''),' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            for j,text in enumerate(texts):self.table.setItem(i,j,QTableWidgetItem(text))
        self.table.resizeColumnsToContents();layout.addWidget(self.table)
        self.status=QLabel('البلد مطلوب للعنوان. رقم الهاتف يجب أن يكون نصاً من 8 أرقام. اختر القسم لتعبئته.');self.status.setWordWrap(True);layout.addWidget(self.status)
        bar=QHBoxLayout();self.buttons=[]
        for title,section in [('استرداد عنوان الطالب المحدد','address'),('استرداد هاتف الطالب المحدد','phone')]:
            b=QPushButton(title);b.clicked.connect(lambda checked=False,s=section:self.start(s));bar.addWidget(b);self.buttons.append(b)
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);bar.addWidget(self.close_button);layout.addLayout(bar)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        self.finished.connect(self.detach);self.table.setCurrentCell(0,0)

    def start(self,section):
        i=self.table.currentRow()
        if i<0 or self.pending:return
        request=uuid.uuid4().hex
        if self.controller.fill_details(self.rows[i],section,request):
            self.pending=request
            for b in self.buttons+[self.close_button]:b.setEnabled(False)
            self.table.setEnabled(False);self.status.setText('جارٍ التحقق من التلميذ ثم تعبئة القسم…')
        else:self.status.setText('جلسة المتصفح غير متاحة. أعد تسجيل الدخول.')

    def result(self,request,event,field):
        if request!=self.pending:return
        self.pending=None;self.table.setEnabled(True)
        for b in self.buttons+[self.close_button]:b.setEnabled(True)
        self.status.setText({
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على سجل واحد مطابق للاسم الكامل وتاريخ الولادة في إدارة الطلاب. لم يُدخل عنوان.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'افتح إدارة الطلاب مع كل المرشحات على «جميع» ودون بحث، ثم أعد المحاولة. لم يُدخل عنوان.',
            'detail_existing':'القسم يحتوي سجلاً أو مسودة؛ لم يُستبدل. راجع الموجود في الموقع.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجعها دون حفظ بيانات ناقصة.',
            'detail_input':'أكمل البلد والمحافظة والقضاء والمنطقة للعنوان، أو راجع الهاتف كنص من 8 أرقام. احفظ Excel وأعد استرداده.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.'))

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.pending=None;self.close_button.setEnabled(True)
            for b in self.buttons:b.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.table.clearContents()

    def reject(self):
        if self.pending:return
        super().reject()
