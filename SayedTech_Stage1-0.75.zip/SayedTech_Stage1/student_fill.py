"""User-run draft filling based on supplied DOM; never clicks the save button."""
import re
import time
import unicodedata
from datetime import datetime
from urllib.parse import urlsplit
from login_flow import exact_https_host, SIMS_HOST, visible
from student_excel import FIELDS, validate_record, shift_for_username

MANAGEMENT = '/dashboard/students/management'
NEW_STUDENT = MANAGEMENT + '/new'

class StudentFillError(Exception):
    def __init__(self, code, field=''):
        self.code, self.field = code, field


def normalized_name(value):
    # Whitespace and Unicode composition only; never fuzzy-match Arabic names.
    return ' '.join(unicodedata.normalize('NFC', value).split())


def search_birth_date(value):
    """Read the search-card date without guessing ambiguous day/month order."""
    for fmt in ('%Y-%m-%d', '%d-%m-%Y'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def ui_step(code, action, field=''):
    try:
        return action()
    except StudentFillError:
        raise
    except Exception:
        # Keep diagnoses specific without exposing student data or raw traces.
        raise StudentFillError(code, field) from None


SEARCH_RESULTS = r'''root => [...root.querySelectorAll('ul > li > button')]
 .map((b,index)=>({index, visible:!!b.getClientRects().length,
   enabled:!b.disabled, text:b.innerText,
   name:b.querySelector('span.block.font-bold')?.textContent || '',
   detail:b.querySelector('span.block.text-xs')?.textContent || ''}))'''


def select_existing_student(page, data, guard):
    """Select one imported record using only the supplied existing-student UI."""
    guard()
    path = urlsplit(page.url).path.rstrip('/')
    if path == '/dashboard/analytics':
        page.goto('https://' + SIMS_HOST + MANAGEMENT, wait_until='domcontentloaded', timeout=20000)
        guard()
        path = urlsplit(page.url).path.rstrip('/')
    if path != MANAGEMENT:
        raise StudentFillError('student_open_management')
    modal = page.locator('.print-area-modal').filter(
        has=page.get_by_role('heading', name='طالب موجود', exact=True))
    if not modal.count():
        ui_step('student_create_unavailable', lambda:
            page.get_by_role('button', name='إنشاء', exact=True).click(timeout=15000))
        guard()
        ui_step('student_existing_unavailable', lambda:
            page.get_by_role('button', name=re.compile(r'^طالب موجود(?:\s|$)')).click(timeout=10000))
    ui_step('student_search_unavailable',lambda: modal.wait_for(state='visible', timeout=10000))
    guard()
    if modal.count() != 1: raise StudentFillError('student_search_changed')
    query = normalized_name(' '.join(data[k] for k in
        ('field-firstName', 'field-middleName', 'field-lastName')))
    search = modal.get_by_label('البحث بالرقم الموحد أو الاسم', exact=True)
    ui_step('student_search_unavailable',lambda: search.fill(query, timeout=5000))
    started = time.monotonic()
    last = None
    changed = started
    while True:
        guard()
        if search.input_value() != query: raise StudentFillError('student_search_changed')
        rows = ui_step('student_search_changed',lambda: modal.evaluate(SEARCH_RESULTS))
        now = time.monotonic()
        if rows != last:
            last, changed = rows, now
        # Give the debounced search time to replace old results; require a
        # stable list and recheck the selected button immediately before click.
        if rows and now-started >= 1.2 and now-changed >= .8: break
        if now-started >= 15: raise StudentFillError('student_existing_not_found')
        page.wait_for_timeout(100)
    matches = []
    for row in rows:
        if not row['visible'] or not row['enabled']: continue
        if normalized_name(row['name']) != query: continue
        match = re.fullmatch(r'\s*(.*?)\s*·\s*تاريخ الميلاد:\s*(\d{1,4}-\d{1,2}-\d{1,4})\s*', row['detail'])
        if not match or search_birth_date(match.group(2)) != data['field-birthDate']: continue
        unified = match.group(1).strip()
        expected = data.get('field-existingUniqueId', '')
        if expected and unified not in ('', '—', '-') and unified != expected: continue
        matches.append(row)
    if not matches: raise StudentFillError('student_existing_not_found')
    if len(matches) != 1: raise StudentFillError('student_existing_ambiguous')
    guard()
    if modal.evaluate(SEARCH_RESULTS) != rows: raise StudentFillError('student_search_changed')
    chosen = modal.locator('ul > li > button').nth(matches[0]['index'])
    if chosen.inner_text() != matches[0]['text']: raise StudentFillError('student_search_changed')
    ui_step('student_result_unavailable',lambda: chosen.click(timeout=5000))
    ui_step('student_form_unavailable',lambda:
        page.locator('#field-firstName').wait_for(state='visible', timeout=15000))
    guard()
    if urlsplit(page.url).path.rstrip('/') != NEW_STUDENT:
        raise StudentFillError('student_open_management')
    # The route and first input may appear before React finishes populating the
    # imported student's fields. Wait for the *whole identity* to match and
    # remain stable; never overwrite a blank or another student's draft.
    identity = ('field-firstName','field-middleName','field-lastName','field-birthDate')
    deadline = time.monotonic() + 12
    stable_since = None
    last = None
    mismatch = 'field-firstName'
    while True:
        guard()
        if urlsplit(page.url).path.rstrip('/') != NEW_STUDENT:
            raise StudentFillError('student_open_management')
        try:
            current = {key:page.locator('#'+key).input_value() for key in identity}
            identifier = page.locator('#field-existingUniqueId')
            uid = identifier.input_value().strip() if identifier.count() else ''
        except Exception:
            current, uid = {}, ''  # A rerender may temporarily detach inputs.
        expected_uid = data.get('field-existingUniqueId', '')
        mismatch = next((key for key in identity
                         if normalized_name(current.get(key,'')) != normalized_name(data[key])), '')
        if not mismatch and expected_uid and uid != expected_uid:
            mismatch = 'field-existingUniqueId'
        snapshot = (tuple(current.get(key,'') for key in identity),uid)
        now = time.monotonic()
        if not mismatch:
            if snapshot != last: stable_since = now
            if stable_since is not None and now-stable_since >= .35:
                if uid and not expected_uid: data['field-existingUniqueId'] = uid
                break
        else:
            stable_since = None
        last = snapshot
        if now >= deadline: raise StudentFillError('student_existing_mismatch', mismatch)
        page.wait_for_timeout(125)

def select_new_student(page, data, guard):
    """Open only the explicit blank form; never replace another draft."""
    guard()
    path=urlsplit(page.url).path.rstrip('/')
    if path=='/dashboard/analytics':
        ui_step('student_open_management',lambda:page.goto('https://'+SIMS_HOST+MANAGEMENT,wait_until='domcontentloaded',timeout=20000))
        guard();path=urlsplit(page.url).path.rstrip('/')
    if path!=MANAGEMENT:raise StudentFillError('student_open_management')
    ui_step('student_create_unavailable',lambda:page.get_by_role('button',name='إنشاء',exact=True).click(timeout=15000))
    guard()
    ui_step('student_new_unavailable',lambda:page.get_by_role('button',name=re.compile(r'^طالب جديد(?:\s|$)')).click(timeout=10000))
    ui_step('student_form_unavailable',lambda:page.locator('#field-firstName').wait_for(state='visible',timeout=15000))
    guard()
    if urlsplit(page.url).path.rstrip('/')!=NEW_STUDENT:raise StudentFillError('student_open_management')
    identity=('field-firstName','field-middleName','field-lastName','field-birthDate','field-existingUniqueId')
    if any(page.locator('#'+key).count()!=1 or page.locator('#'+key).input_value().strip() for key in identity):
        raise StudentFillError('student_existing_mismatch')

def fill_student(page, record, username, cancelled, account_session=None, entry_kind='طالب موجود'):
    data, errors = validate_record(record, shift_for_username(username))
    if errors: raise StudentFillError('student_invalid')
    def guard():
        if cancelled.is_set(): raise StudentFillError('student_cancelled')
        if not exact_https_host(page.url, SIMS_HOST): raise StudentFillError('student_account_required')
        account=visible(page.get_by_text(re.compile(r'^\s*'+re.escape(username)+r'\s*$',re.I)))
        if account_session is not None and account_session.revoked:raise StudentFillError('student_account_required')
        if account is None and not (account_session is not None and account_session.allows(page,username)):
            raise StudentFillError('student_account_required')
    guard()
    if entry_kind=='طالب موجود':select_existing_student(page, data, guard)
    elif entry_kind=='طالب جديد':
        if data.get('field-existingUniqueId'):raise StudentFillError('student_invalid')
        select_new_student(page,data,guard)
    else:raise StudentFillError('student_invalid')
    data, errors = validate_record(data, shift_for_username(username))
    if errors: raise StudentFillError('student_invalid')

    def choose(f):
        guard()
        selector = page.locator('#' + f['id'])
        wanted = data[f['id']]
        deadline = time.monotonic() + 6
        while True:
            guard()
            if selector.count() and selector.is_visible() and selector.is_enabled():
                options = [(o.get_attribute('value') or '', o.inner_text().strip())
                           for o in selector.locator('option').all() if not o.is_disabled()]
                matches = [value for value,label in options if (label == wanted if wanted else value == '')]
                if len(matches) == 1:
                    guard()
                    selector.select_option(value=matches[0],timeout=3000)
                    return
                if len(matches) > 1: raise StudentFillError('student_options_changed',f['id'])
            if time.monotonic() >= deadline: raise StudentFillError('student_options_changed',f['id'])
            page.wait_for_timeout(100)

    # Dependency order: class, then its language, then its section. Never use
    # school-specific grade values copied from the example school.
    for f in FIELDS:
        if f['dynamic']: choose(f)
    for f in FIELDS:
        if f['dynamic']: continue
        guard()
        locator = page.locator('#' + f['id'])
        if f['id'] == 'field-existingUniqueId':
            if entry_kind=='طالب جديد':
                if locator.count()!=1 or locator.input_value().strip():
                    raise StudentFillError('student_existing_mismatch',f['id'])
                continue
            # This number belongs to the imported SIMS record. The Excel
            # placeholder (or even a matching Excel value) must never write it.
            if locator.count() != 1 or locator.input_value().strip() != data[f['id']]:
                raise StudentFillError('student_existing_mismatch', f['id'])
            continue
        if locator.count() and locator.is_visible() and not locator.is_enabled():
            if f['type'] in ('text','date') and locator.input_value() == data.get(f['id']):
                continue
        if not locator.count() or not locator.is_visible() or not locator.is_enabled():
            if data.get(f['id']) not in ('', False):
                raise StudentFillError('student_options_changed',f['id'])
            continue
        if f['type'] == 'select': choose(f)
        elif f['type'] == 'checkbox': ui_step('student_field_failed',lambda: locator.set_checked(data[f['id']],timeout=3000),f['id'])
        else: ui_step('student_field_failed',lambda: locator.fill(data[f['id']],timeout=3000),f['id'])
    guard()
    # Saving and verification of server acceptance are deliberately separate.
    # A filled draft is not a saved or successfully created student.
    return data
