"""Local scan control: only counts/grade labels return from the browser helper."""
from uuid import uuid4
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QComboBox,QPushButton,QProgressBar,QFileDialog
import core


class StudentScanDialog(QDialog):
    def __init__(self,controller,parent=None):
        super().__init__(parent)
        self.controller=controller
        self.request_id=''
        self.pending=False
        self.available=True
        self.path=''
        self.last_result=''
        self.setWindowTitle(f'Sayed tech {core.APP_VERSION} | سحب بيانات الطلاب')
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(780,700)
        layout=QVBoxLayout(self)
        intro=QLabel('سحب بيانات الطلاب من أصغر صف موجود إلى أعلى صف')
        intro.setWordWrap(True);layout.addWidget(intro)
        instructions=QLabel(
            'ابدأ من لوحة التحليلات أو إدارة الطلاب، وأغلق أي ملف طالب. '
            'اجعل الفلاتر الأربعة على «الجميع» وامسح البحث. لا تغيّر المتصفح أثناء السحب.\n\n'
            'يختار الصفوف من الأصغر للأعلى ويكمل كل صفحاته، ١٠٠ طالب بالصفحة. '
            'التجربة الافتراضية تقرأ أول ١٠ طلاب فقط.\n\n'
            'يحفظ التقدّم بعد كل طالب مكتمل على جهازك بجانب Excel. للاستكمال اختر نفس اسم الملف والنطاق والحساب. '
            'عند التوقف يحاول إخراج Excel منفصل بالجزء المنجز دون استبدال ملفك النهائي.\n\n'
            'هذا حفظ محلي لنتيجة القراءة فقط: لا يضغط «حفظ القسم» أو «إرسال للمراجعة» ولا يغيّر بيانات الطالب. '
            'الأقسام المقفلة أو التي تعرض بطاقات دون حقول تبقى معلّمة «غير مقروءة».\n\n'
            'ملف النتيجة لسجلات موجودة؛ تحديثها من Excel غير مفعّل بعد، ولا يُقبل ضمن إنشاء طلاب جدد.')
        instructions.setWordWrap(True);layout.addWidget(instructions)
        self.scope=QComboBox()
        self.scope.addItem('تجربة: أول ١٠ طلاب من أصغر الصفوف',10)
        self.scope.addItem('كل الطلاب، من أصغر صف للأعلى',0)
        layout.addWidget(self.scope)
        self.status=QLabel('جاهز. اختر نطاق السحب ثم مكان ملف Excel.')
        self.status.setTextFormat(Qt.PlainText);self.status.setWordWrap(True);layout.addWidget(self.status)
        self.progress=QProgressBar();self.progress.setRange(0,1);layout.addWidget(self.progress)
        self.start_button=QPushButton('بدء سحب بيانات الطلاب')
        self.start_button.clicked.connect(self.start);layout.addWidget(self.start_button)
        self.stop_button=QPushButton('إيقاف السحب');self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop);layout.addWidget(self.stop_button)
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);layout.addWidget(self.close_button)
        controller.scan_result.connect(self.result);controller.event.connect(self.session_event)
        self.finished.connect(self.cleanup)

    def set_pending(self,value):
        self.pending=value
        self.start_button.setEnabled(not value and self.available)
        self.scope.setEnabled(not value and self.available)
        self.close_button.setEnabled(not value)
        self.stop_button.setEnabled(value)

    def start(self):
        if self.pending or not self.available:return
        path,_=QFileDialog.getSaveFileName(self,'حفظ بيانات الطلاب والنواقص','SayedTech_Existing_Students.xlsx','Excel (*.xlsx)')
        if not path:return
        if not path.lower().endswith('.xlsx'):path+='.xlsx'
        self.path,self.request_id=path,uuid4().hex
        self.last_result=''
        self.set_pending(True);self.progress.setRange(0,0)
        self.status.setText('جارٍ فتح إدارة الطلاب وجمع القائمة، ١٠٠ طالب بالصفحة…')
        if not self.controller.scan_students(path,self.scope.currentData(),self.request_id):
            self.result(self.request_id,'scan_failed',0,0,{})

    def stop(self):
        if self.pending:
            self.controller.cancel_scan(self.request_id)
            self.stop_button.setEnabled(False)
            self.status.setText('جارٍ إيقاف السحب وحفظ الجزء المنجز؛ لن يُستبدل ملف Excel النهائي السابق.')

    def result(self,request_id,event,first,second,detail=None):
        if request_id!=self.request_id or not self.pending:return
        detail=detail or {}
        if event=='scan_progress':
            if detail.get('stage') in {'prepare','pagination'}:
                self.progress.setRange(0,0)
                self.status.setText('جارٍ التحقق من جدول الطلاب وترقيم الصفحات ثم تحميل ١٠٠ سجل بالصفحة…')
                return
            self.progress.setRange(0,max(1,second));self.progress.setValue(first)
            if detail.get('stage')=='inventory':
                self.status.setText(f'جمع قائمة {detail.get("grade") or "كل الصفوف للتحقق"}: {first} من {second} طالب.')
            elif detail.get('stage')=='resume':
                self.status.setText(f'تم العثور على تقدّم محفوظ لـ {detail.get("resumed",0)} طالب. جارٍ مطابقة الصفوف والاستكمال دون إعادة ملفاتهم.')
            elif detail.get('stage')=='export':
                self.status.setText('انتهت القراءة. جارٍ تجهيز ملف Excel مع تقرير النواقص وحدود القراءة…')
            else:
                self.status.setText(f'الصف: {detail.get("grade", "")} — تم {detail.get("grade_done",0)} من {detail.get("grade_total",0)} في هذا الصف.\nإجمالي السحب: {first} من {second}.')
            return
        self.last_result=event
        self.set_pending(False);self.progress.setRange(0,max(1,second))
        self.progress.setValue(first if event in {'scan_saved','scan_saved_partial','scan_paused','scan_paused_checkpoint'} else 0)
        recovery_path=str(Path(self.path).parent/detail['recovery_file']) if detail.get('recovery_file') else ''
        messages={
            'scan_paused':f'توقّف السحب، وحُفظ تقدّم {first} من أصل {second} طالب.\nExcel للجزء المنجز (غير مكتمل):\n{recovery_path}\nللاستكمال: ارجع لإدارة الطلاب واجعل الفلاتر على الجميع، ثم اختر نفس اسم Excel الأصلي ونفس النطاق والحساب:\n{self.path}\nلم يُستبدل ملف Excel النهائي السابق.',
            'scan_paused_checkpoint':f'توقّف السحب، وتقدّم {first} من أصل {second} طالب محفوظ محلياً. تعذّر إخراج Excel للجزء المنجز، لكن يمكنك الاستكمال باختيار نفس اسم Excel الأصلي والنطاق والحساب:\n{self.path}\nلم يُستبدل ملف Excel النهائي السابق.',
            'scan_saved':f'حُفظت بيانات {first} طالب من أصل {second} في القائمة. {detail.get("missing",0)} طالب لديه خانات مطلوبة ناقصة ضمن الحقول المقروءة.\n{self.path}\nراجع ورقة «حالة السحب»؛ لم يُعدّل أي سجل.',
            'scan_saved_partial':f'حُفظت بيانات {first} طالب من أصل {second} في القائمة، مع أقسام أو خانات لم تُقرأ لدى {detail.get("unread",0)} طالب. {detail.get("missing",0)} طالب لديه نواقص مطلوبة مؤكدة ضمن الحقول المقروءة.\n{self.path}\nراجع «حالة السحب» و«الحقول المقروءة». القراءة غير المكتملة لا تعني اكتمال بيانات الطالب، ولم يُعدّل أي سجل.',
            'scan_prepare':'افتح إدارة الطلاب أو لوحة التحليلات، وأغلق ملف أي طالب. اجعل الصف والفرع واللغة والشعبة على «الجميع» وامسح البحث. تعذّر التعرّف إلى الجدول أو أزراره؛ لم يُحفظ ملف جديد.',
            'scan_changed':'تعذّر تأكيد بيانات الصفحة أثناء السحب، فتوقفت العملية دون حفظ ملف جديد. راجع سبب التوقف إن ظهر أدناه، واترك المتصفح دون تغيير أثناء المحاولة.',
            'scan_account_required':'تعذّر تأكيد الحساب الحالي أو انتهت الجلسة. لم يُحفظ ملف جديد.',
            'scan_unknown_grade':'ظهر اسم صف لا يعرف البرنامج ترتيبه. لم يبدأ قراءة الملفات ولم يُحفظ ملف جديد. أرسل اسم الصف كما يظهر في القائمة لإضافته دون تخمين ترتيبه.',
            'scan_cancelled':'توقف السحب ولم يُحفظ ملف جديد. قد يبقى ملف طالب مفتوحاً في المتصفح؛ ارجع لإدارة الطلاب قبل محاولة جديدة.',
            'scan_empty':'القائمة فارغة أو لم تُقرأ سجلات قابلة للتصدير. لم يُحفظ ملف جديد.',
            'scan_busy':'هناك عملية أخرى قيد التنفيذ. انتظر انتهاءها ثم أعد المحاولة.',
            'scan_failed':'تعذّر السحب أو حفظ Excel. لم يُستبدل ملف سابق. راجع الصفحة ومكان الحفظ وأغلق ملف Excel إن كان مفتوحاً، ثم أعد المحاولة.',
        }
        reasons={
            'cancelled_by_user':'تم الإيقاف بطلبك، مع الاحتفاظ بالتقدّم المنجز.',
            'checkpoint_write':'تعذّر تثبيت التقدّم على القرص. توقّف السحب لحماية ما سبق حفظه؛ افحص المساحة وصلاحيات المجلد.',
            'checkpoint_invalid':'ملف التقدّم غير قابل للقراءة أو غير صالح. بقي كما هو؛ اختر اسماً جديداً لبدء سحب مستقل.',
            'checkpoint_mismatch':'التقدّم المحفوظ لا يطابق الحساب أو نطاق السحب أو قائمة الطلاب الحالية. بقي كما هو؛ اختر اسماً جديداً لسحب مستقل.',
            'tab_timeout':'لم تستقر بيانات أحد تبويبات الطالب خلال المهلة.',
            'controls_changed':'تغيّرت بنية حقول الطالب أثناء القراءة.',
            'unexpected_error':'حدث خطأ أثناء القراءة أو التنقل أو حفظ الملف؛ الصورة وحدها لا تحدد سببه.',
            'grade_filter':'تعذّر اختيار فلتر الصف أو لم تستقر القائمة على طلاب الصف المحدد.',
            'grade_coverage':'لم تتطابق قائمة هذا الصف كاملة مع الجرد الأول. قد يكون هناك فلتر فرع أو لغة أو شعبة يقيّد النتائج، أو تغيّرت القائمة أثناء السحب. أعد باقي الفلاتر إلى «الجميع» وابدأ من جديد.',
            'grade_options':'تعذّرت قراءة قائمة الصفوف أو اختلفت خياراتها أثناء السحب.',
            'table_missing':'لم يظهر جدول الطلاب بعد.',
            'headers_changed':'لم تتطابق الأعمدة الأساسية أو ظهر أكثر من جدول مطابق.',
            'pagination_missing':'لم يظهر سطر «الصفحة… من… سجل إجمالاً» بشكل مميز.',
            'pagination_format':'صيغة سطر عدد الصفحات والسجلات غير معروفة.',
            'filters_active':'في بداية السحب يجب أن تكون فلاتر الصف والفرع ولغة التدريس والشعبة على «الجميع». أثناء السحب يختار البرنامج الصف تلقائياً.',
            'search_active':'خانة البحث ليست فارغة. امسحها ثم أعد المحاولة.',
            'rows_invalid':'بعض صفوف الجدول لم تكتمل أو لم يظهر فيها الرقم الموحد وزر التعديل.',
            'duplicate_record':'فُتح نفس سجل الطالب مرة ثانية أثناء السحب؛ توقفت القراءة لتجنب تكراره.',
            'page_size':'لم يتعرّف إلى قائمة 10/25/50/100 طالب بالصفحة.',
            'loading':'لم تستقر بيانات الجدول خلال مهلة الانتظار.',
            'page_not_changed':'لم يتغير رقم الصفحة ومحتواها كما هو متوقع بعد التنقل.',
            'count_changed':'تغير العدد الإجمالي أثناء التنقل بين الصفحات.',
            'row_count':'لم يتطابق عدد الصفوف وترقيم الصفحات مع حجم ١٠٠ طالب بالصفحة.',
            'record_timeout':'تم طلب فتح الطالب، لكن ملفه ورقمه الموحد لم يظهرا خلال المهلة.',
            'list_changed':'اختلفت بيانات صفوف الطلاب عن القائمة التي جُمعت أولاً.',
            'identity_changed':'اختلف رقم الطالب أو اسمه عن الصف المطلوب، أو تعذّر تأكيد هوية طالب لا يظهر له رقم موحد.',
            'account_profile_missing':'الإيميل غير ظاهر ولم يتأكد اسم بطاقة الحساب منذ تسجيل الدخول. أعد تسجيل الدخول بالنسخة الجديدة، وانتظر ظهور اسم الحساب ثم افتح السحب. إذا تكرر السبب أرسل HTML لبطاقة الحساب أسفل الشريط الجانبي، دون بيانات الدخول.',
            'account_session_changed':'تغيّرت بطاقة الحساب أو خرجت الصفحة من جلسة الدخول التي أكدها البرنامج. أنهِ الجلسة وسجّل الدخول مجدداً.',
        }
        message=messages.get(event,messages['scan_failed'])
        if event in {'scan_saved','scan_saved_partial'}:
            message+=f'\nعدد الملفات المقروءة: {detail.get("read",first)}. السجلات المحذوفة أو المعروضة مجدداً التي تم تخطيها: {detail.get("skipped",0)}.'
        if detail.get('reason') in reasons:
            message+='\nسبب التوقف: '+reasons[detail['reason']]
        self.status.setText(message)

    def session_event(self,event):
        if event in {'invalid_input','dependency_missing','browser_missing','timeout','failed','cancelled','browser_closed','disconnected'}:
            self.available=False;self.set_pending(False)
            if self.last_result in {'scan_paused','scan_paused_checkpoint'}:
                self.status.setText(self.status.text()+'\nانتهت جلسة المتصفح؛ سجّل الدخول مجدداً للاستكمال.')
            else:self.status.setText('انتهت جلسة المتصفح. يبقى أي تقدّم محفوظ على القرص؛ سجّل الدخول مجدداً واختر نفس ملف Excel للاستكمال.')

    def reject(self):
        if not self.pending:super().reject()

    def closeEvent(self,event):
        if self.pending:event.ignore()
        else:super().closeEvent(event)

    def cleanup(self,*_):
        self.controller.scan_result.disconnect(self.result);self.controller.event.disconnect(self.session_event)
