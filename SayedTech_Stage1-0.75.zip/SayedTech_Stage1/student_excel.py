"""Read a bounded XLSX input without evaluating formulas or persisting records."""
import json
import re
import zipfile
from datetime import date, datetime, timedelta
from pathlib import PurePosixPath
import xml.etree.ElementTree as ET
import core

SCHEMA = json.loads((core.ASSET_BASE / 'assets/student_simple_schema.json').read_text(encoding='utf-8'))
FIELDS = SCHEMA['fields']
BY_ID = {f['id']: f for f in FIELDS}
HEADERS = [f['label'] for f in FIELDS]
ADDRESS_HEADERS = ['البلد', 'المحافظة', 'القضاء', 'المنطقة', 'الشارع', 'النوع', 'تفاصيل العنوان ١']
ADDRESS_STATUS_HEADER = 'حالة العنوان'
MERGED_HEADERS = HEADERS + ADDRESS_HEADERS + [ADDRESS_STATUS_HEADER]
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
REL = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
IDENTIFIERS = {'field-existingUniqueId', 'field-registryNumber'}
AFTERNOON_OPTIONAL_REGISTRY = {'field-registryNumber', 'field-registryPlace'}
OCCUPATION_SECTORS = {'field-fatherOccupation': 'field-fatherSector',
                      'field-motherOccupation': 'field-motherSector'}
SIMPLE_DEFAULTS = {'isFatherDeceased': 'لا', 'isMotherDeceased': 'لا',
                   'field-motherNationality': 'سوريا', 'field-maritalStatus': 'أعزب/عزباء'}


def apply_simple_defaults(record, *, for_export=False):
    result = dict(record)
    for key, default in SIMPLE_DEFAULTS.items():
        value = result.get(key)
        if value is None or (isinstance(value, str) and not value.strip()):
            result[key] = default
    if for_export:
        # Requested for every prepared student, while keeping raw source intact.
        result['field-maritalStatus'] = 'أعزب/عزباء'
    return result


def shift_for_username(username):
    return 'afternoon' if str(username).strip().lower().endswith('@te.pm.mehe.school') else 'morning'


def optional_registry(record, shift):
    result = dict(record)
    warnings = []
    if shift == 'afternoon':
        for key in sorted(AFTERNOON_OPTIONAL_REGISTRY):
            field = BY_ID[key]
            value = result.get(key, '')
            if value is None: value = ''
            if isinstance(value, str): value = value.strip()
            if not isinstance(value, str) or len(value) > (field['max_length'] or 256) or any(ord(c) < 32 for c in value):
                result[key] = ''
                warnings.append(f"{field['label']} اختياري بعد الظهر: تم تخطي القيمة غير الصالحة للتعبئة، وبقيت كاملة في ملف Excel.")
    return result, warnings


def field_is_required(field, record, shift='morning'):
    if shift == 'afternoon' and field['id'] in AFTERNOON_OPTIONAL_REGISTRY: return False
    sector_key = OCCUPATION_SECTORS.get(field['id'])
    sector = record.get(sector_key, '') if sector_key else ''
    unemployed = isinstance(sector, str) and sector.strip() in ('unemployed', 'عاطل عن العمل')
    return field['required'] and not unemployed

class ExcelInputError(ValueError):
    pass

def normalize_date(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not 1 <= value <= 2958465 or value == 60 or int(value) != value:
            raise ValueError('date')
        base = date(1899, 12, 31) if value < 60 else date(1899, 12, 30)
        result = base + timedelta(days=int(value))
    else:
        result = date.fromisoformat(str(value).strip())
    if result > date.today():
        raise ValueError('future date')
    return result.isoformat()

def validate_record(record, shift='morning'):
    """Return canonical field-id values plus non-personal validation messages."""
    record = apply_simple_defaults(record)
    record, _ = optional_registry(record, shift)
    clean, errors = {}, []
    for f in FIELDS:
        key, label = f['id'], f['label']
        value = record.get(key, '')
        if value is None: value = ''
        if isinstance(value, (dict, list, tuple)):
            errors.append(f'{label}: قيمة غير صالحة'); continue
        if f['type'] == 'checkbox':
            if value in ('', False, 'لا', 'false', '0', 0): clean[key] = False
            elif value in (True, 'نعم', 'true', '1', 1): clean[key] = True
            else: errors.append(f'{label}: استخدم نعم أو لا')
            continue
        if key in IDENTIFIERS and isinstance(value, (int, float, bool)):
            errors.append(f'{label}: أدخله كنص لحفظ الأصفار'); continue
        if isinstance(value, str): value = value.strip()
        # NSLDB exports 0 when a student has no unified number. It must not
        # be compared to the actual number displayed by SIMS.
        if key == 'field-existingUniqueId' and value and set(value) == {'0'}:
            value = ''
        if value == '':
            clean[key] = ''
            if field_is_required(f, clean, shift): errors.append(f'{label}: مطلوب')
            continue
        if f['type'] == 'date':
            try: clean[key] = normalize_date(value)
            except (ValueError, TypeError, OverflowError): errors.append(f'{label}: استخدم تاريخاً صالحاً بصيغة yyyy-mm-dd لا يتجاوز اليوم')
            continue
        if not isinstance(value, str):
            errors.append(f'{label}: أدخل نصاً'); continue
        if len(value) > (f['max_length'] or 256) or any(ord(c) < 32 for c in value):
            errors.append(f'{label}: النص طويل أو يحوي محارف غير صالحة'); continue
        if f['options']:
            matches = [o for o in f['options'] if value in (o['value'], o['label'])]
            if len(matches) != 1:
                errors.append(f'{label}: اختر قيمة من القائمة'); continue
            value = matches[0]['label']
        clean[key] = value
    return clean, errors

def read_students(path, shift='morning'):
    from student_workflow import (WORKFLOW_SHEET, WORKFLOW_HEADERS, SELECTION_HEADER,
                                  workbook_rows, selection_value)
    from nsldb_reference import (REFERENCE_SHEET, REFERENCE_HEADERS, REFERENCE_EXTRA,
                                 FULL_REFERENCE_HEADERS, DETAIL_HEADERS, DETAILED_CHOICE)
    try:
        with zipfile.ZipFile(path) as z:
            expanded_size = sum(i.file_size for i in z.infolist())
            if len(z.infolist()) > 1000 or expanded_size > 128_000_000:
                raise ExcelInputError('ملف Excel كبير جداً.')
            def xml(name):
                data = z.read(name)
                if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
                    raise ExcelInputError('بنية XML غير مدعومة.')
                return ET.fromstring(data)
            from student_unified import is_unified, read_simple_unified
            if is_unified(z):return read_simple_unified(z, shift)
            book = xml('xl/workbook.xml')
            is_reference = any(s.get('name') == REFERENCE_SHEET for s in book.findall('m:sheets/m:sheet', NS))
            is_workflow = any(s.get('name') == WORKFLOW_SHEET for s in book.findall('m:sheets/m:sheet', NS))
            if is_workflow:
                metadata_rows = workbook_rows(z, WORKFLOW_SHEET)
                if any(formulas for _, _, formulas in metadata_rows):
                    raise ExcelInputError('مرجع ملف المبسّط يجب أن يحتوي قيماً ثابتة.')
                metadata = {values.get('A'): values.get('B') for _, values, _ in metadata_rows}
                if metadata.get('نوع الملف') != 'simple_workflow' or str(metadata.get('السنة الدراسية')) != '20252026':
                    raise ExcelInputError('اختر ملف التحويل للمبسّط للعام 2025–2026.')
            if not is_reference and expanded_size > 32_000_000:
                raise ExcelInputError('ملف Excel كبير جداً.')
            if any(s.get('name') == 'حالة السحب' for s in book.findall('m:sheets/m:sheet',NS)):
                raise ExcelInputError('هذا ملف سحب لطلاب موجودين، وليس نموذج إنشاء. استرداد تحديث السجلات الموجودة غير مفعّل بعد.')
            props = book.find('m:workbookPr', NS)
            if props is not None and props.get('date1904') in ('1','true'):
                raise ExcelInputError('نظام تواريخ 1904 غير مدعوم. استخدم النموذج المرفق.')
            sheets = [s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name') == 'الطلاب']
            if len(sheets) != 1: raise ExcelInputError('ورقة «الطلاب» غير موجودة.')
            relations = xml('xl/_rels/workbook.xml.rels')
            targets = [r for r in relations if r.get('Id') == sheets[0].get(REL)]
            if len(targets) != 1 or targets[0].get('TargetMode') == 'External':
                raise ExcelInputError('مرجع ورقة غير صالح.')
            target = targets[0].get('Target','')
            name = target.lstrip('/') if target.startswith('/') else 'xl/' + target
            if '..' in PurePosixPath(name).parts: raise ExcelInputError('مسار غير مدعوم.')
            shared = []
            if 'xl/sharedStrings.xml' in z.namelist():
                shared = [
                    ''.join(t.text or '' for t in si.findall('.//m:t',NS)) for si in xml('xl/sharedStrings.xml')]
            if is_reference:
                marker = next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name') == REFERENCE_SHEET)
                rel = next((r for r in relations if r.get('Id') == marker.get(REL)), None)
                if rel is None or rel.get('TargetMode') == 'External':
                    raise ExcelInputError('مرجع نوع التصدير غير صالح.')
                marker_target = rel.get('Target', '')
                marker_path = marker_target.lstrip('/') if marker_target.startswith('/') else 'xl/' + marker_target
                if '..' in PurePosixPath(marker_path).parts:
                    raise ExcelInputError('مسار غير مدعوم.')
                for row in xml(marker_path).findall('m:sheetData/m:row',NS):
                    values = []
                    for c in row.findall('m:c',NS):
                        value = c.findtext('m:v','',NS)
                        if c.get('t') == 's': value = shared[int(value)]
                        elif c.get('t') == 'inlineStr': value = ''.join(t.text or '' for t in c.findall('.//m:t',NS))
                        values.append(value)
                    if values[:1] == ['نوع التصدير'] and (len(values) != 2 or values[1] != 'simple'):
                        raise ExcelInputError('هذا تصدير مفصّل للاستكمال. استرداد المفصّل إلى SIMS غير مفعّل بعد. استخدم تصدير مبسّط لإنشاء طالب.')
            rows, headers = [], None
            for node in xml(name).findall('m:sheetData/m:row',NS):
                row_no = int(node.get('r','0'))
                if not 1 <= row_no <= 5001: raise ExcelInputError('الحد الأقصى 5000 طالب.')
                cells, formula_columns = {}, set()
                for c in node.findall('m:c',NS):
                    ref = c.get('r','')
                    match = re.fullmatch(r'([A-Z]{1,2})[1-9][0-9]*',ref)
                    if not match: raise ExcelInputError('عنوان خلية غير صالح.')
                    column = match[1]
                    # The merged template's status is derived, never input. Do not
                    # evaluate or trust its formula, cached value, or cached error.
                    if row_no != 1 and headers and headers.get(column) == ADDRESS_STATUS_HEADER:
                        continue
                    if c.find('m:f',NS) is not None: formula_columns.add(column)
                    v = c.find('m:v',NS)
                    value = v.text if v is not None and v.text is not None else ''
                    kind = c.get('t')
                    if kind == 's': value = shared[int(value)]
                    elif kind == 'inlineStr': value = ''.join(t.text or '' for t in c.findall('.//m:t',NS))
                    elif kind == 'b': value = value == '1'
                    elif kind == 'e': raise ExcelInputError(f'يوجد خطأ Excel في الصف {row_no}.')
                    elif kind not in ('str','d') and value != '': value = float(value)
                    cells[column] = value
                if row_no == 1:
                    if DETAILED_CHOICE in cells.values():
                        raise ExcelInputError('هذا تصدير مفصّل للاستكمال، وليس ملف إنشاء مبسّط. استرداد المفصّل غير مفعّل بعد.')
                    if formula_columns: raise ExcelInputError('العناوين يجب أن تكون نصوصاً.')
                    headers = {col: value for col,value in cells.items() if value != ''}
                    schemas = (WORKFLOW_HEADERS,) if is_workflow else ((REFERENCE_HEADERS, FULL_REFERENCE_HEADERS) if is_reference else (HEADERS, MERGED_HEADERS))
                    if is_workflow and headers.get('A') != SELECTION_HEADER:
                        raise ExcelInputError('عمود مسجّل بمدرستي؟ يجب أن يبقى أول عمود.')
                    if not any(len(headers) == len(schema) and set(headers.values()) == set(schema)
                               for schema in schemas):
                        raise ExcelInputError('عناوين الأعمدة مختلفة. استخدم نموذج البرنامج بدون تعديل العناوين.')
                    continue
                if not any(v != '' for v in cells.values()) and not formula_columns: continue
                if headers is None: raise ExcelInputError('صف العناوين مفقود.')
                reference = {}
                if is_workflow:
                    if 'A' in formula_columns:
                        raise ExcelInputError(f'الصف {row_no}: اختيار الطلاب يجب أن يكون قيمة يدوية 0/1 أو لا/نعم، دون معادلات.')
                    try:
                        selected = selection_value(cells.get('A', ''))
                    except ValueError:
                        raise ExcelInputError(f'الصف {row_no}: استخدم 0 أو 1 أو لا أو نعم في أول عمود.') from None
                    if not selected: continue
                if is_reference:
                    reference = {label: cells.get(col, '') for col, label in headers.items() if label in REFERENCE_EXTRA + DETAIL_HEADERS}
                    choices = [col for col, label in headers.items() if label in REFERENCE_EXTRA[:2]]
                    if any(col in formula_columns for col in choices):
                        raise ExcelInputError(f'الصف {row_no}: اختيار الطلاب يجب أن يكون نعم أو لا يدوياً، بدون معادلة.')
                    enrolled = str(reference[REFERENCE_EXTRA[0]]).strip()
                    selected = str(reference[REFERENCE_EXTRA[1]]).strip()
                    if selected not in ('', 'نعم', 'لا') or enrolled not in ('', 'لم أحدد', 'نعم', 'لا'):
                        raise ExcelInputError(f'الصف {row_no}: استخدم القوائم في مسجّل بمدرستي؟ وإدخال مبسّط؟.')
                    if selected != 'نعم':
                        continue
                if any(col not in headers and (value != '' or col in formula_columns) for col,value in cells.items()):
                    raise ExcelInputError(f'بيانات خارج أعمدة النموذج في الصف {row_no}.')
                raw = {f['id']: cells.get(col,'') for col,label in headers.items() for f in FIELDS if f['label'] == label}
                clean, errors = validate_record(raw, shift)
                if is_reference:
                    if enrolled != 'نعم':
                        errors.append('حدّد مسجّل بمدرستي؟ = نعم لهذا الطالب قبل اختيار إدخاله بالمبسّط')
                    if not all(isinstance(reference[label], str) and reference[label].strip()
                               for label in REFERENCE_EXTRA[2:6]):
                        errors.append('معلومات السنة والحالة ومعرّف الشخص والمدرسة في مرجع NSLDB ناقصة')
                address = {label: cells.get(col, '') for col,label in headers.items() if label in ADDRESS_HEADERS}
                if formula_columns: errors.insert(0,'المعادلات غير مسموحة ضمن بيانات الطلاب؛ استخدم قيماً ثابتة')
                if any(value != '' for value in address.values()):
                    errors.append('استرداد العناوين إلى النظام غير مفعّل بعد؛ لم تُرسل بيانات هذا الصف. احتفظ بالملف حتى تفعيل العناوين.')
                row = {'excel_row':row_no,'values':clean,'address':address,'errors':errors,
                       'warnings':optional_registry(raw, shift)[1]}
                if is_reference: row['reference'] = reference
                if is_workflow: row['workflow'] = True
                rows.append(row)
            if headers is None: raise ExcelInputError('صف العناوين مفقود.')
            if not rows:
                if is_workflow:
                    raise ExcelInputError('لم تختر أي طالب. ضع 1 أو نعم في أول عمود للطلاب المطلوب تسجيلهم، ثم احفظ Excel وأعد استرداده.')
                if is_reference:
                    raise ExcelInputError('لم تختر أي طالب. في Excel علّم مسجّل بمدرستي؟ وإدخال مبسّط؟ بـ«نعم» للطلاب المطلوبين فقط.')
                raise ExcelInputError('النموذج فارغ. عبّئ بيانات الطلاب ثم استرده.')
            seen = {}
            people = {}
            for row in rows:
                uid = row['values'].get('field-existingUniqueId')
                if uid:
                    if uid in seen:
                        row['errors'].append('الرقم الموحد مكرر ضمن الملف')
                        seen[uid]['errors'].append('الرقم الموحد مكرر ضمن الملف')
                    else: seen[uid] = row
                if is_reference:
                    person = row['reference'].get('معرّف الشخص في القاعدة')
                    if person:
                        if person in people:
                            message = 'الشخص نفسه مختار بأكثر من تسجيل من القاعدة؛ اختر تسجيلاً واحداً فقط'
                            row['errors'].append(message)
                            people[person]['errors'].append(message)
                        else: people[person] = row
            return rows
    except ExcelInputError: raise
    except (OSError, ValueError, KeyError, IndexError, TypeError, zipfile.BadZipFile, ET.ParseError):
        raise ExcelInputError('تعذّرت قراءة الملف. اختر ملف xlsx صالحاً من نموذج البرنامج.') from None
