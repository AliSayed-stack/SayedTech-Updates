"""Offline reference conversion and explicit enrollment-selection boundaries."""
import copy
import hashlib
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

from nsldb_reference import (map_records, read_tables, write_reference, export_database,
    open_database, password_candidates, ReferenceError, REFERENCE_EXTRA, source_sheets)
from student_excel import read_students, ExcelInputError, NS
from test_students import record


def tables():
    person = {'GPersonID': 101, 'FirstName': 'TEST FIRST', 'LastName': 'TEST LAST',
        'MiddleName': 'TEST FATHER', 'MotherName': 'TEST MOTHER', 'MotherLastName': 'TEST MOTHER FAMILY',
        'DateOfBirth': '13/02/2015', 'PlaceOfBirth': 'TEST PLACE', 'EnrolmentNum': '00123',
        'EnrolmentPlace': 'TEST REGISTRY', 'Gender': 'انثى', 'NationalityID': 1}
    registrations = []
    for year, status in [('2024 / 2025', 'Deleted'), ('2025 / 2026', 'Leave'),
                         ('2025 / 2026', None), ('2025 / 2026', 'Promoted')]:
        registrations.append({'MEHEID': 'TEST SCHOOL', 'TermID': year,
            'GPersonID': 101, 'ClassID': 99, 'ClassSectionID': 1, 'SystemStatus': status,
            'TeachingLangID': 1, 'ClassScheduleID': 2, 'UniqueID': '000001',
            'LivingPhone': '03123456', 'SequenceNb': 12, 'PrevSequenceNb': 7,
            'PrevAttestationNum': '000042'})
    return {'GPerson': [person], 'StudentSchool': registrations,
        'Classes': [{'ID': 99, 'Code': 'PRM01', 'ClassName': 'الاولى اساسي'}],
        'ClassSections': [{'ID': 1, 'Name': 'ا\u200e'}],
        'TeachingLang': [{'ID': 1, 'Code': 'FRA', 'Name': 'فرنسية'}],
        'Nationalities': [{'ID': 1, 'Name': 'لبنان'}],
        'Schedule': [{'ID': 2, 'Name': 'بعد الظهر'}],
        'SchoolInformation': [{'MEHEID': 'TEST SCHOOL', 'TermID': '2025 / 2026', 'SchoolName': 'TEST ONLY SCHOOL'}]}


def choose(path, selected, enrolled='نعم', complete=True, formula=False, uid=None):
    """Disposable Excel edits mimic explicit user choices, never a deliverable."""
    with zipfile.ZipFile(path) as z:
        parts = {n: z.read(n) for n in z.namelist()}
    q = lambda tag: '{' + NS['m'] + '}' + tag
    sheet = ET.fromstring(parts['xl/worksheets/sheet1.xml'])
    for row in sheet.findall('m:sheetData/m:row', NS)[1:]:
        index = int(row.get('r'))
        if index not in selected:
            continue
        cells = {c.get('r'): c for c in row}
        for col, value in [('AB', enrolled), ('AC', 'نعم')]:
            c = cells[col + str(index)]
            for child in list(c): c.remove(child)
            c.set('t', 'inlineStr')
            ET.SubElement(ET.SubElement(c, q('is')), q('t')).text = value
            if formula and col == 'AC': ET.SubElement(c, q('f')).text = '"نعم"'
        if complete:
            data = record()
            if uid is not None: data['field-existingUniqueId'] = uid
            for i, field in enumerate(__import__('student_excel').FIELDS):
                col = chr(65 + i) if i < 26 else 'AA'
                c = cells[col + str(index)]
                for child in list(c): c.remove(child)
                c.set('t', 'inlineStr')
                value = data[field['id']]
                if field['type']=='date':value=value.replace('-','/')
                ET.SubElement(ET.SubElement(c, q('is')), q('t')).text = 'لا' if value is False else str(value)
    parts['xl/worksheets/sheet1.xml'] = ET.tostring(sheet)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, value in parts.items(): z.writestr(name, value)


class FakeDB:
    def __init__(self, source): self.tables = source
    def list_tables(self): return list(self.tables)
    def row_count(self, name): return len(self.tables[name])
    def table_schema(self, name): return [SimpleNamespace(name=c) for c in self.tables[name][0]]
    def read_table(self, name): return copy.deepcopy(self.tables[name])


class NSLDBTests(unittest.TestCase):
    def test_separate_modes_preserve_records_and_keep_detailed_out_of_creation(self):
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'NSLDB.sdf';source.write_bytes(b'TEST'*2048)
            for mode, columns, last in [('simple',36,'AJ'),('detailed',48,'AV')]:
                with self.subTest(mode=mode):
                    output=Path(d)/(mode+'.xlsx')
                    result=export_database(source,output,factory=lambda *a,**kw:FakeDB(tables()),mode=mode)
                    self.assertEqual(result,{'records':4,'people':1,'selected':0})
                    with zipfile.ZipFile(output) as z:
                        sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                        rows=sheet.findall('m:sheetData/m:row',NS)
                        self.assertEqual(len(rows),5)
                        self.assertTrue(all(len(r)==columns for r in rows))
                        self.assertEqual(sheet.find('m:dimension',NS).get('ref'),f'A1:{last}501')
                        book=ET.fromstring(z.read('xl/workbook.xml'))
                        names={s.get('name') for s in book.findall('m:sheets/m:sheet',NS)}
                        self.assertEqual('تسجيلات القاعدة' in names,mode=='detailed')
                        self.assertEqual(len(sheet.findall('m:dataValidations/m:dataValidation',NS)),10)
                    if mode=='simple':
                        with self.assertRaisesRegex(ExcelInputError,'لم تختر'):read_students(output)
                        choose(output,{2})
                        self.assertEqual(len(read_students(output)),1)
                    else:
                        choose(output,{2})
                        with self.assertRaisesRegex(ExcelInputError,'مفصّل'):read_students(output)
                        # Removing only the purpose sheet must not reroute this workbook.
                        with zipfile.ZipFile(output) as z:parts={n:z.read(n) for n in z.namelist()}
                        book=ET.fromstring(parts['xl/workbook.xml']);sheets=book.find('m:sheets',NS)
                        for s in list(sheets):
                            if s.get('name')=='مرجع NSLDB':sheets.remove(s)
                        parts['xl/workbook.xml']=ET.tostring(book)
                        with zipfile.ZipFile(output,'w') as z:
                            for n,v in parts.items():z.writestr(n,v)
                        with self.assertRaisesRegex(ExcelInputError,'مفصّل'):read_students(output)

    def export(self, path, count=None):
        records = map_records(tables())
        if count: records = [copy.deepcopy(records[i % len(records)]) for i in range(count)]
        write_reference(records, path, 'TEST.sdf', '0' * 64, [('StudentSchool', len(records))])
        return records

    def test_all_years_and_deleted_left_promoted_survive_without_fabrication(self):
        rows = map_records(tables())
        self.assertEqual(len(rows), 4)
        self.assertEqual({r['metadata'][3] for r in rows},
            {'محذوف (Deleted)', 'مغادر (Leave)', 'مرفّع (Promoted)', 'غير معلّم بحالة'})
        for r in rows:
            self.assertEqual(r['metadata'][:2], ['لم أحدد', 'لا'])
            v = r['values']
            self.assertEqual(v['field-birthDate'], '2015-02-13')
            self.assertEqual(v['field-registryNumber'], '00123')
            self.assertEqual(v['field-enrollment-promoted-class'], 'الأول أساسي')
            self.assertEqual(v['field-enrollment-grade-section'], 'الشعبة أ')
            self.assertEqual(v['field-motherName'], 'TEST MOTHER')
            self.assertEqual(v['field-firstNameEn'], '')
            self.assertEqual(v['field-maritalStatus'], '')
            self.assertEqual(v['field-enrollment-registration-date'], '')
            self.assertEqual(v['isFatherDeceased'], '')

    def test_optional_source_fields_are_mapped_and_notes_report_only_actual_gaps(self):
        t = tables()
        t['GPerson'][0].update({'FatherOccupation': 'معلم', 'FatherSector': 'قطاع عام',
            'FatherDeceased': 'لا', 'MotherOccupation': 'طبيبة', 'MotherSector': 'قطاع خاص',
            'MotherDeceased': 'نعم', 'MotherNationalityName': 'سوريا', 'MaritalStatus': 'أعزب/عزباء'})
        for row in t['StudentSchool']:
            if row['TermID'] == '2025 / 2026': row['RegistrationDate'] = '2025-09-20'
        mapped = map_records(t)[1]
        values = mapped['values']
        self.assertEqual(values['field-fatherOccupation'], 'معلم')
        self.assertEqual(values['field-fatherSector'], 'قطاع عام')
        self.assertEqual(values['field-motherOccupation'], 'طبيبة')
        self.assertEqual(values['field-motherSector'], 'قطاع خاص')
        self.assertEqual(values['field-motherNationality'], 'سوريا')
        self.assertEqual(values['field-maritalStatus'], 'أعزب/عزباء')
        self.assertEqual(values['field-enrollment-registration-date'], '2025-09-20')
        note = mapped['metadata'][8]
        self.assertNotIn('الخانات غير المتوفرة فارغة', note)
        self.assertNotIn('تاريخ التسجيل', note)
        self.assertNotIn('وفاة الأب', note)
        self.assertIn('شهرة الأم في القاعدة: TEST MOTHER FAMILY', note)

    def test_missing_source_note_is_specific_instead_of_a_blanket_claim(self):
        row = map_records(tables())[1]
        note = row['metadata'][8]
        self.assertNotIn('الخانات غير المتوفرة فارغة', note)
        self.assertIn('قطاع عمل الأب', note)
        self.assertIn('تاريخ التسجيل', note)

    def test_default_selects_nobody_one_selected_ignores_other_rows_and_duplicate_ids(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'reference.xlsx'
            self.export(p)
            with self.assertRaisesRegex(ExcelInputError, 'لم تختر'): read_students(p)
            choose(p, {3})
            rows = read_students(p)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]['excel_row'], 3)
            self.assertEqual(rows[0]['errors'], [])
            self.assertIn('reference', rows[0])

    def test_school_membership_and_missing_required_data_block_with_parent_defaults(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'reference.xlsx'
            self.export(p); choose(p, {2}, enrolled='لا', complete=False)
            row = read_students(p)[0]
            errors = row['errors']
            self.assertTrue(any('مسجّل بمدرستي' in x for x in errors))
            self.assertFalse(row['values']['isFatherDeceased'])
            self.assertFalse(row['values']['isMotherDeceased'])
            self.assertEqual(row['values']['field-motherNationality'],'سوريا')
            self.assertTrue(any('الاسم الأول (بالإنكليزية)' in x for x in errors))

    def test_selected_duplicate_person_is_blocked_even_without_unified_id(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'reference.xlsx'
            self.export(p); choose(p, {2, 3}, uid='')
            rows = read_students(p)
            self.assertTrue(all(any('الشخص نفسه' in e for e in r['errors']) for r in rows))
            self.assertTrue(all(not any('الرقم الموحد مكرر' in e for e in r['errors']) for r in rows))

    def test_formula_selection_is_rejected_and_542nd_row_remains_in_table_and_dropdowns(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'reference.xlsx'
            self.export(p, 541)
            with zipfile.ZipFile(p) as z:
                s = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                ranges = [d.get('sqref') for d in s.findall('m:dataValidations/m:dataValidation', NS)]
                self.assertIn('AB2:AB542', ranges)
                self.assertIn('AC2:AC542', ranges)
                for name in z.namelist():
                    if name.startswith('xl/tables/'):
                        t = ET.fromstring(z.read(name))
                        if t.get('name') == 'StudentsInput': self.assertEqual(t.get('ref'), 'A1:AV542')
            choose(p, {542}); self.assertEqual(read_students(p)[0]['excel_row'], 542)
            choose(p, {542}, formula=True)
            with self.assertRaisesRegex(ExcelInputError, 'بدون معادلة'): read_students(p)

    def test_count_mismatch_or_missing_person_never_produces_partial_reference(self):
        db = FakeDB(tables())
        db.row_count = lambda name: 100
        with self.assertRaises(ReferenceError) as cm: read_tables(db, threading.Event(), lambda *_: None)
        self.assertEqual(cm.exception.code, 'count')
        t = tables(); t['GPerson'] = []
        with self.assertRaises(ReferenceError) as cm: map_records(t)
        self.assertEqual(cm.exception.code, 'identity')

    def test_phone_sequence_and_certificates_are_kept_separately_and_joined_by_year_and_school(self):
        t=tables()
        t['BRCStatement']=[{'MEHEID':school,'GPersonID':101,'TermID':term,'Code':code,
            'BarCode':'000012345678901234','StatementTypeID':1,'ReportName':'Ifada1','PrintDate':'01/02/2025'}
            for school,term,code in [('TEST SCHOOL',20242025,'0042'),('TEST SCHOOL',20252026,'0043'),
                                    ('TEST SCHOOL',20252026,'0044'),('OTHER SCHOOL',20252026,'0099')]]
        rows=map_records(t)
        for r in rows:
            self.assertEqual(r['details'][:2],['03123456',''])
            self.assertEqual(r['details'][3:5],['12','7'])
            self.assertEqual(r['details'][10],'000042')
            self.assertEqual(r['details'][6],'0042' if r['metadata'][2]=='2024 / 2025' else '0043\n0044')
            self.assertNotIn('LivingPhone',r['values'])

    def test_full_source_rows_and_binary_markers_are_exported_without_reading_images(self):
        class Image:
            def read(self):raise AssertionError('Photo must not be read')
        t=tables();t['GPerson'][0]['Photo']=Image()
        t['StudentSchool'][0]['FinalAvg']='08.500'
        sheets=source_sheets(t,threading.Event())
        enrollments=next(s for s in sheets if s['name']=='تسجيلات القاعدة')
        phones=enrollments['headers'].index('رقم الهاتف (LivingPhone)')
        self.assertEqual(enrollments['rows'][0][phones],'03123456')
        self.assertEqual(enrollments['rows'][0][enrollments['headers'].index('FinalAvg')],'08.500')
        people=next(s for s in sheets if s['name']=='أشخاص الطلاب')
        self.assertIn('قيمة ثنائية',people['rows'][0][-1])
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'full.xlsx'
            write_reference(map_records(t),path,'TEST.sdf','0'*64,[],source_data=sheets)
            choose(path,{2})
            r=read_students(path)[0]
            self.assertEqual(r['errors'],[])
            self.assertEqual(r['reference']['رقم الهاتف (LivingPhone)'],'03123456')
            self.assertNotIn('رقم الهاتف (LivingPhone)',r['values'])

    def test_previous_reference_headers_remain_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'previous.xlsx';self.export(path);choose(path,{2})
            with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
            sheet=ET.fromstring(parts['xl/worksheets/sheet1.xml'])
            for row in sheet.findall('m:sheetData/m:row',NS):
                for c in list(row):
                    col=''.join(x for x in c.get('r') if x.isalpha())
                    if len(col)==2 and col>'AJ':row.remove(c)
            parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet)
            with zipfile.ZipFile(path,'w') as z:
                for name,value in parts.items():z.writestr(name,value)
            self.assertEqual(read_students(path)[0]['errors'],[])

    def test_static_app_password_recovery_never_executes_program_or_leaks_engine_errors(self):
        class InvalidPasswordError(Exception): pass
        calls = []
        def factory(path, password):
            calls.append(password)
            if password != 'TEST_ONLY_KEY': raise InvalidPasswordError('SECRET MUST NOT LEAK')
            return 'OPEN'
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'MDBL.dll'
            p.write_bytes('Data Source=C:\\DATA\\NSLDB.sdf;Password=TEST_ONLY_KEY;'.encode('utf-16le'))
            self.assertEqual(password_candidates(p), ['TEST_ONLY_KEY'])
            self.assertEqual(open_database('TEST.sdf', Path(d)/'NSLDB.sdf', factory=factory), 'OPEN')
            with self.assertRaises(ReferenceError) as cm:
                open_database('TEST.sdf', Path(d)/'NSLDB.sdf', password='WRONG_TEST_KEY', factory=factory)
            self.assertEqual(str(cm.exception), 'password')

    def test_local_mehensl_next_to_database_opens_it_without_bundling(self):
        class InvalidPasswordError(Exception): pass
        calls=[]
        def factory(path,password):
            calls.append(password)
            if password!='TEST_ONLY_BUNDLED_KEY': raise InvalidPasswordError()
            return 'OPEN'
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'MEHENSL.exe').write_bytes(b'Data Source=NSLDB.sdf;Password=TEST_ONLY_BUNDLED_KEY;')
            self.assertEqual(open_database('COPY.sdf',root/'isolated/NSLDB.sdf',factory=factory),'OPEN')
            self.assertEqual(calls,['','TEST_ONLY_BUNDLED_KEY'])
            calls.clear()
            with self.assertRaises(ReferenceError):
                open_database('COPY.sdf',root/'isolated/NSLDB.sdf',password='EXPLICIT_WRONG_TEST_KEY',factory=factory)
            self.assertEqual(calls,['EXPLICIT_WRONG_TEST_KEY'])

    def test_bundled_reference_opens_downloaded_database_without_manual_selection(self):
        class InvalidPasswordError(Exception): pass
        calls=[]
        def factory(path,password):
            calls.append(password)
            if password != 'TEST_ONLY_BUNDLED_KEY': raise InvalidPasswordError()
            return 'OPEN'
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); legacy=root/'assets'/'legacy'; legacy.mkdir(parents=True)
            (legacy/'MDBL.dll').write_bytes(b'Data Source=NSLDB.sdf;Password=TEST_ONLY_BUNDLED_KEY;')
            with patch.object(__import__('core'),'ASSET_BASE',root):
                self.assertEqual(open_database('COPY.sdf',root/'Downloads/NSLDB.sdf',factory=factory),'OPEN')
            self.assertEqual(calls,['','TEST_ONLY_BUNDLED_KEY'])

    def test_original_file_and_existing_output_survive_cancel_and_read_only_export(self):
        with tempfile.TemporaryDirectory() as d:
            source = Path(d) / 'NSLDB.sdf'; source.write_bytes(b'TEST' * 2048)
            target = Path(d) / 'reference.xlsx'; target.write_bytes(b'PREVIOUS FILE')
            before = hashlib.sha256(source.read_bytes()).hexdigest()
            cancel = threading.Event(); cancel.set()
            with self.assertRaises(ReferenceError):
                export_database(source, target, cancelled=cancel, factory=lambda *a, **kw: FakeDB(tables()))
            self.assertEqual(target.read_bytes(), b'PREVIOUS FILE')
            cancel.clear()
            def late_cancel(stage, *_):
                if stage == 'export': cancel.set()
            with self.assertRaises(ReferenceError):
                export_database(source, target, cancelled=cancel, progress=late_cancel,
                                factory=lambda *a, **kw: FakeDB(tables()))
            self.assertEqual(target.read_bytes(), b'PREVIOUS FILE')
            stats = export_database(source, target, factory=lambda *a, **kw: FakeDB(tables()))
            self.assertEqual(stats, {'records': 4, 'people': 1, 'selected': 0})
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), before)
            with self.assertRaisesRegex(ExcelInputError, 'لم تختر'): read_students(target)


if __name__ == '__main__': unittest.main()
