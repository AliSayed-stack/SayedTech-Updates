"""One editable workbook; each import validates only its own input fields."""
from student_excel import FIELDS, HEADERS, NS, ExcelInputError, validate_record, optional_registry
from student_workflow import workbook_rows, selection_value
from nsldb_reference import REFERENCE_EXTRA, DETAIL_HEADERS, TARGET_YEAR, canonical_year
from student_detailed import ADDRESS_COLUMNS, DEFAULT_RESIDENCE_COUNTRY
from name_transliteration import suggest_english_names
import xml.etree.ElementTree as ET
import zipfile
import hashlib
import os
import re
import tempfile
from xml.sax.saxutils import escape
from pathlib import Path
from student_workflow import column
from name_transliteration import NAME_PAIRS

MARKER = 'الملف الموحد'
SELECTION = 'اختيار للاستيراد'
from student_promotion import PROMOTION_HEADERS
OLD_ADDRESS_COLUMNS = ADDRESS_COLUMNS[:-1]
LEGACY_HEADERS = [SELECTION] + HEADERS + REFERENCE_EXTRA[2:] + DETAIL_HEADERS + OLD_ADDRESS_COLUMNS
PREVIOUS_HEADERS = LEGACY_HEADERS + PROMOTION_HEADERS
ENTRY_KIND = 'طريقة تسجيل الطالب'
TRANSFER_KIND = 'طالب موجود بمدرسة أخرى'
MOTHER_SURNAME = 'شهرة الأم (للمفصّل)'
MANUAL_DEFAULTS = {'field-nationality':'سوريا', 'field-motherNationality':'سوريا',
                   'isFatherDeceased':'لا', 'isMotherDeceased':'لا'}
MANUAL_YEAR = '2025/2026'
LAST_UNIFIED_HEADERS = PREVIOUS_HEADERS + ['نوع السكن', ENTRY_KIND]
MOTHER_SURNAME_INDEX = LAST_UNIFIED_HEADERS.index(next(f['label'] for f in FIELDS if f['id']=='field-motherName'))+1
UNIFIED_HEADERS_V081 = LAST_UNIFIED_HEADERS[:MOTHER_SURNAME_INDEX] + [MOTHER_SURNAME] + LAST_UNIFIED_HEADERS[MOTHER_SURNAME_INDEX:]
UNIFIED_HEADERS = [h for h in UNIFIED_HEADERS_V081 if h != 'نوع السكن']
UNIFIED_HEADERS.insert(UNIFIED_HEADERS.index('تفاصيل العنوان') + 1, 'نوع السكن')
UNIFIED_HEADERS_V095 = UNIFIED_HEADERS[:]
from identity_card import CARD_COLUMNS, REGISTRY_COLUMN
CARD_INDEX = UNIFIED_HEADERS.index('نوع السكن') + 1
UNIFIED_HEADERS[CARD_INDEX:CARD_INDEX] = CARD_COLUMNS


def source_mother_surname(notes):
    if not isinstance(notes,str):return ''
    match=re.search(r'(?:^|؛\s*)شهرة الأم في القاعدة:\s*([^؛\r\n]+)',notes)
    return match.group(1).strip() if match else ''


def is_unified(z):
    data=z.read('xl/workbook.xml')
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():raise ExcelInputError('بنية XML غير مدعومة.')
    return any(s.get('name')==MARKER for s in ET.fromstring(data).findall('m:sheets/m:sheet',NS))


def selected_rows(z, purpose):
    marker=workbook_rows(z,MARKER)
    if any(f for _,_,f in marker):raise ExcelInputError('مرجع الملف الموحد غير صالح.')
    info={v.get('A'):v.get('B') for _,v,_ in marker}
    if info.get('نوع الملف')!='unified_students' or str(info.get('السنة الدراسية'))!=TARGET_YEAR:
        raise ExcelInputError('اختر الملف الموحد لعام 2025–2026.')
    rows=workbook_rows(z,'الطلاب')
    if not rows or rows[0][0]!=1 or rows[0][2]:raise ExcelInputError('عناوين الملف غير صالحة.')
    headers=rows[0][1]
    if headers.get('A')!=SELECTION or not any(len(headers)==len(schema) and set(headers.values())==set(schema) for schema in (UNIFIED_HEADERS,UNIFIED_HEADERS_V095,UNIFIED_HEADERS_V081,LAST_UNIFIED_HEADERS,PREVIOUS_HEADERS,LEGACY_HEADERS)):
        raise ExcelInputError('عناوين الملف الموحد مختلفة؛ لا تغيّر أسماء الأعمدة.')
    relevant=set(HEADERS) if purpose=='simple' else {
        f['label'] for f in FIELDS if f['id'] in ('field-firstName','field-middleName','field-lastName','field-birthDate','field-existingUniqueId')}
    if purpose=='detailed':relevant.update(ADDRESS_COLUMNS+CARD_COLUMNS+[MOTHER_SURNAME,REGISTRY_COLUMN,'رقم الهاتف (LivingPhone)'])
    relevant.update([SELECTION,ENTRY_KIND,'السنة في القاعدة','معرّف المدرسة في القاعدة','معرّف الشخص في القاعدة'])
    selected=[]
    for number,values,formulas in rows[1:]:
        if 'A' in formulas:raise ExcelInputError(f'الصف {number}: الاختيار يدوي دون معادلات.')
        try:chosen=selection_value(values.get('A',''))
        except ValueError:raise ExcelInputError(f'الصف {number}: استخدم 0 أو 1 أو نعم أو لا في أول عمود.') from None
        if not chosen:continue
        if any(headers.get(c) in relevant for c in formulas):
            raise ExcelInputError(f'الصف {number}: البيانات المستخدمة للاستيراد يجب أن تكون قيماً ثابتة.')
        if any(c not in headers and v!='' for c,v in values.items()):raise ExcelInputError('بيانات خارج أعمدة الملف.')
        row={label:values.get(c,'') for c,label in headers.items()}
        if MOTHER_SURNAME not in row:
            row[MOTHER_SURNAME]=source_mother_surname(row.get('ملاحظات المصدر',''))
        kind=str(row.get(ENTRY_KIND,'طالب موجود') or 'طالب موجود').strip()
        from registration_workbook import canonical_kind,HOME,TRANSFER
        canonical=canonical_kind(kind)
        if canonical is not None:
            kind='طالب جديد' if canonical==HOME else TRANSFER_KIND if canonical==TRANSFER else 'طالب موجود'
        if kind not in ('طالب موجود','طالب جديد',TRANSFER_KIND):
            raise ExcelInputError(f'الصف {number}: طريقة تسجيل الطالب غير معروفة.')
        if kind=='طالب موجود' and canonical_year(row['السنة في القاعدة'])!=TARGET_YEAR:
            raise ExcelInputError('الاستيراد مخصص لعام 2025–2026.')
        uid_label=next(f['label'] for f in FIELDS if f['id']=='field-existingUniqueId')
        if kind in ('طالب جديد',TRANSFER_KIND) and (row.get('معرّف الشخص في القاعدة') or row.get('معرّف المدرسة في القاعدة') or row.get(uid_label)):
            raise ExcelInputError(f'الصف {number}: صف الطالب الجديد لا يحمل معرّفاً من القاعدة؛ راجع اختيار طريقة التسجيل.')
        if kind in ('طالب جديد',TRANSFER_KIND):
            for field_id,default in MANUAL_DEFAULTS.items():
                label=next(f['label'] for f in FIELDS if f['id']==field_id)
                if not str(row.get(label,'') or '').strip():row[label]=default
            if not str(row.get('السنة في القاعدة','') or '').strip():row['السنة في القاعدة']=MANUAL_YEAR
        if not str(row.get('بلد السكن','') or '').strip():
            row['بلد السكن']=DEFAULT_RESIDENCE_COUNTRY
        row[ENTRY_KIND]=kind
        selected.append((number,row))
    if not selected:raise ExcelInputError('لم تختر أي طالب. ضع 1 أو نعم في أول عمود واحفظ الملف.')
    return selected


def read_simple_unified(z, shift='morning'):
    result=[];seen={}
    for number,row in selected_rows(z,'simple'):
        raw=suggest_english_names({f['id']:row[f['label']] for f in FIELDS})
        values,errors=validate_record(raw, shift)
        item={'excel_row':number,'values':values,'errors':errors,'address':{},'workflow':True,'unified':True,
              'entry_kind':'طالب موجود' if row[ENTRY_KIND]==TRANSFER_KIND else row[ENTRY_KIND],
              'reference':{label:row[label] for label in REFERENCE_EXTRA[2:]},
              'warnings':optional_registry(raw,shift)[1]}
        # Match existing simple-import behavior for selected nonblank UIDs.
        uid=values.get('field-existingUniqueId')
        if uid:
            if uid in seen:
                errors.append('الرقم الموحد مكرر ضمن الطلاب المختارين')
                seen[uid]['errors'].append('الرقم الموحد مكرر ضمن الطلاب المختارين')
            else:seen[uid]=item
        result.append(item)
    return result


def convert_to_unified(source,destination):
    from student_detailed import convert_to_detailed
    if Path(destination).exists():
        raise ExcelInputError('ملف العمل موجود مسبقاً. افتحه لاستكماله، أو اختر اسماً جديداً للتحويل حتى لا تضيع تعديلاتك.')
    return convert_to_detailed(source,destination,unified=True)


def add_mother_surname_column(source,destination):
    """Create an upgraded copy of the existing workbook without rewriting its rows."""
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.exists() or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('احفظ الملف المطوّر باسم جديد؛ يبقى ملفك السابق محفوظاً كما هو.')
    if not source.is_file() or source.stat().st_size>64_000_000:
        raise ExcelInputError('اختر ملف Excel موحداً صالحاً.')
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    with zipfile.ZipFile(source) as z:
        if not is_unified(z):raise ExcelInputError('اختر الملف الموحد السابق.')
        rows=workbook_rows(z,'الطلاب')
        if not rows or list(rows[0][1].values())!=LAST_UNIFIED_HEADERS:
            raise ExcelInputError('الملف ليس من النسخة السابقة، أو عمود شهرة الأم موجود فيه بالفعل.')
        parts={name:z.read(name) for name in z.namelist()}
    book=ET.fromstring(parts['xl/workbook.xml'])
    student=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')=='الطلاب')
    rel=student.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    relations=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    target=next(r.get('Target') for r in relations if r.get('Id')==rel)
    part=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if part not in parts or '..' in Path(part).parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    new_letter=column(MOTHER_SURNAME_INDEX+1)
    def shifted_coord(match):
        letters=match.group(1).decode('ascii');number=0
        for ch in letters:number=number*26+ord(ch)-64
        return (column(number+1 if number>MOTHER_SURNAME_INDEX else number)+match.group(2).decode('ascii')).encode('ascii')
    note_letter=next(k for k,v in rows[0][1].items() if v=='ملاحظات المصدر')
    notes={number:source_mother_surname(values.get(note_letter,'')) for number,values,_ in rows[1:]}
    old_xml=parts[part]
    row_pattern=rb'<(?P<tag>(?:[A-Za-z_][\w.-]*:)?row)\b(?P<attrs>[^>]*)>(?P<body>.*?)</(?P=tag)\s*>'
    seen=set()
    def extend(match):
        found=re.search(rb'\br=["\'](\d+)["\']',match.group('attrs'))
        if not found:return match.group(0)
        number=int(found.group(1));seen.add(number)
        prefix=match.group('tag')[:-3]
        value=MOTHER_SURNAME if number==1 else notes.get(number,'')
        c=prefix+b'c';t=escape(value).encode('utf-8')
        cell=(b'<'+c+b' r="'+new_letter.encode('ascii')+str(number).encode('ascii')+
              b'" t="inlineStr"><'+prefix+b'is><'+prefix+b't>'+t+
              b'</'+prefix+b't></'+prefix+b'is></'+c+b'>')
        body=match.group('body')
        c_pattern=re.compile(rb'<'+c+rb'\b[^>]*?(?:/\s*>|>.*?</'+c+rb'\s*>)',re.DOTALL)
        cells=list(c_pattern.finditer(body))
        result=[];cursor=0;inserted=False
        for existing in cells:
            head=existing.group(0)
            ref=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',head.split(b'>',1)[0])
            if not ref or int(ref.group(2))!=number:
                raise ExcelInputError('مرجع خلية Excel غير صالح؛ بقي الأصل محفوظاً.')
            result.append(body[cursor:existing.start()])
            position=0
            for ch in ref.group(1):position=position*26+ch-64
            if position>MOTHER_SURNAME_INDEX and not inserted:
                result.append(cell);inserted=True
            if position>MOTHER_SURNAME_INDEX:
                head=re.sub(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',
                    lambda m:b'r="'+shifted_coord(m)+b'"',head,count=1)
            result.append(head);cursor=existing.end()
        if not inserted:result.append(cell)
        result.append(body[cursor:])
        return b'<'+match.group('tag')+match.group('attrs')+b'>'+b''.join(result)+b'</'+match.group('tag')+b'>'
    updated=re.sub(row_pattern,extend,old_xml,flags=re.DOTALL)
    if 1 not in seen or not set(number for number,_,_ in rows).issubset(seen):
        raise ExcelInputError('تعذّر تحديث صفوف ملف Excel؛ بقي الأصل كما هو.')
    # Shift references for validators, formatting and the used range. Leave
    # worksheet strings and source notes untouched.
    updated=re.sub(rb'\b(?:sqref|ref)=["\'][A-Z0-9: $]+["\']',
        lambda m:re.sub(rb'([A-Z]{1,3})(\d+)',shifted_coord,m.group(0)),updated)
    def shift_col_tag(match):
        return re.sub(rb'\b(?:min|max)=["\']\d+["\']',
            lambda m:re.sub(rb'\d+',lambda n:str(int(n.group(0))+(int(n.group(0))>MOTHER_SURNAME_INDEX)).encode(),m.group(0)),
            match.group(0))
    updated=re.sub(rb'<(?:[A-Za-z_][\w.-]*:)?col\b[^>]*/>',shift_col_tag,updated)
    ET.fromstring(updated)
    parts[part]=updated
    tables=[name for name in parts if name.startswith('xl/tables/') and name.endswith('.xml')]
    for name in tables:
        xml=parts[name]
        table=ET.fromstring(xml)
        if table.get('name')!='StudentsInput':continue
        cols=table.find('m:tableColumns',NS)
        if cols is None or len(cols)!=len(LAST_UNIFIED_HEADERS):
            raise ExcelInputError('تغيّر جدول Excel؛ لم يُعدّل الملف. أرفق نسخة منه للفحص.')
        table_prefix=re.search(rb'<(?P<tag>(?:[A-Za-z_][\w.-]*:)?tableColumns)\b',xml)
        if table_prefix is None:raise ExcelInputError('جدول Excel غير صالح.')
        prefix=table_prefix.group('tag')[:-len(b'tableColumns')]
        tag=prefix+b'tableColumn'
        extra=b'<'+tag+b' id="'+str(MOTHER_SURNAME_INDEX+1).encode()+b'" name="'+escape(MOTHER_SURNAME).encode('utf-8')+b'" />'
        end=b'</'+table_prefix.group('tag')+b'>'
        if xml.count(end)!=1:raise ExcelInputError('جدول Excel غير صالح.')
        column_pattern=re.compile(rb'<'+tag+rb'\b[^>]*/>')
        found=list(column_pattern.finditer(xml))
        if len(found)!=len(LAST_UNIFIED_HEADERS):raise ExcelInputError('جدول Excel غير صالح.')
        insertion=found[MOTHER_SURNAME_INDEX].start() if MOTHER_SURNAME_INDEX<len(found) else xml.index(end)
        xml=xml[:insertion]+extra+xml[insertion:]
        # Table columns after the insertion receive their new ordinal IDs.
        xml=re.sub(column_pattern,lambda m:re.sub(rb'\bid=["\'](\d+)["\']',
            lambda id_match:b'id="'+str(int(id_match.group(1))+(int(id_match.group(1))>MOTHER_SURNAME_INDEX and m.group(0)!=extra)).encode()+b'"',
            m.group(0),count=1),xml)
        xml=re.sub(rb'(<'+table_prefix.group('tag')+rb'\b[^>]*\bcount=["\'])'+str(len(LAST_UNIFIED_HEADERS)).encode()+rb'(["\'])',
                   lambda m:m.group(1)+str(len(UNIFIED_HEADERS_V081)).encode()+m.group(2),xml,count=1)
        xml=re.sub(rb'\bref=["\'][A-Z0-9:]+["\']',
            lambda m:re.sub(rb'([A-Z]{1,3})(\d+)',shifted_coord,m.group(0)),xml)
        ET.fromstring(xml)
        parts[name]=xml
    if hashlib.sha256(source.read_bytes()).hexdigest()!=digest:
        raise ExcelInputError('تغيّر الملف أثناء التحويل؛ أغلق Excel وأعد المحاولة.')
    from excel_dates import format_dates
    format_dates(parts)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent,suffix='.xlsx',delete=False) as handle:
            temporary=Path(handle.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        with zipfile.ZipFile(temporary) as z:
            upgraded=workbook_rows(z,'الطلاب')
            if z.testzip() is not None or list(upgraded[0][1].values())!=UNIFIED_HEADERS_V081 or len(upgraded)!=len(rows):
                raise ExcelInputError('فشل فحص الملف المطوّر؛ بقي الأصل محفوظاً.')
        os.replace(temporary,destination)
    finally:
        if temporary and temporary.exists():temporary.unlink()
    return destination


def _insert_translations(sheet_xml, proposals):
    """Edit only target cells, retaining Excel's original XML namespaces verbatim.

    ElementTree drops namespace declarations used only by mc:Ignorable; Excel
    then repairs sheet1.xml and discards student data. Avoid serializing the
    entire worksheet. All cell values come from the ASCII transliterator.
    """
    by_row={}
    for (number,letter),value in proposals.items():
        if not re.fullmatch(r'[A-Z]{1,3}',letter) or not isinstance(value,str) or any(ord(c)<32 for c in value):
            raise ExcelInputError('قيمة ترجمة غير صالحة.')
        by_row.setdefault(number,{})[letter]=value
    seen=set()
    row_pattern=rb'<(?P<tag>(?:[A-Za-z_][\w.-]*:)?row)\b(?P<attrs>[^>]*)>(?P<body>.*?)</(?P=tag)\s*>'

    def replace_row(match):
        attrs=match.group('attrs')
        number_match=re.search(rb'\br=["\'](\d+)["\']',attrs)
        if not number_match:return match.group(0)
        number=int(number_match.group(1))
        if number not in by_row:return match.group(0)
        seen.add(number)
        tag=match.group('tag')
        prefix=tag[:-3]  # "" or the worksheet namespace prefix, e.g. "ns0:"
        cell_tag=prefix+b'c'
        cell_pattern=re.compile(rb'<'+cell_tag+rb'\b(?P<attrs>[^>]*?)(?:/\s*>|>(?P<body>.*?)</'+cell_tag+rb'\s*>)',re.DOTALL)
        body=match.group('body')
        replacements={}
        cells=list(cell_pattern.finditer(body))
        for cell in cells:
            ref_match=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',cell.group('attrs'))
            if not ref_match or int(ref_match.group(2))!=number:continue
            letter=ref_match.group(1).decode('ascii')
            if letter in by_row[number]:
                attributes=re.sub(rb'\s+t=["\'][^"\']*["\']',b'',cell.group('attrs'))
                value=escape(by_row[number][letter]).encode('utf-8')
                replacements[letter]=(b'<'+cell_tag+attributes+b' t="inlineStr"><'+prefix+b'is><'+prefix+b't>'+value+
                                      b'</'+prefix+b't></'+prefix+b'is></'+cell_tag+b'>')
        missing=set(by_row[number])-set(replacements)
        def index(letter):
            result=0
            for char in letter:result=result*26+ord(char)-64
            return result
        cell_positions=[]
        for cell in cells:
            ref=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',cell.group('attrs'))
            if ref and int(ref.group(2))==number:
                cell_positions.append((index(ref.group(1).decode('ascii')),cell))
        insertions={}
        for letter in sorted(missing,key=index):
            next_cell=next((cell for position,cell in cell_positions if position>index(letter)),None)
            offset=next_cell.start() if next_cell else (cells[-1].end() if cells else 0)
            value=escape(by_row[number][letter]).encode('utf-8')
            new_cell=(b'<'+cell_tag+b' r="'+letter.encode('ascii')+str(number).encode('ascii')+
                      b'" t="inlineStr"><'+prefix+b'is><'+prefix+b't>'+value+
                      b'</'+prefix+b't></'+prefix+b'is></'+cell_tag+b'>')
            insertions.setdefault(offset,[]).append(new_cell)
        pieces=[];cursor=0
        for cell in cells:
            pieces.append(body[cursor:cell.start()])
            pieces.extend(insertions.get(cell.start(),()))
            ref=re.search(rb'\br=["\']([A-Z]{1,3})(\d+)["\']',cell.group('attrs'))
            letter=ref.group(1).decode('ascii') if ref else ''
            pieces.append(replacements.get(letter,cell.group(0)))
            cursor=cell.end()
        pieces.extend(insertions.get(cursor,()))
        pieces.append(body[cursor:])
        return b'<'+tag+attrs+b'>'+b''.join(pieces)+b'</'+tag+b'>'

    changed=re.sub(row_pattern,replace_row,sheet_xml,flags=re.DOTALL)
    if seen!=set(by_row):raise ExcelInputError('تعذّر إيجاد صفوف الترجمة؛ لم يُعدّل الملف.')
    ET.fromstring(changed)  # Catch malformed XML before replacing the original.
    return changed


def translate_manual_names(path):
    """Fill empty English cells for manual rows in the same workbook on request."""
    path=Path(path)
    if path.suffix.lower()!='.xlsx' or not path.is_file() or path.stat().st_size>64_000_000:
        raise ExcelInputError('اختر الملف الموحد بصيغة xlsx.')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        if not is_unified(z):raise ExcelInputError('اختر الملف الموحد.')
        rows=workbook_rows(z,'الطلاب')
        if not rows or not any(set(rows[0][1].values())==set(schema) and len(rows[0][1])==len(schema)
                               for schema in (UNIFIED_HEADERS,UNIFIED_HEADERS_V095,UNIFIED_HEADERS_V081,LAST_UNIFIED_HEADERS)):
            raise ExcelInputError('اختر ملفاً موحداً من النسخ الحديثة.')
        headers=rows[0][1]
        parts={n:z.read(n) for n in z.namelist()}
    by_name={f['id']:f['label'] for f in FIELDS}
    wanted={headers_inv:column_id for column_id,headers_inv in headers.items()}
    proposals={}
    for number,values,formulas in rows[1:]:
        kind=str(values.get(wanted[ENTRY_KIND],'')).strip()
        if kind in ('طالب جديد',TRANSFER_KIND):
            is_manual=True
        elif not kind:
            # Rows typed directly in Excel may not have the route dropdown set.
            # Imported NSLDB rows carry source identities, so they remain excluded.
            identity_labels=('معرّف الشخص في القاعدة','معرّف المدرسة في القاعدة')
            has_identity=any(str(values.get(wanted.get(label,''),'')).strip()
                             for label in identity_labels if label in wanted)
            has_arabic=any(str(values.get(wanted[by_name[arabic]],'')).strip()
                           for arabic,_ in NAME_PAIRS)
            is_manual=has_arabic and not has_identity
        else:
            is_manual=False
        if not is_manual:continue
        raw={arabic:values.get(wanted[by_name[arabic]],'') for arabic,_ in NAME_PAIRS}
        raw.update({english:values.get(wanted[by_name[english]],'') for _,english in NAME_PAIRS})
        translated=suggest_english_names(raw)
        for _,english in NAME_PAIRS:
            letter=wanted[by_name[english]]
            if letter in formulas:raise ExcelInputError(f'الصف {number}: الترجمة لا تعدّل خلية فيها معادلة.')
            if not values.get(letter) and translated.get(english):
                proposals[(number,letter)]=translated[english]
        defaults={next(f['label'] for f in FIELDS if f['id']==key):value
                  for key,value in MANUAL_DEFAULTS.items()}
        defaults['السنة في القاعدة']=MANUAL_YEAR
        defaults['بلد السكن']=DEFAULT_RESIDENCE_COUNTRY
        for label,default in defaults.items():
            letter=wanted[label]
            if letter in formulas:raise ExcelInputError(f'الصف {number}: القيمة الافتراضية لا تعدّل خلية فيها معادلة.')
            if not str(values.get(letter,'') or '').strip():
                proposals[(number,letter)]=default
    if not proposals:return 0
    book=ET.fromstring(parts['xl/workbook.xml'])
    sheet=next(s for s in book.findall('m:sheets/m:sheet',NS) if s.get('name')=='الطلاب')
    rel_id=sheet.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    rels=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    target=next(r.get('Target') for r in rels if r.get('Id')==rel_id)
    sheet_path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
    if sheet_path not in parts or '..' in Path(sheet_path).parts:raise ExcelInputError('مرجع ورقة الطلاب غير صالح.')
    parts[sheet_path]=_insert_translations(parts[sheet_path],proposals)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.xlsx',delete=False) as file:temporary=Path(file.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        with zipfile.ZipFile(temporary) as z:
            if z.testzip() is not None or len(workbook_rows(z,'الطلاب'))!=len(rows):
                raise ExcelInputError('فشل فحص الملف المترجم؛ بقي الملف الأصلي كما هو.')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
        os.replace(temporary,path)
    except OSError:
        raise ExcelInputError('أغلق ملف Excel وتأكد من صلاحية الكتابة ثم أعد الترجمة.') from None
    finally:
        if temporary and temporary.exists():temporary.unlink()
    return len(proposals)
