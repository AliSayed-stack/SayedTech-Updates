"""Student Excel boundary: year/month/day display and strict input, not site identity."""
import copy
import io
import re
import zipfile
import xml.etree.ElementTree as ET
from student_excel import NS,REL,ExcelInputError,normalize_date

FORMAT='yyyy/mm/dd'
Q=lambda n:'{'+NS['m']+'}'+n

def sheets(z):
    book=ET.fromstring(z.read('xl/workbook.xml'));rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    for s in book.findall('m:sheets/m:sheet',NS):
        if s.get('name') not in ('الطلاب','المفصّل'):continue
        r=next(r for r in rels if r.get('Id')==s.get(REL))
        if r.get('TargetMode')=='External':raise ExcelInputError('مرجع ورقة غير صالح.')
        t=r.get('Target','');p=t.lstrip('/') if t.startswith('/') else 'xl/'+t
        if '..' in p.split('/'):raise ExcelInputError('مرجع ورقة غير صالح.')
        yield s.get('name'),p

def strict_dates(z,purpose=None):
    """Validate selected rows only; numeric Excel dates need the explicit format."""
    from student_workflow import workbook_rows,selection_value
    styles=ET.fromstring(z.read('xl/styles.xml'))
    formats={int(n.get('numFmtId')):n.get('formatCode','').lower() for n in styles.findall('m:numFmts/m:numFmt',NS)}
    xfs=styles.find('m:cellXfs',NS)
    for name,part in sheets(z):
        rows=workbook_rows(z,name)
        if not rows:continue
        headers=rows[0][1];dates={c:h for c,h in headers.items() if 'تاريخ' in h}
        if purpose=='simple':
            from student_excel import FIELDS
            allowed={f['label'] for f in FIELDS if f['type']=='date'}
            dates={c:h for c,h in dates.items() if h in allowed}
        elif purpose=='detailed':dates={c:h for c,h in dates.items() if h!='تاريخ التسجيل'}
        selections=[c for c,h in headers.items() if h.startswith('اختيار') or h=='إدخال مبسّط؟']
        cells={c.get('r'):c for c in ET.fromstring(z.read(part)).findall('m:sheetData/m:row/m:c',NS)}
        for number,values,formulas in rows[1:]:
            if selections:
                try:chosen=any(selection_value(values.get(c,'')) for c in selections)
                except ValueError:continue  # Existing selection reader reports this error.
                if not chosen:continue
            for col,label in dates.items():
                value=values.get(col,'')
                if value in ('',None):continue
                valid=False
                try:
                    if isinstance(value,str):valid=bool(re.fullmatch(r'[0-9]{4}/[0-9]{2}/[0-9]{2}',value))
                    elif isinstance(value,(int,float)) and not isinstance(value,bool):
                        c=cells[col+str(number)];xf=xfs[int(c.get('s','0'))]
                        valid=formats.get(int(xf.get('numFmtId','0'))) == FORMAT
                    if not valid or col in formulas:raise ValueError()
                    normalize_date(value,allow_future=True)
                except (ValueError,TypeError,OverflowError,KeyError,IndexError):
                    raise ExcelInputError(f'الصف {number}: «{label}» يقبل YYYY/MM/DD فقط، مثلاً 2016/01/31. لا تغيّر سنة الميلاد لتصحيح التنسيق.') from None

def format_dates(parts):
    """New output only: preserve numeric serials, format strings without guessing."""
    from student_workflow import workbook_rows
    from identity_workbook import serialize
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w') as out:
        for n,v in parts.items():out.writestr(n,v)
    buf.seek(0)
    original_styles=parts['xl/styles.xml']
    styles=ET.fromstring(original_styles);original_count=len(styles.find('m:cellXfs',NS));fmts=styles.find('m:numFmts',NS)
    if fmts is None:fmts=ET.Element(Q('numFmts'));styles.insert(0,fmts)
    found=next((n for n in fmts if n.get('formatCode','').lower()==FORMAT),None)
    new_format=found is None
    if found is None:
        num=max([163]+[int(n.get('numFmtId')) for n in fmts])+1
        found=ET.SubElement(fmts,Q('numFmt'),numFmtId=str(num),formatCode=FORMAT)
    fmt=found.get('numFmtId');fmts.set('count',str(len(fmts)));xfs=styles.find('m:cellXfs',NS);cache={}
    with zipfile.ZipFile(buf) as z:
        for name,part in sheets(z):
            rows=workbook_rows(z,name)
            if not rows:continue
            dates={c for c,h in rows[0][1].items() if 'تاريخ' in h}
            root=ET.fromstring(parts[part]);vals={n:v for n,v,_ in rows};changed=False
            for row in root.findall('m:sheetData/m:row',NS)[1:]:
                number=int(row.get('r'))
                for c in row:
                    col=re.sub('[0-9]','',c.get('r',''))
                    if col not in dates:continue
                    old=int(c.get('s','0'))
                    if xfs[old].get('numFmtId')==fmt:cache[old]=str(old)
                    if old not in cache:
                        xf=copy.deepcopy(xfs[old]);xf.set('numFmtId',fmt);xf.set('applyNumberFormat','1');cache[old]=str(len(xfs));xfs.append(xf)
                    if c.get('s','0')!=cache[old]:changed=True
                    c.set('s',cache[old])
                    value=vals.get(number,{}).get(col,'')
                    if isinstance(value,str) and value and c.find(Q('f')) is None:
                        try:value=normalize_date(value,allow_future=True).replace('-','/')
                        except (ValueError,TypeError,OverflowError):continue
                        if value==vals.get(number,{}).get(col):continue
                        changed=True
                        for child in list(c):c.remove(child)
                        c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,Q('is')),Q('t')).text=value
            if changed:parts[part]=serialize(root,parts[part])
    xfs.set('count',str(len(xfs)))
    if new_format or len(xfs)!=original_count:parts['xl/styles.xml']=serialize(styles,original_styles)
