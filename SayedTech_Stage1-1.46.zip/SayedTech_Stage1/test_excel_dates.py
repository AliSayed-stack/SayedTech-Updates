"""Synthetic strict Excel date boundary and output presentation tests."""
import tempfile
from pathlib import Path
import unittest
import zipfile
from datetime import date
from openpyxl import load_workbook
from registration_workbook import write_template,read_for_simple,HOME,ENTRY_KIND
from student_excel import FIELDS,ExcelInputError
from manual_sections import SELECT
from detailed_import import read_details
from test_students import record

class ExcelDateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'dates.xlsx';write_template(self.path)
        b=load_workbook(self.path);s=b['الطلاب'];self.h={c.value:c.column for c in s[1]}
        for f in FIELDS:
            v=record()[f['id']]
            if f['type']=='date':v=v.replace('-','/')
            s.cell(2,self.h[f['label']],v if not isinstance(v,bool) else 'لا')
        s.cell(2,self.h[SELECT],'1');s.cell(2,self.h[ENTRY_KIND],HOME)
        s.cell(2,self.h['الرقم الموحد للطالب'],'')
        b.save(self.path);b.close()
    def tearDown(self):self.temp.cleanup()
    def set_date(self,value,fmt=None):
        b=load_workbook(self.path);c=b['الطلاب'].cell(2,self.h['تاريخ الولادة']);c.value=value
        if fmt:c.number_format=fmt
        b.save(self.path);b.close()
    def test_text_year_first_only_and_immutable_input(self):
        before=self.path.read_bytes();self.assertEqual(read_for_simple(self.path)[0]['values']['field-birthDate'],'2015-01-02');self.assertEqual(before,self.path.read_bytes())
        for value in ('2015-01-02','01/02/2015','2015/1/2','2015/02/30'):
            self.set_date(value)
            with self.assertRaisesRegex(ExcelInputError,'YYYY/MM/DD'):read_for_simple(self.path)
    def test_numeric_excel_date_requires_year_first_display(self):
        self.set_date(date(2015,1,2),'yyyy/mm/dd');self.assertEqual(read_for_simple(self.path)[0]['values']['field-birthDate'],'2015-01-02')
        self.set_date(date(2015,1,2),'mm/dd/yyyy')
        with self.assertRaises(ExcelInputError):read_for_simple(self.path)
    def test_document_date_strict_and_export_column_styles(self):
        b=load_workbook(self.path);s=b['الطلاب']
        for header in ('تاريخ الولادة','تاريخ التسجيل','المستندات / تاريخ الإصدار','بطاقات التعريف / تاريخ الإصدار','بطاقات التعريف / تاريخ الإنتهاء'):
            if header in self.h:self.assertEqual(s.cell(3,self.h[header]).number_format,'yyyy/mm/dd')
        s.cell(2,self.h['المستندات / تاريخ الإصدار'],'01/02/2020');b.save(self.path);b.close()
        with self.assertRaisesRegex(ExcelInputError,'YYYY/MM/DD'):read_details(self.path)
    def test_export_normalization_keeps_same_calendar_date_and_parts(self):
        from excel_dates import format_dates,strict_dates
        b=load_workbook(self.path);b['الطلاب'].cell(2,self.h['تاريخ الولادة'],'2015-01-02');b.save(self.path);b.close()
        with zipfile.ZipFile(self.path) as z:parts={n:z.read(n) for n in z.namelist()}
        before=dict(parts);format_dates(parts)
        self.assertTrue(set(n for n in parts if parts[n]!=before[n])<= {'xl/styles.xml','xl/worksheets/sheet1.xml'})
        with zipfile.ZipFile(self.path,'w') as z:
            for n,v in parts.items():z.writestr(n,v)
        self.assertEqual(read_for_simple(self.path)[0]['values']['field-birthDate'],'2015-01-02')
