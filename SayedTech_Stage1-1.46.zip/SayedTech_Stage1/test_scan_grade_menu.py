"""Deterministic delayed grade-menu regressions; synthetic account/roster only."""
import threading
import unittest
from unittest.mock import patch
from student_scan import StudentBrowser,ScanError,MANAGEMENT
from test_scan import Page,Node

ALL='جميع المستويات'
FIRST='الأول أساسي'
LAST='الثالث ثانوي'


class MenuNode(Node):
    def count(self):
        if self.kind=='grade_menu':return int(self.page.menu_open and self.page.now>=self.page.show_at)
        return super().count()

    def get_attribute(self,name):
        if self.kind=='grade_button' and name=='aria-expanded':return str(self.page.menu_open).lower()
        return super().get_attribute(name)

    def locator(self,selector):
        if self.kind=='grade_container' and selector=='button':return MenuNode(self.page,'grade_button')
        if self.kind=='grade_menu' and selector=='button':
            return type('Options',(),{'all':lambda _: [MenuNode(self.page,'grade_option',g) for g in self.page.labels()]})()
        return super().locator(selector)


class DelayedPage(Page):
    def __init__(self,username='test@te.mehe.school'):
        super().__init__(3,account=username)
        self.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
        self.now=0;self.show_at=0;self.ready_at=0;self.duplicate=False;self.multiple=False;self.never=False
        self.on_wait=lambda:None

    def labels(self):
        if self.never:return [ALL]
        if self.now<self.ready_at:return [ALL,FIRST]
        return [ALL,FIRST,'الاول اساسي'] if self.duplicate else [ALL,FIRST,LAST,'الروضة الأولى']

    def locator(self,selector):
        if selector=='xpath=//span[normalize-space(.)="الصف"]/parent::div':return MenuNode(self,'grade_container')
        if selector=='div.max-h-60.overflow-y-auto':
            node=MenuNode(self,'grade_menu')
            if self.multiple:return type('Menus',(),{'all':lambda _:[node,MenuNode(self,'grade_menu')]})()
            return node
        return super().locator(selector)

    def wait_for_timeout(self,ms):
        self.now+=ms/1000;self.on_wait()


class GradeMenuTests(unittest.TestCase):
    def browser(self,page,cancel=None):return StudentBrowser(page,page.account,cancel or threading.Event())

    def test_direction_marks_and_multiline_captions_select_requested_grade(self):
        page=DelayedPage();page.labels=lambda:['\u200f'+ALL+'\u200e','  الروضة\n الثالثة\u200f ',FIRST]
        with patch('student_scan.time.monotonic',lambda:page.now):self.browser(page).select_grade('الروضة الثالثة')
        self.assertEqual(page.grade,'  الروضة\n الثالثة\u200f ')
        self.assertEqual(len([a for a in page.actions if a[0]=='grade']),1)

    def test_open_menu_is_reused_without_toggling_for_both_shifts(self):
        for username in ('test@te.mehe.school','test@te.pm.mehe.school'):
            for show_at in (0,2):
                page=DelayedPage(username);page.menu_open=True;page.show_at=page.ready_at=show_at
                with patch('student_scan.time.monotonic',lambda:page.now):
                    _,labels=self.browser(page).open_grades()
                self.assertIn(FIRST,labels);self.assertTrue(page.menu_open)
                self.assertEqual(page.actions,[])

    def test_late_requested_grade_is_awaited_after_partial_menu_with_one_open_click(self):
        page=DelayedPage();page.show_at=2;page.ready_at=12
        with patch('student_scan.time.monotonic',lambda:page.now):self.browser(page).select_grade(LAST)
        self.assertGreaterEqual(page.now,12);self.assertEqual(page.grade,LAST);self.assertFalse(page.menu_open)
        self.assertEqual(page.actions.count(('click','grade_button',None)),1)
        self.assertEqual([a for a in page.actions if a[0]=='grade'],[('grade',LAST)])

    def test_selected_grade_menu_is_closed_before_roster_read_without_reselection(self):
        page=DelayedPage();page.grade=FIRST;page.menu_open=True;browser=self.browser(page);browser.selected_grade=FIRST
        with patch('student_scan.time.monotonic',lambda:page.now):state=browser.move(1)
        self.assertFalse(page.menu_open);self.assertEqual(len(state['rows']),1)
        self.assertFalse(any(a[0]=='grade' for a in page.actions))

    def test_listing_grades_waits_for_stable_options_then_closes_the_menu(self):
        page=DelayedPage();page.ready_at=.4
        with patch('student_scan.time.monotonic',lambda:page.now):grades=self.browser(page).grades()
        self.assertEqual(grades,['الروضة الأولى',FIRST,LAST]);self.assertGreaterEqual(page.now,1.1)
        self.assertFalse(page.menu_open)

    def test_ambiguous_missing_or_unready_options_never_select_a_grade(self):
        for failure in ('duplicate','missing','unready','multiple'):
            page=DelayedPage()
            if failure=='duplicate':page.duplicate=True
            if failure=='missing':page.ready_at=100
            if failure=='unready':page.never=True
            if failure=='multiple':page.multiple=True;page.menu_open=True
            with patch('student_scan.time.monotonic',lambda:page.now),self.assertRaises(ScanError) as error:
                self.browser(page).select_grade(LAST)
            self.assertEqual(error.exception.reason,'grade_options')
            self.assertFalse(any(a[0]=='grade' for a in page.actions))
            self.assertLessEqual(page.actions.count(('click','grade_button',None)),1)

    def test_account_or_cancellation_during_wait_aborts_before_option_click(self):
        for failure in ('account','cancel'):
            page=DelayedPage();page.ready_at=100;cancel=threading.Event();browser=self.browser(page,cancel)
            def changed():
                if page.now>=.4:
                    if failure=='account':page.account='other@te.mehe.school'
                    else:cancel.set()
            page.on_wait=changed
            with patch('student_scan.time.monotonic',lambda:page.now),self.assertRaises(ScanError) as error:browser.select_grade(LAST)
            self.assertEqual(error.exception.code,'scan_account_required' if failure=='account' else 'scan_cancelled')
            self.assertFalse(any(a[0]=='grade' for a in page.actions))


if __name__=='__main__':unittest.main()
