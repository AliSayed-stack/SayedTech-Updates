"""Synthetic explicit-command starting page; no school records or live session."""
import threading
import unittest
from test_student_save import Page
from student_fill import StudentFillError,MANAGEMENT
from student_start import reset_management

class StudentStartTests(unittest.TestCase):
    def test_both_shifts_reset_even_management_or_an_existing_search(self):
        for domain in ('te.mehe.school','te.pm.mehe.school'):
            for path in (MANAGEMENT,MANAGEMENT+'/new','/dashboard/analytics'):
                p=Page('test@'+domain);p.url='https://new-sims.mehe.gov.lb'+path
                before=dict(p.values);reset_management(p,p.account,p.cancelled)
                self.assertEqual(p.url,'https://new-sims.mehe.gov.lb'+MANAGEMENT)
                self.assertEqual([a[0] for a in p.actions],['goto']);self.assertEqual(p.values,before)
    def test_wrong_account_cancel_or_other_host_never_navigates(self):
        for kind in ('account','cancel','host'):
            p=Page()
            if kind=='account':p.email_visible=False
            if kind=='cancel':p.cancelled.set()
            if kind=='host':p.url='https://example.com/'
            with self.assertRaises(StudentFillError):reset_management(p,p.account,p.cancelled)
            self.assertEqual(p.actions,[])
    def test_bad_redirect_and_failed_navigation_stop(self):
        for kind in ('redirect','failure'):
            p=Page()
            def goto(url,**kw):
                p.actions.append(('goto',url))
                if kind=='failure':raise RuntimeError('synthetic')
                p.url='https://new-sims.mehe.gov.lb/login'
            p.goto=goto
            with self.assertRaises(StudentFillError):reset_management(p,p.account,p.cancelled)
            self.assertEqual(len(p.actions),1)
