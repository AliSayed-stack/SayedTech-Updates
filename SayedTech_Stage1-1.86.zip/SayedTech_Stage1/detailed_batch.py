"""Sequential detail imports for the rows explicitly selected in Excel."""
import uuid
from detail_scope import in_grade,scoped_record

SUCCESS={
    'details_import':frozenset({'detail_import_saved'}),
    'details_import_review':frozenset({'detail_import_review_sent','detail_import_review_already'})}


class DetailedImportBatch:
    def __init__(self,rows):
        self.rows=rows
        self.mode=None;self.pending=None;self.index=0;self.active=False
        self.stopping=False;self.event='';self.field=''
        self.completed={mode:set() for mode in SUCCESS}
        self.grade=None
        self.selected=None
        self.use_open_student=False
        self.sections=None

    def start(self,with_review,grade=None,selected=None,*,use_open_student=False,sections=None):
        if self.active or self.pending:return False
        if use_open_student and (with_review or selected is None or len(selected)!=1):
            return False
        self.use_open_student=use_open_student
        self.sections=None if sections is None else tuple(sorted(set(sections)))
        self.grade=grade
        self.selected=None if selected is None else frozenset(selected)
        self.mode='details_import_review' if with_review else 'details_import'
        self.index=0;self.stopping=False;self.event='';self.field=''
        self.active=True;self._advance()
        return True

    def eligible(self,index):
        return (self.selected is None or index in self.selected) and in_grade(self.rows[index],self.grade)

    def _advance(self):
        done=self.completed_for(self.mode)
        while self.index<len(self.rows) and (not self.eligible(self.index) or self.index in done):self.index+=1
        if self.index>=len(self.rows):self.active=False

    def request(self):
        if not self.active or self.pending:return None
        self.pending=uuid.uuid4().hex
        row=scoped_record(self.rows[self.index],self.grade)
        if self.use_open_student:row=dict(row,use_open_student=True)
        if self.sections is not None:row=dict(row,selected_detail_sections=list(self.sections))
        return row,self.mode,self.pending

    def result(self,request,event,field=''):
        if request!=self.pending or self.pending is None:return False
        self.pending=None;self.event=event;self.field=field
        skipped=event=='detail_import_skipped_section' or (event=='detail_no_data' and self.sections is not None)
        if not skipped and event not in SUCCESS[self.mode]:self.active=False;return True
        self.completed_for(self.mode).add(self.index)
        if self.mode=='details_import_review' and not skipped:self.completed_for('details_import').add(self.index)
        self.index+=1
        if self.stopping:self.active=False
        else:self._advance()
        return True

    def stop_after_current(self):
        self.stopping=True
        if self.pending is None:self.active=False

    def disconnect(self):
        self.active=False;self.pending=None;self.event='detail_account'

    @property
    def done(self):
        return sum(self.eligible(i) for i in self.completed_for(self.mode))

    def completed_for(self,mode):
        key=mode if self.sections is None else (mode,self.sections)
        return self.completed.setdefault(key,set())

    @property
    def total(self):
        return sum(self.eligible(i) for i in range(len(self.rows)))

    @property
    def position(self):
        return sum(self.eligible(i) for i in range(min(self.index+1,len(self.rows))))
