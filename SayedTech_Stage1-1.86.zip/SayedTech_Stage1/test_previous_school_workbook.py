import tempfile
from pathlib import Path
import threading
import unittest
from zipfile import ZipFile

from previous_school_workbook import add_previous_school_type
from student_detailed import write_prepared
from student_excel import PREVIOUS_SCHOOL_TYPE_HEADER, PREVIOUS_SCHOOL_TYPES, CURRENT_GRADE_FIELD, BY_ID, NS
from student_scan import empty_result,export_students
from student_site_merge import named_rows,UID,NAME_COLUMNS
from student_unified import ENTRY_KIND,UNIFIED_HEADERS
from previous_academic import HEADERS as ACADEMIC_HEADERS, SCHOOL, GRADE, LIST_NUMBER, RESULT, STATE


class PreviousSchoolWorkbookTests(unittest.TestCase):
    def test_appends_column_to_scan_and_ignores_deleted_students(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'scan.xlsx'
            target=Path(folder)/'new.xlsx'
            records=[empty_result(dict(uid=uid,first='اسم',middle='أب',last='شهرة',
                        grade='الثاني أساسي',language='الفرنسية',section='أ',status=status))
                     for uid,status in (('001','مسجل'),('002','محذوف'))]
            records.append(empty_result(dict(uid='003',first='طفل',middle='أب',last='اختبار',
                           grade='الروضة الثالثة',language='الفرنسية',section='أ',status='مسجل')))
            export_students({'records':records,'inventory':3},source,threading.Event())
            before=source.read_bytes()
            self.assertEqual(add_previous_school_type(source,target),2)
            self.assertEqual(source.read_bytes(),before)
            with ZipFile(target) as workbook:
                from student_excel import ADDRESS_STATUS_HEADER
                columns,rows=named_rows(workbook,'الطلاب',skip_columns=(ADDRESS_STATUS_HEADER,))
                import xml.etree.ElementTree as ET
                part=next(name for name in workbook.namelist() if name.startswith('xl/tables/'))
                table=ET.fromstring(workbook.read(part))
                self.assertEqual([node.get('name') for node in table.find('m:tableColumns',NS)[-6:]],list(ACADEMIC_HEADERS))
                sheet=ET.fromstring(workbook.read('xl/worksheets/sheet1.xml'))
                options='"'+','.join(PREVIOUS_SCHOOL_TYPES.values())+'"'
                self.assertIn(options,[element.text for element in sheet.findall('m:dataValidations/m:dataValidation/m:formula1',NS)])
            self.assertTrue(set(ACADEMIC_HEADERS).issubset(columns))
            self.assertEqual(rows[2][PREVIOUS_SCHOOL_TYPE_HEADER],'التعليم الرسمي')
            self.assertEqual(rows[3][PREVIOUS_SCHOOL_TYPE_HEADER],'')
            self.assertEqual(rows[4][PREVIOUS_SCHOOL_TYPE_HEADER],'جديد')

    def test_keeps_manual_values_and_sets_kindergarten_default(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'unified.xlsx'
            target=Path(folder)/'new.xlsx'
            grade=BY_ID[CURRENT_GRADE_FIELD]['label']
            data=[{UID:'001',ENTRY_KIND:'طالب موجود',PREVIOUS_SCHOOL_TYPE_HEADER:'التعليم الخاص'},
                  {UID:'002',ENTRY_KIND:'طالب موجود',grade:'الروضة الثالثة',PREVIOUS_SCHOOL_TYPE_HEADER:'التعليم الرسمي'},
                  {NAME_COLUMNS[0]:'جديد',NAME_COLUMNS[-1]:'اختبار',ENTRY_KIND:'طالب جديد'}]
            write_prepared([[row.get(label,'') for label in UNIFIED_HEADERS] for row in data],
                           source,True,'synthetic.db','test')
            self.assertEqual(add_previous_school_type(source,target),1)
            with ZipFile(target) as workbook:
                _,rows=named_rows(workbook,'الطلاب')
            self.assertEqual(rows[2][PREVIOUS_SCHOOL_TYPE_HEADER],'التعليم الخاص')
            self.assertEqual(rows[3][PREVIOUS_SCHOOL_TYPE_HEADER],'جديد')
            self.assertEqual(rows[3][ENTRY_KIND],'طالب موجود')
            self.assertEqual(rows[4][PREVIOUS_SCHOOL_TYPE_HEADER],'')

    def test_derives_previous_year_columns_without_using_older_sequence(self):
        with tempfile.TemporaryDirectory() as folder:
            source=Path(folder)/'unified.xlsx';target=Path(folder)/'new.xlsx'
            row={UID:'001',ENTRY_KIND:'طالب موجود',BY_ID[CURRENT_GRADE_FIELD]['label']:'الثاني أساسي',
                 'السنة في القاعدة':'2025/2026','الصف الأصلي في القاعدة':'الأول أساسي',
                 'النتيجة النهائية في القاعدة':'ناجح','اسم المدرسة في القاعدة':'مدرسة تجريبية',
                 'التسلسل الدراسي (SequenceNb)':'0008','التسلسل الدراسي السابق (PrevSequenceNb)':'0032'}
            write_prepared([[row.get(label,'') for label in UNIFIED_HEADERS]],source,True,'synthetic.db','test')
            self.assertEqual(add_previous_school_type(source,target),1)
            with ZipFile(target) as workbook:
                _,rows=named_rows(workbook,'الطلاب')
            self.assertEqual([rows[2][key] for key in (SCHOOL,GRADE,LIST_NUMBER,RESULT,STATE)],
                             ['مدرسة تجريبية','الأول أساسي','0008','ناجح','مترفع'])
