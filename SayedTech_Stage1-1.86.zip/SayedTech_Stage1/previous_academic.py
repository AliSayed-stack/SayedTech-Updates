"""Excel data and live SIMS controls for the previous school year."""
import math
import time

from student_excel import BY_ID, CURRENT_GRADE_FIELD, PREVIOUS_SCHOOL_TYPE_HEADER, PREVIOUS_SCHOOL_TYPES, previous_school_default


SCHOOL = 'المدرسة السابقة'
GRADE = 'الصف السابق'
LIST_NUMBER = 'رقم الطالب على لائحة السنة السابقة'
RESULT = 'نتيجة السنة الدراسية السابقة'
STATE = 'وضع الطالب'
GRADE_OPTIONS = dict(zip(
    [f'kg_{n}' for n in range(1,4)]+[f'grade_{n}' for n in range(1,10)]+[f'secondary_{n}' for n in range(1,4)],
    ['الروضة الأولى','الروضة الثانية','الروضة الثالثة']+
    [f'{ordinal} أساسي' for ordinal in ('الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع')]+
    [f'{ordinal} ثانوي' for ordinal in ('الأول','الثاني','الثالث')]))
FIELDS = {
    PREVIOUS_SCHOOL_TYPE_HEADER:('previousSchoolType',PREVIOUS_SCHOOL_TYPES),
    SCHOOL:('previousSchoolId',None),
    GRADE:('previousGradeLevel',GRADE_OPTIONS),
    LIST_NUMBER:('previousListNumber',None),
    RESULT:('previousAcademicYearResult',{'passed':'ناجح','failed':'راسب'}),
    STATE:('studentState',{'repeater':'معيد','promoted':'مترفع','from_home':'من البيت','discontinued':'منقطع'}),
}
HEADERS = tuple(FIELDS)
DROPDOWNS = {label:options for label,(_,options) in FIELDS.items() if options}


def from_excel(row):
    return {key:row[label] for label,(key,_) in FIELDS.items() if label in row}


def has_data(record):
    values=record.get('values',{})
    return any(values.get(key) not in ('',None) for key,_ in FIELDS.values())


def grade_code(value):
    if value in GRADE_OPTIONS:return value
    from student_scan import grade_rank,ScanError
    try:return tuple(GRADE_OPTIONS)[grade_rank(value)-1]
    except (ScanError,IndexError):return ''


def workbook_defaults(row):
    from nsldb_reference import TARGET_YEAR, canonical_year
    from manual_sections import norm
    current=row.get(BY_ID[CURRENT_GRADE_FIELD]['label'],'')
    defaults={PREVIOUS_SCHOOL_TYPE_HEADER:previous_school_default(current)}
    if canonical_year(row.get('السنة في القاعدة',''))!=TARGET_YEAR:
        return defaults
    grade=grade_code(row.get('الصف الأصلي في القاعدة',''))
    result={'ناجح':'ناجح','نجاح':'ناجح','راسب':'راسب','رسوب':'راسب',
            'succ':'ناجح','usuc':'راسب'}.get(norm(row.get('النتيجة النهائية في القاعدة','')).casefold(),'')
    sequence=row.get('التسلسل الدراسي (SequenceNb)','')
    if isinstance(sequence,(int,float)) and not isinstance(sequence,bool) and math.isfinite(sequence) and int(sequence)==sequence:
        sequence=str(int(sequence))
    defaults.update({SCHOOL:row.get('اسم المدرسة في القاعدة',''), GRADE:GRADE_OPTIONS.get(grade,''),
                     LIST_NUMBER:sequence, RESULT:result})
    now=grade_code(current)
    if grade and now and result:
        grades=tuple(GRADE_OPTIONS)
        advance=grades.index(now)-grades.index(grade)
        if result=='ناجح' and advance==1:defaults[STATE]='مترفع'
        if result=='راسب' and advance==0:defaults[STATE]='معيد'
    return defaults


def planned_values(record):
    from detailed_import import DetailError
    values=record.get('values',{})
    plan=[]
    for label,(key,options) in FIELDS.items():
        value=values.get(key)
        if value in ('',None):continue
        if (key in ('previousListNumber','previousSchoolId') and isinstance(value,(int,float)) and not isinstance(value,bool)
                and math.isfinite(value) and int(value)==value and value>=0):
            value=str(int(value))
        if not isinstance(value,str) or len(value)>256 or any(ord(c)<32 for c in value):
            raise DetailError('detail_input',label)
        value=value.strip()
        if not value:continue
        if options:
            value={caption:code for code,caption in options.items()}.get(value,value)
            if value not in options:raise DetailError('detail_input',label)
        plan.append((label,key,value,options))
    return plan


def choose_school(page,scope,wanted,guard):
    from detailed_import import DetailError,norm
    trigger=scope.locator('button#field-previousSchoolId[aria-haspopup="listbox"]')
    try:trigger.wait_for(state='visible',timeout=5000)
    except Exception:raise DetailError('detail_options',SCHOOL) from None
    guard()
    if trigger.count()!=1:raise DetailError('detail_options',SCHOOL)
    current=norm(trigger.inner_text())
    if current==norm(wanted):return False
    if current not in ('','اختر مدرسة','--اختيار--'):raise DetailError('detail_existing',SCHOOL)
    if not trigger.is_enabled():raise DetailError('detail_options',SCHOOL)
    trigger.click(timeout=5000)
    deadline=time.monotonic()+10
    searched=False
    while time.monotonic()<deadline:
        guard()
        controls=trigger.get_attribute('aria-controls')
        menus=[item for item in page.get_by_role('listbox').all()
               if item.is_visible() and (not controls or item.get_attribute('id')==controls)]
        if len(menus)>1:raise DetailError('detail_options',SCHOOL)
        if menus:
            menu=menus[0]
            options=[]
            for option in menu.get_by_role('option').all():
                if not option.is_visible() or not option.is_enabled():continue
                text=[norm(line) for line in option.inner_text().splitlines() if norm(line)]
                if norm(wanted) in text or wanted in (option.get_attribute('data-value'),option.get_attribute('value')):
                    options.append((option,text))
            if len(options)>1:raise DetailError('detail_options',SCHOOL)
            if options:
                option,text=options[0]
                guard();option.click(timeout=5000);guard()
                if norm(trigger.inner_text()) not in text or trigger.get_attribute('aria-expanded')=='true':
                    raise DetailError('detail_options',SCHOOL)
                return True
            search=[item for item in menu.locator('input[type="search"], input[type="text"]').all() if item.is_visible()]
            if not searched and len(search)==1 and search[0].is_enabled():
                guard();search[0].fill(wanted,timeout=3000);searched=True
        page.wait_for_timeout(100)
    raise DetailError('detail_options',SCHOOL)
