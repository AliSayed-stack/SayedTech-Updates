import tempfile
from pathlib import Path
import threading
import unittest
from zipfile import ZipFile

from student_detailed import write_prepared
from student_scan import empty_result, export_students
from student_site_merge import merge_site_workbooks, named_rows, UID, BIRTH, NAME_COLUMNS
from student_unified import UNIFIED_HEADERS, MATCH_COLUMN, selected_rows
from test_student_workflow import selections


class SiteMergeTests(unittest.TestCase):
    def test_full_database_export_keeps_reference_only_headers(self):
        from nsldb_reference import DETAILED_CHOICE, map_records, write_reference
        from test_nsldb import tables
        with tempfile.TemporaryDirectory() as directory:
            base,scan,output=[Path(directory)/f'{name}.xlsx' for name in ('raw','scan','merged')]
            write_reference(map_records(tables())[:1],base,'synthetic.sdf','0'*64,[],mode='detailed')
            with ZipFile(base) as book:
                _,original=named_rows(book,'الطلاب')
            uid=next(row[UID] for row in original.values() if row[UID] and str(row[UID]).strip('0'))
            record=empty_result(dict(uid=uid,first='TEST',middle='TEST',last='TEST',
                                    grade='الثاني أساسي',status='مسجل',language='الفرنسية',section='أ'))
            export_students({'records':[record],'inventory':1},scan,threading.Event())
            self.assertEqual(merge_site_workbooks(base,scan,output),(1,1))
            with ZipFile(output) as book:
                columns,rows=named_rows(book,'الطلاب')
                self.assertIn(DETAILED_CHOICE,columns)
                self.assertEqual(rows[2][MATCH_COLUMN],'SIMS وNSLDB')

    def test_outputs_sims_roster_and_preserves_matching_database_columns(self):
        with tempfile.TemporaryDirectory() as directory:
            base, scan, output = [Path(directory) / f'{name}.xlsx' for name in ('base','sims','merged')]
            stored = [
                {UID:'001', BIRTH:'2015/02/03', NAME_COLUMNS[0]:'قديم', 'معرّف الشخص في القاعدة':'db1',
                 'محافظة السكن':'الجنوب', 'هاتف الترشيح (OEPhone)':'03123457'},
                {UID:'002', BIRTH:'2015/02/03', NAME_COLUMNS[0]:'بالقاعدة فقط', 'معرّف الشخص في القاعدة':'db2'},
            ]
            write_prepared([[row.get(label,'') for label in UNIFIED_HEADERS] for row in stored],
                           base,True,'synthetic.db','test')
            original=base.read_bytes()
            records=[]
            for uid,first,status in [('001','محدث','مسجل'),('003','على الموقع','مسجل'),('004','محذوف','محذوف')]:
                result=empty_result(dict(uid=uid,first=first,middle='أب',last='عائلة',
                                        grade='الروضة الثالثة' if uid=='003' else 'الثاني أساسي',
                                        status=status,language='الفرنسية',section='أ'))
                result['values']['field-birthDate']='2015-02-03'
                result['read_ids'].append('field-birthDate')
                result['address']={'المحافظة':'الشمال'}
                records.append(result)
            export_students({'records':records,'inventory':3},scan,threading.Event())
            self.assertEqual(merge_site_workbooks(base,scan,output),(2,1))
            self.assertEqual(base.read_bytes(),original)
            with ZipFile(output) as book:
                columns, rows=named_rows(book,'الطلاب')
            self.assertEqual(columns,set(UNIFIED_HEADERS)|{MATCH_COLUMN})
            self.assertEqual([row[UID] for row in rows.values()],['001','003'])
            self.assertEqual(rows[2][NAME_COLUMNS[0]],'محدث')
            self.assertEqual(rows[2]['محافظة السكن'],'الشمال')
            self.assertEqual(rows[2]['معرّف الشخص في القاعدة'],'db1')
            self.assertEqual(rows[2]['هاتف الترشيح (OEPhone)'],'03123457')
            self.assertEqual(rows[3]['معرّف الشخص في القاعدة'],'')
            self.assertEqual(rows[3][MATCH_COLUMN],'SIMS فقط')
            self.assertEqual(rows[2]['نوع المدرسة السابقة'],'التعليم الرسمي')
            self.assertEqual(rows[3]['نوع المدرسة السابقة'],'جديد')
            selections(output,{3:1})
            with ZipFile(output) as book:
                selected=selected_rows(book,'detailed')
            self.assertEqual(selected[0][1][UID],'003')
            self.assertTrue(selected[0][1]['_site_merge_existing'])
