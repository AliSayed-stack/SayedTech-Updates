"""One editable workbook; each import validates only its own input fields."""
from student_excel import FIELDS, HEADERS, NS, ExcelInputError, validate_record, optional_registry
from student_workflow import workbook_rows, selection_value
from nsldb_reference import REFERENCE_EXTRA, DETAIL_HEADERS, TARGET_YEAR, canonical_year
from student_detailed import ADDRESS_COLUMNS
from name_transliteration import suggest_english_names
import xml.etree.ElementTree as ET
from io import BytesIO
import zipfile
import hashlib
import os
import re
import tempfile
from pathlib import Path
from student_workflow import column
from name_transliteration import NAME_PAIRS

MARKER = 'الملف الموحد'
SELECTION = 'اختيار للاستيراد'
from student_promotion import PROMOTION_HEADERS
OLD_ADDRESS_COLUMNS = ADDRESS_COLUMNS[:-1]
LEGACY_HEADERS = [SELECTION] + HEADERS + REFERENCE_EXTRA[2:] + DETAIL_HEADERS + OLD_ADDRESS_COLUMNS
PREVIOUS_HEADERS = LEGACY_HEADERS + PROMOTION_HEADERS
ENTRY_KIND = 'طريقة تسجيل الطالب'
UNIFIED_HEADERS = PREVIOUS_HEADERS + ['نوع السكن', ENTRY_KIND]


def is_unified(z):
    data=z.read('xl/workbook.xml')
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():raise ExcelInputError('بنية XML غير مدعومة.')
    return any(s.get('name')==MARKER for s in ET.fromstring(data).findall('m:sheets/m:sheet',NS))


def selected_rows(z, purpose):
    marker=workbook_rows(z,MARKER)
    if any(f for _,_,f in marker):raise ExcelInputError('مرجع الملف الموحد غير صالح.')
    info={v.get('A'):v.get('B') for _,v,_ in marker}
    if info.get('نوع الملف')!='unified_students' or str(info.get('السنة الدراسية'))!=TARGET_YEAR:
        raise ExcelInputError('اختر الملف الموحد لعام 2025–2026.')
    rows=workbook_rows(z,'الطلاب')
    if not rows or rows[0][0]!=1 or rows[0][2]:raise ExcelInputError('عناوين الملف غير صالحة.')
    headers=rows[0][1]
    if headers.get('A')!=SELECTION or not any(len(headers)==len(schema) and set(headers.values())==set(schema) for schema in (UNIFIED_HEADERS,PREVIOUS_HEADERS,LEGACY_HEADERS)):
        raise ExcelInputError('عناوين الملف الموحد مختلفة؛ لا تغيّر أسماء الأعمدة.')
    relevant=set(HEADERS) if purpose=='simple' else {
        f['label'] for f in FIELDS if f['id'] in ('field-firstName','field-middleName','field-lastName','field-birthDate','field-existingUniqueId')}
    if purpose=='detailed':relevant.update(ADDRESS_COLUMNS+['رقم الهاتف (LivingPhone)'])
    relevant.update([SELECTION,ENTRY_KIND,'السنة في القاعدة','معرّف المدرسة في القاعدة','معرّف الشخص في القاعدة'])
    selected=[]
    for number,values,formulas in rows[1:]:
        if 'A' in formulas:raise ExcelInputError(f'الصف {number}: الاختيار يدوي دون معادلات.')
        try:chosen=selection_value(values.get('A',''))
        except ValueError:raise ExcelInputError(f'الصف {number}: استخدم 0 أو 1 أو نعم أو لا في أول عمود.') from None
        if not chosen:continue
        if any(headers.get(c) in relevant for c in formulas):
            raise ExcelInputError(f'الصف {number}: البيانات المستخدمة للاستيراد يجب أن تكون قيماً ثابتة.')
        if any(c not in headers and v!='' for c,v in values.items()):raise ExcelInputError('بيانات خارج أعمدة الملف.')
        row={label:values.get(c,'') for c,label in headers.items()}
        kind=str(row.get(ENTRY_KIND,'طالب موجود') or 'طالب موجود').strip()
        if kind not in ('طالب موجود','طالب جديد'):
            raise ExcelInputError(f'الصف {number}: طريقة تسجيل الطالب يجب أن تكون طالب موجود أو طالب جديد.')
        if kind=='طالب موجود' and canonical_year(row['السنة في القاعدة'])!=TARGET_YEAR:
            raise ExcelInputError('الاستيراد مخصص لعام 2025–2026.')
        uid_label=next(f['label'] for f in FIELDS if f['id']=='field-existingUniqueId')
        if kind=='طالب جديد' and (row.get('معرّف الشخص في القاعدة') or row.get('معرّف المدرسة في القاعدة') or row.get(uid_label)):
            raise ExcelInputError(f'الصف {number}: صف الطالب الجديد لا يحمل معرّفاً من القاعدة؛ راجع اختيار طريقة التسجيل.')
        row[ENTRY_KIND]=kind
        selected.append((number,row))
    if not selected:raise ExcelInputError('لم تختر أي طالب. ضع 1 أو نعم في أول عمود واحفظ الملف.')
    return selected


def read_simple_unified(z, shift='morning'):
    result=[];seen={}
    for number,row in selected_rows(z,'simple'):
        raw=suggest_english_names({f['id']:row[f['label']] for f in FIELDS})
        values,errors=validate_record(raw, shift)
        item={'excel_row':number,'values':values,'errors':errors,'address':{},'workflow':True,'unified':True,
              'entry_kind':row[ENTRY_KIND],
              'reference':{label:row[label] for label in REFERENCE_EXTRA[2:]},
              'warnings':optional_registry(raw,shift)[1]}
        # Match existing simple-import behavior for selected nonblank UIDs.
        uid=values.get('field-existingUniqueId')
        if uid:
            if uid in seen:
                errors.append('الرقم الموحد مكرر ضمن الطلاب المختارين')
                seen[uid]['errors'].append('الرقم الموحد مكرر ضمن الطلاب المختارين')
            else:seen[uid]=item
        result.append(item)
    return result


def convert_to_unified(source,destination):
    from student_detailed import convert_to_detailed
    return convert_to_detailed(source,destination,unified=True)


def translate_manual_names(path):
    """Fill empty English cells for manual rows in the same workbook on request."""
    path=Path(path)
    if path.suffix.lower()!='.xlsx' or not path.is_file() or path.stat().st_size>64_000_000:
        raise ExcelInputError('اختر الملف الموحد بصيغة xlsx.')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(path) as z:
        if not is_unified(z):raise ExcelInputError('اختر الملف الموحد.')
        rows=workbook_rows(z,'الطلاب')
        if not rows or set(rows[0][1].values())!=set(UNIFIED_HEADERS) or len(rows[0][1])!=len(UNIFIED_HEADERS):
            raise ExcelInputError('اختر أحدث ملف موحد.')
        headers=rows[0][1]
        parts={n:z.read(n) for n in z.namelist()}
    by_name={f['id']:f['label'] for f in FIELDS}
    wanted={headers_inv:column_id for column_id,headers_inv in headers.items()}
    proposals={}
    for number,values,formulas in rows[1:]:
        kind=str(values.get(wanted[ENTRY_KIND],'')).strip()
        if kind == 'طالب جديد':
            is_manual=True
        elif not kind:
            # Rows added directly in Excel may not have had their route dropdown
            # set yet. Imported NSLDB rows always carry source identities; use
            # those to distinguish them from a genuinely hand-entered student.
            source_identity_labels=('معرّف الشخص في القاعدة','معرّف المدرسة في القاعدة')
            source_identity=any(str(values.get(wanted.get(label,''),'')).strip()
                                for label in source_identity_labels if label in wanted)
            arabic_names=any(str(values.get(wanted[by_name[arabic]],'')).strip()
                             for arabic,_ in NAME_PAIRS)
            is_manual=arabic_names and not source_identity
        else:
            is_manual=False
        if not is_manual:continue
        raw={arabic:values.get(wanted[by_name[arabic]],'') for arabic,_ in NAME_PAIRS}
        raw.update({english:values.get(wanted[by_name[english]],'') for _,english in NAME_PAIRS})
        translated=suggest_english_names(raw)
        for _,english in NAME_PAIRS:
            letter=wanted[by_name[english]]
            if letter in formulas:raise ExcelInputError(f'الصف {number}: الترجمة لا تعدّل خلية فيها معادلة.')
            if not values.get(letter) and translated.get(english):
                proposals[(number,letter)]=translated[english]
    if not proposals:return 0
    q=lambda name:'{'+NS['m']+'}'+name
    sheet_xml=parts['xl/worksheets/sheet1.xml']
    # ElementTree otherwise rewrites namespace prefixes (for example the
    # prefixes named in mc:Ignorable), which can make Excel discard sheet1.xml.
    for _event,(prefix,uri) in ET.iterparse(BytesIO(sheet_xml),events=('start-ns',)):
        if prefix != 'xml' and not re.fullmatch(r'ns\d+',prefix or ''):
            ET.register_namespace(prefix or '',uri)
    sheet=ET.fromstring(sheet_xml)
    for row in sheet.findall('m:sheetData/m:row',NS):
        number=int(row.get('r','0'))
        if not any(n==number for n,_ in proposals):continue
        cells={c.get('r'):c for c in row.findall('m:c',NS)}
        for (n,letter),value in proposals.items():
            if n!=number:continue
            ref=letter+str(number)
            cell=cells.get(ref)
            if cell is None:cell=ET.Element(q('c'),r=ref);row.append(cell)
            for child in list(cell):cell.remove(child)
            cell.set('t','inlineStr')
            ET.SubElement(ET.SubElement(cell,q('is')),q('t')).text=value
        cell_tag=q('c')
        cells_in_row=[child for child in row if child.tag==cell_tag]
        other_children=[child for child in row if child.tag!=cell_tag]
        cells_in_row.sort(key=lambda c:UNIFIED_HEADERS.index(
            headers[''.join(x for x in c.get('r','') if x.isalpha())]))
        row[:]=cells_in_row+other_children
    parts['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
        raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,suffix='.xlsx',delete=False) as file:temporary=Path(file.name)
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
            for name,data in parts.items():z.writestr(name,data)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ExcelInputError('تغيّر الملف أثناء الترجمة؛ أغلق Excel وأعد المحاولة.')
        os.replace(temporary,path)
    except OSError:
        raise ExcelInputError('أغلق ملف Excel وتأكد من صلاحية الكتابة ثم أعد الترجمة.') from None
    finally:
        if temporary and temporary.exists():temporary.unlink()
    return len(proposals)
