"""User-run, read-only student inventory and bounded form inspection.

No save/add/fill operation, network interception, or private API is used.
Only observed table rows, pagination controls and student tabs are opened.
"""
import copy
import hashlib
from collections import Counter
import math
import os
from pathlib import Path
import re
import tempfile
import time
from datetime import date
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET
import zipfile

import core
from login_flow import exact_https_host, SIMS_HOST, visible
from student_fill import MANAGEMENT
from student_excel import FIELDS, BY_ID, ADDRESS_HEADERS, NS, REL
from manual_sections import SPECS, TAIL_HEADERS as MANUAL_HEADERS, MAP_SHEET, MOTHER_SURNAME, observed_values

TABS = ('المعلومات الشخصية', 'الجنسيات والقيد', 'عناوين السكن', 'الهواتف',
        'البريد الإلكتروني', 'الأقارب', 'بطاقات التعريف', 'المستندات', 'حالة التسجيل')
TABLE_HEADERS = ('الرقم الموحد للطالب', 'الاسم الأول', 'اسم الأب', 'الشهرة',
                 'صف الطالب', 'فرع الصف', 'لغة التدريس', 'الشعبة', 'المدرسة',
                 'الحالة', 'نتائج امتحان الدخول')
REPORT_SHEET = 'حالة السحب'
HEADER_FIELDS = {'uid':('الرقم الموحد للطالب',),'first':('الاسم الأول',),'middle':('اسم الأب',),
    'last':('الشهرة',),'grade':('صف الطالب','الصف'),'language':('لغة التدريس','لغة التعليم'),
    'section':('الشعبة','شعبة الصف')}
OPTIONAL_HEADERS = {'status':('الحالة','حالة الطالب'),'branch':('فرع الصف',),'school':('المدرسة',)}
GRADE_REASONS = frozenset({'grade_menu_missing','grade_menu_multiple','grade_menu_unstable',
    'grade_target_missing','grade_target_disabled','grade_target_multiple','grade_not_applied','grade_menu_not_closed'})
REASONS = GRADE_REASONS | frozenset({'table_missing','headers_changed','pagination_missing','pagination_format',
    'filters_active','search_active','rows_invalid','page_size','loading',
    'page_not_changed','count_changed','row_count','record_timeout','list_changed','identity_changed','duplicate_record',
    'account_profile_missing','account_session_changed','grade_filter','grade_options','grade_coverage','selection_changed','checkpoint_write','checkpoint_invalid','checkpoint_mismatch','tab_timeout','controls_changed','unexpected_error','cancelled_by_user'})
EVENTS = frozenset({'scan_progress', 'scan_saved', 'scan_saved_partial', 'scan_cancelled',
    'scan_prepare', 'scan_account_required', 'scan_changed', 'scan_failed', 'scan_busy',
    'scan_unknown_grade', 'scan_empty','scan_paused','scan_paused_checkpoint','scan_grades','scan_roster'})


class ScanError(Exception):
    def __init__(self, code, reason=''):
        self.code = code
        self.reason = reason if reason in REASONS else ''


def clean_detail(detail):
    if not isinstance(detail, dict): return {}
    out = {}
    from scan_selection import clean_choices
    out.update(clean_choices(detail))
    if detail.get('stage') in {'prepare','pagination','inventory', 'read', 'export','resume'}: out['stage'] = detail['stage']
    if detail.get('reason') in REASONS:out['reason']=detail['reason']
    grade = detail.get('grade')
    if isinstance(grade, str) and len(grade) <= 128: out['grade'] = grade
    grades=detail.get('grades')
    if isinstance(grades,list) and 0<len(grades)<=50 and all(isinstance(g,str) and 0<len(g)<=128 for g in grades):
        out['grades']=grades
    for key in ('inventory', 'selected', 'unread', 'missing','read','skipped','grade_done','grade_total','grade_index','grade_count','resumed'):
        if type(detail.get(key)) is int and 0 <= detail[key] <= 5000: out[key] = detail[key]
    if detail.get('cause') in EVENTS:out['cause']=detail['cause']
    name=detail.get('recovery_file')
    if isinstance(name,str) and re.fullmatch(r'SayedTech_Recovery_[a-f0-9]{32}\.xlsx',name):out['recovery_file']=name
    return out


def normalized(text):
    text = re.sub('[\u064b-\u065f\u0670\u0640]', '', str(text))
    text = re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]', '', text)
    return ' '.join(text.translate(str.maketrans('أإآى', 'اااي')).split())


def field_label(text):
    return normalized(re.sub(r'\s*\*\s*$', '', str(text)))


def existing_field_key(section, field, fields):
    """Resolve only existing workbook fields, within the observed site's section."""
    label=field_label(field['label'])
    key=field.get('id','')
    if section=='النموذج عند الفتح':
        return key if key in BY_ID else None
    if section=='عناوين السكن':return None
    if section not in ('المعلومات الشخصية','الجنسيات والقيد','الأقارب','حالة التسجيل'):return None
    allowed=set(BY_ID)
    if section=='الجنسيات والقيد':
        allowed={'field-nationality','field-registryNumber','field-registryPlace'}
    elif section=='حالة التسجيل':
        allowed={k for k in BY_ID if k.startswith('field-enrollment-')}
    elif section=='الأقارب':
        allowed={k for k in BY_ID if any(x in k for x in ('father','Father','mother','Mother','middleName'))}
        group=field.get('group','')
        if group:
            relations=[f for f in fields if f.get('group')==group and field_label(f['label'])=='نوع العلاقة']
            # Prefer the explicit relationship over an ordinal card title.
            relation=field_label(relations[0]['value']) if len(relations)==1 else ''
            if not relation:
                number=re.search(r'#?\s*([0-9٠-٩]+)\s*$',group)
                relation={'1':'الاب','2':'الام','١':'الاب','٢':'الام'}.get(number[1] if number else '', '')
            parent='father' if relation=='الاب' else 'mother' if relation=='الام' else ''
            if not parent:return None
            names={'الاسم الاول (بالعربية)': 'field-middleName' if parent=='father' else 'field-motherName',
                   'الاسم الاول (بالانكليزية)': 'field-middleNameEn' if parent=='father' else 'field-motherNameEn',
                   'قطاع العمل':f'field-{parent}Sector','المهنة':f'field-{parent}Occupation',
                   'الجنسية':'field-motherNationality' if parent=='mother' else None,
                   'متوفي':'isFatherDeceased' if parent=='father' else 'isMotherDeceased',
                   'متوفاة':'isMotherDeceased' if parent=='mother' else None}
            if label in names:return names[label]
    if key in allowed:return key
    aliases={field_label(BY_ID[k]['label']):k for k in allowed}
    if section in ('المعلومات الشخصية','حالة التسجيل'):
        aliases.update({field_label(a):k for a,k in {
            'الصف':'field-enrollment-promoted-class','لغة التدريس':'field-enrollment-teaching-language',
            'الشعبة':'field-enrollment-grade-section'}.items() if k in allowed})
    # A relative's generic first name or surname must never replace the student's.
    return aliases.get(label)


def canonical_uid(value):
    value=str(value).strip()
    return '' if not value or all(c in '-—– ' for c in value) or set(value)=={'0'} else value


def row_key(row):
    # A missing ID is not an identity shared by all unidentified students.
    return tuple(row.get(k,'') for k in ('uid','first','middle','last','grade','language','section','status','branch','school'))


def is_deleted(item):
    return normalized(item.get('status','')).casefold() in {'محذوف','محذوفة','تم الحذف','deleted'}


def empty_result(item, skipped=''):
    values={'field-existingUniqueId':item['uid'],'field-firstName':item['first'],
        'field-middleName':item['middle'],'field-lastName':item['last'],
        'field-enrollment-promoted-class':item['grade'],'field-enrollment-teaching-language':item['language'],
        'field-enrollment-grade-section':item['section']}
    return {'item':item,'values':values,'read_ids':list(values),'address':{},'fields':[],
        'unread_tabs':[],'empty_tabs':[],'skipped':skipped}


def grade_rank(label):
    name = normalized(label)
    if name in ('العاشر', 'الصف العاشر'): return 13
    ordinals = ('الاول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع')
    for i, ordinal in enumerate(ordinals, 1):
        if name in (f'{ordinal} اساسي', f'الصف {ordinal} اساسي'): return 3 + i
        if i <= 3:
            if name in (f'الروضة {ordinal}', f'روضة {ordinal}', f'الروضة {ordinal}ة',
                        ('الروضة الاولي', 'الروضة الثانية', 'الروضة الثالثة')[i-1]): return i
            if name in (f'{ordinal} ثانوي', f'الصف {ordinal} ثانوي'): return 12 + i
    raise ScanError('scan_unknown_grade')


LIST_SCRIPT = r'''() => {
 const shown = el => !!el.getClientRects().length;
 const clean = text => text.replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g,'').replace(/\s+/g,' ').trim();
 const tables = [...document.querySelectorAll('table')].filter(shown);
 const texts = [...document.querySelectorAll('p')].filter(shown).map(el => clean(el.textContent));
 // Read each labelled management control, not captions in unrelated buttons
 // or a dropdown portal. A selected grade may hide/reset dependent filters.
 const spans = [...document.querySelectorAll('span')].filter(shown);
 const captions = ['الصف','فرع الصف','لغة التدريس','الشعبة'].map(label => {
   const controls=spans.filter(e=>clean(e.textContent)===label).flatMap(e=>{
     // Labels may have their own wrapper and may also be repeated above the
     // field. Find the nearest single-control container, never a whole grid.
     for(let p=e.parentElement;p;p=p.parentElement){
       const buttons=[...p.querySelectorAll('button')].filter(shown);
       if(buttons.length===1)return [buttons[0]];
       if(buttons.length>1)break;
     }
     return [];
   });
   return [...new Set(controls)].map(b=>clean(b.textContent));
 });
 return {
  tables: tables.map(t => ({headers:[...t.querySelectorAll('thead th')].map(e=>e.textContent.trim()),
    rows:[...t.querySelectorAll('tbody tr')].map(r=>({
      editable:r.getAttribute('aria-label')==='تعديل',
      cells:[...r.querySelectorAll('td')].map(e=>e.textContent.trim())}))})),
  pagers:texts.filter(t=>/^الصفحة\s+[0-9٠-٩]+\s+من\s+[0-9٠-٩]+/.test(t)),
  searches:[...document.querySelectorAll('input')].filter(e=>shown(e) &&
    (e.type==='search' || /بحث/.test(e.placeholder))).map(e=>e.value),
  gradeFilter:captions[0],
  otherFilters:captions.slice(1),
  allFilters:['جميع المستويات','جميع الفروع','جميع لغات التدريس','جميع الشعب'].map((t,i)=>
    captions[i].length===1 && captions[i][0]===t ? 1 : 0)
 };
}'''

FORM_SCRIPT = r'''() => {
 const shown = el => !!el.getClientRects().length;
 const clean = text => String(text || '').replace(/\s+/g,' ').trim();
 const groupOf = el => {
   for (let p=el.parentElement;p && p.tagName!=='SECTION';p=p.parentElement) {
     const titles=[...p.querySelectorAll('h3,h4,h5,span,p')].filter(e => shown(e) &&
       /^الأقارب\s*#?\s*[0-9٠-٩]+$/.test(clean(e.textContent)));
     const names=[...new Set(titles.map(e=>clean(e.textContent)))];
     if (names.length===1) return names[0];
     if (names.length>1) return '';
   }
   return '';
 };
 return [...document.querySelectorAll('input,select,textarea')].filter(e => shown(e) &&
  !['password','hidden','file','submit','button'].includes(e.type)).map(e => {
   let label=e.labels && e.labels.length ? [...e.labels].map(l=>l.textContent.trim()).join(' ') : '';
   if (!label) {
     for (let p=e.parentElement;p && p.tagName!=='SECTION';p=p.parentElement) {
       if (p.querySelectorAll('input,select,textarea').length!==1)break;
       const captions=[...p.querySelectorAll('label')].filter(shown);
       if (captions.length===1){label=clean(captions[0].textContent);break;}
     }
   }
   return {id:e.id||'', label, group:groupOf(e), required:e.required || e.getAttribute('aria-required')==='true' || /\*/.test(label),
    value:e.type==='checkbox' ? e.checked : e.tagName==='SELECT' ?
      (e.value ? e.selectedOptions[0]?.textContent.trim() || '' : '') : e.value,
    kind:e.type==='checkbox'?'checkbox':e.tagName==='SELECT'?'select':e.type || 'text'};
 }).filter(e=>e.label);
}'''

from detail_dom import snapshot_script, settled_script, tab_locator
TAB_SNAPSHOT_SCRIPT=snapshot_script([s['label'] for s in SPECS]+ADDRESS_HEADERS)
SETTLED_TAB_SCRIPT=settled_script(TAB_SNAPSHOT_SCRIPT)


def parse_list(raw, grade=None):
    if not isinstance(raw, dict) or not isinstance(raw.get('tables'), list): raise ScanError('scan_prepare','table_missing')
    tables=[]
    for t in raw['tables']:
        indexes=header_indexes(t.get('headers',[]))
        if indexes is not None:tables.append((t,indexes))
    if len(tables)!=1:raise ScanError('scan_prepare','headers_changed' if raw['tables'] else 'table_missing')
    if len(raw.get('pagers', []))!=1:raise ScanError('scan_prepare','pagination_missing')
    # The initial unfiltered inventory must be complete. Once a grade is
    # selected, dependent filters can disappear or change caption; completeness
    # is then established by matching the entire grade roster to that inventory.
    if grade is None and raw.get('allFilters') != [1, 1, 1, 1]:
        raise ScanError('scan_prepare','filters_active')
    if grade and [normalized(g) for g in raw.get('gradeFilter',[])] != [normalized(grade)]:
        raise ScanError('scan_prepare','grade_filter')
    if grade:
        for index,(captions,all_label) in enumerate(zip(raw.get('otherFilters',[]),
                ('جميع الفروع','جميع لغات التدريس','جميع الشعب'))):
            if not captions or captions==[all_label]:continue
            # SIMS disables the branch selector up to the first secondary
            # grade and replaces its caption with this explicit placeholder.
            if index==0 and len(captions)==1 and normalized(captions[0])==normalized('لا ينطبق على هذا الصف') and grade_rank(grade)<=13:
                continue
            raise ScanError('scan_prepare','filters_active')
    if any(str(s).strip() for s in raw.get('searches', [])):raise ScanError('scan_prepare','search_active')
    text = normalized(raw['pagers'][0]).translate(str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789'))
    m = re.fullmatch(r'الصفحة\s+(\d+)\s+من\s+(\d+)\s*[·•]\s*([\d,٬]+)\s+سجل اجمالا', text)
    if not m: raise ScanError('scan_prepare','pagination_format')
    number, pages, total = [int(v.replace(',','').replace('٬','')) for v in m.groups()]
    if not 1 <= number <= pages <= 5000 or not 0 <= total <= 5000: raise ScanError('scan_prepare')
    rows = []
    table,indexes=tables[0]
    for item in table.get('rows', []):
        cells = item.get('cells')
        if not item.get('editable'):
            if total == 0: continue
            raise ScanError('scan_prepare','rows_invalid')
        if (not isinstance(cells, list) or len(cells) != len(table['headers']) or
            any(not isinstance(c, str) or len(c) > 1024 for c in cells)):
            raise ScanError('scan_prepare','rows_invalid')
        rows.append({**{key:cells[i].strip() for key,i in indexes.items()},
                     'uid_column':indexes['uid'],'page': number, 'index': len(rows)})
        rows[-1]['uid']=canonical_uid(rows[-1]['uid'])
        if not rows[-1]['uid'] and not is_deleted(rows[-1]) and not all(canonical_uid(rows[-1][k]) for k in ('first','last')):
            raise ScanError('scan_prepare','rows_invalid')
    if len(rows)>100:raise ScanError('scan_changed','row_count')
    if grade and any(normalized(r['grade'])!=normalized(grade) for r in rows):
        raise ScanError('scan_prepare','grade_filter')
    return {'number': number, 'pages': pages, 'total': total, 'rows': rows}


def header_indexes(headers):
    if not isinstance(headers,list) or any(not isinstance(h,str) for h in headers):return None
    names=[normalized(h) for h in headers]
    indexes={}
    for key,labels in HEADER_FIELDS.items():
        hits=[i for i,h in enumerate(names) if h in {normalized(label) for label in labels}]
        if len(hits)!=1:return None
        indexes[key]=hits[0]
    for key,labels in OPTIONAL_HEADERS.items():
        hits=[i for i,h in enumerate(names) if h in {normalized(label) for label in labels}]
        if len(hits)==1:indexes[key]=hits[0]
    return indexes


class StudentBrowser:
    def __init__(self, page, username, cancelled, account_session=None):
        self.page, self.username, self.cancelled = page, username, cancelled
        self.record_url = None
        self.record_uid = None
        self.record_urls={}
        self.account_session=account_session
        self.selected_grade=None

    def guard(self):
        if self.cancelled.is_set(): raise ScanError('scan_cancelled')
        if not exact_https_host(self.page.url, SIMS_HOST): raise ScanError('scan_account_required')
        if visible(self.page.get_by_text(re.compile(r'^\s*'+re.escape(self.username)+r'\s*$',re.I))) is None:
            allowed=self.account_session is not None and self.account_session.allows(self.page,self.username)
            if not allowed and self.account_session is not None and not self.account_session.revoked:
                # A navigation can briefly hide the account card. Await the
                # already bound caption; never replace it with a new name.
                end=time.monotonic()+3
                while time.monotonic()<end and not self.account_session.revoked:
                    if self.cancelled.is_set():raise ScanError('scan_cancelled')
                    self.page.wait_for_timeout(100)
                    if self.account_session.allows(self.page,self.username):allowed=True;break
            if not allowed:
                raise ScanError('scan_account_required',self.account_session.reason if self.account_session is not None else 'account_profile_missing')
        elif self.account_session is not None and self.account_session.revoked:
            raise ScanError('scan_account_required','account_session_changed')
        path = urlsplit(self.page.url).path.rstrip('/')
        if path != '/dashboard/analytics' and path != MANAGEMENT and not path.startswith(MANAGEMENT+'/'):
            raise ScanError('scan_changed','list_changed')
        if self.record_url is not None and self.page.url != self.record_url: raise ScanError('scan_changed','identity_changed')
        if self.record_uid is not None:
            uid=self.page.locator('#field-existingUniqueId')
            if uid.count()==1 and uid.is_visible() and canonical_uid(uid.input_value())!=self.record_uid:
                raise ScanError('scan_changed','identity_changed')

    def listing(self):
        self.guard()
        if urlsplit(self.page.url).path.rstrip('/') != MANAGEMENT: raise ScanError('scan_prepare')
        return parse_list(self.page.evaluate(LIST_SCRIPT), self.selected_grade)

    def wait_list(self, expected=None, changed_from=None, total=None, page_size=None):
        end, last, since = time.monotonic()+35, None, time.monotonic()
        reason='loading'
        while time.monotonic() < end:
            self.guard()
            try: state = self.listing()
            except ScanError as exc:
                if exc.code != 'scan_prepare': raise
                reason=exc.reason or 'loading'
                state = None
            if state != last: last, since = state, time.monotonic()
            if state:
                if expected is not None and state['number']!=expected:reason='page_not_changed'
                elif changed_from is not None and [row_key(r) for r in state['rows']]==changed_from:reason='page_not_changed'
                elif total is not None and state['total']!=total:reason='count_changed'
                elif page_size is not None and (state['pages']!=max(1,math.ceil(state['total']/page_size)) or
                        len(state['rows'])!=min(page_size,max(0,state['total']-(state['number']-1)*page_size))):reason='row_count'
                elif time.monotonic()-since>=.7:return state
            self.page.wait_for_timeout(100)
        raise ScanError('scan_changed',reason)

    def button(self, name):
        matches = [b for b in self.page.get_by_role('button', name=name, exact=True).all() if b.is_visible()]
        if len(matches) != 1: raise ScanError('scan_prepare')
        return matches[0]

    def step(self, state, direction):
        self.guard()
        button = self.button('التالي' if direction == 1 else 'السابق')
        if not button.is_enabled(): raise ScanError('scan_changed','page_not_changed')
        button.click(timeout=5000)
        return self.wait_list(state['number']+direction, [row_key(r) for r in state['rows']], state['total'])

    def page_size(self):
        self.guard()
        candidates = []
        for selector in self.page.locator('select').all():
            if selector.is_visible():
                labels=selector.evaluate('(e)=>Array.from(e.options,o=>o.value+":"+o.textContent.trim())')
                if isinstance(labels,list) and [re.sub(r'\s+','',normalized(s)) for s in labels]==[
                    '10:10/صفحة','25:25/صفحة','50:50/صفحة','100:100/صفحة']:
                    candidates.append(selector)
        if len(candidates) != 1: raise ScanError('scan_prepare','page_size')
        return candidates[0]

    def prepare(self):
        self.guard()
        if urlsplit(self.page.url).path.rstrip('/') == '/dashboard/analytics':
            self.page.goto('https://'+SIMS_HOST+MANAGEMENT,wait_until='domcontentloaded',timeout=20000)
        elif urlsplit(self.page.url).path.rstrip('/') != MANAGEMENT:
            # Never discard a pre-existing student draft.
            raise ScanError('scan_prepare')
        return self.move(1)

    def grade_button(self):
        self.guard()
        buttons = [b for b in self.page.locator('xpath=//span[normalize-space(.)="الصف"]/parent::div').locator('button').all() if b.is_visible()]
        def grade_caption(button):
            if normalized(button.inner_text())==normalized('جميع المستويات'):return True
            try:grade_rank(button.inner_text());return True
            except ScanError as exc:
                if exc.code!='scan_unknown_grade':raise
                return False
        if len(buttons)!=1 or not grade_caption(buttons[0]):
            # Current supplied SIMS trigger: direct truncated caption and
            # chevron SVG, without aria-expanded or a stable React id. Popup
            # options have no chevron. Do not depend on the label's wrapper.
            selector=('xpath=//button[@type="button"]'
                '[span[contains(concat(" ",normalize-space(@class)," ")," truncate ")]]'
                '[*[local-name()="svg" and contains(concat(" ",normalize-space(@class)," ")," lucide-chevron-down ")]]')
            buttons=[candidate for candidate in self.page.locator(selector).all()
                     if candidate.is_visible() and grade_caption(candidate)]
        if len(buttons)!=1:raise ScanError('scan_prepare','grade_filter')
        return buttons[0]

    def grade_menu(self):
        menus=[]
        for menu in self.page.locator('div.max-h-60.overflow-y-auto').all():
            if menu.is_visible():
                labels=[' '.join(re.sub('[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]','',b.inner_text()).split())
                        for b in menu.locator('button').all() if b.is_visible()]
                if any(normalized(g)==normalized('جميع المستويات') for g in labels):menus.append((menu,labels))
        if not menus:raise ScanError('scan_prepare','grade_menu_missing')
        if len(menus)!=1:raise ScanError('scan_prepare','grade_menu_multiple')
        return menus[0]

    def grade_popup_visible(self):
        # Other filters use the same scroll-container classes. Their popup
        # cannot establish that the grade menu is open (or keep it open).
        try:self.grade_menu();return True
        except ScanError as exc:
            if exc.reason=='grade_menu_missing':return False
            if exc.reason=='grade_menu_multiple':return True
            raise

    def open_grades(self, required=None):
        # A previous attempt/user may have left this popup open or opening.
        # Toggle at most once; clicking an already open trigger closes it.
        end=time.monotonic()+20;attempted=False;last=None;since=None;reason='grade_filter'
        while time.monotonic()<end:
            self.guard()
            state=None
            try:
                button=self.grade_button()
                reason='grade_options'
                if not attempted:
                    if self.grade_popup_visible() or button.get_attribute('aria-expanded')=='true':attempted=True
                    elif button.is_enabled():
                        self.guard();button.click(timeout=5000);attempted=True
                menu,labels=self.grade_menu()
                grades=[g for g in labels if normalized(g)!=normalized('جميع المستويات')]
                valid=(0<len(grades)<=50 and all(g.strip() for g in grades) and
                       len({normalized(g) for g in labels})==len(labels) and menu.get_attribute('aria-busy')!='true')
                reason='grade_menu_unstable'
                if valid and required is not None:
                    options=[b for b in menu.locator('button').all() if b.is_visible() and
                             normalized(b.inner_text())==normalized(required)]
                    valid=len(options)==1 and options[0].is_enabled()
                    reason=('grade_target_missing' if not options else
                            'grade_target_multiple' if len(options)!=1 else
                            'grade_target_disabled' if not options[0].is_enabled() else 'grade_menu_unstable')
                if valid:state=tuple(labels)
            except ScanError as exc:
                if exc.code!='scan_prepare' or exc.reason not in GRADE_REASONS | {'grade_filter','grade_options'}:raise
                reason=exc.reason
            if state!=last:last=state;since=time.monotonic() if state is not None else None
            if state is not None and time.monotonic()-since>=.7:return menu,labels
            self.page.wait_for_timeout(100)
        raise ScanError('scan_prepare',reason)

    def wait_grades_closed(self,caption):
        end=time.monotonic()+10
        while time.monotonic()<end:
            self.guard()
            if (not self.grade_popup_visible() and
                    normalized(self.grade_button().inner_text())==normalized(caption)):return
            self.page.wait_for_timeout(100)
        raise ScanError('scan_changed','grade_menu_not_closed' if self.grade_popup_visible() else 'grade_not_applied')

    def grades(self):
        _,labels=self.open_grades()
        # Close the popup without selecting a student or changing a form.
        button=self.grade_button();caption=button.inner_text().strip()
        self.guard();button.click(timeout=5000)
        self.wait_grades_closed(caption)
        grades=[g for g in labels if normalized(g)!=normalized('جميع المستويات')]
        if not grades or len(grades)>50 or len({normalized(g) for g in grades})!=len(grades):
            raise ScanError('scan_prepare','grade_options')
        return sorted(grades,key=grade_rank)

    def select_grade(self, grade):
        self.guard()
        caption=grade or 'جميع المستويات'
        button=self.grade_button();current=button.inner_text().strip()
        if normalized(current)==normalized(caption):
            if self.grade_popup_visible() or button.get_attribute('aria-expanded')=='true':
                self.open_grades(required=caption)
                self.guard();self.grade_button().click(timeout=5000)
                self.wait_grades_closed(caption)
            return
        menu,labels=self.open_grades(required=caption)
        options=[b for b in menu.locator('button').all() if b.is_visible() and normalized(b.inner_text())==normalized(caption)]
        if len(options)!=1 or not options[0].is_enabled():raise ScanError('scan_changed','grade_options')
        self.guard();options[0].click(timeout=5000)
        self.wait_grades_closed(caption)
        # wait_list also requires every resulting row to belong to this grade.

    def move(self, number):
        self.select_grade(self.selected_grade)
        state = self.wait_list()
        size = self.page_size()
        if size.input_value() != '100':
            self.guard(); size.select_option(value='100',timeout=5000)
        state=self.wait_list(page_size=100)
        if not 1 <= number <= state['pages']: raise ScanError('scan_changed','count_changed')
        while state['number'] != number:
            state = self.step(state,1 if state['number'] < number else -1)
        return state

    def inventory(self, progress, grade=None):
        self.selected_grade=grade
        progress(0,0,{'stage':'prepare'})
        state = self.prepare()
        if not state['total']:
            if grade is None:raise ScanError('scan_empty')
            self.inventory_pages={}
            return []
        total, pages, records = state['total'], state['pages'], []
        for number in range(1,pages+1):
            if state['number'] != number or state['total'] != total or state['pages'] != pages:
                raise ScanError('scan_changed','count_changed')
            if len(state['rows']) != min(100,total-(number-1)*100): raise ScanError('scan_changed','row_count')
            for row in state['rows']:
                records.append(row)
            progress(len(records),total,{'stage':'inventory','grade':grade or ''})
            if number < pages: state = self.step(state,1)
        if len(records) != total: raise ScanError('scan_changed','count_changed')
        self.inventory_pages = {n:[row_key(r) for r in records if r['page']==n] for n in range(1,pages+1)}
        return records

    def read_birth_date(self, item, keep_open_if_birth=None):
        """Inspect identity; optionally stay on a verified matching record."""
        state=self.move(item['page'])
        if [row_key(r) for r in state['rows']]!=self.inventory_pages[item['page']]:
            raise ScanError('scan_changed','list_changed')
        tables=[t for t in self.page.locator('table').all() if t.is_visible() and
                header_indexes(t.locator('thead th').all_inner_texts()) is not None]
        if len(tables)!=1:raise ScanError('scan_changed','headers_changed')
        rows=tables[0].locator('tbody tr[aria-label="تعديل"]')
        if rows.count()!=len(state['rows']):raise ScanError('scan_changed','row_count')
        row=rows.nth(item['index'])
        if canonical_uid(row.locator('td').nth(item['uid_column']).inner_text())!=item['uid']:
            raise ScanError('scan_changed','identity_changed')
        self.guard();row.click(timeout=7000)
        end=time.monotonic()+25
        last=None;since=time.monotonic();birth='';keep_open=False
        try:
            while time.monotonic()<end:
                self.guard()
                path=urlsplit(self.page.url).path.rstrip('/')
                if path.startswith(MANAGEMENT+'/') and path!=MANAGEMENT+'/new':
                    fields=self.controls()
                    values={f['id']:f['value'] for f in fields if sum(x['id']==f['id'] for x in fields)==1}
                    same=all(normalized(values.get(key,''))==normalized(item[name]) for key,name in
                             (('field-firstName','first'),('field-middleName','middle'),('field-lastName','last')))
                    if item['uid'] and canonical_uid(values.get('field-existingUniqueId',''))!=item['uid']:same=False
                    birth=values.get('field-birthDate','')
                    if isinstance(birth,str) and birth and same:
                        from identity_dates import identity_birth
                        try:birth=identity_birth(birth)
                        except (ValueError,TypeError,OverflowError):raise ScanError('scan_changed','identity_changed') from None
                        snapshot=(self.page.url,tuple((key,values.get(key,'')) for key in
                            ('field-existingUniqueId','field-firstName','field-middleName','field-lastName','field-birthDate')))
                        if snapshot!=last:last,since=snapshot,time.monotonic()
                        if time.monotonic()-since>=.8:
                            keep_open = keep_open_if_birth is not None and birth == identity_birth(keep_open_if_birth)
                            return birth
                self.page.wait_for_timeout(100)
            raise ScanError('scan_changed','identity_changed')
        finally:
            # Keep only an explicitly verified match open. Restore the roster
            # for every mismatch or failed identity read.
            if not keep_open and urlsplit(self.page.url).path.rstrip('/').startswith(MANAGEMENT+'/'):
                self.page.go_back(wait_until='domcontentloaded',timeout=20000)
                self.move(item['page'])

    def controls(self):
        self.guard()
        data = self.page.evaluate(FORM_SCRIPT)
        if not isinstance(data,list) or len(data)>500: raise ScanError('scan_changed','controls_changed')
        for item in data:
            if not isinstance(item,dict) or not isinstance(item.get('id'),str) or not isinstance(item.get('label'),str):
                raise ScanError('scan_changed','controls_changed')
            if not isinstance(item.get('value'),(str,bool)) or len(str(item['value']))>8192:
                raise ScanError('scan_changed','controls_changed')
        self.guard()
        return data

    def read_later_tab(self,tab_name):
        """One read-only visit; caller retries only an unread visit once."""
        self.guard()
        tabs=[t for t in tab_locator(self.page,tab_name).all() if t.is_visible()]
        if len(tabs)!=1 or not tabs[0].is_enabled() or tabs[0].get_attribute('aria-disabled')=='true':
            return None
        if tabs[0].get_attribute('aria-selected')!='true':
            tabs[0].click(timeout=5000)
        self.guard()
        snapshot=self.page.evaluate(SETTLED_TAB_SCRIPT,tab_name)
        self.guard()
        # Rebind after React renders; do not retain a positional tab locator.
        tabs=[t for t in tab_locator(self.page,tab_name).all() if t.is_visible()]
        if (not isinstance(snapshot,dict) or not snapshot.get('found') or snapshot.get('loading') or
                snapshot.get('overflow') or len(tabs)!=1 or tabs[0].get_attribute('aria-selected')!='true'):
            return None
        return snapshot

    def read(self, item, previous=None):
        state = self.move(item['page'])
        if [row_key(r) for r in state['rows']] != self.inventory_pages[item['page']]: raise ScanError('scan_changed','list_changed')
        tables=[]
        for table in self.page.locator('table').all():
            if table.is_visible() and header_indexes(table.locator('thead th').all_inner_texts()) is not None:tables.append(table)
        if len(tables)!=1:raise ScanError('scan_changed','headers_changed')
        rows = tables[0].locator('tbody tr[aria-label="تعديل"]')
        if rows.count() != len(state['rows']): raise ScanError('scan_changed','row_count')
        row = rows.nth(item['index'])
        if canonical_uid(row.locator('td').nth(item['uid_column']).inner_text()) != item['uid']: raise ScanError('scan_changed','identity_changed')
        self.guard(); row.click(timeout=7000)
        end = time.monotonic()+25
        last,since=None,time.monotonic()
        saw_form=False
        while True:
            self.guard()
            path = urlsplit(self.page.url).path.rstrip('/')
            uid = self.page.locator('#field-existingUniqueId')
            if path.startswith(MANAGEMENT+'/') and path != MANAGEMENT+'/new' and uid.count()==1 and uid.is_visible():
                saw_form=True
                fields=self.controls()
                values={f['id']:f['value'] for f in fields if sum(x['id']==f['id'] for x in fields)==1}
                identity_ok=(not item['uid'] or canonical_uid(uid.input_value())==item['uid']) and all(
                    key in values and normalized(values[key])==normalized(item[name])
                    for key,name in (('field-firstName','first'),('field-middleName','middle'),('field-lastName','last')))
                grade_value=values.get('field-enrollment-promoted-class')
                if grade_value and normalized(grade_value)!=normalized(item['grade']):identity_ok=False
                snapshot=(self.page.url,fields)
                if snapshot!=last:last,since=snapshot,time.monotonic()
                if identity_ok and time.monotonic()-since>=.8:break
            if time.monotonic()>end:raise ScanError('scan_changed','identity_changed' if saw_form else 'record_timeout')
            self.page.wait_for_timeout(100)
        self.record_url = self.page.url
        self.record_uid = canonical_uid(uid.input_value())
        record_ref=hashlib.sha256(self.record_url.encode('utf-8')).hexdigest()
        if record_ref in self.record_urls:
            result=empty_result(item,'duplicate_record')
            result['duplicate_of']=self.record_urls[record_ref]
            result['record_ref']=record_ref
            self.record_url=None;self.record_uid=None
            self.page.go_back(wait_until='domcontentloaded',timeout=20000);self.move(item['page'])
            return result
        result = {'item':item, 'values':{}, 'address':{}, 'read_ids':[], 'fields':[], 'tab_texts':{}, 'unread_tabs':[], 'empty_tabs':[]}
        retained_tabs=set(TABS[:3])
        if previous is not None:
            if previous.get('reader_version') in (5,6):
                retained_tabs.update(t for t in TABS[3:] if t not in previous.get('unread_tabs',[]))
            result=copy.deepcopy(previous);result['item']=item
            result['fields']=[f for f in result.get('fields',[]) if f['section'] in retained_tabs]
            result['tab_texts']={k:v for k,v in result.get('tab_texts',{}).items() if k in retained_tabs}
            for key in ('unread_tabs','empty_tabs'):result[key]=[t for t in result[key] if t in retained_tabs]
        self.capture(result, 'النموذج عند الفتح', fields)
        for key,name in (('field-firstName','first'),('field-middleName','middle'),('field-lastName','last')):
            if key not in result['read_ids'] or normalized(result['values'].get(key,''))!=normalized(item[name]):
                raise ScanError('scan_changed','identity_changed')
        self.record_urls[record_ref]=(item['grade'],item['page'],item['index'])
        result['record_ref']=record_ref
        for key,value in {'field-existingUniqueId':item['uid'], 'field-firstName':item['first'],
                'field-middleName':item['middle'],'field-lastName':item['last'],
                'field-enrollment-promoted-class':item['grade'],
                'field-enrollment-teaching-language':item['language'],
                'field-enrollment-grade-section':item['section']}.items():
            if key not in result['read_ids']:
                result['values'][key]=value;result['read_ids'].append(key)
        mode = [b for b in self.page.get_by_role('radio',name='مفصّل',exact=True).all() if b.is_visible()]
        if len(mode)!=1 or not mode[0].is_enabled():
            result['unread_tabs']=list(TABS)
        else:
            if mode[0].get_attribute('aria-checked') != 'true':
                self.guard(); mode[0].click(timeout=5000)
            for tab_name in (TABS[:3] if previous is None else ()):
                self.guard()
                tabs = [t for t in tab_locator(self.page,tab_name).all() if t.is_visible()]
                if len(tabs)!=1 or not tabs[0].is_enabled() or tabs[0].get_attribute('aria-disabled')=='true':
                    result['unread_tabs'].append(tab_name); continue
                tab=tabs[0]
                before_fields=self.controls()
                changed_tab=tab.get_attribute('aria-selected')!='true'
                if changed_tab:
                    self.guard(); tab.click(timeout=5000)
                end, last, since = time.monotonic()+15, None, time.monotonic()
                while True:
                    self.guard()
                    fields = self.controls()
                    snapshot=self.page.evaluate(TAB_SNAPSHOT_SCRIPT,tab_name)
                    combined=(fields,snapshot)
                    if combined != last: last,since=combined,time.monotonic()
                    selected=tab.get_attribute('aria-selected')=='true'
                    # A selected tab can still show the preceding panel or a loading shell.
                    ready=(not isinstance(snapshot,dict) or not snapshot.get('loading'))
                    has_content=bool(fields or (isinstance(snapshot,dict) and snapshot.get('found')))
                    if selected and ready and has_content and time.monotonic()-since>=1.5: break
                    # Preserve an explicit unread result for an unavailable/empty panel.
                    if selected and ready and not has_content and time.monotonic()-since>=3: break
                    if time.monotonic()>end: raise ScanError('scan_changed','tab_timeout')
                    self.page.wait_for_timeout(100)
                # A tab may contain both editable controls and saved cards.
                snapshot=self.page.evaluate(TAB_SNAPSHOT_SCRIPT,tab_name)
                if isinstance(snapshot,dict) and snapshot.get('overflow'):
                    raise ScanError('scan_changed','controls_changed')
                card_text=(snapshot.get('text','') if isinstance(snapshot,dict) and snapshot.get('found') else '')
                if not isinstance(card_text,str):card_text=''
                if card_text:
                    result['tab_texts'][tab_name]=card_text
                display_fields=snapshot.get('fields',[]) if isinstance(snapshot,dict) else []
                if display_fields:
                    self.capture(result,tab_name,display_fields)
                if fields:
                    if changed_tab and fields == before_fields:
                        result['unread_tabs'].append(tab_name)
                    else:self.capture(result,tab_name,fields)
                else:
                    # Existing saved cards show static text instead of inputs.
                    # Keep their visible text as a read-only snapshot without
                    # guessing which line belongs to which editable field.
                    if not card_text and not display_fields:
                        if visible(self.page.get_by_text('لم يُعثر على أية سجلات',exact=True)):
                            result['empty_tabs'].append(tab_name)
                        result['unread_tabs'].append(tab_name)
            # Give asynchronous panels time to render. A second pass visits
            # only unsuccessful reads, never repeats a successful section and
            # never Add/Edit/Save, even when the visible inputs are locked.
            pending=[t for t in TABS[3:] if previous is None or t not in retained_tabs];partial={};unmapped=[]
            for attempt in range(2):
                failed=[]
                for tab_name in pending:
                    self.guard()
                    try:
                        snapshot=self.read_later_tab(tab_name)
                        if snapshot is None:
                            failed.append(tab_name);continue
                        fields=snapshot.get('fields',[])
                        if not fields and not snapshot.get('empty') and snapshot.get('text'):
                            # A static card was actually read but its unknown
                            # layout cannot be projected into editable columns.
                            partial[tab_name]=snapshot;unmapped.append(tab_name);continue
                        if snapshot.get('timed_out') or (not fields and not snapshot.get('empty')):
                            partial[tab_name]=snapshot;failed.append(tab_name);continue
                        if fields:self.capture(result,tab_name,fields)
                        if snapshot.get('text'):result['tab_texts'][tab_name]=snapshot['text']
                        if snapshot.get('empty'):result['empty_tabs'].append(tab_name)
                    except ScanError as exc:
                        if exc.reason!='controls_changed':raise
                        failed.append(tab_name)
                    except Exception:
                        self.guard();failed.append(tab_name)
                pending=failed
                if not pending:break
                if attempt==0:
                    self.guard();self.page.wait_for_timeout(200)
            for tab_name in pending+unmapped:
                result['unread_tabs'].append(tab_name)
                snapshot=partial.get(tab_name,{})
                if snapshot.get('fields'):self.capture(result,tab_name,snapshot['fields'])
                if snapshot.get('text'):result['tab_texts'][tab_name]=snapshot['text']
        result['reader_version']=6
        self.guard()
        self.record_url=None
        self.record_uid=None
        self.page.go_back(wait_until='domcontentloaded',timeout=20000)
        self.move(item['page'])
        return result

    @staticmethod
    def capture(result, section, fields):
        keys=[existing_field_key(section,f,fields) for f in fields]
        for field in fields:
            if field['id']=='field-existingUniqueId':field={**field,'value':canonical_uid(field['value'])}
            key = existing_field_key(section,field,fields)
            label = re.sub(r'\s*\*\s*$', '', field['label']).strip()
            if key in BY_ID and keys.count(key)==1:
                result['values'][key] = field['value']
                if key not in result['read_ids']: result['read_ids'].append(key)
            # Do not collapse repeated address/nationality controls into one.
            address_label=next((h for h in ADDRESS_HEADERS if field_label(h)==field_label(label)),None)
            if section=='عناوين السكن' and address_label and sum(field_label(f['label'])==field_label(label) for f in fields)==1:
                result['address'][address_label] = field['value']
            if label:
                result['fields'].append({'section':section,'label':label,'group':field.get('group',''),'value':field['value'],
                    'required':bool(field['required']),'kind':field['kind']})


def collect_students(page, username, cancelled, limit=10, progress=lambda *_:None, browser_factory=StudentBrowser, account_session=None, checkpoint=None, grade=None, selection=None):
    if type(limit) is not int or limit not in (0,10): raise ScanError('scan_prepare')
    if selection is not None and limit!=0:raise ScanError('scan_prepare')
    if grade is not None and (limit!=0 or not isinstance(grade,str) or not grade.strip() or len(grade)>128):raise ScanError('scan_prepare')
    browser=browser_factory(page,username,cancelled,account_session=account_session) if account_session is not None else browser_factory(page,username,cancelled)
    if grade is None:
        records=browser.inventory(progress)
        grades=browser.grades()
    else:
        # inventory sets selected_grade before prepare. Select the requested
        # live option directly, then verify its caption and scoped roster.
        # Do not open/close an unrelated all-grades listing or read the whole
        # school before applying this scope. Missing/ambiguous options still
        # stop in select_grade; never fall back to an unfiltered inventory.
        records=browser.inventory(progress,grade=grade)
        if not records:raise ScanError('scan_empty')
        grades=[grade]
    from scan_selection import select_records
    inventory_records=records
    records=select_records(records,selection,username,grade)
    if not records:raise ScanError('scan_empty')
    if checkpoint is not None:
        checkpoint.bind(records)
        progress(0,min(limit,len(records)) if limit else len(records),{'stage':'resume','resumed':len(checkpoint.cache)})
    known={normalized(g) for g in grades}
    if any(normalized(r['grade']) not in known and not is_deleted(r) for r in records):
        raise ScanError('scan_unknown_grade')
    output=[]
    occurrences=Counter()
    resumed=0
    selected_count=min(limit,len(records)) if limit else len(records)
    for grade_index,grade in enumerate(grades,1):
        expected=[r for r in records if normalized(r['grade'])==normalized(grade)]
        if not expected:continue
        # Select the real UI grade, inventory its pages, then finish its files
        # before selecting another grade. Never merge repeated/missing IDs.
        group=inventory_records if len(grades)==1 and browser.selected_grade==grade else browser.inventory(progress,grade=grade)
        coverage=[r for r in inventory_records if normalized(r['grade'])==normalized(grade)]
        if Counter(map(row_key,group))!=Counter(map(row_key,coverage)):
            raise ScanError('scan_changed','grade_coverage')
        selected_keys={row_key(r) for r in expected}
        group=[r for r in group if row_key(r) in selected_keys]
        for grade_done,item in enumerate(group,1):
            if cancelled.is_set():raise ScanError('scan_cancelled')
            detail={'stage':'read','grade':grade,'inventory':len(records),
                'grade_done':grade_done-1,'grade_total':len(group),
                'grade_index':grade_index,'grade_count':len(grades)}
            progress(len(output),selected_count,detail)
            result=checkpoint.take(item) if checkpoint is not None else None
            previous=None
            if (result is not None and not result.get('skipped') and result.get('reader_version')==5 and
                    not set(result.get('unread_tabs',[])).intersection(TABS[3:])):
                result['reader_version']=6
            if (result is not None and not result.get('skipped') and
                    (result.get('reader_version')!=6 or set(result.get('unread_tabs',[])).intersection(TABS[3:]))):
                if result.get('reader_version') in (2,3,4,5,6):previous=result
                result=None
            if result is not None:
                resumed+=1
                if result.get('record_ref'):
                    browser.record_urls[result['record_ref']]=(item['grade'],item['page'],item['index'])
            else:result=empty_result(item,'deleted') if is_deleted(item) else (browser.read(item,previous=previous) if previous is not None else browser.read(item))
            result['values']['field-existingUniqueId']=canonical_uid(result['values'].get('field-existingUniqueId',''))
            if item['uid'] and result['values']['field-existingUniqueId'] != item['uid']:
                raise ScanError('scan_changed','identity_changed')
            if any(normalized(result['values'].get(k,''))!=normalized(item[name])
                for k,name in (('field-firstName','first'),('field-middleName','middle'),('field-lastName','last'))):
                raise ScanError('scan_changed','identity_changed')
            if ('field-enrollment-promoted-class' in result['read_ids'] and
                normalized(result['values']['field-enrollment-promoted-class']) != normalized(item['grade'])):
                raise ScanError('scan_changed','identity_changed')
            output.append(result)
            occurrences[row_key(item)]+=1
            if checkpoint is not None:checkpoint.save(result,occurrences[row_key(item)],len(output))
            detail['resumed']=resumed
            detail['grade_done']=grade_done
            progress(len(output),selected_count,detail)
            if limit and len(output)>=limit:return {'inventory':len(records),'records':output,'limit':limit}
    # Deleted records without an available grade are reported without opening.
    for item in records:
        if normalized(item['grade']) not in known and is_deleted(item):
            output.append(empty_result(item,'deleted'))
            occurrences[row_key(item)]+=1
            if checkpoint is not None:checkpoint.save(output[-1],occurrences[row_key(item)],len(output))
            if limit and len(output)>=limit:break
    if not limit and len(output)!=len(records):raise ScanError('scan_changed','row_count')
    return {'inventory':len(records),'records':output,'limit':limit}


def list_scan_grades(page,username,cancelled,account_session=None):
    browser=StudentBrowser(page,username,cancelled,account_session=account_session)
    browser.prepare()
    return browser.grades()


def missing_fields(row):
    if row.get('skipped'):return [],[]
    missing={f['label'] for f in FIELDS if f['required'] and f['id'] in row['read_ids'] and row['values'].get(f['id'],'')==''}
    missing.update(f['section']+' / '+f['label'] for f in row['fields'] if f['required'] and f['value']=='')
    unread=[f['label'] for f in FIELDS if f['id'] not in row['read_ids']]
    return sorted(missing),unread


def export_students(data, path, cancelled):
    """Populate the bundled native XLSX, retaining its dropdowns and formats.

    A marker/report sheet makes this an existing-record extract. Creation import
    explicitly rejects it; it cannot accidentally re-create existing students.
    """
    rows=data['records']
    if not 1<=len(rows)<=5000: raise ScanError('scan_empty')
    address_defaults={};phone_defaults={}
    if data.get('shift')=='morning':
        from scan_dropdowns import dropdown_options
        from manual_sections import phone_country_parts
        lebanon=[label for label in dropdown_options()['الهواتف / رمز الدولة']
                 if phone_country_parts(label)==('961','LB')]
        if len(lebanon)!=1:raise ScanError('scan_failed')
        address_defaults={'البلد':'لبنان','النوع':'دائم'}
        phone_defaults={'الهواتف / النوع':'خلوي','الهواتف / رمز الدولة':lebanon[0],'الهواتف / الأساسية':'نعم'}
    target=Path(path)
    if target.suffix.lower()!='.xlsx': raise ScanError('scan_failed')
    source=core.ASSET_BASE/'assets/student_with_addresses.xlsx'
    if target.resolve()==source.resolve(): raise ScanError('scan_failed')
    q=lambda tag:'{'+NS['m']+'}'+tag
    def cell(row,col,value,style=None):
        c=ET.SubElement(row,q('c'),r=f'{col}{row.get("r")}',t='inlineStr')
        if style is not None:c.set('s',style)
        if isinstance(value,bool):value='نعم' if value else 'لا'
        text=re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]','',str(value))
        ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=text
        return c
    with zipfile.ZipFile(source) as z:items={n:z.read(n) for n in z.namelist()}
    sheet=ET.fromstring(items['xl/worksheets/sheet1.xml'])
    body=sheet.find('m:sheetData',NS)
    template=copy.deepcopy(body.findall('m:row',NS)[1])
    maxrow=max(501,len(rows)+1)
    styles={re.sub(r'\d+','',c.get('r')):c.get('s') for c in template}
    from student_workflow import column
    from scan_workbook_layout import BASE_COUNT, MOTHER_INDEX, shift_ref, shift_formula, insert_mother_header, insert_mother_table
    insert_mother_header(sheet)
    endcol=column(BASE_COUNT+len(MANUAL_HEADERS))
    header=body.findall('m:row',NS)[0]
    header_style=header.find('m:c',NS).get('s')
    cols=sheet.find('m:cols',NS)
    for j,label in enumerate(MANUAL_HEADERS,BASE_COUNT+1):
        cell(header,column(j),label,header_style)
        ET.SubElement(cols,q('col'),min=str(j),max=str(j),width='22',customWidth='1')
    for row in list(body)[1:]:body.remove(row)
    formula=shift_formula(next(c.find('m:f',NS).text for c in template if c.get('r')=='AI2'))
    for index in range(2,maxrow+1):
        if cancelled.is_set(): raise ScanError('scan_cancelled')
        node=ET.SubElement(body,q('row'),r=str(index),ht=template.get('ht','20'),customHeight='1')
        values=[];manual={}
        if index-2<len(rows):
            result=rows[index-2]
            address=dict(result['address']);manual=observed_values(result)
            if not result.get('skipped'):
                for payload,defaults in ((address,address_defaults),(manual,phone_defaults)):
                    for key,value in defaults.items():
                        current=payload.get(key)
                        if current is None or (isinstance(current,str) and not current.strip()):payload[key]=value
            values=[result['values'].get(f['id'],'') for f in FIELDS]+[address.get(label,'') for label in ADDRESS_HEADERS]
        for col_index in range(35):
            if col_index==MOTHER_INDEX-1:
                cell(node,column(MOTHER_INDEX),manual.get(MOTHER_SURNAME,''),styles.get('B'));continue
            old_index=col_index-(col_index>=MOTHER_INDEX)
            old_col=column(old_index+1);col=shift_ref(old_col+'1')[:-1]
            value=values[old_index] if values else ''
            c=cell(node,col,value,styles.get(old_col))
            if old_index<len(FIELDS) and FIELDS[old_index]['type']=='date' and value:
                try:
                    dt=date.fromisoformat(value)
                    serial=(dt-date(1899,12,30)).days
                    c.remove(c.find('m:is',NS));c.attrib.pop('t');ET.SubElement(c,q('v')).text=str(serial)
                except (ValueError,TypeError):pass
        c=ET.SubElement(node,q('c'),r=f'{column(BASE_COUNT)}{index}')
        if styles.get('AI') is not None:c.set('s',styles['AI'])
        if index-2<len(rows) and rows[index-2].get('skipped'):
            c.set('t','inlineStr')
            ET.SubElement(ET.SubElement(c,q('is')),q('t')).text='سجل متخطّى — لم تُقرأ العناوين'
        elif index-2<len(rows) and TABS[2] in rows[index-2]['unread_tabs']:
            c.set('t','inlineStr')
            ET.SubElement(ET.SubElement(c,q('is')),q('t')).text=('لا سجلات عناوين' if TABS[2] in rows[index-2]['empty_tabs'] else 'لم تُقرأ العناوين')
        else:
            ET.SubElement(c,q('f')).text=re.sub(r'(\$?[A-Z]{1,3})(\$?)(\d+)',
                lambda m:m[1]+m[2]+(m[3] if m[2] else str(int(m[3])+index-2)),formula)
        for j,label in enumerate(MANUAL_HEADERS,BASE_COUNT+1):
            cell(node,column(j),('0' if j==BASE_COUNT+1 and index-2<len(rows) else manual.get(label,'')),styles.get('B'))
    dim=sheet.find('m:dimension',NS)
    if dim is None:
        dim=ET.Element(q('dimension'));sheet.insert(0,dim)
    dim.set('ref',f'A1:{endcol}{maxrow}')
    for dv in sheet.findall('m:dataValidations/m:dataValidation',NS):
        dv.set('sqref',re.sub(r'(?<=[A-Z])501\b',str(maxrow),dv.get('sqref','')))
    for cf in sheet.findall('m:conditionalFormatting',NS):
        cf.set('sqref',re.sub(r'(?<=[A-Z])501\b',str(maxrow),cf.get('sqref','')))
    items['xl/worksheets/sheet1.xml']=ET.tostring(sheet,encoding='utf-8',xml_declaration=True)
    for name in list(items):
        if name.startswith('xl/tables/') and name.endswith('.xml'):
            table=ET.fromstring(items[name])
            if table.get('name')=='StudentsInput':
                table.set('ref',f'A1:{endcol}{maxrow}')
                autofilter=table.find('m:autoFilter',NS)
                if autofilter is not None:autofilter.set('ref',f'A1:{endcol}{maxrow}')
                insert_mother_table(table)
                table_cols=table.find('m:tableColumns',NS)
                for j,label in enumerate(MANUAL_HEADERS,BASE_COUNT+1):ET.SubElement(table_cols,q('tableColumn'),id=str(j),name=label)
                table_cols.set('count',str(BASE_COUNT+len(MANUAL_HEADERS)))
                items[name]=ET.tostring(table,encoding='utf-8',xml_declaration=True)
    reports=[['صف Excel','الرقم الموحد للطالب','اسم الطالب','الصف','حالة الفحص','النواقص المطلوبة المقروءة','الخانات الأصلية غير المقروءة','الأقسام غير المقروءة','أقسام دون سجلات','ملاحظة الرقم الموحد','الحالة في النظام']]
    details=[['صف Excel','الرقم الموحد للطالب','الصف','القسم','الحقل','ترتيب الظهور','القيمة','مطلوب','الحالة']]
    tab_snapshots=[['صف Excel','الرقم الموحد للطالب','الصف','التبويبة','النص الظاهر في البطاقة']]
    for i,row in enumerate(rows,2):
        missing,unread=missing_fields(row)
        state='نواقص وقراءة غير مكتملة' if missing and (unread or row['unread_tabs']) else 'قراءة غير مكتملة' if unread or row['unread_tabs'] else 'نواقص' if missing else 'لا نواقص في الحقول المقروءة'
        if row.get('skipped')=='deleted':state='محذوف — تم تخطي قراءة الملف'
        elif row.get('skipped')=='duplicate_record':state='نفس السجل المفتوح سابقاً — تم تخطي تكرار القراءة'
        item=row['item']
        uid=row['values'].get('field-existingUniqueId','')
        reports.append([i,uid,' '.join([item['first'],item['middle'],item['last']]),item['grade'],state,
            '؛ '.join(missing),'؛ '.join(unread),'؛ '.join(row['unread_tabs']),'؛ '.join(row['empty_tabs']),
            ('لم يظهر رقم موحد في القائمة؛ لم يُفتح الملف' if row.get('skipped') else 'لم يظهر رقم موحد في القائمة؛ تم التحقق بالاسم والسجل المفتوح') if not item['uid'] else '',item.get('status','')])
        for j,f in enumerate(row['fields'],1):
            details.append([i,uid,item['grade'],f['section'],f['label'],j,f['value'],
                'نعم' if f['required'] else 'لا','ناقص' if f['required'] and f['value']=='' else 'مقروء'])
        for tab_name,content in row.get('tab_texts',{}).items():
            tab_snapshots.append([i,uid,item['grade'],tab_name,content])
    reports.extend([[],['نطاق السحب',f"قُرئ {len(rows)} من أصل {data['inventory']} سجلاً في القائمة"],
        ['مهم','سجلات موجودة: عدّل الأعمدة اليدوية، وضع 1 في اختيار الاسترداد اليدوي. استرد كل قسم من زر الاسترداد اليدوي، ثم راجعه واحفظه بالموقع. لا تستخدم الملف لإنشاء طلاب جدد.'],
        ['سرعة القراءة','زيارة واحدة لكل قسم، مع مهلة قصيرة لاستقرار خاناته قبل قراءة قيمها. لا يُضغط إضافة أو حفظ أثناء السحب. القسم غير الجاهز يبقى معلّماً غير مقروء؛ فراغ Excel لا يثبت فراغ الموقع.'],
        ['حدود القراءة','الحقول الظاهرة في المفصّل موجودة في ورقة «الحقول المقروءة». نص البطاقات المحفوظة في «البطاقات الظاهرة»؛ يُعرض كما هو دون تخمين خاناته. الأقسام غير المقروءة لا تعني أن بيانات الطالب ناقصة.'],
        ['الترتيب','من أصغر صف موجود إلى أعلى صف، وبترتيب القائمة داخل الصف نفسه.']])
    if data.get('interrupted'):
        reports.append(['حالة العملية','سحب متوقف وغير مكتمل. يحتوي فقط السجلات المنجزة المحفوظة؛ استكمل بنفس حساب الدخول واسم ملف Excel الأصلي.'])
    book=ET.fromstring(items['xl/workbook.xml'])
    rels=ET.fromstring(items['xl/_rels/workbook.xml.rels'])
    content=ET.fromstring(items['[Content_Types].xml'])
    sheets=book.find('m:sheets',NS)
    relation_ns='http://schemas.openxmlformats.org/package/2006/relationships'
    content_ns='http://schemas.openxmlformats.org/package/2006/content-types'
    next_id=max(int(s.get('sheetId')) for s in sheets)+1
    stylebook=ET.fromstring(items['xl/styles.xml'])
    xfs=stylebook.find('m:cellXfs',NS)
    report_style=copy.deepcopy(xfs[int(styles['B'])])
    alignment=report_style.find('m:alignment',NS)
    if alignment is None:alignment=ET.SubElement(report_style,q('alignment'))
    alignment.set('wrapText','1');alignment.set('vertical','top')
    report_style.set('numFmtId','49')
    report_style_id=str(len(xfs));xfs.append(report_style);xfs.set('count',str(len(xfs)))
    items['xl/styles.xml']=ET.tostring(stylebook,encoding='utf-8',xml_declaration=True)
    mapping=[['عمود Excel','القسم بالموقع','المجموعة','اسم الخانة','نوع الإدخال'],
             [MANUAL_HEADERS[0],'اختيار الطالب','','1 أو نعم للاسترداد','اختيار']]
    mapping.extend([s['header'],s['section'],s['group'],s['label'],s['kind']] for s in SPECS)
    for sheet_name,table,widths in [(REPORT_SHEET,reports,[12,24,32,22,30,65,65,55,45,55,25]),
                                   ('الحقول المقروءة',details,[12,24,22,30,38,15,48,12,18]),
                                   ('البطاقات الظاهرة',tab_snapshots,[12,24,22,30,95]),
                                   (MAP_SHEET,mapping,[55,26,22,32,20])]:
        sheet_id=next_id;next_id+=1
        part=f'xl/worksheets/sheet{sheet_id}.xml';rid=f'rIdStudentScan{sheet_id}'
        ET.SubElement(sheets,q('sheet'),name=sheet_name,sheetId=str(sheet_id),attrib={REL:rid})
        ET.SubElement(rels,'{'+relation_ns+'}Relationship',Id=rid,Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet',Target=f'worksheets/sheet{sheet_id}.xml')
        ET.SubElement(content,'{'+content_ns+'}Override',PartName='/'+part,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
        report=ET.Element(q('worksheet'))
        views=ET.SubElement(report,q('sheetViews'));view=ET.SubElement(views,q('sheetView'),workbookViewId='0',rightToLeft='1')
        ET.SubElement(view,q('pane'),ySplit='1',topLeftCell='A2',activePane='bottomLeft',state='frozen')
        cols=ET.SubElement(report,q('cols'))
        for j,width in enumerate(widths,1):ET.SubElement(cols,q('col'),min=str(j),max=str(j),width=str(width),customWidth='1')
        rb=ET.SubElement(report,q('sheetData'))
        header_style=body.find('m:row/m:c',NS).get('s')
        for i,values in enumerate(table,1):
            rn=ET.SubElement(rb,q('row'),r=str(i))
            if i==1:rn.set('ht','36');rn.set('customHeight','1')
            else:
                lines=max([1]+[math.ceil(len(str(value))/max(1,widths[j]-4)) for j,value in enumerate(values)])
                rn.set('ht',str(min(240,max(30,18*lines))));rn.set('customHeight','1')
            for j,value in enumerate(values):cell(rn,chr(65+j),value,header_style if i==1 else report_style_id)
        ET.SubElement(report,q('autoFilter'),ref=f'A1:{chr(64+len(widths))}{len(rows)+1 if sheet_name==REPORT_SHEET else len(table)}')
        items[part]=ET.tostring(report,encoding='utf-8',xml_declaration=True)
    calc=book.find('m:calcPr',NS)
    if calc is not None:calc.set('fullCalcOnLoad','1')
    items['xl/workbook.xml']=ET.tostring(book,encoding='utf-8',xml_declaration=True)
    items['xl/_rels/workbook.xml.rels']=ET.tostring(rels,encoding='utf-8',xml_declaration=True)
    items['[Content_Types].xml']=ET.tostring(content,encoding='utf-8',xml_declaration=True)
    from scan_dropdowns import attach_scan_dropdowns
    attach_scan_dropdowns(items)
    from excel_dates import format_dates
    format_dates(items)
    tmp=None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent,suffix='.xlsx',delete=False) as f:tmp=Path(f.name)
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
            for name,blob in items.items():z.writestr(name,blob)
        if cancelled.is_set():raise ScanError('scan_cancelled')
        os.replace(tmp,target)
    except OSError:raise ScanError('scan_failed') from None
    finally:
        if tmp is not None:tmp.unlink(missing_ok=True)
