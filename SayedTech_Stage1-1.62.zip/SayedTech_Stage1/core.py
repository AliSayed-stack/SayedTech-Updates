"""School-only statistics with disclosed submission and no personal fields."""
import json
import os
import subprocess
import sys
import unicodedata
import webbrowser
from pathlib import Path

FORM_ID = '1FAIpQLSf4sUUHYauzRj8ilNrazO4CxCUSLKAPHjVE_eiOy53xPoIE0g'
FORM_URL = f'https://docs.google.com/forms/d/e/{FORM_ID}/viewform'
POST_URL = f'https://docs.google.com/forms/d/e/{FORM_ID}/formResponse'
SIMS_URL = 'https://new-sims.mehe.gov.lb/login'
APP_VERSION = '1.62'
SCHOOL_FIELD = 'entry.194100191'
CENTER_FIELD = 'entry.1598435947'
BASE = Path(sys.executable).parent if getattr(sys, 'frozen', False) else Path(__file__).parent
ASSET_BASE = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))

class AppError(Exception):
    pass

def validate_school(name, center):
    name = ' '.join(name.split())
    if not 2 <= len(name) <= 160 or any(unicodedata.category(c).startswith('C') for c in name):
        raise AppError('أدخل اسم المدرسة بشكل صحيح، من حرفين إلى 160 حرفاً.')
    center = center.strip()
    if not center or len(center) > 12 or not all(c.isdecimal() for c in center):
        raise AppError('رقم المركز التربوي يجب أن يكون من رقم واحد إلى 12 رقماً.')
    center = ''.join(str(unicodedata.decimal(c)) for c in center)
    return name, center

def school_payload(name, center):
    name, center = validate_school(name, center)
    return {SCHOOL_FIELD: name, CENTER_FIELD: center}

def open_auth_browser(url, choice):
    if choice == 'default':
        if not webbrowser.open(url):raise AppError('تعذّر فتح المتصفح الافتراضي.')
        return
    if choice not in ('chrome','edge'):raise AppError('اختر Google Chrome أو Microsoft Edge.')
    from browser_launch import installed_executable
    path=installed_executable(choice)
    if path is None:raise AppError('ثبّت Google Chrome أو Microsoft Edge ثم أعد المحاولة.')
    subprocess.Popen([str(path),url],shell=False)

def registration_path():
    base = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.local' / 'share')))
    return base / 'SayedTech' / 'school.json'

def read_school():
    try:
        data = json.loads(registration_path().read_text(encoding='utf-8'))
        return {k: data[k] for k in ('school', 'center') if isinstance(data.get(k), str)}
    except (OSError, ValueError, AttributeError):
        return {}

def save_school(name, center):
    path = registration_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps({'school': name, 'center': center}, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, path)

def submit_school(name, center, post=None):
    payload = school_payload(name, center)
    if post is None:
        import requests
        post = requests.post
    # No auth headers, Microsoft cookies, personal IDs, tokens, or extra fields.
    response = post(POST_URL, data=payload, timeout=(10, 25),
                    headers={'Accept-Language': 'en-US,en;q=0.9'}, allow_redirects=False)
    text = response.text.casefold()
    # HTTP 200 alone is insufficient: Google may return validation/challenge HTML.
    accepted = any(s in text for s in ('your response has been recorded', 'تم تسجيل ردك', 'تم تسجيل إجابتك'))
    if response.status_code != 200 or not accepted:
        raise AppError('لم يؤكّد Google Form استلام البيانات. افحص الاتصال وإعدادات النموذج؛ لا تعتبر التسجيل مكتملًا.')
    return validate_school(name, center)


def open_sims(browser_choice='default'):
    open_auth_browser(SIMS_URL, browser_choice)
