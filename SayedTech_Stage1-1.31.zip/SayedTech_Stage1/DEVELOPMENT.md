# Development and verification

## Runtime and setup

Python desktop app targeting Windows 10/11 x64, PySide6 and Playwright using installed Chrome/Edge. Application dependencies are pinned in `requirements.txt`. Use Python 3.12 and the included Windows setup/start scripts.

Offline Excel/HTML regression tests additionally use `requirements-dev.txt`:

```sh
python -m pip install -r requirements-dev.txt
```

Node.js is required by the production JavaScript extraction tests. Their structural DOM adapter is not a live browser.

## Tests

Run from the project directory:

```sh
python -m unittest discover -p "test_*.py" -q
```

Login startup, blank navigation, OAuth handoff and browser/profile packaging:

```sh
python -m unittest test_login_startup test_login test_account_session test_packaging -q
```

Startup uses fake contexts/navigation, never a real school account. The printed installer-ready path from packaging tests is synthetic; it is not a Windows installer build. Native Chrome/Edge startup still requires validation on Windows.

Focused manual import regressions:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_birth_identity test_document_import test_detailed_batch test_manual_dynamic_forms test_manual_site_bindings test_manual_sections test_manual_auto_save test_manual_save test_manual_address test_detailed_import -q
```

Shared student-attendance workbook, supplied-shape DOM binder, serial queue and RTL UI:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_attendance test_attendance_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_attendance_ui -q
```

AttendanceExportDialog handles the extraction-only screen; AttendanceDialog handles the recovery-only screen. Keep app.py routing them separately for both shifts.

The attendance tests use synthetic DOM and a fake download; they do not run Playwright against a signed-in site. The native attendance template is authored by `tools/build_attendance_template.mjs` with `@oai/artifact-tool` in a development-only Node environment. Generate its contract JSON from `attendance_schema.HEADERS` and `list(attendance_schema.REASONS.items())` as `headers` and `reasons`, then invoke `node tools/build_attendance_template.mjs assets/student_attendance.xlsx <contract.json>`. Move generated PNG/inspection sidecars outside the source. Runtime XLSX reading/writing uses only ZIP/XML.

Afternoon database/unified dimensions and native-feature preservation:

```sh
python -m unittest test_student_excel_layout test_nsldb test_student_unified test_student_detailed -q
```

Morning export defaults and checkpoint/recovery propagation:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_checkpoint -q
```

Defaults require explicit morning shift metadata supplied by the scan wrapper. Keep raw reads unchanged and retain populated cells, including checkbox False. The regression checks that only the five requested blank cells differ from an afternoon export and that every other XLSX part is byte-identical.

Grade-menu timing, pending/open state, delayed target options and scope:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_grade_sync test_scan_grade_trigger test_scan_grade_menu test_grade_scan test_detail_scope test_detailed_batch_ui -q
```

Grade-sync tests exercise the existing correlated worker entry without inventory, draft navigation or pupil writes; Qt tests check pending/stale/failure/session routing. The DOM snapshot runs production LIST_SCRIPT on nested/repeated synthetic wrappers using Node. The trigger regressions execute production XPath against supplied-shape HTML with lxml; the label wrapper and unrelated controls are synthetic. The menu regressions use a deterministic clock and synthetic Playwright-shaped adapters. They reproduce pre-open toggle closure and partial-menu timing against 1.24, and preserve strict identity, account and grade-scope checks.

Excel layout and prior-file upgrades:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_detail_dom -q
```

Detailed-import window geometry, action reachability, inherited-theme regression and screen fitting:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_detailed_layout test_detailed_batch_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_detailed_layout -q
```

Qt tests skip when PySide6 is unavailable. On a headless system with Qt installed, set `QT_QPA_PLATFORM=offscreen`. Test fixtures contain synthetic values.

The multi-document regressions use a populated synthetic prior-format workbook and an lxml adapter around the supplied document form. They check unchanged input bytes, grouping/identity conflicts, independent card saves, review ordering, file preservation and uncertain-save/cancellation gates. They are not a live SIMS save.

## Modules

| Area | Files |
| --- | --- |
| Manual schema, Excel reading and field filling | `manual_sections.py` |
| Serial document cards from repeated pupil rows | `document_import.py` |
| Strict birth-date identity and sanitized mismatch diagnostics | `identity_dates.py` |
| Identity guards and section routing | `detailed_import.py` |
| Batch detail import UI and queue | `detailed_dialog.py`, `detailed_batch.py` |
| Student attendance contract, native Excel, browser binding and queue UI | `attendance_schema.py`, `attendance_excel.py`, `attendance_browser.py`, `attendance_dialog.py` |
| Save/confirm and separate review submission | `manual_save.py` |
| Extraction, snapshots and checkpoints | `student_scan.py`, `detail_dom.py`, `student_checkpoint.py` |
| Column relocation and native Excel lists | `scan_workbook_layout.py`, `scan_dropdowns.py` |
| Browser process event protocol | `login_worker.py`, `login_controller.py` |
| Windows build and update manifest | `build_windows.py`, `publish_update.py` |

## Source packaging

```sh
python tools/package_source.py
```

The ZIP is created beside the project folder using an explicit source allowlist. The script reads `core.APP_VERSION`; it does not change it. The ZIP retains the `SayedTech_Stage1/` root required by the updater.

GitHub's current Windows build workflow lives in the update repository, as documented in `UPDATE_GUIDE_AR.md`. This cleanup does not replace that workflow.

## Verification limits

Local tests cover ZIP/XML structure, supplied/adapted HTML bindings, rendering delays, identity guards and save routing using offline adapters. Passing them does not establish a native Excel opening, a live SIMS session or a compiled Windows installer. Verify the Windows build in GitHub Actions.
