# Development handoff — Sayed tech 1.12

## Recovery

This is the clean baseline after the final local-phone correction. Restore the folder from `SayedTech_Stage1-1.12.zip` or from a development repository. Start with `AGENTS.md`. Continuing development does not require the original temporary execution workspace.

Updater repository: `https://github.com/AliSayed-stack/SayedTech-Updates`. Its workflow takes a versioned ZIP from the root or a published release. Runtime update configuration remains in `assets/update_source.json`.

## Behaviors to retain

- Student export has 56 columns ending at BD. A is `اختيار للاسترداد اليدوي`. Header-based reading accepts the old order and extra obsolete attachment columns.
- `شهرة الأم` follows the Arabic mother name, before the English name, and targets relative #2 only.
- Keep original Excel formats/row heights and lookup lists. Updating a previous extract saves a separate copy.
- Manual import is per selected student and section. Address comes first and uses the existing seven address columns.
- Manual ID/document sections save and confirm after successful filling without requiring a file upload. Empty sections are not added/saved.
- Current registration status is display-only; the note is editable. Review submission is explicit and separate. Termination is untouched.
- The current supplied phone form has one type select, an eight-character numeric-mode input, and a primary checkbox; it has no country-code field.
- `fill_manual_section` skips retained Lebanese code 961 only after a stable local layout is confirmed. The older country-select form still binds normally, and an existing unmatched select is not ignored.

## Last functional fix

Versions 1.10/1.11 stopped during phone prevalidation at `الهواتف / رمز الدولة`. The supplied HTML proved that field is absent. Reproduced using `test_fixtures/phones_local_site.html`, then fixed in 1.12. Before cleanup, the final focused regression run passed 54 tests covering both phone forms and other import sections.

## Cleanup

Runtime code and static assets are retained. Development preview images and separate historical CHANGES files were consolidated into `CHANGELOG_AR.md`. Tests and sanitized fixtures remain. `.gitignore` excludes local school data, sessions, environments and generated output. `tools/package_source.py` builds the correctly named source ZIP.

## Verification record

Verified on 2026-10-23: full unittest discovery completed 327 tests, with 15 skipped in this environment, zero failures and zero errors. The two legacy test assumptions were updated: scan parity now includes the additional manual-section lists, and XML preservation checks accept equivalent namespace prefixes. Application runtime code, Windows scripts and static assets were byte-compared with the delivered 1.12 archive; all 65 relevant files are unchanged.

The clean ZIP was successfully restored using the app's own source-updater extractor, and update-manifest generation was checked. No Windows installer was compiled here; the packaging tests use synthetic executables. See `DEVELOPMENT.md` for commands and verification limits.
