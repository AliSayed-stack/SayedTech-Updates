# Sayed tech development instructions

Read `WORKSPACE_STATE.md` and `DEVELOPMENT.md` before changing the app.

- Preserve the Arabic desktop workflow and both school shifts.
- Make focused changes from the current source baseline and retain compatibility with previous exported Excel files.
- Manual import binds headers by name. Selection is the first exported column; mother surname follows the Arabic mother name. The main export has 56 columns.
- Keep runtime Excel handling in the existing ZIP/XML code. `openpyxl` and `lxml` are test dependencies.
- Preserve worksheet/table references, validations, named ranges and namespaces. Invalidate calculation-chain metadata after relocating formula cells.
- Do not use React IDs as stable selectors. Scope controls and buttons to their section and use labels or verified form structure.
- Local phone forms can omit the country-code select. Retain this behavior and support for the older country-select form.
- Manual ID/document import does not require an attachment; keep unrelated legacy features intact.
- Never operate on the termination checkbox. Review submission remains a separate user action.
- Never commit student records, credentials, profiles, scan checkpoints or school-session screenshots. Use synthetic test fixtures.
- Keep `core.APP_VERSION`, ZIP filename and release tag consistent. Update the handoff after material changes.
- Run appropriate regression tests. Do not claim Windows or live SIMS verification from offline mocks.

The archive root is `SayedTech_Stage1`. The existing updater consumes `SayedTech_Stage1-X.Y.zip`.
