"""Offline multi-page scan, identity boundaries, and native XLSX preservation."""
import copy
import json
import math
import shutil
import subprocess
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile
from student_scan import (TABLE_HEADERS,TABS,LIST_SCRIPT,FORM_SCRIPT,StudentBrowser,ScanError,
    TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT,grade_rank,parse_list,collect_students,export_students,missing_fields,clean_detail,MANAGEMENT)
from student_excel import FIELDS,NS,REL,read_students,ExcelInputError
from manual_sections import TAIL_HEADERS as MANUAL_HEADERS,SELECT
from student_workflow import column
from scan_workbook_layout import BASE_COUNT, MOTHER_INDEX, shift_ref, shift_formula,col_index
from test_students import record
import core


class Clock:
    def __init__(self):self.value=0
    def __call__(self):self.value+=.15;return self.value


class Node:
    def __init__(self,page,kind,key=None):self.page,self.kind,self.key=page,kind,key
    def all(self):return [self] if self.count() else []
    def count(self):
        if self.kind=='grade_menu':return int(self.page.menu_open)
        if self.kind=='rowset':return len(self.page.current_rows())
        if self.kind=='uid':return int(self.page.view=='record' and (self.page.mode=='simple' or self.page.tab==TABS[0]))
        if self.kind=='radio':return int(self.page.view=='record')
        if self.kind=='tab':return int(self.page.view=='record' and self.page.mode=='detailed')
        return 1
    def is_visible(self):return bool(self.count())
    def is_enabled(self):
        if self.kind=='button':return self.page.number>1 if self.key=='السابق' else self.page.number<math.ceil(len(self.page.filtered_rows())/self.page.size)
        return True
    def get_attribute(self,name):
        if name=='aria-checked':return 'true' if self.page.mode=='detailed' else 'false'
        if name=='aria-selected':return 'true' if self.page.tab==self.key else 'false'
        if name=='aria-disabled':return 'false'
    def input_value(self):
        if self.kind=='size':return str(self.page.size)
        if self.kind=='uid':return 'WRONG' if self.page.wrong_uid else self.page.selected['uid']
        raise AssertionError(self.kind)
    def evaluate(self,script,*args):
        if self.kind=='size':return [f'{n}:{n} / صفحة' for n in (10,25,50,100)]
        raise AssertionError(script)
    def select_option(self,value,**kw):
        if self.kind!='size':raise AssertionError('Record writes forbidden')
        self.page.actions.append(('size',value));self.page.size=int(value);self.page.number=1
    def nth(self,index):return Node(self.page,'row',index) if self.kind=='rowset' else Node(self.page,'cell',(self.key,index))
    def locator(self,selector):
        if self.kind=='grade_container' and selector=='button':return Node(self.page,'grade_button')
        if self.kind=='grade_menu' and selector=='button':return type('Options',(),{'all':lambda _: [Node(self.page,'grade_option',g) for g in ['جميع المستويات']+self.page.grade_options()]})()
        if self.kind=='row' and selector=='td':return Node(self.page,'cells',self.key)
        if self.kind=='table' and selector=='thead th':return Node(self.page,'headers')
        if self.kind=='table' and selector=='tbody tr[aria-label="تعديل"]':return Node(self.page,'rowset')
        raise AssertionError(selector)
    def all_inner_texts(self):
        if self.kind=='headers':return list(self.page.table_headers)
        raise AssertionError(self.kind)
    def inner_text(self):
        if self.kind=='grade_button':return self.page.grade or 'جميع المستويات'
        if self.kind=='grade_option':return self.key
        if self.kind=='cell':return self.page.table_cells(self.page.current_rows()[self.key[0]])[self.key[1]]
        raise AssertionError(self.kind)
    def click(self,**kw):
        p=self.page;p.actions.append(('click',self.kind,self.key))
        if self.kind=='row':
            p.selected=p.current_rows()[self.key];p.view='record';p.mode='simple';p.tab=TABS[0]
            p.actions.append(('opened',p.grade,p.number,p.selected['record_id']))
            key='same-record' if p.repeat_record_url else p.selected['record_id']
            p.url='https://new-sims.mehe.gov.lb'+MANAGEMENT+'/'+key+'/edit'
        elif self.kind=='grade_button':p.menu_open=not p.menu_open
        elif self.kind=='grade_option':
            p.grade=None if self.key=='جميع المستويات' else self.key
            p.menu_open=False;p.number=1;p.actions.append(('grade',p.grade))
        elif self.kind=='radio':p.mode='detailed'
        elif self.kind=='tab':p.tab=self.key
        elif self.kind=='button':
            if not p.stale:p.number+=1 if self.key=='التالي' else -1
        else:raise AssertionError('Unexpected mutation')


class Page:
    def __init__(self,total=105,account='test@te.mehe.school'):
        self.records=[{'record_id':f'record-{i}','uid':f'{i:06d}','first':'TEST','middle':'TEST','last':'TEST',
            'grade':('الثالث ثانوي','الأول أساسي','الروضة الأولى')[i%3],
            'language':'الفرنسية','section':'الشعبة أ'} for i in range(1,total+1)]
        self.account=account
        self.size=10;self.number=1;self.url='https://new-sims.mehe.gov.lb/dashboard/analytics'
        self.view='list';self.mode='simple';self.tab=TABS[0];self.selected=None
        self.actions=[];self.wrong_uid=False;self.stale=False;self.filters=True
        self.wrong_names=False;self.repeat_record_url=False
        self.table_headers=list(TABLE_HEADERS)
        self.grade=None;self.menu_open=False;self.stale_grade=False;self.hydration_reads=0
    def grade_options(self):return list(dict.fromkeys(r['grade'] for r in self.records if r['grade']!='—'))
    def filtered_rows(self):return [r for r in self.records if self.stale_grade or self.grade is None or r['grade']==self.grade]
    def current_rows(self):return self.filtered_rows()[(self.number-1)*self.size:self.number*self.size]
    def table_cells(self,r):return [r['uid'],r['first'],r['middle'],r['last'],r['grade'],'',r['language'],r['section'],'TEST',r.get('status',''),'']
    def get_by_text(self,text,**kw):
        if isinstance(text,str) and text=='لم يُعثر على أية سجلات':return Node(self,'empty')
        if not isinstance(text,str) and text.search(self.account):return Node(self,'account')
        return type('Empty',(),{'all':lambda s:[]})()
    def get_by_role(self,role,name,exact=True):
        if role=='button' and name in ('التالي','السابق'):return Node(self,'button',name)
        if role=='radio' and name=='مفصّل':return Node(self,'radio')
        if role=='tab' and name in TABS:return Node(self,'tab',name)
        raise AssertionError('Save/Add/unknown button forbidden')
    def locator(self,selector):
        if selector=='xpath=//span[normalize-space(.)="الصف"]/parent::div':return Node(self,'grade_container')
        if selector=='div.max-h-60.overflow-y-auto':return Node(self,'grade_menu')
        if selector=='select':return Node(self,'size')
        if selector=='table':return Node(self,'table')
        if selector=='#field-existingUniqueId':return Node(self,'uid')
        if selector=='table tbody tr[aria-label="تعديل"]':return Node(self,'rowset')
        raise AssertionError(selector)
    def goto(self,url,**kw):self.actions.append(('goto',));self.url=url;self.view='list'
    def go_back(self,**kw):
        self.actions.append(('back',));self.url='https://new-sims.mehe.gov.lb'+MANAGEMENT;self.view='list'
        # Exercise the case where the website resets pagination after return.
        self.number=1;self.size=10;self.grade=None
    def wait_for_timeout(self,*args):pass
    def evaluate(self,script,*args):
        if script==LIST_SCRIPT:
            return {'tables':[{'headers':list(self.table_headers),'rows':[
                {'editable':True,'cells':self.table_cells(r)}
                for r in self.current_rows()]}],
                'pagers':[f'الصفحة {self.number} من {max(1,math.ceil(len(self.filtered_rows())/self.size))} · {len(self.filtered_rows())} سجل إجمالاً'],
                'searches':[''],'gradeFilter':[self.grade or 'جميع المستويات'],
                'allFilters':[0 if self.grade else 1,1,1,1] if self.filters else [0,0,1,1]}
        if script==FORM_SCRIPT:
            if self.mode=='detailed' and self.tab!=TABS[0]:return []
            hydrating=self.hydration_reads>0
            if hydrating:self.hydration_reads-=1
            values=record();values.update({'field-existingUniqueId':self.selected['uid'],
                'field-firstName':'WRONG' if self.wrong_names or hydrating else self.selected['first'],
                'field-middleName':self.selected['middle'],'field-lastName':self.selected['last'],
                'field-enrollment-promoted-class':self.selected['grade'],'field-motherNameEn':''})
            return [{'id':f['id'],'label':f['label'],'required':f['required'],'value':values[f['id']],'kind':f['type']} for f in FIELDS]
        if script in (TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT):return {'found':False,'text':''}
        raise AssertionError('Unexpected script')


class ScanTests(unittest.TestCase):
    def test_missing_ids_are_read_separately_across_pages(self):
        page=Page(102)
        for i,r in enumerate(page.records):
            r['uid']=('—','–','-','')[i%4]
            r['first']=f'TEST{i}'
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),102)
        self.assertTrue(all(r['values']['field-existingUniqueId']=='' for r in data['records']))
        self.assertEqual(len({r['values']['field-firstName'] for r in data['records']}),102)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'missing-id.xlsx';export_students(data,path,threading.Event())
            with zipfile.ZipFile(path) as z:
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                rows=sheet.findall('m:sheetData/m:row',NS)[1:103]
                self.assertTrue(all(not row[1].find('m:is/m:t',NS).text for row in rows))
                report=ET.fromstring(z.read('xl/worksheets/sheet5.xml'))
                first=report.findall('m:sheetData/m:row',NS)[1]
                self.assertIn('لم يظهر رقم موحد',first[-2].find('m:is/m:t',NS).text)
                details=ET.fromstring(z.read('xl/worksheets/sheet6.xml'))
                refs={r[0].find('m:is/m:t',NS).text for r in details.findall('m:sheetData/m:row',NS)[1:]}
                self.assertEqual(refs,{str(i) for i in range(2,104)})

    def test_missing_id_wrong_name_stops_and_repeated_record_is_skipped(self):
        page=Page(3)
        for r in page.records:r['uid']='—'
        page.wrong_names=True
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(cm.exception.reason,'identity_changed')
        page.wrong_names=False;page.repeat_record_url=True
        page.view='list';page.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(sum(r.get('skipped')=='duplicate_record' for r in data['records']),2)

    def test_repeated_real_uid_keeps_separate_records_and_deleted_is_not_opened(self):
        page=Page(102)
        page.records[100]['uid']=page.records[0]['uid']
        page.records[100]['first']='OTHER'
        page.records[0]['status']='محذوف'
        page.records[0]['grade']='—'
        page.records[1]['status']='غير نشط'
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),102)
        pair=[r for r in data['records'] if r['item']['uid']==page.records[0]['uid']]
        self.assertEqual(len(pair),2)
        self.assertEqual(sum(r.get('skipped')=='deleted' for r in pair),1)
        self.assertTrue(any(r['values']['field-firstName']=='OTHER' and not r.get('skipped') for r in pair))
        self.assertEqual(sum(a[0]=='click' and a[1]=='row' for a in page.actions),101)
        self.assertFalse(next(r for r in data['records'] if r['item'].get('status')=='غير نشط').get('skipped'))
        deleted=next(r for r in data['records'] if r.get('skipped')=='deleted')
        self.assertEqual(missing_fields(deleted),([],[]))

    def test_active_students_with_same_uid_are_not_merged(self):
        page=Page(3)
        for i,r in enumerate(page.records):r.update(uid='SAME-ID',first=f'TEST{i}')
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),3)
        self.assertTrue(all(not r.get('skipped') for r in data['records']))
        self.assertEqual(len({r['values']['field-firstName'] for r in data['records']}),3)
        self.assertTrue(all(r['values']['field-existingUniqueId']=='SAME-ID' for r in data['records']))

    def test_real_snapshot_javascript_and_arabic_layout_variants(self):
        node=shutil.which('node')
        if node is None:self.skipTest('Node is unavailable for DOM script regression')
        raw=Page(3).evaluate(LIST_SCRIPT)
        raw['pagers']=['\u200fالصفحة ١ من ١ • ٣ سجل إجمالًا\u200e']
        # Extra/reordered columns, line wraps and directional marks are display
        # differences; identity still comes from its named column.
        raw['tables'][0]['headers'].insert(0,'تحديد')
        raw['tables'][0]['headers'][1]='\u200fالرقم الموحد\n للطالب'
        for row in raw['tables'][0]['rows']:row['cells'].insert(0,'')
        fixture={'raw':raw,'script':LIST_SCRIPT}
        harness=r'''
const fs=require('fs'); const {raw,script}=JSON.parse(fs.readFileSync(0,'utf8'));
const el=text=>({textContent:text,getClientRects:()=>[{}]});
const tables=raw.tables.map(t=>({...el(''),querySelectorAll:s=>s==='thead th'?t.headers.map(el):
 t.rows.map(r=>({getAttribute:()=>r.editable?'تعديل':'',querySelectorAll:()=>r.cells.map(el)}))}));
const defaults=['جميع المستويات','جميع الفروع','جميع لغات التدريس','جميع الشعب'];
const labels=['الصف','فرع الصف','لغة التدريس','الشعبة'].map((t,i)=>({ ...el(t),
 parentElement:{querySelectorAll:()=>[el('\u200f '+defaults[i].replaceAll(' ','\n ')+' \u200e')]}}));
// Unrelated/portal buttons must not be counted as management filters.
global.document={querySelectorAll:s=>s==='table'?tables:s==='p'?raw.pagers.map(el):s==='span'?labels:
 s==='button'?[...defaults,...defaults].map(el):[]};
process.stdout.write(JSON.stringify(eval('('+script+')')()));
'''
        result=subprocess.run([node,'-e',harness],input=json.dumps(fixture),text=True,capture_output=True,check=True)
        state=parse_list(json.loads(result.stdout))
        self.assertEqual(state['total'],3)
        self.assertEqual(state['rows'][0]['uid'],'000001')
        self.assertEqual(state['rows'][0]['uid_column'],1)

    def test_only_unrelated_columns_are_optional_and_errors_keep_their_reason(self):
        raw=Page(3).evaluate(LIST_SCRIPT)
        for i in (10,9,8,5):
            raw['tables'][0]['headers'].pop(i)
            for row in raw['tables'][0]['rows']:row['cells'].pop(i)
        self.assertEqual(len(parse_list(raw)['rows']),3)
        raw['tables'][0]['headers'][0]='UNKNOWN'
        with self.assertRaises(ScanError) as cm:parse_list(raw)
        self.assertEqual(cm.exception.reason,'headers_changed')
        page=Page();page.filters=False;page.url='https://new-sims.mehe.gov.lb'+MANAGEMENT
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            StudentBrowser(page,'test@te.mehe.school',threading.Event()).wait_list()
        self.assertEqual(cm.exception.reason,'filters_active')
        page=Page();page.stale=True
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            collect_students(page,'test@te.mehe.school',threading.Event())
        self.assertEqual(cm.exception.reason,'page_not_changed')
        self.assertEqual(clean_detail({'reason':'headers_changed','uid':'SECRET'}),{'reason':'headers_changed'})

    def test_non_applicable_branch_through_tenth_grade_only(self):
        for grade in ('الروضة الأولى', 'السادس أساسي', 'الأول ثانوي', 'العاشر'):
            with self.subTest(grade=grade):
                page=Page(1);page.records[0]['grade']=grade;page.grade=grade
                raw=page.evaluate(LIST_SCRIPT)
                raw['otherFilters']=[['لا ينطبق على هذا الصف'],['جميع لغات التدريس'],['جميع الشعب']]
                self.assertEqual(parse_list(raw,grade)['total'],1)
                raw['otherFilters'][0]=['الفرع العلمي']
                with self.assertRaises(ScanError) as cm:parse_list(raw,grade)
                self.assertEqual(cm.exception.reason,'filters_active')
                raw['otherFilters'][0]=['لا ينطبق على هذا الصف']
                raw['otherFilters'][1]=['الفرنسية']
                with self.assertRaises(ScanError) as cm:parse_list(raw,grade)
                self.assertEqual(cm.exception.reason,'filters_active')
                raw['otherFilters'][1]=['جميع لغات التدريس']
                raw['otherFilters'][2]=['الشعبة أ']
                with self.assertRaises(ScanError) as cm:parse_list(raw,grade)
                self.assertEqual(cm.exception.reason,'filters_active')
        page=Page(1);page.grade='الثاني ثانوي';page.records[0]['grade']=page.grade
        raw=page.evaluate(LIST_SCRIPT)
        raw['otherFilters']=[['لا ينطبق على هذا الصف'],['جميع لغات التدريس'],['جميع الشعب']]
        with self.assertRaises(ScanError) as cm:parse_list(raw,page.grade)
        self.assertEqual(cm.exception.reason,'filters_active')

    def test_open_uses_named_uid_column_with_extra_leading_column(self):
        page=Page(3)
        page.table_headers.insert(0,'تحديد')
        old_cells=page.table_cells
        page.table_cells=lambda r:['']+old_cells(r)
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),3)
        self.assertTrue(all(r['item']['uid_column']==1 for r in data['records']))

    def test_selected_grade_allows_changed_dependent_captions_but_checks_full_roster(self):
        class DynamicFilters(Page):
            def evaluate(self,script,*args):
                raw=super().evaluate(script,*args)
                if script==LIST_SCRIPT and self.grade:
                    # Reproduce the old failure: grade is correct, but an
                    # unrelated all-level caption remains and dependent filters
                    # no longer display their default all captions.
                    raw['allFilters']=[1,0,0,0]
                return raw
        page=DynamicFilters(6)
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),6)
        self.assertEqual([a[1] for a in page.actions if a[0]=='opened'],
            ['الروضة الأولى']*2+['الأول أساسي']*2+['الثالث ثانوي']*2)
        class RestrictedGrade(DynamicFilters):
            def filtered_rows(self):
                rows=super().filtered_rows()
                return rows[1:] if self.grade else rows
        page=RestrictedGrade(6)
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(cm.exception.reason,'grade_coverage')
        self.assertFalse(any(a[0]=='opened' for a in page.actions))
        class EmptyGrade(DynamicFilters):
            def filtered_rows(self):return [] if self.grade else super().filtered_rows()
        page=EmptyGrade(6)
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(cm.exception.reason,'grade_coverage')
        self.assertFalse(any(a[0]=='opened' for a in page.actions))

    def test_grade_filter_finishes_every_page_before_next_grade_and_restores_on_return(self):
        page=Page(204)
        for i,r in enumerate(page.records):r['grade']='الروضة الأولى' if i<202 else 'الثالث ثانوي'
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        opened=[a for a in page.actions if a[0]=='opened']
        self.assertEqual([a[1] for a in opened],['الروضة الأولى']*202+['الثالث ثانوي']*2)
        self.assertEqual([a[2] for a in opened[:202]],[1]*100+[2]*100+[3]*2)
        self.assertEqual(len(data['records']),204)
        # The fake resets the grade, page and page size on every back navigation.
        self.assertGreaterEqual(page.actions.count(('grade','الروضة الأولى')),202)
        self.assertEqual(len({a[3] for a in opened}),204)

    def test_stale_grade_rows_are_rejected_and_hydrating_identity_is_awaited(self):
        page=Page(3);page.stale_grade=True
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError) as cm:
            collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(cm.exception.reason,'grade_filter')
        self.assertFalse(any(a[0]=='opened' for a in page.actions))
        page=Page(3);page.hydration_reads=8
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),3)
        self.assertTrue(all(r['values']['field-firstName']=='TEST' for r in data['records']))

    def test_sort_order_and_unknown_grade_are_explicit(self):
        grades=['الثالث ثانوي','التاسع أساسي','الروضة الثالثة','الأول ثانوي','الأول أساسي','الروضة الأولى','الروضة الثانية']
        self.assertEqual(sorted(grades,key=grade_rank),['الروضة الأولى','الروضة الثانية','الروضة الثالثة','الأول أساسي','التاسع أساسي','الأول ثانوي','الثالث ثانوي'])
        with self.assertRaises(ScanError):grade_rank('UNKNOWN')

    def test_multipage_100_inventory_sorted_trial_and_no_record_writes(self):
        page=Page();events=[]
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),10,lambda *e:events.append(e))
        self.assertEqual(data['inventory'],105);self.assertEqual(len(data['records']),10)
        self.assertTrue(all(r['item']['grade']=='الروضة الأولى' for r in data['records']))
        self.assertEqual([r['item']['uid'] for r in data['records']],[f'{i:06d}' for i in range(2,30,3)])
        self.assertIn(('size','100'),page.actions)
        self.assertTrue(any(e[0]==105 and e[2]['stage']=='inventory' for e in events))
        self.assertEqual(page.view,'list')
        self.assertTrue(all(r['unread_tabs'] for r in data['records']))
        self.assertTrue(all(missing_fields(r)[0] for r in data['records']))

    def test_all_scope_crosses_pages_and_preserves_identity(self):
        page=Page(102)
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(len(data['records']),102)
        self.assertEqual(len({r['item']['uid'] for r in data['records']}),102)
        self.assertEqual([grade_rank(r['item']['grade']) for r in data['records']],sorted(grade_rank(r['grade']) for r in page.records))

    def test_stale_pagination_filters_duplicate_and_wrong_record_stop(self):
        page=Page();page.stale=True
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError):
            collect_students(page,'test@te.mehe.school',threading.Event())
        page=Page();page.filters=False
        with self.assertRaises(ScanError):parse_list(page.evaluate(LIST_SCRIPT))
        page=Page(3);page.wrong_uid=True
        with patch('student_scan.time.monotonic',Clock()),self.assertRaises(ScanError):
            collect_students(page,'test@te.mehe.school',threading.Event())
        self.assertFalse(any(a[1:]==('radio',None) for a in page.actions if a[0]=='click'))

    def test_wrong_account_redirect_draft_and_cancellation_are_rejected(self):
        for username,url in [('other@te.mehe.school','https://new-sims.mehe.gov.lb/dashboard/analytics'),
                             ('test@te.mehe.school','https://evil.example/dashboard/students/management'),
                             ('test@te.mehe.school','https://new-sims.mehe.gov.lb'+MANAGEMENT+'/new')]:
            page=Page();page.url=url
            with self.assertRaises(ScanError):StudentBrowser(page,username,threading.Event()).prepare()
            self.assertEqual(page.actions,[])
        cancelled=threading.Event();cancelled.set()
        with self.assertRaises(ScanError) as cm:StudentBrowser(Page(),'test@te.mehe.school',cancelled).guard()
        self.assertEqual(cm.exception.code,'scan_cancelled')

    def test_unread_values_and_repeated_controls_are_not_collapsed(self):
        result={'values':{},'read_ids':[],'address':{},'fields':[]}
        field={'id':'generated1','label':'المنطقة*','required':True,'value':'A','kind':'select'}
        StudentBrowser.capture(result,TABS[2],[field,dict(field,id='generated2',value='B')])
        self.assertNotIn('المنطقة',result['address'])
        self.assertEqual([f['value'] for f in result['fields']],['A','B'])
        self.assertFalse(missing_fields(result)[0]);self.assertTrue(missing_fields(result)[1])
        self.assertEqual(clean_detail({'grade':'الروضة الأولى','uid':'SECRET','name':'SECRET','inventory':5}),{'grade':'الروضة الأولى','inventory':5})

    def test_waits_for_saved_panel_and_captures_explicit_display_fields(self):
        class Delayed(Page):
            reads=0
            def evaluate(self,script,*args):
                if script in (TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT) and args[0]=='بطاقات التعريف':
                    self.reads+=1
                    if self.reads<9:
                        return {'found':True,'text':'','loading':True}
                    return {'found':True,'text':'رقم الوثيقة\n00123','loading':False,
                        'fields':[{'id':'','label':'رقم الوثيقة','value':'00123',
                                   'required':False,'kind':'display'}]}
                return super().evaluate(script,*args)
        page=Delayed(1)
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        self.assertEqual(page.reads,1)
        row=data['records'][0]
        self.assertFalse(any(f['section']=='بطاقات التعريف' for f in row['fields']))
        self.assertIn('بطاقات التعريف',row['unread_tabs'])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'compact.xlsx'
            export_students(data,path,threading.Event())
            with zipfile.ZipFile(path) as z:
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                for col in sheet.findall('m:cols/m:col',NS):
                    if int(col.get('min'))>BASE_COUNT+1:self.assertEqual(col.get('width'),'22')
                rows=sheet.findall('m:sheetData/m:row',NS)
                self.assertEqual(rows[1].get('customHeight'),'1')
                self.assertNotIn('00123',ET.tostring(rows[1],encoding='unicode'))
                self.assertNotIn('00123',z.read('xl/worksheets/sheet6.xml').decode())
                self.assertEqual(len(rows[0]),BASE_COUNT+len(MANUAL_HEADERS))

    def test_saved_cards_and_optional_detailed_fields_are_exported(self):
        class Cards(Page):
            def evaluate(self,script,*args):
                if script in (TAB_SNAPSHOT_SCRIPT,SETTLED_TAB_SCRIPT) and args[0]=='بطاقات التعريف':
                    return {'found':True,'text':'نوع المستند\nهوية\nرقم الوثيقة\n123456'}
                if script==FORM_SCRIPT and self.view=='record' and self.mode=='detailed' and self.tab=='الجنسيات والقيد':
                    return [{'id':'dynamic-optional','label':'مكان القيد','required':False,'value':'زغرتا','kind':'text'}]
                return super().evaluate(script,*args)
        page=Cards(1)
        with patch('student_scan.time.monotonic',Clock()):
            data=collect_students(page,'test@te.mehe.school',threading.Event(),0)
        row=data['records'][0]
        self.assertEqual(row['tab_texts']['بطاقات التعريف'],'نوع المستند\nهوية\nرقم الوثيقة\n123456')
        self.assertIn('بطاقات التعريف',row['unread_tabs'])
        self.assertTrue(any(f['label']=='مكان القيد' and f['value']=='زغرتا' for f in row['fields']))
        row['fields'].extend([
            {'section':'الأقارب','label':'الشهرة','value':'الأب','required':False,'kind':'text'},
            {'section':'الأقارب','label':'الشهرة','value':'الأم','required':False,'kind':'text'}])
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'details.xlsx';export_students(data,path,threading.Event())
            with zipfile.ZipFile(path) as z:
                book=ET.fromstring(z.read('xl/workbook.xml'))
                names=[s.get('name') for s in book.findall('m:sheets/m:sheet',NS)]
                self.assertIn('البطاقات الظاهرة',names)
                self.assertIn('123456',z.read('xl/worksheets/sheet7.xml').decode())
                self.assertIn('زغرتا',z.read('xl/worksheets/sheet6.xml').decode())
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                exported=sheet.findall('m:sheetData/m:row',NS)
                def values(node):
                    return {c.get('r')[:-len(node.get('r'))]:''.join(t.text or '' for t in c.findall('.//m:t',NS)) for c in node}
                headings=values(exported[0]);record=values(exported[1])
                self.assertEqual(record['M'],'زغرتا')
                with zipfile.ZipFile(core.ASSET_BASE/'assets/student_with_addresses.xlsx') as original:
                    template=ET.fromstring(original.read('xl/worksheets/sheet1.xml'))
                    def width(cols,n):return next((c.get('width') for c in cols if int(c.get('min'))<=n<=int(c.get('max'))),None)
                    for n in range(1,36):self.assertEqual(width(sheet.find('m:cols',NS),n+(n>=MOTHER_INDEX)+1),width(template.find('m:cols',NS),n))
                    original_headers=values(template.find('m:sheetData/m:row',NS))
                    self.assertEqual({k:headings[column(col_index(shift_ref(k+'1')[:-1])+1)] for k in original_headers},original_headers)
                    self.assertEqual(headings['A'],SELECT)
                    self.assertEqual(list(headings.values())[BASE_COUNT+1:],MANUAL_HEADERS[1:])
                    old_styles=ET.fromstring(original.read('xl/styles.xml')).find('m:cellXfs',NS)
                    new_styles=ET.fromstring(z.read('xl/styles.xml')).find('m:cellXfs',NS)
                    self.assertEqual([ET.tostring(x) for x in old_styles],[ET.tostring(x) for x in list(new_styles)[:len(old_styles)]])
                table=ET.fromstring(z.read('xl/tables/table1.xml'))
                self.assertEqual(len(table.findall('m:tableColumns/m:tableColumn',NS)),BASE_COUNT+len(MANUAL_HEADERS))
                self.assertEqual(table.get('ref'),f'A1:{column(BASE_COUNT+len(MANUAL_HEADERS))}501')


    def data(self):
        with patch('student_scan.time.monotonic',Clock()):
            return collect_students(Page(3),'test@te.mehe.school',threading.Event(),0)

    def test_export_preserves_dropdowns_dates_ids_and_rejects_creation_import(self):
        data=self.data();data['records'][0]['address']['الشارع']='=HYPERLINK("https://example.invalid")'
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'scan.xlsx';export_students(data,path,threading.Event())
            with zipfile.ZipFile(core.ASSET_BASE/'assets/student_with_addresses.xlsx') as z:
                original=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                refs=z.read('xl/worksheets/sheet4.xml')
            with zipfile.ZipFile(path) as z:
                self.assertIsNone(z.testzip())
                book=ET.fromstring(z.read('xl/workbook.xml'))
                self.assertIn('حالة السحب',[s.get('name') for s in book.findall('m:sheets/m:sheet',NS)])
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                row=sheet.findall('m:sheetData/m:row',NS)[1]
                self.assertEqual(row[0].find('m:is/m:t',NS).text,'0')
                self.assertEqual(row[1].find('m:is/m:t',NS).text,data['records'][0]['item']['uid'])
                street=next(c for c in row if c.get('r')=='AH2')
                self.assertEqual(street.get('t'),'inlineStr');self.assertIsNone(street.find('m:f',NS))
                status=next(c for c in row if c.get('r')=='AK2')
                self.assertEqual(status.find('m:is/m:t',NS).text,'لا سجلات عناوين')
                self.assertEqual(z.read('xl/worksheets/sheet4.xml'),refs)
                for old,new in zip(original.findall('m:dataValidations/m:dataValidation',NS),sheet.findall('m:dataValidations/m:dataValidation',NS)):
                    old.set('sqref',shift_ref(old.get('sqref')))
                    def next_column(text):
                        return __import__('re').sub(r'(\$?)([A-Z]+)(\$?\d+)',lambda m:m[1]+column(col_index(m[2])+1)+m[3],text)
                    old.set('sqref',next_column(old.get('sqref')))
                    old.set('showDropDown','0')
                    for f in old:
                        if f.text:f.text=shift_formula(shift_formula(f.text),next_column)
                    formula=new.find('m:formula1',NS)
                    if formula is not None and formula.text.startswith('SayedSourceList_'):
                        definition=next(n for n in book.findall('m:definedNames/m:definedName',NS) if n.get('name')==formula.text)
                        self.assertEqual(old.find('m:formula1',NS).text,definition.text)
                        old.find('m:formula1',NS).text=formula.text
                    self.assertEqual(ET.tostring(old),ET.tostring(new))
                date_cell=next(c for c in row if c.get('r')=='I2')
                self.assertIsNotNone(date_cell.find('m:v',NS))
                rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
                for rel in rels:
                    if rel.get('Id','').startswith('rIdStudentScan'):
                        self.assertTrue(rel.get('Type').endswith('/worksheet'))
                        self.assertIn('xl/'+rel.get('Target'),z.namelist())
            with self.assertRaisesRegex(ExcelInputError,'طلاب موجودين'):read_students(path)

    def test_extended_export_ranges_and_atomic_failure_and_cancel(self):
        data=self.data();data['records']=[copy.deepcopy(data['records'][0]) for _ in range(501)];data['inventory']=501
        data['records'][-1]['unread_tabs']=[]
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'scan.xlsx';export_students(data,path,threading.Event())
            with zipfile.ZipFile(path) as z:
                sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                dimension=sheet.find('m:dimension',NS).get('ref')
                self.assertTrue(dimension.startswith('A1:') and dimension.endswith('502'))
                last=sheet.findall('m:sheetData/m:row',NS)[-1]
                self.assertIn('AD502',next(c for c in last if c.get('r')=='AK502').find('m:f',NS).text)
                self.assertTrue(any('502' in d.get('sqref') for d in sheet.findall('m:dataValidations/m:dataValidation',NS)))
                table=ET.fromstring(z.read('xl/tables/table1.xml'))
                self.assertEqual(table.get('ref'),dimension)
            original=path.read_bytes()
            cancelled=threading.Event();cancelled.set()
            with self.assertRaises(ScanError):export_students(data,path,cancelled)
            self.assertEqual(path.read_bytes(),original)
            with patch('student_scan.os.replace',side_effect=OSError('TEST')),self.assertRaises(ScanError):
                export_students(data,path,threading.Event())
            self.assertEqual(path.read_bytes(),original)
            self.assertEqual(list(Path(tmp).iterdir()),[path])


if __name__=='__main__':unittest.main()
