"""Offline Qt, SQL CE and asset smoke check for the packaged application."""

def check_app():
    from PySide6.QtWidgets import QApplication, QWidget
    from PySide6.QtSvgWidgets import QSvgWidget
    from sqlce import SqlceDatabase
    from student_unified import UNIFIED_HEADERS
    from detailed_import import read_details
    import core
    for name in ('student_simple_schema.json', 'student_unified.xlsx'):
        if not (core.ASSET_BASE/'assets'/name).is_file(): raise RuntimeError('Missing application asset')
    app = QApplication.instance() or QApplication([])
    widget = QWidget(); widget.show(); app.processEvents(); widget.close()
    if not SqlceDatabase or not UNIFIED_HEADERS or not read_details or not QSvgWidget:
        raise RuntimeError('Missing dependency')
