import uuid
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView,QComboBox

class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.pending=None
        self.manual_mode=all('manual' in r for r in rows)
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setLayoutDirection(Qt.RightToLeft);self.resize(1050,620)
        layout=QVBoxLayout(self)
        note=QLabel('الاستيراد المفصّل متاح لمدارس قبل الظهر وبعد الظهر بنفس الخطوات، ضمن حساب المدرسة المسجّل. '
            'اختر التلميذ والقسم المطلوب. يتحقق البرنامج من الاسم الكامل وتاريخ الولادة قبل فتح السجل. '
            'عند بدء أي طلب يرجع المتصفح إلى إدارة الطلاب، ثم يفتح الطالب المطابق؛ احفظ أي مسودة مفتوحة قبل الضغط. '
            'كل كبسة تحفظ القسم المحدد وتؤكد الحفظ. في الأقارب يملأ شهرة الأم ويحفظ القسم. '
            'الزر العلوي يحفظ الأقسام التي لها بيانات في الملف بالترتيب: العنوان، الهاتف، شهرة الأم، وبطاقة التعريف عند اختيار نوع المستند. '
            'لا يُرسل أي سجل للمراجعة.')
        note.setWordWrap(True);layout.addWidget(note)
        from manual_sections import IMPORT_SECTIONS,section_summary
        headings=(['صف Excel','الطالب']+list(IMPORT_SECTIONS) if self.manual_mode else ['صف Excel','الطالب','شهرة الأم','البلد','العنوان','الهاتف','نوع المستند','رقم الوثيقة','تاريخ الانتهاء'])
        self.table=QTableWidget(len(rows),len(headings))
        self.table.setHorizontalHeaderLabels(headings)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[str(row['excel_row']),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                str(row.get('mother_surname','')),address.get('البلد',''),
                ' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            card=row.get('identity_card',{})
            texts.extend(str(card.get(k,'') or '') for k in ('type','number','expiry'))
            if self.manual_mode:
                texts=texts[:2]+[section_summary(row,title) for title in IMPORT_SECTIONS]
            for j,text in enumerate(texts):
                item=QTableWidgetItem(text);item.setToolTip(text);self.table.setItem(i,j,item)
        self.table.resizeColumnsToContents();layout.addWidget(self.table)
        self.status=QLabel('اختر القسم. العنوان يحتاج البلد والمحافظة والقضاء والمنطقة، والهاتف 8 أرقام، والأقارب شهرة الأم.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.buttons=[]
        if self.manual_mode:
            note.setText('اختر الطالب والقسم الذي عبّأته في Excel. يربط البرنامج الأعمدة بخانات القسم المحدد فقط، ويتحقق من هوية الطالب. '
                         'عناوين السكن تستخدم أعمدة البلد والمحافظة والقضاء والمنطقة والشارع والنوع وتفاصيل العنوان الموجودة في الملف. '
                         'اختر تعبئة فقط للمراجعة أو تعبئة وحفظ مع تأكيد حفظ القسم. الخانات الفارغة لا تمسح بيانات الموقع. '
                         'بطاقات التعريف والمستندات تُحفظ وتُؤكّد تلقائياً بعد تعبئة البيانات، دون ملف مرفق. الحالة الحالية للقراءة فقط؛ الإرسال للمراجعة له زر منفصل للطالب المحدد.')
            self.manual_sections=QComboBox()
            for title in IMPORT_SECTIONS:self.manual_sections.addItem(title,'manual:'+title)
            layout.addWidget(self.manual_sections)
            manual_button=QPushButton('تعبئة القسم اليدوي المحدد — ثم احفظه بالموقع')
            self.manual_fill_button=manual_button
            manual_button.clicked.connect(lambda:self.start(self.manual_sections.currentData()))
            layout.addWidget(manual_button)
            self.manual_save_button=QPushButton('تعبئة وحفظ القسم المحدد')
            self.manual_save_button.clicked.connect(lambda:self.start(self.manual_sections.currentData().replace('manual:','manual_save:',1)))
            layout.addWidget(self.manual_save_button)
            self.review_button=QPushButton('إرسال الطالب المحدد للمراجعة')
            self.review_button.clicked.connect(lambda:self.start('review_send'))
            layout.addWidget(self.review_button)
            self.manual_controls=[manual_button,self.manual_sections,self.manual_save_button,self.review_button]
            self.buttons.extend(self.manual_controls)
            self.manual_sections.currentIndexChanged.connect(self.manual_changed)
            self.manual_changed()
        self.all_button=QPushButton('استرداد وحفظ كل الأقسام المتاحة للطالب المحدد')
        self.all_button.clicked.connect(lambda:self.start('all'))
        layout.addWidget(self.all_button);self.buttons.append(self.all_button)
        self.card_button=QPushButton('تعبئة وحفظ بطاقة التعريف — دون رفع ملف')
        self.card_button.clicked.connect(lambda:self.start('identity_card'))
        layout.addWidget(self.card_button);self.buttons.append(self.card_button)
        bar=QHBoxLayout()
        for title,section in [('استرداد عنوان الطالب المحدد','address'),('استرداد هاتف الطالب المحدد','phone'),('تعبئة شهرة الأم وحفظ الأقارب','relative')]:
            b=QPushButton(title);b.clicked.connect(lambda checked=False,s=section:self.start(s));bar.addWidget(b);self.buttons.append(b)
        if self.manual_mode:
            for b in self.buttons:
                if b not in self.manual_controls:b.hide()
            self.status.setText('اختر القسم من القائمة. بعد كل تعبئة احفظه بالموقع قبل فتح قسم آخر.')
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);bar.addWidget(self.close_button);layout.addLayout(bar)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        self.finished.connect(self.detach);self.table.setCurrentCell(0,0)

    def manual_changed(self,*args):
        if self.manual_mode and not self.pending:
            current=self.manual_sections.currentData()
            auto=current in ('manual:بطاقات التعريف','manual:المستندات')
            self.manual_fill_button.setText('تعبئة وحفظ القسم المحدد تلقائياً' if auto else 'تعبئة القسم المحدد فقط')
            self.manual_save_button.setVisible(not auto)
            self.manual_save_button.setEnabled(current!='manual:حالة التسجيل')

    def start(self,section):
        i=self.table.currentRow()
        if i<0 or self.pending:return
        request=uuid.uuid4().hex
        if self.controller.fill_details(self.rows[i],section,request):
            self.pending=request
            for b in self.buttons+[self.close_button]:b.setEnabled(False)
            self.table.setEnabled(False);self.status.setText('جارٍ التحقق من التلميذ ثم تعبئة القسم…')
        else:self.status.setText('جلسة المتصفح غير متاحة. أعد تسجيل الدخول.')

    def result(self,request,event,field):
        if request!=self.pending:return
        self.pending=None;self.table.setEnabled(True)
        for b in self.buttons+[self.close_button]:b.setEnabled(True)
        if self.manual_mode:self.manual_changed()
        self.status.setText({
            'detail_save_blocked':'زر الحفظ ما زال معطلاً. راجع الحقول المطلوبة في القسم؛ لم يُضغط الحفظ.',
            'detail_no_data':'القسم فارغ في Excel؛ تم تخطيه دون إضافة أو حفظ.',
            'detail_review_sent':'تم الإرسال للمراجعة، وتأكد ظهور «مقدّم للمراجعة» في الموقع.',
            'detail_review_already':'الطالب مقدّم للمراجعة بالفعل؛ لم يُرسل مرة ثانية.',
            'detail_card_input':'اختر نوع المستند من أعمدة بطاقة التعريف في Excel، وأكمل رقم الوثيقة (أو رقم السجل السابق). تاريخ الانتهاء اختياري ويجب أن يكون تاريخاً صالحاً عند إدخاله.',
            'detail_card_disabled':'زر حفظ بطاقة التعريف ما زال معطلاً في الموقع. راجع الحقول أو رسالة التحقق الظاهرة؛ لم يتم الضغط على الحفظ.',
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_saved':'حُفظ القسم المحدد بنجاح.',
            'detail_all_saved':'حُفظت الأقسام المتاحة من ملف Excel بالتتابع بنجاح.',
            'detail_all_partial':'اكتملت الأقسام التي أمكن تعبئتها. بعض الأقسام موجودة سلفاً أو ناقصة في Excel وتُخطّيت دون استبدالها. راجع عمود شهرة الأم ونتيجة الموقع.',
            'detail_mother_missing':'شهرة الأم فارغة في صف Excel المحدد. عبّئ عمود «شهرة الأم (للمفصّل)» واحفظ الملف ثم أعد استيراده.',
            'detail_mother_field':'شهرة الأم وصلت من Excel، لكن لم أستطع تحديد خانة الشهرة وحدها داخل «الأقارب #2» الخاصة بالأم. ابعث HTML لهذا القسم مع عنوانه والخانة لضبطه.',
            'detail_save_unknown':'تم الضغط على حفظ القسم، لكن لم يصل تأكيد نجاح. راجع القسم المفتوح وما سبقه قبل إعادة المحاولة.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على سجل واحد مطابق للاسم الكامل وتاريخ الولادة في إدارة الطلاب. لم يُدخل عنوان.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'تعذّر الرجوع إلى إدارة الطلاب أو جرد سجلاتها. افتح الإدارة وتأكد أن كل المرشحات «جميع» ودون بحث، ثم أعد المحاولة.',
            'detail_existing':'القسم يحتوي سجلاً أو مسودة؛ لم يُستبدل. راجع الموجود في الموقع.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار أو مربع التأكيد بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_input':'أكمل بيانات القسم المختار في Excel: العنوان أو الهاتف أو شهرة الأم، ثم احفظ الملف وأعد استرداده.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.'))
        from manual_sections import HEADERS
        if field in HEADERS:self.status.setText(self.status.text()+'\nالخانة: '+field)

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.pending=None;self.close_button.setEnabled(True)
            for b in self.buttons:b.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.table.clearContents()

    def reject(self):
        if self.pending:return
        super().reject()
