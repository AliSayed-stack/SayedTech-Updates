"""Local, read-only NSLDB student reference export. No SIMS or account access."""
from datetime import date, datetime
import hashlib
from html import unescape
import os
from pathlib import Path
import re
import tempfile
import threading
import xml.etree.ElementTree as ET
import zipfile

import core
from student_excel import FIELDS, HEADERS, NS

REFERENCE_SHEET = 'مرجع NSLDB'
REFERENCE_EXTRA = ['مسجّل بمدرستي؟', 'إدخال مبسّط؟', 'السنة في القاعدة',
    'الحالة في القاعدة', 'معرّف الشخص في القاعدة', 'معرّف المدرسة في القاعدة',
    'الدوام في القاعدة', 'اسم المدرسة في القاعدة', 'ملاحظات المصدر']
REFERENCE_HEADERS = HEADERS + REFERENCE_EXTRA
DETAIL_HEADERS = ['رقم الهاتف (LivingPhone)', 'هاتف الترشيح (OEPhone)',
    'البريد الإلكتروني (OEEmail)', 'التسلسل الدراسي (SequenceNb)',
    'التسلسل الدراسي السابق (PrevSequenceNb)', 'الرقم الداخلي في المدرسة (SchoolInternalID)',
    'رقم الإفادة (Code)', 'باركود الإفادة (BarCode)', 'نوع الإفادة (StatementTypeID / ReportName)',
    'تاريخ طباعة الإفادة (PrintDate)', 'رقم الإفادة السابقة (PrevAttestationNum)',
    'سنة الإفادة السابقة (PrevAttestationYear)']
FULL_REFERENCE_HEADERS = REFERENCE_HEADERS + DETAIL_HEADERS
DETAILED_CHOICE = 'استكمال مفصّل؟'
DETAILED_HEADERS = [DETAILED_CHOICE if h == REFERENCE_EXTRA[1] else h for h in FULL_REFERENCE_HEADERS]
EXPORT_MODES = {'simple', 'detailed', 'reference'}
TARGET_YEAR = '20252026'
TARGET_YEAR_LABEL = '2025–2026'
SOURCE_SHEETS = (('StudentSchool', 'تسجيلات القاعدة'), ('GPerson', 'أشخاص الطلاب'),
    ('BRCStatement', 'إفادات الطلاب'), ('StudentCurriculum', 'مقررات الطلاب'),
    ('StudentJustification', 'استثناءات الطلاب'), ('StudentSupplement', 'تغييرات الطلاب'),
    ('StudentDocs', 'مستندات الطلاب'))
LOOKUPS = ('StudentStatus', 'Regions', 'Casa', 'Area', 'IdentityType', 'BloodType',
    'ResultType', 'JustifiedType', 'Curriculum', 'CurriculumType', 'CurriculumSubType',
    'SchoolSector', 'FieldType', 'CertificationType', 'CertificationSession', 'ReasonStatus',
    'DiscountType', 'DiscountReason', 'ScheduleType', 'ClassCurriculum', 'CurriculumSub',
    'JobTitle', 'JobType')
MAX_RECORDS = 5000
MAX_DATABASE_BYTES = 512 * 1024 * 1024
TABLES = ('GPerson', 'StudentSchool', 'Classes', 'ClassSections', 'TeachingLang',
          'Nationalities', 'Schedule', 'SchoolInformation', 'BRCStatement',
          'StudentCurriculum', 'StudentJustification', 'StudentSupplement', 'StudentDocs') + LOOKUPS
REQUIRED = {'GPerson': {'GPersonID', 'FirstName', 'LastName'},
    'StudentSchool': {'MEHEID', 'TermID', 'GPersonID', 'ClassID', 'SystemStatus'},
    'Classes': {'ID', 'Code', 'ClassName'}, 'ClassSections': {'ID', 'Name'},
    'TeachingLang': {'ID', 'Code', 'Name'}, 'Nationalities': {'ID', 'Name'}}


class ReferenceError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def check_cancelled(cancelled):
    if cancelled.is_set():
        raise ReferenceError('cancelled')


def text(value):
    """Materialize only used textual values; never read photos or other blobs."""
    if value is None:
        return ''
    if hasattr(value, 'read'):
        value = value.read()
    if not isinstance(value, (str, int, float, bool)):
        raise ReferenceError('schema')
    return str(value).strip()


def _source_value(person, registration, names, token_groups=()):
    """Find a known field alias without treating unrelated AddedOn dates as enrollment dates."""
    aliases = {re.sub(r'[^a-z0-9]', '', name.lower()) for name in names}
    for row in (person, registration):
        for key, value in row.items():
            normalized = re.sub(r'[^a-z0-9]', '', str(key).lower())
            token_match = any(all(token in normalized for token in group) for group in token_groups)
            if (normalized in aliases or token_match) and value is not None and text(value):
                return text(value), str(key)
    return '', ''


def _bool_source(value):
    value = text(value).strip().lower()
    if value in {'1', 'true', 'yes', 'y', 'نعم', 'متوفى', 'متوفاة'}:
        return 'نعم'
    if value in {'0', 'false', 'no', 'n', 'لا', 'غير متوفى', 'غير متوفاة'}:
        return 'لا'
    return ''


def _source_date(value):
    value = text(value)
    if not value:
        return ''
    for fmt in ('%d/%m/%Y', '%Y-%m-%d', '%m/%d/%Y', '%d-%m-%Y'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    return value


def password_candidates(program_path):
    """Read SDF connection literals statically; never load or execute an EXE/DLL."""
    path = Path(program_path)
    if path.suffix.lower() not in {'.exe', '.dll', '.config'} or not path.is_file():
        raise ReferenceError('program')
    if path.stat().st_size > 32 * 1024 * 1024:
        raise ReferenceError('program')
    data = path.read_bytes()
    strings = [m.group().decode('ascii') for m in re.finditer(rb'[\x20-\x7e]{8,}', data)]
    strings += [m.group().decode('utf-16le') for m in re.finditer(rb'(?:[\x20-\x7e]\x00){8,}', data)]
    pattern = re.compile(r'(?:password|pwd|ssce:database password)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^;\x00\r\n]*))', re.I)
    result = []
    for s in strings:
        # Some app versions concatenate "Data Source=" with a separate SDF
        # path/password literal. Both are connection settings, not app execution.
        if '.sdf' not in s.lower():
            continue
        for match in pattern.finditer(unescape(s)):
            value = next(v for v in match.groups() if v is not None).strip()
            if 0 < len(value) <= 40 and value not in result:
                result.append(value)
            if len(result) >= 10:
                return result
    return result


def open_database(path, source_path, password='', program_path='', factory=None):
    if factory is None:
        try:
            from sqlce import SqlceDatabase
        except ImportError:
            raise ReferenceError('dependency') from None
        factory = SqlceDatabase
    candidates = [password] if password else ['']
    if not password:
        files = [Path(program_path)] if program_path else []
        if not program_path:
            parent = Path(source_path).parent
            # Read a matching local installation first, then bundled files.
            # Never execute or load either file as code.
            files += [folder / name for folder in (parent, parent.parent,
                      core.ASSET_BASE / 'assets' / 'legacy')
                      for name in ('MDBL.dll', 'MEHENSL.exe') if (folder / name).is_file()]
        for file in files:
            candidates += [p for p in password_candidates(file) if p not in candidates]
    for candidate in candidates:
        try:
            return factory(str(path), password=candidate)
        except Exception as exc:
            if type(exc).__name__ == 'InvalidPasswordError':
                continue
            # No engine error text, connection string or password enters the UI.
            raise ReferenceError('format') from None
    raise ReferenceError('password')


def read_tables(db, cancelled, progress, academic_year=None):
    available = set(db.list_tables())
    if not set(REQUIRED) <= available:
        raise ReferenceError('schema')
    result, counts = {'_schema': {}}, []
    for i, name in enumerate(TABLES, 1):
        check_cancelled(cancelled)
        if name not in available:
            result[name] = []
            continue
        count = db.row_count(name)
        limit = MAX_RECORDS if name == 'StudentSchool' and not academic_year else 100000
        if count > limit:
            raise ReferenceError('limit')
        columns = list(db.table_schema(name))
        schema = {c.name for c in columns}
        result['_schema'][name] = [(c.name, getattr(c, 'type_name', '')) for c in columns]
        if not REQUIRED.get(name, set()) <= schema:
            raise ReferenceError('schema')
        rows = db.read_table(name)
        if len(rows) != count:
            raise ReferenceError('count')
        result[name] = rows
        counts.append((name, count))
        progress('read', i, len(TABLES))
    return result, counts


def map_records(tables, cancelled=None):
    cancelled = cancelled or threading.Event()
    people = {}
    for person in tables['GPerson']:
        key = person['GPersonID']
        if key in people:
            raise ReferenceError('identity')
        people[key] = person
    lookup = {n: {r['ID']: r for r in tables.get(n, []) if 'ID' in r} for n in
              ('Classes', 'ClassSections', 'TeachingLang', 'Nationalities', 'Schedule', 'JobTitle', 'JobType')}
    schools = {(text(r.get('MEHEID')), text(r.get('TermID'))): text(r.get('SchoolName'))
               for r in tables.get('SchoolInformation', [])}
    grades = {'GRD01': 'الروضة الأولى', 'GRD02': 'الروضة الثانية', 'GRD03': 'الروضة الثالثة',
        **{f'PRM{i:02}': name + ' أساسي' for i, name in enumerate(
            ('الأول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع'), 1)},
        'SCD01': 'الأول ثانوي', 'SCD02': 'الثاني ثانوي', 'SCD03': 'الثالث ثانوي'}
    ranks = {code: i for i, code in enumerate(grades)}
    result = []
    statements = {}
    for statement in tables.get('BRCStatement', []):
        key = (text(statement.get('MEHEID')), text(statement.get('GPersonID')),
               canonical_year(statement.get('TermID')))
        statements.setdefault(key, []).append(statement)
    for s in tables['StudentSchool']:
        check_cancelled(cancelled)
        if s['GPersonID'] not in people:
            raise ReferenceError('identity')
        person = people[s['GPersonID']]
        values = {f['id']: '' for f in FIELDS}
        mapping = {'firstName': 'FirstName', 'firstNameEn': 'FirstNameEN',
            'lastName': 'LastName', 'lastNameEn': 'LastNameEN', 'middleName': 'MiddleName',
            'middleNameEn': 'MiddleNameEN', 'motherName': 'MotherName',
            'registryNumber': 'EnrolmentNum', 'registryPlace': 'EnrolmentPlace', 'birthPlace': 'PlaceOfBirth'}
        for target, source in mapping.items():
            values['field-' + target] = text(person.get(source))
        # Some database builds store these details directly on the person or
        # enrollment row. Read them when present; older schemas simply omit them.
        optional_source_fields = {
            'field-middleName': ('FatherName', 'FatherFirstName', 'ParentFatherName'),
            'field-middleNameEn': ('FatherNameEN', 'FatherFirstNameEN'),
            'field-motherName': ('MotherFirstName', 'ParentMotherName'),
            'field-fatherSector': ('FatherSector', 'FatherWorkSector', 'FatherJobTypeName', 'FatherJobTypeID'),
            'field-fatherOccupation': ('FatherOccupation', 'FatherJob', 'FatherProfession', 'FatherJobTitleName', 'FatherJobTitleID'),
            'field-motherSector': ('MotherSector', 'MotherWorkSector', 'MotherJobTypeName', 'MotherJobTypeID'),
            'field-motherOccupation': ('MotherOccupation', 'MotherJob', 'MotherProfession', 'MotherJobTitleName', 'MotherJobTitleID'),
            'field-motherNationality': ('MotherNationalityName', 'MotherNationalityID'),
            'field-maritalStatus': ('MaritalStatusName', 'MaritalStatus', 'SocialStatus', 'CivilStatus'),
            'field-enrollment-registration-date': ('RegistrationDate', 'EnrollmentDate', 'EnrolmentDate', 'AdmissionDate'),
        }
        source_keys = {}
        for field_id, aliases in optional_source_fields.items():
            fuzzy = {
                'field-fatherSector': (('father', 'sector'), ('father', 'worktype'), ('father', 'jobtype')),
                'field-fatherOccupation': (('father', 'occupation'), ('father', 'profession'), ('father', 'jobtitle')),
                'field-motherSector': (('mother', 'sector'), ('mother', 'worktype'), ('mother', 'jobtype')),
                'field-motherOccupation': (('mother', 'occupation'), ('mother', 'profession'), ('mother', 'jobtitle')),
                'field-motherNationality': (('mother', 'nationality'),),
                'field-maritalStatus': (('marital', 'status'), ('social', 'status'), ('civil', 'status')),
                'field-enrollment-registration-date': (('registration', 'date'), ('enrollment', 'date'), ('enrolment', 'date'), ('admission', 'date')),
            }.get(field_id, ())
            value, key = _source_value(person, s, aliases, fuzzy)
            source_keys[field_id] = key
            if value and key.lower().endswith('id'):
                table = ('JobType' if 'Sector' in field_id else
                         'JobTitle' if 'Occupation' in field_id else
                         'Nationalities' if 'Nationality' in field_id else '')
                candidate = lookup.get(table, {}).get(value)
                if candidate is None and value.isdigit():
                    candidate = lookup.get(table, {}).get(int(value))
                if candidate:
                    value = text(candidate.get('Name')) or text(candidate.get('Code'))
            if value and not values.get(field_id):
                values[field_id] = _source_date(value) if field_id == 'field-enrollment-registration-date' else value
        for field_id, aliases in {
                'isFatherDeceased': ('FatherDeceased', 'IsFatherDeceased', 'FatherIsDeceased', 'FatherDead'),
                'isMotherDeceased': ('MotherDeceased', 'IsMotherDeceased', 'MotherIsDeceased', 'MotherDead')}.items():
            parent = 'father' if field_id == 'isFatherDeceased' else 'mother'
            value, key = _source_value(person, s, aliases,
                ((parent, 'deceased'), (parent, 'death'), (parent, 'dead')))
            source_keys[field_id] = key
            if value:
                values[field_id] = _bool_source(value)
        values['field-existingUniqueId'] = text(s.get('UniqueID'))
        values['field-nationality'] = text(lookup['Nationalities'].get(person.get('NationalityID'), {}).get('Name'))
        values['field-gender'] = {'انثى': 'أنثى', 'أنثى': 'أنثى', 'ذكر': 'ذكر',
            'male': 'ذكر', 'female': 'أنثى'}.get(text(person.get('Gender')), '')
        dob = text(person.get('DateOfBirth'))
        for fmt in ('%d/%m/%Y', '%Y-%m-%d'):
            try:
                values['field-birthDate'] = datetime.strptime(dob, fmt).date().isoformat()
                break
            except ValueError:
                pass
        grade = lookup['Classes'].get(s.get('ClassID'), {})
        code = text(grade.get('Code'))
        values['field-enrollment-promoted-class'] = grades.get(code, text(grade.get('ClassName')))
        language = lookup['TeachingLang'].get(s.get('TeachingLangID'), {})
        values['field-enrollment-teaching-language'] = {'ARA': 'العربية', 'FRA': 'الفرنسية',
            'ENG': 'الإنكليزية'}.get(text(language.get('Code')), text(language.get('Name')))
        section = text(lookup['ClassSections'].get(s.get('ClassSectionID'), {}).get('Name'))
        section = re.sub('[\u200b-\u200f\ufeff]', '', section).strip()
        if section:
            values['field-enrollment-grade-section'] = section if section.startswith('الشعبة ') else 'الشعبة ' + ('أ' if section == 'ا' else section)
        status = text(s.get('SystemStatus'))
        school_id, term = text(s.get('MEHEID')), text(s.get('TermID'))
        notes = []
        if dob and not values['field-birthDate']:
            notes.append('تاريخ الولادة غير قابل للمطابقة: ' + dob)
        if code not in grades:
            notes.append('راجع مطابقة الصف والفرع الأصلي: ' + text(grade.get('ClassName')))
        if text(person.get('MotherLastName')):
            notes.append('شهرة الأم في القاعدة: ' + text(person.get('MotherLastName')))
        # Report only specific gaps in this student's source row. The old
        # blanket sentence incorrectly sounded like every row had empty data.
        missing = []
        for label, field_id in (
                ('قطاع عمل الأب', 'field-fatherSector'), ('مهنة الأب', 'field-fatherOccupation'),
                ('وفاة الأب', 'isFatherDeceased'), ('قطاع عمل الأم', 'field-motherSector'),
                ('مهنة الأم', 'field-motherOccupation'), ('وفاة الأم', 'isMotherDeceased'),
                ('تاريخ التسجيل', 'field-enrollment-registration-date')):
            if not values.get(field_id):
                missing.append(label)
        if missing:
            notes.append('حقول لم تُنقل لعدم وجود قيمة مطابقة في سجل المصدر: ' + '، '.join(missing) +
                         '. راجع أوراق المصدر إذا كانت المعلومات مسجلة تحت اسم حقل مختلف.')
        legacy_dates = [f'{name}={text(s.get(name))}' for name in ('AddedOn', 'NSLAddedOn') if text(s.get(name))]
        if legacy_dates and not values.get('field-enrollment-registration-date'):
            notes.append('تاريخ إضافة السجل القديم محفوظ في ورقة تسجيلات القاعدة (' + '؛ '.join(legacy_dates) + ')، ولا يُعامل كتاريخ تسجيل.')
        metadata = ['لم أحدد', 'لا', term,
            {'Deleted': 'محذوف (Deleted)', 'Leave': 'مغادر (Leave)',
             'Promoted': 'مرفّع (Promoted)'}.get(status, status or 'غير معلّم بحالة'),
            text(s['GPersonID']), school_id,
            text(lookup['Schedule'].get(s.get('ClassScheduleID'), {}).get('Name')),
            schools.get((school_id, term), ''), '؛ '.join(notes)]
        papers = statements.get((school_id, text(s['GPersonID']), canonical_year(term)), [])
        details = [text(s.get(name)) for name in ('LivingPhone', 'OEPhone', 'OEEmail',
                   'SequenceNb', 'PrevSequenceNb', 'SchoolInternalID')]
        details += ['\n'.join(text(p.get(name)) for p in papers) for name in ('Code', 'BarCode')]
        details += ['\n'.join(text(p.get('StatementTypeID')) + ' / ' + text(p.get('ReportName')) for p in papers),
                    '\n'.join(text(p.get('PrintDate')) for p in papers),
                    text(s.get('PrevAttestationNum')), text(s.get('PrevAttestationYear'))]
        result.append({'values': values, 'metadata': metadata, 'details': details,
                       'sort': (ranks.get(code, 999), term, values['field-lastName'],
                                values['field-firstName'], text(s['GPersonID']))})
    if not result:
        raise ReferenceError('empty')
    if len(result) > MAX_RECORDS:
        raise ReferenceError('limit')
    # Every enrollment survives, including identical IDs and all status values.
    return sorted(result, key=lambda r: r['sort'])


def canonical_year(value):
    digits = re.sub(r'\D', '', text(value))
    if len(digits) == 8 and int(digits[4:]) == int(digits[:4]) + 1:
        return digits
    return text(value)


def tables_for_year(tables, year=TARGET_YEAR):
    """Keep the chosen year's registrations and their school/person relations."""
    year = canonical_year(year)
    if year != TARGET_YEAR:
        raise ReferenceError('year')
    result = dict(tables)
    registrations = [r for r in tables['StudentSchool'] if canonical_year(r.get('TermID')) == year]
    if not registrations:
        raise ReferenceError('year_empty')
    result['StudentSchool'] = registrations
    identities = {(text(r.get('MEHEID')), text(r.get('GPersonID'))) for r in registrations}
    people = {person for _, person in identities}
    schools = {school for school, _ in identities}
    result['GPerson'] = [r for r in tables['GPerson'] if text(r['GPersonID']) in people]
    for name, _ in SOURCE_SHEETS:
        if name in ('GPerson', 'StudentSchool'):
            continue
        result[name] = [r for r in tables.get(name, []) if canonical_year(r.get('TermID')) == year and
                        (text(r.get('MEHEID')), text(r.get('GPersonID'))) in identities]
    result['SchoolInformation'] = [r for r in tables.get('SchoolInformation', [])
        if canonical_year(r.get('TermID')) == year and text(r.get('MEHEID')) in schools]
    return result


def source_sheets(tables, cancelled):
    """Preserve every scalar student column and related row before closing SQL CE."""
    people = {text(r['GPersonID']): r for r in tables['GPerson']}
    student_ids = {text(r.get('GPersonID')) for table, _ in SOURCE_SHEETS if table != 'GPerson'
                   for r in tables.get(table, [])}
    aliases = {'GPersonID': 'معرّف الشخص', 'MEHEID': 'معرّف المدرسة', 'TermID': 'السنة الأصلية',
        'LivingPhone': 'رقم الهاتف', 'OEPhone': 'هاتف الترشيح', 'OEEmail': 'البريد الإلكتروني',
        'SequenceNb': 'التسلسل الدراسي', 'PrevSequenceNb': 'التسلسل السابق',
        'PrevAttestationNum': 'رقم الإفادة السابقة', 'PrevAttestationYear': 'سنة الإفادة السابقة',
        'Code': 'الرمز أو رقم الإفادة', 'BarCode': 'الباركود', 'StatementTypeID': 'نوع الإفادة',
        'PrintDate': 'تاريخ الطباعة', 'PrintTime': 'وقت الطباعة', 'ReportName': 'اسم التقرير',
        'SchoolInternalID': 'الرقم الداخلي بالمدرسة', 'UniqueID': 'الرقم الموحد',
        'FirstName': 'الاسم', 'MiddleName': 'اسم الأب', 'LastName': 'الشهرة',
        'MotherName': 'اسم الأم', 'MotherLastName': 'شهرة الأم', 'DateOfBirth': 'تاريخ الولادة',
        'PlaceOfBirth': 'محل الولادة', 'EnrolmentNum': 'رقم السجل', 'EnrolmentPlace': 'مكان القيد',
        'IdentityNo': 'رقم مستند الهوية', 'SystemStatus': 'حالة السجل',
        'PrevSchoolName': 'المدرسة السابقة', 'IssueNumber': 'رقم المستند أو القرار',
        'IssueDate': 'تاريخ المستند أو القرار', 'Photo': 'الصورة', 'DocData': 'المرفق'}
    def scalar(value, typ, column):
        if value is None:
            return ''
        if typ.lower() in {'image', 'binary', 'varbinary'} or column in {'Photo', 'DocData'} or isinstance(value, bytes):
            return '[قيمة ثنائية موجودة؛ غير مضمّنة في Excel]'
        if hasattr(value, 'read'):
            value = value.read()
        if isinstance(value, bytes):
            return '[قيمة ثنائية موجودة؛ غير مضمّنة في Excel]'
        result = value.isoformat() if isinstance(value, (date, datetime)) else str(value)
        if len(result) > 32767:
            raise ReferenceError('cell_limit')
        return result
    result = []
    for table, sheet_name in SOURCE_SHEETS:
        rows = tables.get(table, [])
        if table == 'GPerson':
            rows = [r for r in rows if text(r['GPersonID']) in student_ids]
        columns = tables.get('_schema', {}).get(table, [])
        if not columns and rows:
            columns = [(name, '') for name in rows[0]]
        headers = ['اسم الطالب'] + [aliases.get(name, name) + (' (' + name + ')' if name in aliases else '')
                                    for name, _ in columns]
        data = []
        for row in rows:
            check_cancelled(cancelled)
            person = people.get(text(row.get('GPersonID')), {})
            name = ' '.join(text(person.get(k)) for k in ('FirstName', 'MiddleName', 'LastName'))
            data.append([name] + [scalar(row.get(name), typ, name) for name, typ in columns])
        result.append({'name': sheet_name, 'headers': headers, 'rows': data})
    # Resolve lookup IDs without guessing the meaning of their numeric codes.
    codes = []
    for table in ('Classes', 'ClassSections', 'TeachingLang', 'Nationalities', 'Schedule') + LOOKUPS:
        for row in tables.get(table, []):
            codes.append([table, text(row.get('ID')), text(row.get('Code')),
                          text(row.get('Name', row.get('ClassName', row.get('CasaName', row.get('AreaName')))))])
    result.append({'name': 'قوائم القاعدة', 'headers': ['جدول المصدر', 'المعرّف (ID)', 'الرمز (Code)', 'الاسم'], 'rows': codes})
    return result


def write_reference(records, path, source_name, digest, counts, cancelled=None, source_data=None,
                    mode='reference', academic_year=None):
    """Runtime value fill of the bundled Artifact Tool-authored native template."""
    cancelled = cancelled or threading.Event()
    if mode not in EXPORT_MODES:
        raise ReferenceError('mode')
    if academic_year and (canonical_year(academic_year) != TARGET_YEAR or
            any(canonical_year(r['metadata'][2]) != TARGET_YEAR for r in records)):
        raise ReferenceError('year')
    target = Path(path)
    template = core.ASSET_BASE / ('assets/student_nsldb_2025.xlsx' if academic_year and mode == 'detailed'
                                else f'assets/student_nsldb_{mode}.xlsx')
    protected = {core.ASSET_BASE / f'assets/student_nsldb_{m}.xlsx' for m in EXPORT_MODES}
    protected |= {core.ASSET_BASE / 'assets/student_simple.xlsx', core.ASSET_BASE / 'assets/student_with_addresses.xlsx'}
    protected |= {core.ASSET_BASE / 'assets/student_nsldb_2025.xlsx', core.ASSET_BASE / 'assets/student_workflow_simple.xlsx'}
    if target.suffix.lower() != '.xlsx' or target.resolve() in {p.resolve() for p in protected}:
        raise ReferenceError('output')
    last_column = 'AJ' if mode == 'simple' else 'AV'
    q = lambda name: '{' + NS['m'] + '}' + name
    def column(index):
        name = ''
        while index:
            index, rem = divmod(index - 1, 26)
            name = chr(65 + rem) + name
        return name
    def cell(row, col, value, style=None, numeric=False):
        node = ET.SubElement(row, q('c'), r=f'{col}{row.get("r")}')
        if style is not None:
            node.set('s', style)
        if numeric:
            ET.SubElement(node, q('v')).text = str(value)
        else:
            node.set('t', 'inlineStr')
            value = re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]', '\ufffd', str(value))
            ET.SubElement(ET.SubElement(node, q('is')), q('t')).text = value
        return node
    with zipfile.ZipFile(template) as z:
        items = {name: z.read(name) for name in z.namelist()}
    sheet = ET.fromstring(items['xl/worksheets/sheet1.xml'])
    body = sheet.find('m:sheetData', NS)
    styles = {re.sub(r'\d+', '', c.get('r')): c.get('s') for c in body[1]}
    for row in list(body)[1:]:
        body.remove(row)
    maxrow = max(501, len(records) + 1)
    for index, record in enumerate(records, 2):
        check_cancelled(cancelled)
        lines = max((value.count('\n') + 1 for value in record.get('details', []) if isinstance(value, str)), default=1)
        row = ET.SubElement(body, q('row'), r=str(index), ht=str(max(48, min(400, lines * 15))), customHeight='1')
        for n, f in enumerate(FIELDS, 1):
            value = record['values'].get(f['id'], '')
            numeric = False
            if f['type'] == 'date' and value:
                value = (date.fromisoformat(value) - date(1899, 12, 30)).days
                numeric = True
            cell(row, column(n), value, styles.get(column(n)), numeric)
        extra = record['metadata'] + ([] if mode == 'simple' else record.get('details', [''] * len(DETAIL_HEADERS)))
        for n, value in enumerate(extra, len(FIELDS) + 1):
            cell(row, column(n), value, styles.get(column(n)))
    dimension = sheet.find('m:dimension', NS)
    if dimension is None:
        dimension = ET.Element(q('dimension'))
        sheet.insert(1 if sheet.find('m:sheetPr', NS) is not None else 0, dimension)
    dimension.set('ref', f'A1:{last_column}{maxrow}')
    for tag in ('m:dataValidations/m:dataValidation', 'm:conditionalFormatting'):
        for node in sheet.findall(tag, NS):
            node.set('sqref', re.sub(r'(?<=[A-Z])501\b', str(maxrow), node.get('sqref', '')))
    items['xl/worksheets/sheet1.xml'] = ET.tostring(sheet, encoding='utf-8', xml_declaration=True)
    for name in list(items):
        if name.startswith('xl/tables/') and name.endswith('.xml'):
            table = ET.fromstring(items[name])
            if table.get('name') == 'StudentsInput':
                table.set('ref', f'A1:{last_column}{maxrow}')
                auto = table.find('m:autoFilter', NS)
                if auto is not None:
                    auto.set('ref', f'A1:{last_column}{maxrow}')
                items[name] = ET.tostring(table, encoding='utf-8', xml_declaration=True)
    # Resolve marker sheet through workbook relationships, never assume its index.
    book = ET.fromstring(items['xl/workbook.xml'])
    marker = next(s for s in book.find('m:sheets', NS) if s.get('name') == REFERENCE_SHEET)
    rel_id = marker.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
    rels = ET.fromstring(items['xl/_rels/workbook.xml.rels'])
    part = next(r.get('Target') for r in rels if r.get('Id') == rel_id)
    part = part.lstrip('/') if part.startswith('/') else 'xl/' + part
    meta = ET.fromstring(items[part])
    content = meta.find('m:sheetData', NS)
    for row in list(content):
        content.remove(row)
    info = [('Sayed tech — مرجع NSLDB', ''), ('إصدار التنسيق', '2'),
        ('اسم ملف المصدر', source_name), ('بصمة SHA-256', digest),
        ('عدد التسجيلات', len(records)), ('تاريخ الاستخراج', datetime.now().isoformat(timespec='seconds')),
        ('طريقة الاختيار', 'نعم في مسجّل بمدرستي؟ وإدخال مبسّط؟'),
        ('الإجراء الافتراضي', 'لا تسجيل لأي طالب'),
        ('الأعمدة الإضافية', 'الهاتف والتسلسل والإفادات للمراجعة فقط؛ لا تدخل تلقائياً في المبسّط'),
        ('الصور والمرفقات', 'يظهر وجود القيمة الثنائية بعلامة؛ الصور والمرفقات غير مضمّنة في Excel'),
        ('الجدول المقروء', 'عدد السجلات')]
    if mode != 'reference':
        info[1] = ('إصدار التنسيق', '3')
        info[6] = ('طريقة الاختيار', 'نعم في مسجّل بمدرستي؟ و' + (DETAILED_CHOICE if mode == 'detailed' else REFERENCE_EXTRA[1]))
        info[8] = ('محتوى الملف', 'خانات المبسّط الـ27 وأعمدة الاختيار والمصدر' if mode == 'simple' else
                   'البيانات المتاحة كاملة؛ استرداد المفصّل إلى SIMS غير مفعّل بعد')
        info.insert(2, ('نوع التصدير', mode))
    info += counts
    if academic_year:
        info.insert(3, ('السنة الدراسية', canonical_year(academic_year)))
        info.insert(4, ('نطاق السحب', 'كل بيانات الطلاب المرتبطة بتسجيلات 2025–2026، بجميع الحالات'))
    for index, pair in enumerate(info, 1):
        row = ET.SubElement(content, q('row'), r=str(index))
        for col, value in zip(('A', 'B'), pair):
            cell(row, col, value, numeric=isinstance(value, int))
    dimension = meta.find('m:dimension', NS)
    if dimension is None:
        dimension = ET.Element(q('dimension'))
        meta.insert(1 if meta.find('m:sheetPr', NS) is not None else 0, dimension)
    dimension.set('ref', f'A1:B{len(info)}')
    items[part] = ET.tostring(meta, encoding='utf-8', xml_declaration=True)
    for dataset in ([] if mode == 'simple' else source_data or []):
        marker = next(s for s in book.find('m:sheets', NS) if s.get('name') == dataset['name'])
        rid = marker.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        target_part = next(r.get('Target') for r in rels if r.get('Id') == rid)
        target_part = target_part.lstrip('/') if target_part.startswith('/') else 'xl/' + target_part
        raw = ET.fromstring(items[target_part])
        grid = raw.find('m:sheetData', NS)
        header_style = grid[0][0].get('s') if len(grid) and len(grid[0]) else None
        body_style = grid[1][0].get('s') if len(grid) > 1 and len(grid[1]) else None
        for node in list(grid): grid.remove(node)
        for index, values in enumerate([dataset['headers']] + dataset['rows'], 1):
            check_cancelled(cancelled)
            row = ET.SubElement(grid, q('row'), r=str(index), ht='52' if index == 1 else '24', customHeight='1')
            for col, value in enumerate(values, 1):
                cell(row, column(col), value, header_style if index == 1 else body_style)
        dim = raw.find('m:dimension', NS)
        if dim is None:
            dim = ET.Element(q('dimension'));raw.insert(1 if raw.find('m:sheetPr', NS) is not None else 0, dim)
        last = column(len(dataset['headers']))
        dim.set('ref', f'A1:{last}{len(dataset["rows"])+1}')
        auto = raw.find('m:autoFilter', NS)
        if auto is not None: raw.remove(auto)
        auto = ET.Element(q('autoFilter'), ref=f'A1:{last}{len(dataset["rows"])+1}')
        children = list(raw)
        position = next((i for i, node in enumerate(children) if node.tag in {q('conditionalFormatting'), q('dataValidations'), q('pageMargins'), q('pageSetup'), q('drawing')}), len(children))
        raw.insert(position, auto)
        items[target_part] = ET.tostring(raw, encoding='utf-8', xml_declaration=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix='.xlsx', delete=False) as f:
            temporary = Path(f.name)
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
            for name, value in items.items():
                check_cancelled(cancelled)
                z.writestr(name, value)
        check_cancelled(cancelled)
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def export_database(source, destination, password='', program_path='', cancelled=None,
                    progress=None, factory=None, mode='reference', academic_year=None):
    if mode not in EXPORT_MODES:
        raise ReferenceError('mode')
    if academic_year and canonical_year(academic_year) != TARGET_YEAR:
        raise ReferenceError('year')
    cancelled = cancelled or threading.Event()
    progress = progress or (lambda *_: None)
    source = Path(source)
    destination = Path(destination)
    if not source.is_file() or source.suffix.lower() != '.sdf':
        raise ReferenceError('input')
    if not 4096 <= source.stat().st_size <= MAX_DATABASE_BYTES:
        raise ReferenceError('limit')
    def digest_file(path):
        digest = hashlib.sha256()
        with path.open('rb') as file:
            while chunk := file.read(1024 * 1024):
                check_cancelled(cancelled)
                digest.update(chunk)
        return digest.hexdigest()
    with tempfile.TemporaryDirectory(prefix='SayedTech_NSLDB_') as folder:
        snapshot = Path(folder) / 'NSLDB.sdf'
        before = digest_file(source)
        with source.open('rb') as original, snapshot.open('wb') as copy_file:
            while chunk := original.read(1024 * 1024):
                check_cancelled(cancelled)
                copy_file.write(chunk)
        if before != digest_file(snapshot) or before != digest_file(source):
            raise ReferenceError('changed')
        progress('open', 0, 0)
        db = open_database(snapshot, source, password, program_path, factory)
        tables = None
        try:
            tables, counts = read_tables(db, cancelled, progress, academic_year=academic_year)
            if academic_year:
                tables = tables_for_year(tables, academic_year)
                counts = [(name, len(tables.get(name, []))) for name, _ in counts]
            records = map_records(tables, cancelled)
            source_data = [] if mode == 'simple' else source_sheets(tables, cancelled)
        finally:
            tables = None
            db = None
        progress('export', 0, len(records))
        write_reference(records, destination, source.name, before, counts, cancelled, source_data,
                        mode=mode, academic_year=academic_year)
        return {'records': len(records), 'people': len({r['metadata'][4] for r in records}),
                'selected': 0}
