"""Scoped DOM extraction: values come from controls, never a form's innerText."""
import json
import re


def tab_locator(page,title):
    tab=page.get_by_role('tab',name=title,exact=True)
    if tab.count():return tab
    # An incomplete step can display its ordinal instead of the check icon.
    return page.get_by_role('tab',name=re.compile(r'^\s*(?:[0-9٠-٩]+\s*)?'+re.escape(title)+r'\s*$'))

SNAPSHOT_JS = r'''(tabName) => {
 const shown=e=>!!e.getClientRects().length;
 const clean=s=>String(s??'').replace(/[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g,'').replace(/\s+/g,' ').trim();
 const all=[...document.querySelectorAll('section')].filter(shown).filter(s=>
   [...s.querySelectorAll('h1,h2,h3,h4,[role="heading"]')].some(h=>shown(h)&&clean(h.textContent)===tabName));
 const candidates=all.filter(s=>!all.some(other=>other!==s&&s.contains(other)));
 if(candidates.length!==1)return {found:false,text:'',fields:[]};
 const section=candidates[0];
 const content=[...section.children].find(e=>e.classList.contains('p-5'))||section;
 const groupOf=e=>{
   for(let p=e.parentElement;p&&p!==section;p=p.parentElement){
     const names=[...new Set([...p.querySelectorAll('h3,h4,h5,span,p')].filter(h=>shown(h)&&/^الأقارب\s*#?\s*[0-9٠-٩]+$/.test(clean(h.textContent))).map(h=>clean(h.textContent)))];
     if(names.length===1)return names[0];if(names.length>1)return '';
   }return '';
 };
 const fields=[];
 for(const e of content.querySelectorAll('input,select,textarea')){
   if(!shown(e)||['hidden','file','password','submit','button'].includes(e.type))continue;
   let label=[...(e.labels||[])].map(l=>clean(l.textContent)).join(' ');
   if(!label){
     for(let p=e.parentElement;p&&p!==section;p=p.parentElement){
       if(p.querySelectorAll('input,select,textarea').length!==1)break;
       const labels=[...p.querySelectorAll('label')].filter(shown);
       if(labels.length===1){label=clean(labels[0].textContent);break;}
     }
   }
   if(!label)continue;
   const kind=e.type==='checkbox'?'checkbox':e.tagName==='SELECT'?'select':e.type||'text';
   const value=kind==='checkbox'?e.checked:e.tagName==='SELECT'?
     (e.value?clean(e.selectedOptions[0]?.textContent):''):e.value;
   fields.push({id:e.id||'',label,group:groupOf(e),value,kind,
     required:e.required||e.getAttribute('aria-required')==='true'||/\*/.test(label)});
 }
 const labels=new Set(__LABELS__.map(clean));
 for(const label of content.querySelectorAll('label,dt,span,p,div')){
   if(!shown(label))continue;
   const name=clean(label.textContent).replace(/\s*\*\s*$/,'');
   if(!labels.has(name))continue;
   const target=label.htmlFor?document.getElementById(label.htmlFor):null;
   if(target&&/^(INPUT|SELECT|TEXTAREA)$/.test(target.tagName))continue;
   if(label.children.length&&label.tagName!=='LABEL'&&label.tagName!=='DT')continue;
   const value=label.nextElementSibling;
   if(!value||!shown(value)||value.matches('input,select,textarea,button')||value.querySelector('input,select,textarea,button'))continue;
   if(value.nextElementSibling&&label.tagName!=='DT'&&label.tagName!=='LABEL')continue;
   const val=clean(value.innerText);
   if(val)fields.push({id:'',label:name,group:groupOf(label),value:val,kind:'display',required:false});
 }
 // Attachment names are export-only. A browser cannot recover a local upload path.
 const links=[...content.querySelectorAll('a[href]')].filter(shown);
 if(links.length)fields.push({id:'',label:'الملف المحفوظ',group:'',
   value:links.map(a=>clean(a.textContent)||a.getAttribute('download')||a.getAttribute('href')).join('\n'),kind:'display',required:false});
 const text=clean(content.innerText);
 return {found:true,fields,text:text.length<=32767?text:'',overflow:text.length>32767,
   loading:!![...content.querySelectorAll('[aria-busy="true"],[role="progressbar"]')].filter(shown).length,
   empty:text.includes('لم يُعثر على أية سجلات')};
}'''


def snapshot_script(labels):
    return SNAPSHOT_JS.replace('__LABELS__',json.dumps(sorted(set(labels)),ensure_ascii=False))


def settled_script(snapshot):
    # One evaluation, a short rendering budget, no repeated tab clicks. Sample
    # live .value properties too: React updates need not mutate textContent.
    return r'''async tabName => {
 const read=('''+snapshot+r''');
 const started=performance.now();let last='',since=started,current;
 while(true){
   current=read(tabName);
   const signature=JSON.stringify(current);
   const now=performance.now();
   if(signature!==last){last=signature;since=now;}
   if(current.found&&!current.loading&&(current.empty||current.fields.length)&&now-since>=180)return current;
   if(now-started>=1800)return {...current,timed_out:true};
   await new Promise(resolve=>setTimeout(resolve,40));
 }
}'''
