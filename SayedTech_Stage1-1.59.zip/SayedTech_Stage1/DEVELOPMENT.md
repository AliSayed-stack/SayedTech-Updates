# Development and verification

## Runtime and setup

Python desktop app targeting Windows 10/11 x64, PySide6 and Playwright using installed Chrome/Edge. Application dependencies are pinned in `requirements.txt`. Use Python 3.12 and the included Windows setup/start scripts.

Offline Excel/HTML regression tests additionally use `requirements-dev.txt`:

```sh
python -m pip install -r requirements-dev.txt
```

Node.js is required by the production JavaScript extraction tests. Their structural DOM adapter is not a live browser.

## Tests

Run from the project directory:

```sh
python -m unittest discover -p "test_*.py" -q
```

Login startup, blank navigation, OAuth handoff and browser/profile packaging:

```sh
python -m unittest test_login_startup test_login test_account_session test_packaging -q
```

Startup uses fake contexts/navigation, never a real school account. The printed installer-ready path from packaging tests is synthetic; it is not a Windows installer build. Native Chrome/Edge startup still requires validation on Windows.

Focused manual import regressions:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_birth_identity test_document_import test_detailed_batch test_manual_dynamic_forms test_manual_site_bindings test_manual_sections test_manual_auto_save test_manual_save test_manual_address test_detailed_import -q
```

Shared student-attendance workbook, supplied-shape DOM binder, serial queue and RTL UI:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_attendance test_attendance_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_attendance_ui -q
```

AttendanceExportDialog handles the extraction-only screen; AttendanceDialog handles the recovery-only screen. Keep app.py routing them separately for both shifts.

The attendance tests use synthetic DOM and a fake download; they do not run Playwright against a signed-in site. The native attendance template is authored by `tools/build_attendance_template.mjs` with `@oai/artifact-tool` in a development-only Node environment. Generate its contract JSON from `attendance_schema.HEADERS` and `list(attendance_schema.REASONS.items())` as `headers` and `reasons`, then invoke `node tools/build_attendance_template.mjs assets/student_attendance.xlsx <contract.json>`. Move generated PNG/inspection sidecars outside the source. Runtime XLSX reading/writing uses only ZIP/XML.

Afternoon database/unified dimensions and native-feature preservation:

```sh
python -m unittest test_student_excel_layout test_nsldb test_student_unified test_student_detailed -q
```

Morning export defaults and checkpoint/recovery propagation:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_checkpoint -q
```

Defaults require explicit morning shift metadata supplied by the scan wrapper. Keep raw reads unchanged and retain populated cells, including checkbox False. The regression checks that only the five requested blank cells differ from an afternoon export and that every other XLSX part is byte-identical.

Grade-menu timing, pending/open state, delayed target options and scope:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_grade_sync test_scan_grade_trigger test_scan_grade_menu test_grade_scan test_detail_scope test_detailed_batch_ui -q
```

Grade-sync tests exercise the existing correlated worker entry without inventory, draft navigation or pupil writes; Qt tests check pending/stale/failure/session routing. The DOM snapshot runs production LIST_SCRIPT on nested/repeated synthetic wrappers using Node. The trigger regressions execute production XPath against supplied-shape HTML with lxml; the label wrapper and unrelated controls are synthetic. The menu regressions use a deterministic clock and synthetic Playwright-shaped adapters. They reproduce pre-open toggle closure and partial-menu timing against 1.24, and preserve strict identity, account and grade-scope checks.

Excel layout and prior-file upgrades:

```sh
python -m unittest test_scan test_scan_dropdowns test_scan_selection test_detail_dom -q
```

Detailed-import window geometry, action reachability, inherited-theme regression and screen fitting:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_detailed_layout test_detailed_batch_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_detailed_layout -q
```

Qt tests skip when PySide6 is unavailable. On a headless system with Qt installed, set `QT_QPA_PLATFORM=offscreen`. Test fixtures contain synthetic values.

The multi-document regressions use a populated synthetic prior-format workbook and an lxml adapter around the supplied document form. They check unchanged input bytes, grouping/identity conflicts, independent card saves, review ordering, file preservation and uncertain-save/cancellation gates. They are not a live SIMS save.

## Modules

| Area | Files |
| --- | --- |
| Manual schema, Excel reading and field filling | `manual_sections.py` |
| Serial document cards from repeated pupil rows | `document_import.py` |
| Strict birth-date identity and sanitized mismatch diagnostics | `identity_dates.py` |
| Identity guards and section routing | `detailed_import.py` |
| Batch detail import UI and queue | `detailed_dialog.py`, `detailed_batch.py` |
| Student attendance contract, native Excel, browser binding and queue UI | `attendance_schema.py`, `attendance_excel.py`, `attendance_browser.py`, `attendance_dialog.py` |
| Save/confirm and separate review submission | `manual_save.py` |
| Extraction, snapshots and checkpoints | `student_scan.py`, `detail_dom.py`, `student_checkpoint.py` |
| Column relocation and native Excel lists | `scan_workbook_layout.py`, `scan_dropdowns.py` |
| Browser process event protocol | `login_worker.py`, `login_controller.py` |
| Windows build and update manifest | `build_windows.py`, `publish_update.py` |

## Source packaging

```sh
python tools/package_source.py
```

The ZIP is created beside the project folder using an explicit source allowlist. The script reads `core.APP_VERSION`; it does not change it. The ZIP retains the `SayedTech_Stage1/` root required by the updater.

GitHub's current Windows build workflow lives in the update repository, as documented in `UPDATE_GUIDE_AR.md`. This cleanup does not replace that workflow.

## Verification limits

Local tests cover ZIP/XML structure, supplied/adapted HTML bindings, rendering delays, identity guards and save routing using offline adapters. Passing them does not establish a native Excel opening, a live SIMS session or a compiled Windows installer. Verify the Windows build in GitHub Actions.


Custom extraction scopes (both shifts):

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_scan_filters test_scan_picker_ui test_grade_scan test_checkpoint test_scan -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_scan_picker_ui -q
```

scan_selection.py validates account/scope-bound snapshot signatures and bounded roster metadata; scan_picker.py handles transient checkboxes/search/live status choices. The helper accepts at most 5000 integer indexes within the existing 32-KiB command bound. Selection is revalidated against a fresh full table inventory before any pupil file is opened. Complete grade inventories remain the coverage baseline, while only selected files are read. Checkpoints bind both the subset roster and filter digest. No real school roster is used in tests.


Afternoon unified registration:

```sh
QT_QPA_PLATFORM=offscreen python -m unittest test_registration_workbook test_registration_ui test_students test_existing_student test_student_save test_detailed_import test_document_import test_student_unified test_login_ui -q
QT_QPA_PLATFORM=offscreen QT_SCALE_FACTOR=1.5 python -m unittest test_registration_ui -q
```

registration_workbook.py composes the established native scan template with its 56 columns and adds one registration-route column only to this separate creation template. Runtime authoring remains ZIP/XML, preserving dropdowns/names/styles and using an explicit registration marker. Simple and detailed readers dispatch separately; the generic existing-record scan is still refused for creation. Translation reuses the namespace-preserving ASCII spelling patcher, never a full worksheet rewrite. Tests use synthetic workbooks; openpyxl remains test-only.


Date input consistency: `python -m unittest test_date_consistency test_registration_dates test_birth_identity test_manual_dynamic_forms test_identity_card test_attendance -q`. normalize_date provides strict ISO/year-first slash/month-first slash/numeric parsing and explicit allow_future. Documents reuse it, keeping only legacy DD-MM-YYYY as a separate dash format; slash dates are month-first across user inputs. Existing attendance table overlap detection retains its conservative legacy interpretation set and additionally recognizes year-first slashes. Future attendance still requires the live calendar bounds.


Formatted document dates: test_document_import simulates a date control reformatting an ISO fill to YYYY/MM/DD. It checks both flags and two serial card saves, reusing an unsaved partial editable card, and refusing a genuinely different rendered date before flags/save/next Add. This models the observed value format using the supplied-form adapter, not a live browser or complete new custom-calendar HTML.


1.38 registration route coverage checks three mixed types in one workbook, existing/new-site routing with and without UID, no global UI filter, blank/unknown type stops, old-label compatibility, and older unified readers. Route-list copy tests compare exact sheetData bytes and every unrelated ZIP part before/after; use the real updater in test_registration_workbook and test_student_unified, not a workbook rewrite. Source cells retain their old compatible labels when list validation is upgraded.


Afternoon template defaults: test_registration_workbook checks every one of 500 input rows, exact native option labels, empty pupil selection/route/UID/birth, and preservation of employee edits through reading and route-list upgrades. A release audit against 1.38 confirmed that only the eleven requested cell columns differ; all other XLSX parts and formulas are unchanged.


## 1.40 — afternoon registration class list
The supplied native select contains kg_3 and grade_1 through grade_6, labelled الروضة الثالثة through السادس أساسي. The blank registration template previously had no validation on صف الطالب (AA). Add an explicit visible list for all 500 rows, afternoon registration only. Existing fill_student already resolves the requested Arabic label against current live enabled options; it never hardcodes native option values and still rejects absent/ambiguous live options. No browser binding was changed. These supplied options are not a discovery of every school's live classes.
The existing update-options button adds/replaces a grade-only validation for marked registration workbooks in a separate copy, while retaining route updates. Legacy unified files retain route-only upgrading. Patch validation XML only; keep sheetData and all other ZIP parts unchanged. Employee values, defaults, dimensions and morning exports remain unchanged.
Verification: 32 focused workbook/simple-fill/shift/UI tests completed: 28 passed, four Qt tests skipped because PySide6 is unavailable. New coverage confirms list labels/range/visible arrow, upgrade of an older filled file with missing grade validation, immutable source and retained pupil class. No native SIMS/Excel/Windows verification.


1.41: User clarified that afternoon schools may extend to الثاني ثانوي. Extend registration-only Excel class choices in progression with السابع أساسي، الثامن أساسي، التاسع أساسي، الأول ثانوي، الثاني ثانوي. Both fresh templates and existing-file copy upgrades share the expanded choices. Browser selection remains bound to the actual live enabled class options; an unavailable grade still stops rather than silently choosing another. No account, date, save or morning change. Test the upper-grade choices and preservation of a filled الثاني ثانوي class. Offline verification only.


## 1.42 — simple save date comparison
User screenshots show a pre-save blocked result naming birth date; registration date visibly uses YYYY/MM/DD. student_save.snapshot previously compared raw visible date strings with canonical ISO record values. Normalize nonblank date-spec values and raw snapshot values using shared normalize_date before equality/stability comparison. This is in-memory verification only: no new birth writes or workbook changes. Reject invalid/future/different calendar dates; retain browser validity, required fields, modal/account checks, one Save/confirmation and fresh success requirement. Both shifts share this path. Synthetic tests cover year-first slash birth/registration values, both shifts, one save/confirm, unchanged form values, and different/invalid/future dates blocking before Save. Native live cause/verification is not claimed; screenshots do not supply full date DOM.


## 1.43 — existing pupil birth identity before filling
New screenshots on 1.42 show student_existing_mismatch naming birth before any filling; visible birth uses YYYY/MM/DD. The earlier 1.42 correction covered save snapshots only. select_existing_student now compares birth through identity_birth, with unchanged strict names/UID and stability checks. For existing pupils, fill_student rechecks calendar birth and skips writing that field entirely, even if enabled. New-from-home still fills its provided birth. Different/invalid/missing existing birth stops; never swap components or bypass identity. Synthetic both-shift regressions verify slash birth proceeds through one save while retaining the original slash form value with no birth fill action, and a genuinely swapped date stops before writes. No live site verification.


## 1.44 — grade option text normalization
User supplied both open grade trigger and menu; both structurally match current selectors. No confirmed live cause is established. A concrete inconsistent text check existed: grade_menu used raw labels.count for the all-levels sentinel whereas other grade checks normalize text. Strip direction marks/collapse whitespace for menu labels and normalize sentinel comparisons. Retain unique-menu/unique-option/stability/account/cancel/one-toggle guards; no fallback grade or school-wide search. Synthetic regression covers direction marks and multiline labels; do not claim this reproduces the unknown live cause. Existing birth write protection unchanged.


## 1.45 — strict student Excel dates YYYY/MM/DD
Explicit user supersedes permissive Excel date input: only padded ASCII YYYY/MM/DD text or numeric Excel dates whose exact display format is yyyy/mm/dd are accepted at student simple/detail importer boundaries. excel_dates.strict_dates checks chosen rows and reports row/header before browser dispatch. Internal normalize_date and site identity parsers remain permissive for site/legacy source readings; no date guessing or altered birth. Calendar validity/future field policy still enforced by existing readers.
New student scan (both shifts), afternoon registration (through shared scan), NSLDB export, unified conversion, card workbook and bundled morning blank template use excel_dates.format_dates. Numeric serials remain untouched; text values with a known valid source format are converted to year-first text on new outputs. Clone styles per date column; retain other formatting/parts. Existing-file registration options upgrade now also formats dates in its separate output copy under explicit unified-date request, overriding the old route-only restriction; never replace original. Unparseable dates remain unchanged and blocked on import. Attendance is outside the four requested categories. Existing pupil birth remains verification-only and site inputs retain their required internal format.
Synthetic test_excel_dates covers strict rejection, numeric display requirements, date equality, document boundary and unchanged input bytes/other parts. Local tests are not native Excel/SIMS validation.

Strict-date verification in 1.45: test_excel_dates + simple save/existing-pupil suite: 29 passed. Updated prior permissive Excel-reader regression to expect strict rejection under explicit user instruction; internal source/site parser tests retain their permissive contract. Date consistency/registration/birth checks: 19 passed, one Qt skip. NSLDB fixtures now enter user Excel dates in the required year-first format (source-table records remain unchanged); NSLDB + strict boundary tests: 20 passed. Layout/packaging/updater checks: 18 passed. No native Windows, live SIMS or native Excel application test.


## 1.46 — explicit simple/detail commands start at management
User explicitly requests any student registration/restoration command to restart from management. login_worker now invokes student_start.reset_management before simple fill/save/duplicate-check and detailed commands (including review). It validates account/cancellation before and after one public management navigation, even if already at management with a modal/page/filter. Wrong shift blocks detail navigation first. This deliberate explicit new-command start may discard an existing unsaved draft under the user's request, superseding old draft-retention behavior at that boundary. Internal section recursion/confirmed-save re-entry is unchanged: never restart inside a section, replay an uncertain save or change birth data.
The correlated scope_grade helper is not a registration/restoration button and retains its existing behavior. Attendance stays on its separate requested workflow. No login/startup/extraction/date logic changes. Synthetic tests check both shifts, management/form/analytics origins, no writes, account/host/cancel blocks, failed/redirected navigation. No live SIMS/Windows test.


## 1.47 — remove redundant afternoon menu entries
User screenshot identifies student_simple/student_detailed legacy placeholders in afternoon management as unnecessary. Hide those two menu buttons when show_section runs under afternoon; restore visibility under morning. Keep registration chooser's real registration_simple/registration_detailed, scan, NSLDB and registration/import backends unchanged. Reversible presentation-only edit; no new redundant test. Packaging/updater checks apply.


## 1.48 — student section transfers, both shifts
User supplied sections URL/page/chips/language headings, expanded card HTML with data-enrollment-id labels, checkboxes, move-here and Save buttons, plus success toast «تم نقل طالب واحد.». They confirmed move-here then Save. New student_sections menu opens SectionDialog; separate export/import actions and checked serial queue. SectionRunner discovers live grades/cards from UI, starts at management then sections, clears search, exports enrollment identity/current class/language/section/name. No pupil form or birth control is touched. Workbook marker binds username hash; selected fixed rows require unique enrollment IDs and destination; no ordinary registration workbook is accepted. Employee enters exact destination name, e.g. الشعبة ب. Transfer is restricted to same grade/language and verifies live source enrollment ID/name/current section and unique destination. Preselected checkboxes stop. Check exactly one enrollment, use that language/card move button, then unique visible enabled Save once. Require fresh exact single-student success plus server-page destination readback. Mark attempted before Move, retain gate for rest of worker session on any outcome, no automatic retry. Page/account/cancel guards remain.
New modules section_excel/section_browser/section_dialog; worker/controller serialized protocol with bounded request and whitelisted events, no pupil data in replies. UI ignores stale results, locks pending, stops queue on any failure, leaves pending student running once when stop requested. Existing registration/details/attendance routes remain.
Tests: 30 section workbook/synthetic browser protocol/production JS DOM-adapter/real offscreen Qt menu/queue/registration/startup/packaging/updater checks passed; 2 section UI checks at 150% also passed. Production SNAP runs against a supplied-shape fixture containing only invented names/IDs. No supplied private names/screenshots/IDs are packaged. Qt dependency installed only in test environment; requirements unchanged. No live school transfer, native Windows build or native Excel app tested. An existing unrelated detail DOM roundtrip expectation still expects ISO output instead of the new 1.45 year-first presentation; it was not changed in this feature.


## 1.49 — account hydration at management/sections navigation
User screenshot shows section_account while still on management, before sections navigation. SectionRunner previously mapped every reset_management error to section_account and checked account immediately after DOMContentLoaded, before React profile hydration. Shared verify_dashboard_account retains immediate pre-navigation verification; after navigation it waits up to 15 seconds for expected email or the existing bound profile proof. No navigation/write occurs while account is unverified. Cancellation, other host/non-dashboard redirect and revoked session stop; bound changed profile still revokes as before. Reset navigation/path errors now map to section_options rather than blaming workbook account. Sections start also waits after its own navigation.
Synthetic tests reproduce delayed account appearance on BOTH navigation stages, bounded absent-profile wait and cancellation. No live SIMS test; this addresses a concrete early-stop timing weakness, not a confirmed live trace. No workbook, pupil identity, birth, move/save retry or UI workflow changes.


## 1.50 — grade chips scoped to supplied horizontal bar; await card opening
User now reaches sections in 1.49 but sees section_options with collapsed cards. They supplied exact flex gap-2 overflow-x-auto pb-1 grade bar and collapsed section cards. Old export collected ALL rounded-full buttons in the entire page, potentially including profile/help controls; new grade_buttons binds one visible supplied bar via class-token XPath and direct type=button children, waits for unique nonempty labels. Both enumeration and requested-grade click use this scoped binding. No school grades are hardcoded and no fallback class is selected.
Old card loop clicked and waited 100ms, risking toggling the same slow-opening card closed. Now wait for that button's aria-expanded=true before looking for the next collapsed card; keep completeness count and unique language/section checks. Tests run production bar XPath on supplied-shape synthetic HTML with an unrelated rounded profile button, and a delayed expansion model requiring exactly one click. 31 focused sections/Qt/student-start/packaging/updater checks passed. No confirmed live trace or native SIMS transfer. Account checks, date/birth protections, per-student Save/success/readback and uncertain retry block unchanged.


## 1.51 — wait for sections options after the title
User 1.50 screenshots show sections with collapsed cards and the generic section_options message. Public frontend inspected on 2026-10-30: h1 renders before the asynchronous year/section options; search, grade bar and cards render only in the R&&C branch. SectionRunner.start checked exact search count immediately after waiting for h1, so normal loading could stop before any grade/card action. Now bounded wait for exactly one visible enabled search, with account/path/cancellation checks on each poll, before clearing it and enumerating grades. No selector broadening or pupil/birth writes. Missing controls still stop. New whitelisted diagnostics distinguish search readiness, grade selection, card expansion and incomplete pupil counts; unknown post-Move saves retain their existing stop/retry gate.
Synthetic end-to-end export regression delays search until after title, then verifies grade -> cards -> populated workbook for BOTH account shifts; missing options time out without output. Focused 33-test run: 31 passed, 2 Qt tests skipped because PySide6 is unavailable in this runtime. No signed-in live SIMS or native Windows/Excel verification. Public bundle inspection is structural evidence, not proof of the user's exact execution timing.


## 1.52 — selected-grade sections export; stable card locators
User 1.51 screenshot now shows the first card expanded and section_cards, and requests export of a chosen grade only. Root selector defect: Locator.all() on section button[aria-expanded="false"] produces live nth locators into the false-only query. Clicking the first card changes its attribute; the wait then resolves the next closed card or no element instead of the opened card. cards() now enumerates section button[aria-expanded] (independent of attribute value), reads the current state, clicks only false once, and waits on the same stable indexed query. Keep snapshot completeness and unique-card checks. A two-card live-query adapter reproduces section_cards against the archived 1.51 implementation and passes with both cards opened exactly once after this fix.
Sections dialog adds تحميل صفوف المدرسة and an initially unselected grade combo. New correlated section_grades command reads live grade chips only (no pupil enumeration); bounded unique labels flow through a dedicated signal. Export requires a chosen grade in UI, worker and browser; binds the live chip and reads only that grade, with no all-school fallback. Backend revalidates the chosen grade after fresh guarded navigation. Import and account-bound workbook schema unchanged. Both shifts share the flow. No pupil birth/form writes or changes to move/save/fresh-success/readback/uncertain-retry rules.
Verification: 37 focused sections/real offscreen Qt/controller/start/packaging/updater tests passed. PySide6 Essentials 6.10.2 installed in test environment only; requirements untouched. Regression includes both-shift delayed export, missing-grade no navigation/file, stale grade-list replies and bounded protocol, selected-grade payload, two cards through changing attributes, immutable Excel and move/save guards. No live school export/transfer, native Windows installer or Excel application verification.


## 1.53 — accept a whole selected section plan; skip unchanged rows locally
User's workbook screenshot marks all pupils, with both changed and same current/requested sections, and they request one batch for everyone. read_sections now validates selected rows with allow_same=True while retaining required destination/identity/account/formula/duplicate checks. Default validate remains strict for browser transfer. Dialog displays unchanged rows as «لا نقل مطلوب حسب الملف», unchecks/disables them, and filters source==target at queue construction even if programmatically rechecked. This is a local no-op based on the file, not a claim of live verified placement/success. No browser requests, moves or saves for those rows. Changed marked rows remain checked, execute serially under one existing batch action and stop on any unknown/error. Existing move/save/fresh-toast/readback and uncertain retry gate unchanged. Entirely unchanged files display their rows/count and disable transfer. Input workbook remains immutable; old filled files and selected-grade export remain compatible. No pupil birth/date/form or account-routing edits.
Verification details recorded below after focused checks. No signed-in live SIMS or native Windows/Excel verification.

1.53 focused verification: 40 tests passed, including real offscreen Qt mixed/all-unchanged queues, immutable mixed Excel reads, strict browser no-op refusal, missing destination and duplicate rejection, prior grade/card/account/save guards, packaging and updater. Test-only Qt Essentials 6.10.2 installed; runtime requirements unchanged.


## 1.54 — exact section matching ignores display whitespace
User supplied the real filled workbook read-only after repeated section_identity stops. Audit found 8 destination cells with a trailing ASCII space; the first selected row is affected. Raw matching treated the padded destination as absent and 5 same-section plans as moves. Source file was hash-verified unchanged; no pupil names/IDs/account or private files are included in source/tests. Aggregate audit: 35 selected, 13 real moves and 22 unchanged after display normalization (previous raw comparison counted 18 moves).
section_excel.validate copies the input and normalizes only display labels (grade/language/source/name/target) with the same bidi-removal and whitespace collapse used by production SNAP. Shared label_text is imported by section_browser. IDs and account hashes remain exact/strict; no spelling/Arabic-letter substitutions or fuzzy namesake matching. Normalize before empty/same-section checks, live destination lookup and local queue filtering. Source Excel is never rewritten. Existing move/save/success/readback/attempt gates and pupil birth protection unchanged.
Synthetic regression reproduces section_identity with zero Moves under archived 1.53 validate for a padded destination; updated matcher completes one Move/Save with fresh toast/server readback in adapter. Tests retain different label/Arabic letter and invalid-ID/blank failures, classify padded same-section rows as no-ops, and verify workbook bytes immutable. Focused 42 tests: 36 passed, 6 Qt tests skipped because PySide6 unavailable in this runtime. No UI code changed. No signed-in live school mutation, native Windows or Excel application tested.


## 1.55 — attendance account hydration after navigation
2026-11-02 user screenshot is attendance export under desktop 1.47, shows attendance_account while browser is at student management. Concrete weakness remains in current AttendanceRunner.go: immediate guard after DOMContentLoaded can reject the account before the React header/bound profile is ready. Keep immediate pre-navigation guard, modal protection, exact host/target path and existing session; after navigation use shared verify_dashboard_account(wait=True), <=15 seconds, then full attendance guard. Map StudentFillError to attendance_account. No rebind, account bypass, OAuth/login replay or automatic retries. Attendance roster/import/export share go for both shifts. No dates, birth, Excel schema, identity, overlap, selected rows, Save/fresh-toast or unknown-save gates changed.
Synthetic delayed-profile regression fails immediately with archived 1.54 go, passes corrected path for both shifts through management and attendance. Missing profile times out; cancellation and redirect stop without clicks. Focused attendance/UI/start/account/packaging/updater suite: 46 tests, 40 passed and 6 Qt skips because PySide6 unavailable. UI unchanged. No signed-in live site or native Windows/Excel verification; screenshot alone does not prove the exact live timing cause.


## 1.56 — sections grade click binds caption, not nth position
User screenshot on desktop 1.55 shows chosen الأول أساسي, site still الروضة الثالثة and section_grades. Public sections frontend inspected 2026-11-02 retains supplied bar/heading structure and an optional unassigned chip before grades. Existing grade() used a Locator.all() nth reference retained while enumerating labels; dynamic insertion/reordering can resolve that reference to a different button at click time. New binding waits for bar readiness, then builds a fresh exact anchored accessible-caption locator inside the unique grade bar. Display whitespace/bidi variation supported, genuine spelling/suffix differences still blocked. Missing/disabled/ambiguous target stops without fallback. Click exactly once; require unique requested heading, then both heading and card snapshot stable together before return. No automatic repeat clicks or school-wide scan. New fixed diagnostic events distinguish unavailable grade, click failure and requested heading not appearing.
Synthetic live-position regression inserts the optional chip after enumeration: archived 1.55 grade clicks the previous/default grade and fails, new binding clicks selected caption once. Ignored clicks fail with section_grade_applied; unavailable grade fails before click. Exact regex tests cover bidi/newline/nonbreaking spaces and reject other/spelled-differently/suffixed grades. 56 focused sections/attendance/start/packaging/updater tests: 50 passed, 6 Qt skips. UI behavior otherwise unchanged. No live signed-in site or native Windows/Excel testing. Public code and synthetic regression establish a selector weakness, not proof that chip insertion caused the user's screenshot. Preserve all prior date/birth/account/identity/Move/Save/fresh-success/readback/retry protections.


## 1.57 — skip previously attempted pupils and continue sections queue
User screenshot on 1.56 shows several section_saved rows followed by section_uncertain («سبق طلب نقل هذا التلميذ في الجلسة»); explicitly requests skip and continue. SectionDialog.result now treats ONLY section_uncertain as a nonfatal skip: retain visible warning, mark local skipped (never done/saved), uncheck/disable its box, and schedule the next queued row if active. Eligibility/run button exclude skipped rows even if programmatically rechecked. A user-requested stop remains stopped. section_unknown, identity/account errors and all other failures retain stop behavior. Browser attempted gate remains untouched and returns before any navigation/Move/Save for an attempted key; never repeat uncertain or previously completed transfers. Reopening/reimporting still uses the same worker session gate. No account/date/birth/Excel/extraction/attendance edits.
Recovered authoritative source 1.56 from existing Library item before editing because scratch canonical source was older. Preserve 1.55 attendance hydration and 1.56 caption-based grade binding. Focused 46 sections/real offscreen Qt/start/packaging/updater tests passed. New regressions cover stale replies, skip -> next, no false success, no requeue after forced checkbox, fresh unknown/account/identity stops and explicit halt winning over skip. Test-only Qt Essentials 6.10.2 installed; requirements unchanged. No signed-in site/Windows/Excel application verification.


## 1.58 — live section dropdowns and adjacent pupil/current/new columns
User requires destination as dropdown from site sections, adjacent pupil/current/new columns, both shifts. Export retains ALL discovered cards as options, including empty sections, separately per (grade, language); no invented choices or hardcoded school levels. write_sections now requires explicit options and writes v2 workbook with columns اختيار، اسم الطالب، الشعبة الحالية، الشعبة الجديدة، الصف، لغة التعليم، معرّف التسجيل. Hidden خيارات الشعب sheet holds exact live catalog; workbook defined names map each class/language group's C-cell range. Visible destination D cells use native list validation with visible arrow, stop error and blank initial value. Same-section choice remains allowed and locally skipped. Body23/header48, RTL and account marker retained.
Reader binds fields by header with legacy الشعبة المطلوبة alias; accepts v1 filled workbooks in original order, never rewrites source. v2 reader also validates selected source/target against its matching exported catalog, rejecting invalid pasted entries before browser dispatch; site still revalidates actual current options/identity. Old files cannot gain options without fresh export; remain import-compatible. Existing 1.57 skip/queue, 1.56 grade caption and 1.55 attendance hydration remain. No birth/date or Move/Save policy changes.
New tests check BOTH shifts, column adjacency, visible/stop native validation, hidden named source ranges, per-language choices, empty destination card carried through browser export, invalid cross-language target stops, immutable input and v1 header compatibility. Runtime remains stdlib ZIP/XML; openpyxl is test-only. No real pupil files/IDs/options packaged. Verification record follows. No live signed-in school, native Excel app or Windows installer tested.

1.58 verification: 61 focused tests completed: 53 passed, 8 Qt skips because PySide6 is unavailable. Sections workbook/browser/legacy/layout plus attendance/start/packaging/updater passed. No live Excel/SIMS/Windows claim.


## 1.59 — read-only already-at-destination and specific identity diagnostics
User 1.58 screenshot asks why repeated re-extraction requested. Generic section_identity previously conflated missing/duplicate enrollment, missing destination, wrong name/language/current source and unavailable checkbox, and rejected a pupil already at requested destination. Screenshot alone does not identify the exact failed comparison. Transfer now retains exact account/grade + unique enrollment ID + exact normalized name/language and unique destination verification, then returns section_already if current section equals requested destination, before any checkbox/Move/Save and without adding attempt key. UI marks desired state verified, shows explicitly no new transfer/save, unchecks row and continues. Existing attempted key still returns section_uncertain before navigation and is skipped under 1.57; uncertain writes are never replayed. Unexpected third-source sections remain blocked.
New fixed diagnostic events distinguish missing/ambiguous enrollment, destination unavailable, name/language/source differences and missing checkbox (possibly locked enrollment). No raw names/IDs/URLs transmitted in diagnostics. Generic race identity error no longer blindly demands re-extraction. Unknown save, wrong identity/account and cancellation stop behavior preserved. No source workbook rewrite, birth/date edits or weakening of matching. Retain v2 dropdowns and legacy reader, both shifts.
Verification: archived 1.58 transfer reproduces refusal when exact pupil already at requested destination; corrected synthetic flow is read-only and completes for both shifts, refuses wrong ID/name/language/destination/third source, and UI continues to next with distinct status. 69 focused sections/real offscreen Qt/attendance/start/packaging/updater tests passed. Qt Essentials 6.10.2 installed only for tests; requirements unchanged. No live signed-in transfer, native Windows installer or native Excel app verification.
