import uuid
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView

class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.pending=None
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setLayoutDirection(Qt.RightToLeft);self.resize(1050,620)
        layout=QVBoxLayout(self)
        note=QLabel('الاستيراد المفصّل متاح لمدارس قبل الظهر وبعد الظهر بنفس الخطوات، ضمن حساب المدرسة المسجّل. '
            'اختر التلميذ والقسم المطلوب. يتحقق البرنامج من الاسم الكامل وتاريخ الولادة قبل فتح السجل. '
            'عند بدء أي طلب يرجع المتصفح إلى إدارة الطلاب، ثم يفتح الطالب المطابق؛ احفظ أي مسودة مفتوحة قبل الضغط. '
            'كل كبسة تحفظ القسم المحدد وتؤكد الحفظ. في الأقارب يملأ شهرة الأم ويحفظ القسم. '
            'الزر العلوي يحفظ الأقسام التي لها بيانات في الملف بالترتيب: العنوان، الهاتف، شهرة الأم، وبطاقة التعريف عند اختيار نوع المستند. '
            'لا يُرسل أي سجل للمراجعة.')
        note.setWordWrap(True);layout.addWidget(note)
        self.table=QTableWidget(len(rows),9)
        self.table.setHorizontalHeaderLabels(['صف Excel','الطالب','شهرة الأم','البلد','العنوان','الهاتف','نوع المستند','رقم الوثيقة','تاريخ الانتهاء'])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[str(row['excel_row']),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                str(row.get('mother_surname','')),address.get('البلد',''),
                ' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            card=row.get('identity_card',{})
            texts.extend(str(card.get(k,'') or '') for k in ('type','number','expiry'))
            for j,text in enumerate(texts):self.table.setItem(i,j,QTableWidgetItem(text))
        self.table.resizeColumnsToContents();layout.addWidget(self.table)
        self.status=QLabel('اختر القسم. العنوان يحتاج البلد والمحافظة والقضاء والمنطقة، والهاتف 8 أرقام، والأقارب شهرة الأم.');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.buttons=[]
        self.all_button=QPushButton('استرداد وحفظ كل الأقسام المتاحة للطالب المحدد')
        self.all_button.clicked.connect(lambda:self.start('all'))
        layout.addWidget(self.all_button);self.buttons.append(self.all_button)
        self.card_button=QPushButton('تعبئة وحفظ بطاقة التعريف — دون رفع ملف')
        self.card_button.clicked.connect(lambda:self.start('identity_card'))
        layout.addWidget(self.card_button);self.buttons.append(self.card_button)
        bar=QHBoxLayout()
        for title,section in [('استرداد عنوان الطالب المحدد','address'),('استرداد هاتف الطالب المحدد','phone'),('تعبئة شهرة الأم وحفظ الأقارب','relative')]:
            b=QPushButton(title);b.clicked.connect(lambda checked=False,s=section:self.start(s));bar.addWidget(b);self.buttons.append(b)
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);bar.addWidget(self.close_button);layout.addLayout(bar)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        self.finished.connect(self.detach);self.table.setCurrentCell(0,0)

    def start(self,section):
        i=self.table.currentRow()
        if i<0 or self.pending:return
        request=uuid.uuid4().hex
        if self.controller.fill_details(self.rows[i],section,request):
            self.pending=request
            for b in self.buttons+[self.close_button]:b.setEnabled(False)
            self.table.setEnabled(False);self.status.setText('جارٍ التحقق من التلميذ ثم تعبئة القسم…')
        else:self.status.setText('جلسة المتصفح غير متاحة. أعد تسجيل الدخول.')

    def result(self,request,event,field):
        if request!=self.pending:return
        self.pending=None;self.table.setEnabled(True)
        for b in self.buttons+[self.close_button]:b.setEnabled(True)
        self.status.setText({
            'detail_card_input':'اختر نوع المستند من أعمدة بطاقة التعريف في Excel، وأكمل رقم الوثيقة (أو رقم السجل السابق). تاريخ الانتهاء اختياري ويجب أن يكون تاريخاً صالحاً عند إدخاله.',
            'detail_card_disabled':'زر حفظ بطاقة التعريف ما زال معطلاً في الموقع. راجع الحقول أو رسالة التحقق الظاهرة؛ لم يتم الضغط على الحفظ.',
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_saved':'حُفظ القسم المحدد بنجاح.',
            'detail_all_saved':'حُفظت الأقسام المتاحة من ملف Excel بالتتابع بنجاح.',
            'detail_all_partial':'اكتملت الأقسام التي أمكن تعبئتها. بعض الأقسام موجودة سلفاً أو ناقصة في Excel وتُخطّيت دون استبدالها. راجع عمود شهرة الأم ونتيجة الموقع.',
            'detail_mother_missing':'شهرة الأم فارغة في صف Excel المحدد. عبّئ عمود «شهرة الأم (للمفصّل)» واحفظ الملف ثم أعد استيراده.',
            'detail_mother_field':'شهرة الأم وصلت من Excel، لكن لم أستطع تحديد خانة الشهرة وحدها داخل «الأقارب #2» الخاصة بالأم. ابعث HTML لهذا القسم مع عنوانه والخانة لضبطه.',
            'detail_save_unknown':'تم الضغط على حفظ القسم، لكن لم يصل تأكيد نجاح. راجع القسم المفتوح وما سبقه قبل إعادة المحاولة.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على سجل واحد مطابق للاسم الكامل وتاريخ الولادة في إدارة الطلاب. لم يُدخل عنوان.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'تعذّر الرجوع إلى إدارة الطلاب أو جرد سجلاتها. افتح الإدارة وتأكد أن كل المرشحات «جميع» ودون بحث، ثم أعد المحاولة.',
            'detail_existing':'القسم يحتوي سجلاً أو مسودة؛ لم يُستبدل. راجع الموجود في الموقع.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار أو مربع التأكيد بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_input':'أكمل بيانات القسم المختار في Excel: العنوان أو الهاتف أو شهرة الأم، ثم احفظ الملف وأعد استرداده.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.'))

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.pending=None;self.close_button.setEnabled(True)
            for b in self.buttons:b.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        self.rows=[];self.table.clearContents()

    def reject(self):
        if self.pending:return
        super().reject()
