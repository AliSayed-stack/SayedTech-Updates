# نشر إصدار Sayed tech عبر GitHub

## تجهيز المصدر

1. رقم النسخة في `core.py` هو `0.81`، ويجب أن يطابق وسم الإصدار `v.81`.
2. تأكد أن `assets/update_source.json` يحتوي رابط المستودع الثابت:
   `https://raw.githubusercontent.com/AliSayed-stack/SayedTech-Updates/main/latest.json`
3. اختبر التعديلات، ثم اضغط مجلد `SayedTech_Stage1` كله في ملف اسمه `SayedTech_Stage1-0.81.zip`. يجب أن يكون مجلد `SayedTech_Stage1` في جذر الأرشيف.

## النشر والبناء

يمكن رفع `SayedTech_Stage1-0.81.zip` إلى جذر المستودع `main`؛ يبدأ GitHub Actions إنشاء الإصدار والمثبّت وتحديث `latest.json` تلقائياً. أو استخدم خطوات الإصدار اليدوية أدناه.

1. في GitHub افتح `AliSayed-stack/SayedTech-Updates` ثم **Releases → Draft a new release**.
2. أنشئ الوسم `v.81`، واكتب عنوان الإصدار، وأرفق `SayedTech_Stage1-0.81.zip`.
3. انشر الإصدار. نشره يشغّل تلقائياً Workflow باسم **Build and publish Windows installer**.
4. انتظر نجاح جميع خطوات Workflow. عند النجاح، يرفق GitHub ملف `SayedTech-Setup-Windows-x64.exe` بالإصدار، ويحدّث `latest.json` في الفرع `main` مع رابط الملف وبصمة SHA-256.
5. افحص صفحة الإصدار للتأكد من ظهور ملف التثبيت. لا توزّع ملفاً من تشغيل بناء فاشل.

لا تشغّل `BUILD_EXE_WINDOWS.bat` على جهاز الموظف. GitHub Actions يبني ملف Windows على خادم Windows، والموظف لا يحتاج Python.

## تحديث نسخة الموظف

من البرنامج يضغط الموظف **تحديث البرنامج**، ثم **فحص التحديثات**، **تنزيل التحديث**، وبعد إنهاء جلسة SIMS يضغط **تثبيت التحديث**. يتحقق البرنامج من HTTPS وبصمة SHA-256 قبل تشغيل المثبّت. لا يبدأ التثبيت أثناء جلسة SIMS.
