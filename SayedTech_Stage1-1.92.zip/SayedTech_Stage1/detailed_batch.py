"""Sequential detail imports for the rows explicitly selected in Excel."""
import uuid
from detail_scope import in_grade,scoped_record
from detailed_import import RESUMABLE_SECTION_ERRORS,clean_resume_detail

SUCCESS={
    'details_import':frozenset({'detail_import_saved'}),
    'details_import_review':frozenset({'detail_import_review_sent','detail_import_review_already'})}
SKIPPABLE=RESUMABLE_SECTION_ERRORS|{'detail_no_data','detail_existing','detail_ambiguous',
    'detail_not_found','detail_birth_mismatch','detail_save_unknown'}


class DetailedImportBatch:
    def __init__(self,rows):
        self.rows=rows
        self.mode=None;self.pending=None;self.index=0;self.active=False
        self.stopping=False;self.event='';self.field=''
        self.completed={mode:set() for mode in SUCCESS}
        self.skipped={}
        self.resume_detail=None
        self.resume_sections=None
        self.grade=None
        self.selected=None
        self.use_open_student=False
        self.sections=None

    def start(self,with_review,grade=None,selected=None,*,use_open_student=False,sections=None):
        if self.active or self.pending:return False
        if use_open_student and (with_review or selected is None or len(selected)!=1):
            return False
        self.use_open_student=use_open_student
        self.sections=None if sections is None else tuple(sorted(set(sections)))
        self.grade=grade
        self.selected=None if selected is None else frozenset(selected)
        self.mode='details_import_review' if with_review else 'details_import'
        self.index=0;self.stopping=False;self.event='';self.field=''
        self.resume_detail=None;self.resume_sections=None
        self.active=True;self._advance()
        return True

    def eligible(self,index):
        return (self.selected is None or index in self.selected) and in_grade(self.rows[index],self.grade)

    def _advance(self):
        done=self.completed_for(self.mode)|self.skipped_for_run()
        while self.index<len(self.rows) and (not self.eligible(self.index) or self.index in done):self.index+=1
        if self.index>=len(self.rows):self.active=False

    def request(self):
        if not self.active or self.pending:return None
        self.pending=uuid.uuid4().hex
        row=scoped_record(self.rows[self.index],self.grade)
        if self.resume_sections is None and self.use_open_student:row=dict(row,use_open_student=True)
        sections=self.sections if self.resume_sections is None else self.resume_sections
        if sections is not None:row=dict(row,selected_detail_sections=list(sections))
        mode=self.mode if self.resume_sections is None else 'details_import'
        return row,mode,self.pending

    def result(self,request,event,field='',detail=None):
        if request!=self.pending or self.pending is None:return False
        self.pending=None;self.event=event;self.field=field
        self.resume_detail=clean_resume_detail(event,detail)
        if self.resume_sections is not None and event in (
                'detail_import_saved','detail_import_skipped_section','detail_no_data'):
            self.skipped_for_run().add(self.index)
            self.resume_sections=None;self.index+=1
            if self.stopping:self.active=False
            else:self._advance()
            return True
        skipped=event=='detail_import_skipped_section' or (event=='detail_no_data' and self.sections is not None)
        if not skipped and event not in SUCCESS[self.mode]:self.active=False;return True
        self.completed_for(self.mode).add(self.index)
        if self.mode=='details_import_review' and not skipped:self.completed_for('details_import').add(self.index)
        self.index+=1
        if self.stopping:self.active=False
        else:self._advance()
        return True

    @property
    def can_skip(self):
        return (not self.active and not self.pending and not self.stopping
                and self.event in SKIPPABLE and self.index<len(self.rows))

    def skipped_for_run(self):
        return self.skipped.setdefault((self.mode,self.sections),set())

    def resume(self,*,same_student,selected):
        if not self.can_skip or (same_student and (self.resume_detail is None or self.index not in selected)):
            return False
        allowed=range(len(self.rows)) if self.selected is None else self.selected
        self.selected=frozenset(allowed).intersection(selected)
        remaining=self.resume_detail['remaining_sections'] if same_student else []
        self.resume_detail=None;self.event='';self.field=''
        self.active=True
        if remaining:self.resume_sections=tuple(remaining)
        else:
            self.skipped_for_run().add(self.index)
            self.resume_sections=None;self.index+=1
            self._advance()
        return True

    def stop_after_current(self):
        self.stopping=True
        if self.pending is None:self.active=False

    def disconnect(self):
        self.active=False;self.pending=None;self.event='detail_account'
        self.resume_detail=None;self.resume_sections=None

    @property
    def done(self):
        return sum(self.eligible(i) for i in self.completed_for(self.mode))

    def completed_for(self,mode):
        key=mode if self.sections is None else (mode,self.sections)
        return self.completed.setdefault(key,set())

    @property
    def total(self):
        return sum(self.eligible(i) for i in range(len(self.rows)))

    @property
    def position(self):
        return sum(self.eligible(i) for i in range(min(self.index+1,len(self.rows))))
