"""Separate section extraction/import actions, checked serial queue."""
from uuid import uuid4
import json
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QFileDialog,QTableWidget,QTableWidgetItem,QAbstractItemView,QHeaderView,QComboBox
from section_excel import read_sections
from student_excel import ExcelInputError
from detailed_dialog import DIALOG_STYLE
MESSAGES={'section_exported':'تم استخراج ملف التشعيب. ضع 1 في اختيار واختر الشعبة الجديدة من القائمة.',
'section_saved':'تم نقل التلميذ وحفظ النقل والتحقق من الشعبة.', 'section_account':'تأكد من حساب المدرسة وأن الملف مستخرج منه.',
'section_options':'تعذّرت قراءة خيارات التشعيب أو زر الحفظ. راجع الصفحة.', 'section_identity':'تغيّر السجل أثناء التحقّق؛ توقفت العملية. راجع الموقع.',
'section_already':'موجود بالفعل في الشعبة الجديدة؛ تم التحقّق منه دون نقل أو حفظ جديد.',
'section_pupil_missing':'معرّف تسجيل التلميذ غير موجود ضمن الصف الموجود في الملف؛ راجع سجله على الموقع.',
'section_pupil_ambiguous':'معرّف التسجيل ظهر أكثر من مرة؛ تعذّر تحديد تلميذ واحد للنقل.',
'section_destination':'الشعبة الجديدة غير موجودة أو مكرّرة ضمن نفس الصف ولغة التعليم على الموقع.',
'section_name':'معرّف التسجيل موجود لكن اسم التلميذ يختلف عن الملف؛ لم يُنقل.',
'section_language':'معرّف التسجيل موجود لكن لغة التعليم تختلف عن الملف؛ لم يُنقل.',
'section_source':'التلميذ موجود بشعبة تختلف عن الحالية والجديدة في الملف؛ راجع شعبته على الموقع.',
'section_locked':'لا يوجد مربع تحديد متاح لهذا التلميذ؛ قد لا تسمح حالة تسجيله بالنقل.',
'section_search':'لم يظهر بحث الطلاب بعد تحميل صفحة الشعب؛ لم يبدأ السحب.',
'section_grades':'تعذّر تحديد صفوف صفحة الشعب أو تأكيد الصف المختار.',
'section_grade_missing':'زر الصف المختار غير موجود أو غير متاح في صفحة الشعب؛ حدّث صفوف المدرسة.',
'section_grade_click':'تعذّر الضغط على زر الصف المختار؛ راجع صفحة الشعب المفتوحة.',
'section_grade_applied':'تم الضغط على الصف لكن عنوان الموقع لم ينتقل إليه؛ لم يبدأ السحب.',
'section_cards':'تعذّر فتح شعب الصف وانتظار ظهور محتواها.',
'section_rows':'ظهرت الشعب لكن عدد الأسماء المحمّلة لا يطابق عدد الطلاب المعروض؛ لم يُحفظ ملف ناقص.',
'section_unknown':'نتيجة النقل غير مؤكدة؛ راجع الموقع يدوياً. توقفت القائمة دون إعادة الحفظ.',
'section_uncertain':'تم تخطّيه: سبق طلب نقله في الجلسة، ولم يُعد النقل أو الحفظ. راجع الموقع للتحقّق من نتيجته.',
'section_failed':'توقفت العملية. راجع الموقع.', 'section_input':'راجع الملف والخيارات.', 'section_busy':'انتظر انتهاء العملية الحالية.'}
class SectionDialog(QDialog):
    def __init__(self,controller,parent):
        super().__init__(parent);self.controller=controller;self.pending=None;self.rows=[];self.queue=[];self.active=False;self.available=True
        self.setObjectName('detailedImport');self.setWindowTitle('Sayed tech | التشعيب');self.setLayoutDirection(Qt.RightToLeft);self.resize(1000,650);self.setStyleSheet(DIALOG_STYLE)
        layout=QVBoxLayout(self);note=QLabel('يمكن تحديد التلاميذ كلهم بـ1 في Excel واختيار الشعبة الجديدة من القائمة. يُتخطّى من شعبته المطلوبة هي الحالية حسب الملف، ويُنقل الباقون ويحفظ كل تلميذ تلقائياً بالتتابع ضمن نفس الصف واللغة. يُتخطّى أيضاً من سبق طلب نقله في الجلسة دون إعادة نقله. تتوقف القائمة عند نتيجة نقل جديدة غير مؤكدة.');note.setWordWrap(True);layout.addWidget(note)
        scope=QHBoxLayout();self.grades_button=QPushButton('تحميل صفوف المدرسة');self.grade=QComboBox();self.grade.addItem('اختر الصف للاستخراج','');self.grade.setMinimumWidth(200)
        scope.addWidget(QLabel('صف الاستخراج:'));scope.addWidget(self.grade,1);scope.addWidget(self.grades_button);layout.addLayout(scope)
        self.grades_button.clicked.connect(lambda:self.send('section_grades'));self.grade.currentIndexChanged.connect(lambda:self.refresh())
        actions=QHBoxLayout();self.export_button=QPushButton('استخراج ملف التشعيب');self.import_button=QPushButton('استرداد ملف التشعيب')
        self.export_button.clicked.connect(self.export);self.import_button.clicked.connect(self.load)
        for b in (self.export_button,self.import_button):actions.addWidget(b)
        layout.addLayout(actions);self.table=QTableWidget(0,7);self.table.setHorizontalHeaderLabels(['اختيار','صف Excel','اسم الطالب','الصف','اللغة','النقل','النتيجة']);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.table.horizontalHeader().setSectionResizeMode(6,QHeaderView.Stretch);layout.addWidget(self.table,1)
        self.status=QLabel('');self.status.setWordWrap(True);layout.addWidget(self.status);footer=QHBoxLayout()
        self.run=QPushButton('نقل وحفظ المحددين');self.stop=QPushButton('إيقاف بعد التلميذ الحالي');close=QPushButton('إغلاق')
        self.run.clicked.connect(self.start);self.stop.clicked.connect(self.halt);close.clicked.connect(self.reject)
        for b in (self.run,self.stop,close):footer.addWidget(b)
        layout.addLayout(footer);controller.section_result.connect(self.result);controller.section_grades.connect(self.receive_grades);controller.event.connect(self.session);self.finished.connect(self.detach);self.refresh()
    def refresh(self):
        ready=self.available and self.pending is None and not self.active
        for b in (self.export_button,self.import_button):b.setEnabled(ready)
        self.grade.setEnabled(ready);self.grades_button.setEnabled(ready);self.export_button.setEnabled(ready and bool(self.grade.currentData()))
        self.run.setEnabled(ready and any(r['source']!=r['target'] and not r.get('done') and not r.get('skipped') for r in self.rows));self.table.setEnabled(ready);self.stop.setEnabled(self.active)
    def export(self):
        if self.pending or self.active or not self.grade.currentData():return
        path,_=QFileDialog.getSaveFileName(self,'استخراج التشعيب','SayedTech_Sections.xlsx','Excel (*.xlsx)')
        if not path:return
        if not path.lower().endswith('.xlsx'):path+='.xlsx'
        self.send('section_export',path=path,grade=self.grade.currentData())
    def receive_grades(self,request,raw):
        if not self.pending or self.pending[0]!=request:return
        labels=json.loads(raw);self.pending=None
        self.grade.blockSignals(True);self.grade.clear();self.grade.addItem('اختر الصف للاستخراج','')
        for label in labels:self.grade.addItem(label,label)
        self.grade.blockSignals(False);self.status.setText('اختر الصف ثم اضغط استخراج ملف التشعيب. يُسحب الصف المختار فقط.');self.refresh()
    def load(self):
        if self.pending or self.active:return
        path,_=QFileDialog.getOpenFileName(self,'ملف التشعيب','','Excel (*.xlsx)')
        if not path:return
        try:self.rows=read_sections(path)
        except ExcelInputError as e:self.status.setText(str(e));return
        self.table.setRowCount(len(self.rows))
        for i,r in enumerate(self.rows):
            unchanged=r['source']==r['target']
            for j,value in enumerate(('',r['excel_row'],r['name'],r['grade'],r['language'],r['source']+' ← '+r['target'],'لا نقل مطلوب حسب الملف' if unchanged else '')):
                item=QTableWidgetItem(str(value))
                if j==0:
                    item.setFlags(item.flags()|Qt.ItemIsUserCheckable);item.setCheckState(Qt.Unchecked if unchanged else Qt.Checked)
                    if unchanged:item.setFlags(item.flags()&~Qt.ItemIsEnabled)
                self.table.setItem(i,j,item)
        skipped=sum(r['source']==r['target'] for r in self.rows);moves=len(self.rows)-skipped
        self.status.setText(f'المطلوب نقلهم: {moves}؛ لا نقل مطلوب حسب الملف: {skipped}. '+('اضغط نقل وحفظ المحددين لتشغيلهم بالتتابع.' if moves else 'لا يوجد نقل للتنفيذ.'));self.refresh()
    def send(self,action,**payload):
        request=uuid4().hex;self.pending=(request,payload.get('index'))
        payload.pop('index',None)
        if not self.controller.sections(action,request,**payload):self.pending=None;self.active=False;self.status.setText('تعذّر إرسال الطلب.')
        else:self.status.setText('جارٍ تحميل صفوف المدرسة…' if action=='section_grades' else ('جارٍ استخراج الصف المختار…' if action=='section_export' else 'جارٍ نقل التلميذ وحفظ النقل…'))
        self.refresh()
    def start(self):
        if self.pending or not self.available:return
        self.queue=[i for i in range(len(self.rows)) if self.table.item(i,0).checkState()==Qt.Checked and self.rows[i]['source']!=self.rows[i]['target'] and not self.rows[i].get('done') and not self.rows[i].get('skipped')]
        if not self.queue:return
        self.active=True;self.next()
    def next(self):
        if self.pending or not self.active:return
        if not self.queue:self.active=False;self.refresh();return
        i=self.queue.pop(0);self.send('section_import',record=self.rows[i],index=i)
    def result(self,request,event):
        if not self.pending or self.pending[0]!=request:return
        _,index=self.pending;self.pending=None;self.status.setText(MESSAGES.get(event,'توقفت العملية.'))
        if index is not None:
            self.table.item(index,6).setText(self.status.text())
            if event in ('section_saved','section_already'):self.rows[index]['done']=True;self.table.item(index,0).setCheckState(Qt.Unchecked)
            elif event=='section_uncertain':
                self.rows[index]['skipped']=True
                item=self.table.item(index,0);item.setCheckState(Qt.Unchecked);item.setFlags(item.flags()&~Qt.ItemIsEnabled)
            else:self.active=False;self.queue=[]
        if self.active:QTimer.singleShot(0,self.next)
        self.refresh()
    def halt(self):self.active=False;self.queue=[];self.refresh()
    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.available=False;self.pending=None;self.active=False;self.queue=[];self.refresh()
    def reject(self):
        if self.pending:self.halt();self.status.setText('انتظر انتهاء التلميذ الحالي قبل الإغلاق.');return
        super().reject()
    def detach(self,*args):
        self.controller.section_result.disconnect(self.result);self.controller.section_grades.disconnect(self.receive_grades);self.controller.event.disconnect(self.session);self.rows=[];self.queue=[];self.table.clearContents()
