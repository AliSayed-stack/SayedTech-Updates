"""Merge an unfiltered SIMS export into the NSLDB workbook layout."""
from collections import defaultdict
import hashlib
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

from student_excel import BY_ID, HEADERS, ExcelInputError, normalize_date
from student_scan import REPORT_SHEET, canonical_uid, is_deleted, normalized
from student_workflow import workbook_rows
from student_unified import ENTRY_KIND, MOTHER_SURNAME, SELECTION, UNIFIED_HEADERS, source_mother_surname
from student_unified import MATCH_COLUMN, SITE_ONLY, SITE_AND_DB
from nsldb_reference import REFERENCE_EXTRA, DETAILED_CHOICE
from previous_academic import workbook_defaults, should_apply_default


UID = BY_ID['field-existingUniqueId']['label']
BIRTH = BY_ID['field-birthDate']['label']
NAME_COLUMNS = [BY_ID[f'field-{part}Name']['label'] for part in ('first','middle','last')]
SITE_ALIASES = {
    'بلد السكن': ('البلد', 'عناوين السكن'),
    'محافظة السكن': ('المحافظة', 'عناوين السكن'),
    'قضاء السكن': ('القضاء', 'عناوين السكن'),
    'منطقة / بلدة السكن': ('المنطقة', 'عناوين السكن'),
    'الشارع': ('الشارع', 'عناوين السكن'),
    'تفاصيل العنوان': ('تفاصيل العنوان ١', 'عناوين السكن'),
    'نوع السكن': ('النوع', 'عناوين السكن'),
    'رقم الهاتف (LivingPhone)': ('الهواتف / رقم الهاتف', 'الهواتف'),
    'نوع الهاتف': ('الهواتف / النوع', 'الهواتف'),
    MOTHER_SURNAME: ('شهرة الأم', 'الأقارب'),
}


def named_rows(z, sheet, *, skip_columns=()):
    rows = workbook_rows(z, sheet, ignore_headers=skip_columns, max_row=5020 if sheet==REPORT_SHEET else 5001)
    if not rows or rows[0][0] != 1 or rows[0][2]:
        raise ExcelInputError('عناوين ملف Excel غير صالحة.')
    columns = {col: val for col, val in rows[0][1].items() if val}
    if len(columns) != len(set(columns.values())):
        raise ExcelInputError('يوجد عنوان عمود مكرر.')
    result = {}
    for number, cells, formulas in rows[1:]:
        if formulas & {col for col,label in columns.items() if label not in skip_columns}:
            raise ExcelInputError(f'الصف {number}: استعمل قيماً ثابتة للدمج.')
        if any(value not in ('', None) for value in cells.values()):
            result[number] = {label: cells.get(col,'') for col,label in columns.items()}
    return set(columns.values()), result


def identity(row):
    names = tuple(normalized(row.get(label,'')) for label in NAME_COLUMNS)
    if not all(names):
        return None
    try:
        return names + (normalize_date(row.get(BIRTH,'')),)
    except (ValueError, TypeError, OverflowError):
        return None


def indexed(rows, key):
    groups = defaultdict(list)
    for number,row in rows.items():
        value = key(row)
        if value:
            groups[value].append(number)
    return groups


def merge_rows(base, site, report, headers=UNIFIED_HEADERS):
    active = {number:row for number,row in site.items()
              if number in report and not is_deleted({'status':report[number]['الحالة في النظام']})
              and not any(str(report[number]['حالة الفحص']).startswith(prefix)
                          for prefix in ('محذوف','نفس السجل المفتوح سابقاً'))}
    if not active:
        raise ExcelInputError('ملف السحب لا يحتوي سجلات طلاب قابلة للدمج.')
    get_uid = lambda row: canonical_uid(row.get(UID,''))
    db_ids, site_ids = indexed(base,get_uid), indexed(active,get_uid)
    db_names, site_names = indexed(base,identity), indexed(active,identity)
    matches = {}
    used = set()
    for number,row in active.items():
        uid=get_uid(row)
        if uid and len(site_ids[uid])==len(db_ids[uid])==1:
            matches[number]=db_ids[uid][0]
            used.add(db_ids[uid][0])
    merged=[]
    for number,row in active.items():
        source=matches.get(number)
        if source is None:
            key=identity(row)
            if key and len(site_names[key])==len(db_names[key])==1:
                candidate=db_names[key][0]
                uid, old_uid=get_uid(row), get_uid(base[candidate])
                if candidate not in used and (not uid or not old_uid):
                    source=candidate
                    matches[number]=source
                    used.add(source)
        output=dict(base.get(source,{}))
        if source is not None and MOTHER_SURNAME not in output:
            output[MOTHER_SURNAME]=source_mother_surname(output.get('ملاحظات المصدر',''))
        unread={label.strip() for label in str(report[number]['الخانات الأصلية غير المقروءة']).split('؛')}
        for label in HEADERS:
            if label in row and (label not in unread or (label==UID and row[label])):
                output[label]=row[label]
        inactive_tabs={title.strip() for key in ('الأقسام غير المقروءة','أقسام دون سجلات')
                       for title in str(report[number][key]).split('؛')}
        for target,(label,tab) in SITE_ALIASES.items():
            if tab not in inactive_tabs and row.get(label) not in ('',None):
                output[target]=row[label]
        for field in BY_ID.values():
            label=field['label']
            if field['type']=='date' and output.get(label) not in ('',None):
                output[label]=normalize_date(output[label],allow_future=True).replace('-','/')
        output[SELECTION]='0'
        output[ENTRY_KIND]='طالب موجود'
        for label,value in workbook_defaults(output).items():
            if should_apply_default(output,label):
                output[label]=value
        output[MATCH_COLUMN]=SITE_AND_DB if source is not None else SITE_ONLY
        merged.append([output.get(label,'') for label in headers])
    return merged,len(matches)


def merge_site_workbooks(source, scan, destination):
    from student_detailed import write_prepared
    source,scan,destination=map(Path,(source,scan,destination))
    if len({source.resolve(),scan.resolve(),destination.resolve()})!=3 or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('اختر اسماً مستقلاً للملف المدموج.')
    try:
        for path in (source,scan):
            if path.stat().st_size>64_000_000:
                raise ExcelInputError('ملف Excel كبير جداً.')
        with ZipFile(source) as db, ZipFile(scan) as sims:
            for book in (db,sims):
                if len(book.infolist())>1000 or sum(item.file_size for item in book.infolist())>128_000_000:
                    raise ExcelInputError('ملف Excel كبير جداً.')
            columns,base=named_rows(db,'الطلاب')
            allowed_extra=(*REFERENCE_EXTRA[:2],DETAILED_CHOICE)
            if not {UID,BIRTH,*NAME_COLUMNS,'السنة في القاعدة'}.issubset(columns) or not columns.issubset(set(UNIFIED_HEADERS)|set(allowed_extra)):
                raise ExcelInputError('أعمدة ملف NSLDB غير معروفة.')
            extras=[label for label in allowed_extra if label in columns]+[MATCH_COLUMN]
            if 'الصف الأصلي في القاعدة' not in columns:
                from student_promotion import source_results, apply_promotion, PROMOTION_HEADERS
                try:results=source_results(db)
                except ExcelInputError:results={}
                for row in base.values():
                    prepared=dict(row)
                    apply_promotion(prepared,results)
                    row.update({label:prepared[label] for label in PROMOTION_HEADERS})
            from student_excel import ADDRESS_STATUS_HEADER
            _,site=named_rows(sims,'الطلاب',skip_columns=(ADDRESS_STATUS_HEADER,))
            _,report_rows=named_rows(sims,REPORT_SHEET)
            report={int(float(row['صف Excel'])):row for row in report_rows.values()
                    if re.fullmatch(r'[0-9]+(?:\.0)?',str(row['صف Excel'])) and float(row['صف Excel'])>=2}
            extent=next((row[UID] for row in report_rows.values() if row['صف Excel']=='نطاق السحب'),'')
            match=re.fullmatch(r'قُرئ (\d+) من أصل (\d+) سجلاً في القائمة',str(extent))
            if (not match or not report or int(match[1])!=int(match[2]) or int(match[1])!=len(report)
                    or any(row['صف Excel']=='حالة العملية' for row in report_rows.values())):
                raise ExcelInputError('استكمل سحب SIMS قبل الدمج.')
            if any(number not in site for number in report):
                raise ExcelInputError('صفوف ملف السحب وتقريره غير متطابقة.')
            rows,matched=merge_rows(base,site,report,UNIFIED_HEADERS+extras)
        write_prepared(rows,destination,True,source.name,hashlib.sha256(source.read_bytes()).hexdigest(),
                       additional_headers=extras,site_merge=True)
        return len(rows),matched
    except ExcelInputError:
        raise
    except (OSError,ValueError,KeyError,TypeError,IndexError,BadZipFile,ET.ParseError):
        raise ExcelInputError('تعذّر دمج الملفين. افحص ملف السحب وأغلق ملف الإخراج في Excel.') from None
