"""Read-only extraction controls and transient, account-bound roster choices."""
from uuid import uuid4
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QComboBox,QPushButton,QProgressBar,QFileDialog,QScrollArea
import core


GRADE_FAILURE_TEXT = {
    'account_profile_missing':'تعذّر التحقق من بطاقة حساب المدرسة. سجّل الدخول مجدداً من التطبيق.',
    'account_session_changed':'تغيّرت جلسة حساب المدرسة. سجّل الدخول مجدداً من التطبيق.',
    'page_size':'تعذّر التعرّف على قائمة عدد الطلاب في الصفحة.',
    'pagination_format':'تعذّر قراءة صيغة عدّاد الصفحات والسجلات.',
    'rows_invalid':'تعذّرت قراءة بعض صفوف جدول الطلاب.',
    'unexpected_error':'حدث خطأ أثناء قراءة قائمة الصفوف أو جدول الطلاب.',
    'grade_filter':'تعذّر تحديد زر فلتر الصف في إدارة الطلاب.',
    'filters_active':'أعد الفلاتر إلى «الجميع» واختر «كل الأجناس» في فلتر الجنس.',
    'search_active':'امسح خانة البحث في إدارة الطلاب، ثم أعد المحاولة.',
    'headers_changed':'تعذّر التعرّف على أعمدة جدول الطلاب في هذه الصفحة.',
    'pagination_missing':'تعذّر العثور على عدّاد صفحات الطلاب.',
    'grade_menu_missing':'لم تظهر قائمة صفوف تحتوي خيار «جميع المستويات» بعد طلب فتحها.',
    'grade_menu_multiple':'ظهرت أكثر من قائمة صفوف؛ تعذّر تحديد القائمة الصحيحة.',
    'grade_menu_unstable':'ظهرت قائمة الصفوف لكن خياراتها لم تستقر أو فيها خيارات مكررة.',
    'grade_target_missing':'الصف المطلوب غير موجود ضمن خيارات قائمة الصفوف الظاهرة.',
    'grade_target_multiple':'ظهر الصف المطلوب أكثر من مرة في القائمة؛ لم يُضغط أي خيار.',
    'grade_target_disabled':'خيار الصف المطلوب موجود لكنه غير مفعّل في الموقع.',
    'grade_not_applied':'أُغلقت القائمة لكن عنوان فلتر الصف لم يتحول إلى الصف المطلوب.',
    'grade_menu_not_closed':'بقيت قائمة الصفوف مفتوحة بعد طلب اختيار الصف أو إغلاقها.',
}


class StudentScanDialog(QDialog):
    def __init__(self,controller,parent=None,*,merge_source=None):
        super().__init__(parent)
        self.controller=controller
        self.request_id=''
        self.pending=False
        self.available=True
        self.path=''
        self.last_result=''
        self.merge_source=merge_source
        self.merge_path=''
        self.setWindowTitle(f'Sayed tech {core.APP_VERSION} | سحب بيانات الطلاب')
        self.setLayoutDirection(Qt.RightToLeft)
        self.setStyleSheet('QPushButton,QComboBox {padding:6px 10px;}')
        self.resize(800,730)
        self.morning=getattr(parent,'school_shift',None)=='morning'
        self.loading_grades=False
        self.grades_request=''
        self.choice_request=''
        self.selection_spec=None
        layout=QVBoxLayout(self)
        intro=QLabel('اختر نطاق السحب: كل التلاميذ، صف محدد، تلاميذ تختارهم، أو حالة التسجيل.')
        intro.setWordWrap(True);layout.addWidget(intro)
        instructions=QLabel(
            'ابدأ من لوحة التحليلات أو إدارة الطلاب، وأغلق أي ملف طالب. '
            'اجعل الفلاتر الأربعة على «الجميع» وامسح البحث. لا تغيّر المتصفح أثناء السحب.\n\n'
            'يمكنك تحميل قائمة الصفوف واختيار صف واحد ليصدر ملفه فور اكتمال قراءته. '
            'السحب الكامل يختار الصفوف من الأصغر للأعلى ويكمل كل صفحاته، ١٠٠ طالب بالصفحة. '
            'أو اختر تلاميذ محددين أو حالة تسجيل من القائمة المقروءة من الموقع.\n\n'
            'يحفظ التقدّم بعد كل طالب مكتمل على جهازك بجانب Excel. للاستكمال اختر نفس اسم الملف والنطاق والحساب. '
            'عند التوقف يحاول إخراج Excel منفصل بالجزء المنجز دون استبدال ملفك النهائي.\n\n'
            'هذا حفظ محلي لنتيجة القراءة فقط: لا يضغط «حفظ القسم» أو «إرسال للمراجعة» ولا يغيّر بيانات الطالب. '
            'الأقسام المقفلة أو التي تعرض بطاقات دون حقول تبقى معلّمة «غير مقروءة».\n\n'
            'بعد عنوان السكن: زيارة واحدة لكل قسم مع مهلة قصيرة لاستقرار خاناته؛ تُقرأ القيم الموجودة، والخانات الأخرى تبقى جاهزة للإدخال اليدوي. '
            'لإرفاق مستند، أكمل نوعه في Excel. من إدراج ← صور اختر «وضع فوق الخلايا» وصورة JPG أو PNG. '
            'لملف PDF اختر إدراج ← كائن ← إنشاء من ملف، واختر العرض كأيقونة واترك «ارتباط بالملف» غير محدد. '
            'وسّع الصف عند الحاجة وضع الصورة أو الأيقونة داخل خلية «المستندات / صورة المستند» في صفها، مرفق واحد لكل مستند.\n\n'
            'لتجهيز معلومات السنة الدراسية السابقة، استخدم الزر أدناه. بعد تحديد الطلاب في Excel، ارجع إلى قسم الإدارة لفتح الاسترداد المفصّل.')
        instructions.setWordWrap(True)
        help_area=QScrollArea();help_area.setWidgetResizable(True);help_area.setWidget(instructions)
        help_area.setMaximumHeight(180);help_area.setVisible(False);layout.addWidget(help_area)
        help_button=QPushButton('تعليمات السحب والاستكمال')
        help_button.clicked.connect(lambda:help_area.setVisible(not help_area.isVisible()));layout.addWidget(help_button)
        self.scope=QComboBox()
        self.scope.addItem('كل الطلاب، من أصغر صف للأعلى',0)
        if not self.merge_source:
            self.scope.addItem('صف واحد محدد','grade')
            self.scope.addItem('تلاميذ أختارهم','selected')
            self.scope.addItem('حسب حالة التسجيل','status')
        self.scope.currentIndexChanged.connect(self.scope_changed)
        layout.addWidget(self.scope)
        self.grade_select=QComboBox();self.grade_select.addItem('حمّل الصفوف واختر الصف المطلوب','')
        layout.addWidget(self.grade_select)
        self.load_grades_button=QPushButton('تحميل الصفوف من النظام')
        self.load_grades_button.clicked.connect(self.load_grades)
        layout.addWidget(self.load_grades_button)
        self.choose_button=QPushButton('تحميل القائمة وتخصيص السحب')
        self.choose_button.clicked.connect(self.load_choices);layout.addWidget(self.choose_button)
        self.choice_summary=QLabel();layout.addWidget(self.choice_summary)
        self.scope_changed()
        self.status=QLabel('جاهز. اختر نطاق السحب ثم مكان ملف Excel.')
        self.status.setTextFormat(Qt.PlainText);self.status.setWordWrap(True);layout.addWidget(self.status)
        self.progress=QProgressBar();self.progress.setRange(0,1);layout.addWidget(self.progress)
        self.start_button=QPushButton('بدء سحب بيانات الطلاب')
        self.start_button.clicked.connect(self.start);layout.addWidget(self.start_button)
        self.stop_button=QPushButton('إيقاف السحب');self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop);layout.addWidget(self.stop_button)
        self.previous_school_button=QPushButton('إضافة معلومات السنة الدراسية السابقة')
        self.previous_school_button.clicked.connect(self.add_previous_school);layout.addWidget(self.previous_school_button)
        self.close_button=QPushButton('إغلاق');self.close_button.clicked.connect(self.reject);layout.addWidget(self.close_button)
        controller.scan_result.connect(self.result);controller.event.connect(self.session_event)
        self.finished.connect(self.cleanup)
        available=self.screen().availableGeometry()
        self.resize(min(800,available.width()-40),min(730,available.height()-60))

    def set_pending(self,value):
        self.pending=value
        self.start_button.setEnabled(not value and self.available)
        self.scope.setEnabled(not value and self.available)
        self.grade_select.setEnabled(not value and self.available)
        self.load_grades_button.setEnabled(not value and self.available)
        self.close_button.setEnabled(not value)
        self.stop_button.setEnabled(value)
        self.previous_school_button.setEnabled(not value)
        self.choose_button.setEnabled(not value and self.available)

    def add_previous_school(self):
        from previous_school_workbook import add_previous_school_type
        from student_excel import ExcelInputError
        source,_=QFileDialog.getOpenFileName(self,'اختر ملف الطلاب المسحوب أو المدموج',self.merge_path or self.path,'Excel (*.xlsx)')
        if not source:return
        proposed=str(Path(source).with_name(Path(source).stem+'_previous_year.xlsx'))
        destination,_=QFileDialog.getSaveFileName(self,'حفظ نسخة بمعلومات السنة الدراسية السابقة',proposed,'Excel (*.xlsx)')
        if not destination:return
        if not destination.lower().endswith('.xlsx'):destination+='.xlsx'
        try:
            count=add_previous_school_type(source,destination)
        except ExcelInputError as exc:self.status.setText(str(exc));return
        self.status.setText(f'تم تجهيز أعمدة السنة الدراسية السابقة وتعبئة القيم المتاحة في {count} صفاً.\n{destination}')

    def scope_changed(self,*_):
        chosen=self.scope.currentData()=='grade'
        self.grade_select.setVisible(chosen)
        self.load_grades_button.setVisible(chosen)
        custom=self.scope.currentData() in ('selected','status')
        self.choose_button.setVisible(custom);self.choice_summary.setVisible(custom)
        self.selection_spec=None;self.choice_summary.setText('لم يُعتمد اختيار بعد.')

    def load_choices(self):
        if self.pending or self.loading_grades or not self.available:return
        self.choice_request=self.request_id=uuid4().hex
        self.selection_spec=None;self.set_pending(True)
        self.status.setText('جارٍ تحميل أسماء التلاميذ وحالات التسجيل؛ لا تُفتح ملفات الطلاب…')
        if not self.controller.list_scan_roster(self.choice_request):
            self.result(self.choice_request,'scan_failed',0,0,{})

    def load_grades(self):
        if self.pending or self.loading_grades or not self.available:return
        self.grades_request=uuid4().hex
        self.request_id=self.grades_request
        self.loading_grades=True
        self.set_pending(True)
        self.scope.setEnabled(False);self.load_grades_button.setEnabled(False)
        self.status.setText('جارٍ قراءة قائمة الصفوف من نظام SIMS…')
        if not self.controller.list_scan_grades(self.grades_request):
            self.result(self.grades_request,'scan_failed',0,0,{})

    def start(self):
        if self.pending or self.loading_grades or not self.available:return
        grade=None
        custom=self.scope.currentData() in ('selected','status')
        if custom and not self.selection_spec:
            self.status.setText('اضغط «تحميل القائمة وتخصيص السحب» واعتمد اختيارك أولاً.');return
        if self.scope.currentData()=='grade':
            grade=self.grade_select.currentData()
            if not grade:
                self.status.setText('اضغط «تحميل الصفوف من النظام»، ثم اختر الصف المراد تصديره.')
                return
        path,_=QFileDialog.getSaveFileName(self,'حفظ بيانات الطلاب والنواقص','SayedTech_Existing_Students.xlsx','Excel (*.xlsx)')
        if not path:return
        if not path.lower().endswith('.xlsx'):path+='.xlsx'
        if self.merge_source:
            merged,_=QFileDialog.getSaveFileName(self,'حفظ ملف NSLDB وSIMS المدموج',
                str(Path(path).with_name('SayedTech_NSLDB_SIMS.xlsx')),'Excel (*.xlsx)')
            if not merged:return
            if not merged.lower().endswith('.xlsx'):merged+='.xlsx'
            if len({Path(p).resolve() for p in (self.merge_source,path,merged)})!=3:
                self.status.setText('استعمل ثلاثة مسارات مختلفة لملف القاعدة وملف السحب والملف المدموج.')
                return
            self.merge_path=merged
        self.path,self.request_id=path,uuid4().hex
        self.last_result=''
        self.set_pending(True);self.progress.setRange(0,0)
        self.status.setText('جارٍ فتح إدارة الطلاب وجمع القائمة، ١٠٠ طالب بالصفحة…')
        if not self.controller.scan_students(path,0,self.request_id,grade,selection=self.selection_spec if custom else None):
            self.result(self.request_id,'scan_failed',0,0,{})

    def stop(self):
        if self.pending:
            self.controller.cancel_scan(self.request_id)
            self.stop_button.setEnabled(False)
            self.status.setText('جارٍ إيقاف السحب وحفظ الجزء المنجز؛ لن يُستبدل ملف Excel النهائي السابق.')

    def result(self,request_id,event,first,second,detail=None):
        if request_id==self.choice_request and self.choice_request:
            self.choice_request='';self.set_pending(False)
            if event!='scan_roster' or not self.available or not (detail or {}).get('roster'):
                self.status.setText('تعذّر تحميل قائمة التلاميذ. ارجع لإدارة الطلاب وامسح البحث وأعد المحاولة.');return
            from scan_picker import ScanPicker
            picker=ScanPicker(detail,self.scope.currentData()=='status',self,
                              ordered=self.morning and self.scope.currentData()=='selected')
            if picker.exec()==QDialog.Accepted:
                self.selection_spec=picker.selection
                self.choice_summary.setText('حالة التسجيل: '+picker.selection['status'] if 'status' in picker.selection else f'عدد التلاميذ المختارين: {len(picker.selection["indexes"])}')
                self.status.setText('اعتمد الاختيار. اضغط «بدء سحب بيانات الطلاب».')
            return
        if request_id==self.grades_request and self.loading_grades:
            self.loading_grades=False
            self.set_pending(False)
            self.scope.setEnabled(self.available);self.load_grades_button.setEnabled(self.available)
            grades=(detail or {}).get('grades',[]) if event=='scan_grades' else []
            if grades:
                self.grade_select.clear()
                for grade in grades:self.grade_select.addItem(grade,grade)
                self.status.setText('اختر الصف، ثم اضغط «بدء سحب بيانات الطلاب». سيُصدّر Excel لهذا الصف فقط.')
            else:
                fallback = ('تعذّر تحديد جلسة SIMS المتصلة. اترك صفحة SIMS واحدة ضمن المتصفح الذي فتحه التطبيق.'
                            if event=='scan_account_required' else
                            'تعذّر تحميل الصفوف. افتح إدارة الطلاب، اجعل الفلاتر على «الجميع»، وأغلق ملف الطالب ثم أعد المحاولة.')
                self.status.setText(GRADE_FAILURE_TEXT.get((detail or {}).get('reason'), fallback))
            return
        if request_id!=self.request_id or not self.pending:return
        detail=detail or {}
        if event=='scan_progress':
            if detail.get('stage') in {'prepare','pagination'}:
                self.progress.setRange(0,0)
                self.status.setText('جارٍ التحقق من جدول الطلاب وترقيم الصفحات ثم تحميل ١٠٠ سجل بالصفحة…')
                return
            self.progress.setRange(0,max(1,second));self.progress.setValue(first)
            if detail.get('stage')=='inventory':
                self.status.setText(f'جمع قائمة {detail.get("grade") or "كل الصفوف للتحقق"}: {first} من {second} طالب.')
            elif detail.get('stage')=='resume':
                self.status.setText(f'تم العثور على تقدّم محفوظ لـ {detail.get("resumed",0)} طالب. جارٍ مطابقة الصفوف والاستكمال دون إعادة ملفاتهم.')
            elif detail.get('stage')=='export':
                self.status.setText('انتهت القراءة. جارٍ تجهيز ملف Excel مع تقرير النواقص وحدود القراءة…')
            else:
                self.status.setText(f'الصف: {detail.get("grade", "")} — تم {detail.get("grade_done",0)} من {detail.get("grade_total",0)} في هذا الصف.\nإجمالي السحب: {first} من {second}.')
            return
        self.last_result=event
        self.set_pending(False);self.progress.setRange(0,max(1,second))
        self.progress.setValue(first if event in {'scan_saved','scan_saved_partial','scan_paused','scan_paused_checkpoint'} else 0)
        if self.merge_source and event in ('scan_saved','scan_saved_partial'):
            from student_excel import ExcelInputError
            from student_site_merge import merge_site_workbooks
            try:
                total,matched=merge_site_workbooks(self.merge_source,self.path,self.merge_path)
            except ExcelInputError as exc:
                self.status.setText(f'{exc}\nملف سحب SIMS محفوظ في:\n{self.path}')
            else:
                self.status.setText(f'تم حفظ {total} طالباً من SIMS، منهم {matched} مطابقون للقاعدة.\nملف SIMS: {self.path}\nالملف المدموج: {self.merge_path}')
            return
        recovery_path=str(Path(self.path).parent/detail['recovery_file']) if detail.get('recovery_file') else ''
        messages={
            'scan_paused':f'توقّف السحب، وحُفظ تقدّم {first} من أصل {second} طالب.\nExcel للجزء المنجز (غير مكتمل):\n{recovery_path}\nللاستكمال: ارجع لإدارة الطلاب واجعل الفلاتر على الجميع، ثم اختر نفس اسم Excel الأصلي ونفس النطاق والحساب:\n{self.path}\nلم يُستبدل ملف Excel النهائي السابق.',
            'scan_paused_checkpoint':f'توقّف السحب، وتقدّم {first} من أصل {second} طالب محفوظ محلياً. تعذّر إخراج Excel للجزء المنجز، لكن يمكنك الاستكمال باختيار نفس اسم Excel الأصلي والنطاق والحساب:\n{self.path}\nلم يُستبدل ملف Excel النهائي السابق.',
            'scan_saved':f'حُفظت بيانات {first} طالب من أصل {second} في القائمة. {detail.get("missing",0)} طالب لديه خانات مطلوبة ناقصة ضمن الحقول المقروءة.\n{self.path}\nراجع ورقة «حالة السحب»؛ لم يُعدّل أي سجل.',
            'scan_saved_partial':f'حُفظت بيانات {first} طالب من أصل {second} في القائمة، مع أقسام أو خانات لم تُقرأ لدى {detail.get("unread",0)} طالب. {detail.get("missing",0)} طالب لديه نواقص مطلوبة مؤكدة ضمن الحقول المقروءة.\n{self.path}\nراجع «حالة السحب» و«الحقول المقروءة» و«البطاقات الظاهرة». القراءة غير المكتملة لا تعني اكتمال بيانات الطالب، ولم يُعدّل أي سجل.',
            'scan_prepare':'افتح إدارة الطلاب أو لوحة التحليلات، وأغلق ملف أي طالب. اجعل الصف والفرع واللغة والشعبة على «الجميع» وامسح البحث. تعذّر التعرّف إلى الجدول أو أزراره؛ لم يُحفظ ملف جديد.',
            'scan_changed':'تعذّر تأكيد بيانات الصفحة أثناء السحب، فتوقفت العملية دون حفظ ملف جديد. راجع سبب التوقف إن ظهر أدناه، واترك المتصفح دون تغيير أثناء المحاولة.',
            'scan_account_required':'تعذّر تأكيد الحساب الحالي أو انتهت الجلسة. لم يُحفظ ملف جديد.',
            'scan_unknown_grade':'ظهر اسم صف لا يعرف البرنامج ترتيبه. لم يبدأ قراءة الملفات ولم يُحفظ ملف جديد. أرسل اسم الصف كما يظهر في القائمة لإضافته دون تخمين ترتيبه.',
            'scan_cancelled':'توقف السحب ولم يُحفظ ملف جديد. قد يبقى ملف طالب مفتوحاً في المتصفح؛ ارجع لإدارة الطلاب قبل محاولة جديدة.',
            'scan_empty':'القائمة فارغة أو لم تُقرأ سجلات قابلة للتصدير. لم يُحفظ ملف جديد.',
            'scan_busy':'هناك عملية أخرى قيد التنفيذ. انتظر انتهاءها ثم أعد المحاولة.',
            'scan_failed':'تعذّر السحب أو حفظ Excel. لم يُستبدل ملف سابق. راجع الصفحة ومكان الحفظ وأغلق ملف Excel إن كان مفتوحاً، ثم أعد المحاولة.',
        }
        reasons={
            'cancelled_by_user':'تم الإيقاف بطلبك، مع الاحتفاظ بالتقدّم المنجز.',
            'checkpoint_write':'تعذّر تثبيت التقدّم على القرص. توقّف السحب لحماية ما سبق حفظه؛ افحص المساحة وصلاحيات المجلد.',
            'checkpoint_invalid':'ملف التقدّم غير قابل للقراءة أو غير صالح. بقي كما هو؛ اختر اسماً جديداً لبدء سحب مستقل.',
            'checkpoint_mismatch':'التقدّم المحفوظ لا يطابق الحساب أو نطاق السحب أو قائمة الطلاب الحالية. بقي كما هو؛ اختر اسماً جديداً لسحب مستقل.',
            'tab_timeout':'لم تستقر بيانات أحد تبويبات الطالب خلال المهلة.',
            'controls_changed':'تغيّرت بنية حقول الطالب أثناء القراءة.',
            'unexpected_error':'حدث خطأ أثناء القراءة أو التنقل أو حفظ الملف؛ الصورة وحدها لا تحدد سببه.',
            'grade_filter':'تعذّر اختيار فلتر الصف أو لم تستقر القائمة على طلاب الصف المحدد.',
            'grade_coverage':'لم تتطابق قائمة هذا الصف كاملة مع الجرد الأول. قد يكون هناك فلتر فرع أو لغة أو شعبة يقيّد النتائج، أو تغيّرت القائمة أثناء السحب. أعد باقي الفلاتر إلى «الجميع» وابدأ من جديد.',
            'grade_options':'تعذّرت قراءة قائمة الصفوف أو اختلفت خياراتها أثناء السحب.',
            **GRADE_FAILURE_TEXT,
            'selection_changed':'تغيّرت قائمة التلاميذ أو أصبح الاختيار ملتبساً. أعد تحميل قائمة الاختيار وحدّد التلاميذ مجدداً؛ لم يُستبدل ملفك.',
            'table_missing':'لم يظهر جدول الطلاب بعد.',
            'headers_changed':'لم تتطابق الأعمدة الأساسية أو ظهر أكثر من جدول مطابق.',
            'pagination_missing':'لم يظهر سطر «الصفحة… من… سجل إجمالاً» بشكل مميز.',
            'pagination_format':'صيغة سطر عدد الصفحات والسجلات غير معروفة.',
            'filters_active':'في بداية السحب اجعل الفلاتر المتاحة على «الجميع». بعد اختيار صف لا يحتاج فرعاً، عبارة «لا ينطبق على هذا الصف» في خانة الفرع مقبولة؛ اللغة والشعبة تبقيان على «الجميع».',
            'search_active':'خانة البحث ليست فارغة. امسحها ثم أعد المحاولة.',
            'rows_invalid':'بعض صفوف الجدول لم تكتمل أو لم يظهر فيها الرقم الموحد وزر التعديل.',
            'duplicate_record':'فُتح نفس سجل الطالب مرة ثانية أثناء السحب؛ توقفت القراءة لتجنب تكراره.',
            'page_size':'لم يتعرّف إلى قائمة 10/25/50/100 طالب بالصفحة.',
            'loading':'لم تستقر بيانات الجدول خلال مهلة الانتظار.',
            'page_not_changed':'لم يتغير رقم الصفحة ومحتواها كما هو متوقع بعد التنقل.',
            'count_changed':'تغير العدد الإجمالي أثناء التنقل بين الصفحات.',
            'row_count':'لم يتطابق عدد الصفوف وترقيم الصفحات مع حجم ١٠٠ طالب بالصفحة.',
            'record_timeout':'تم طلب فتح الطالب، لكن ملفه ورقمه الموحد لم يظهرا خلال المهلة.',
            'list_changed':'اختلفت بيانات صفوف الطلاب عن القائمة التي جُمعت أولاً.',
            'identity_changed':'اختلف رقم الطالب أو اسمه عن الصف المطلوب، أو تعذّر تأكيد هوية طالب لا يظهر له رقم موحد.',
            'account_profile_missing':'الإيميل غير ظاهر ولم يتأكد اسم بطاقة الحساب منذ تسجيل الدخول. أعد تسجيل الدخول بالنسخة الجديدة، وانتظر ظهور اسم الحساب ثم افتح السحب. إذا تكرر السبب أرسل HTML لبطاقة الحساب أسفل الشريط الجانبي، دون بيانات الدخول.',
            'account_session_changed':'تغيّرت بطاقة الحساب أو خرجت الصفحة من جلسة الدخول التي أكدها البرنامج. أنهِ الجلسة وسجّل الدخول مجدداً.',
        }
        message=messages.get(event,messages['scan_failed'])
        if event in {'scan_saved','scan_saved_partial'}:
            message+=f'\nعدد الملفات المقروءة: {detail.get("read",first)}. السجلات المحذوفة أو المعروضة مجدداً التي تم تخطيها: {detail.get("skipped",0)}.'
        if detail.get('reason') in reasons:
            message+='\nسبب التوقف: '+reasons[detail['reason']]
        self.status.setText(message)

    def session_event(self,event):
        if event in {'invalid_input','dependency_missing','browser_missing','timeout','failed','cancelled','browser_closed','disconnected'}:
            self.available=False;self.set_pending(False)
            self.loading_grades=False;self.load_grades_button.setEnabled(False)
            self.choice_request='';self.selection_spec=None
            if self.last_result in {'scan_paused','scan_paused_checkpoint'}:
                self.status.setText(self.status.text()+'\nانتهت جلسة المتصفح؛ سجّل الدخول مجدداً للاستكمال.')
            else:self.status.setText('انتهت جلسة المتصفح. يبقى أي تقدّم محفوظ على القرص؛ سجّل الدخول مجدداً واختر نفس ملف Excel للاستكمال.')

    def reject(self):
        if not self.pending:super().reject()

    def closeEvent(self,event):
        if self.pending:event.ignore()
        else:super().closeEvent(event)

    def cleanup(self,*_):
        self.controller.scan_result.disconnect(self.result);self.controller.event.disconnect(self.session_event)
