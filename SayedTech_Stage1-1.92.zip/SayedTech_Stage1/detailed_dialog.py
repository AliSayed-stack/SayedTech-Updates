import uuid
from PySide6.QtCore import Qt,QTimer
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,
    QTableWidget,QTableWidgetItem,QPushButton,QAbstractItemView,QComboBox,
    QWidget,QScrollArea,QFrame,QGroupBox,QToolButton,QSizePolicy,QLayout,QHeaderView,QStyledItemDelegate,QCheckBox)
from detailed_batch import DetailedImportBatch
from detailed_import import DETAIL_SECTION_LABELS, UID_LABEL
from detail_scope import grade_choices,in_grade,scoped_record

DIALOG_STYLE='''
QDialog#detailedImport { background: #f3f6fa; }
QDialog#detailedImport QWidget { font-size: 13px; }
QDialog#detailedImport QWidget#detailBody, QDialog#detailedImport QScrollArea { background: transparent; }
QDialog#detailedImport QLabel#detailTitle { font-size: 18px; font-weight: 700; }
QDialog#detailedImport QLabel#detailStatus { color: #496178; padding: 4px 2px; }
QDialog#detailedImport QGroupBox { background: white; border: 1px solid #d7e1ec; border-radius: 8px; margin-top: 8px; font-weight: 600; }
QDialog#detailedImport QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top right; right: 12px; padding: 0 4px; }
QDialog#detailedImport QComboBox { background: #f9fbfd; color: #1a2a43; border: 1px solid #d7e1ec; padding: 5px 10px; min-height: 22px; border-radius: 6px; }
QDialog#detailedImport QPushButton { color: white; background: #138d79; font-weight: 600; border: none; padding: 6px 10px; min-height: 22px; border-radius: 6px; }
QDialog#detailedImport QPushButton:hover { background: #0f7b69; }
QDialog#detailedImport QPushButton:disabled { color: #eef4f3; background: #a4bcb8; }
QDialog#detailedImport QPushButton#detailSecondary { color: #24466c; background: #e8eef5; }
QDialog#detailedImport QPushButton#detailSecondary:hover { background: #dce6f1; }
QDialog#detailedImport QPushButton#detailSecondary:disabled { color: #8291a1; background: #eef1f5; }
QDialog#detailedImport QPushButton#detailStop { background: #b3562c; }
QDialog#detailedImport QPushButton#detailStop:disabled { background: #c6b7b0; }
QDialog#detailedImport QToolButton { color: #246b97; background: transparent; padding: 4px; border: none; }
QDialog#detailedImport QTableWidget { background: white; alternate-background-color: #f6f9fc; border: 1px solid #d7e1ec; gridline-color: #e4eaf1; selection-background-color: #def2ec; selection-color: #173e35; }
QDialog#detailedImport QHeaderView::section { background: #eaf0f6; color: #24466c; padding: 6px; border: none; border-bottom: 1px solid #d7e1ec; font-weight: 600; }
'''


class DetailedImportDialog(QDialog):
    def __init__(self,rows,controller,parent):
        super().__init__(parent)
        self.rows=rows;self.controller=controller;self.batch=DetailedImportBatch(rows);self.single_pending=None;self.scope_request=None
        self.birth_diagnostics={}
        self._fitted=False;self._action_columns=None
        self.setObjectName('detailedImport')
        self.setWindowTitle('Sayed tech | استيراد مفصّل')
        self.setWindowFlag(Qt.WindowMaximizeButtonHint,True)
        self.setLayoutDirection(Qt.RightToLeft)
        self.setStyleSheet(DIALOG_STYLE)
        outer=QVBoxLayout(self);outer.setContentsMargins(12,12,12,10);outer.setSpacing(8)
        # The scrollable body can exceed a small/high-DPI screen without
        # forcing the native window beyond its available work area.
        outer.setSizeConstraint(QLayout.SetNoConstraint)
        self.body_scroll=QScrollArea();self.body_scroll.setWidgetResizable(True)
        self.body_scroll.setFrameShape(QFrame.NoFrame)
        self.body_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.body_scroll.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
        self.body=QWidget();self.body.setObjectName('detailBody')
        self.body_scroll.setWidget(self.body);outer.addWidget(self.body_scroll,1)
        layout=QVBoxLayout(self.body);layout.setContentsMargins(0,0,0,0);layout.setSpacing(8)
        header=QHBoxLayout()
        title=QLabel('استرداد المعلومات المفصّلة');title.setObjectName('detailTitle')
        header.addWidget(title,1)
        self.help_button=QToolButton();self.help_button.setText('إرشادات الاستخدام')
        self.help_button.setCheckable(True);self.help_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.help_button.setArrowType(Qt.LeftArrow);header.addWidget(self.help_button)
        layout.addLayout(header)
        note=QLabel('تُستورد بيانات كل التلاميذ المعلّمين بـ1 أو نعم في أول عمود في Excel، لمدارس قبل الظهر وبعد الظهر. '
            'يتحقق البرنامج من هوية كل طالب، ثم يعبّئ ويحفظ الأقسام التي فيها بيانات: عناوين السكن والهواتف والبريد الإلكتروني وشهرة الأم وبطاقات التعريف والمستندات. '
            'الخانات الفارغة لا تمسح بيانات الموقع، ولا يلزم مرفق لبطاقات التعريف والمستندات. '
            'لتعبئة قسم واحد، اختر الطالب من الجدول والقسم من القائمة واضغط تعبئة وحفظ القسم المحدد. '
            'اختر الصف، وأزل إشارة استرداد عن الطلاب الذين تريد تخطّيهم؛ الاستيراد المجمع يعمل على المؤشّر عليهم ضمن الصف فقط. الإرسال بعد تأكيد حفظ الأقسام. '
            'إذا تعثّرت التعبئة أو الحفظ، تتوقف العملية عند الطالب لمراجعته قبل المتابعة. احفظ أي مسودة مفتوحة في المتصفح قبل البدء.')
        note.setWordWrap(True);note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Minimum)
        self.help_scroll=QScrollArea();self.help_scroll.setWidgetResizable(True)
        self.help_scroll.setFrameShape(QFrame.NoFrame);self.help_scroll.setWidget(note)
        self.help_scroll.setFixedHeight(100);self.help_scroll.hide();layout.addWidget(self.help_scroll)
        self.help_button.toggled.connect(self.show_help)
        scope_line=QHBoxLayout();scope_line.addWidget(QLabel('صف الاسترداد والبحث:'))
        self.grade_combo=QComboBox()
        self.grade_combo.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        self.grade_combo.setMinimumContentsLength(12)
        self.grade_combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.grade_combo.addItem('كل الصفوف',None)
        for grade in grade_choices(rows):self.grade_combo.addItem(grade,grade)
        scope_line.addWidget(self.grade_combo,1);layout.addLayout(scope_line)
        from manual_sections import IMPORT_SECTIONS,section_summary
        self.manual_mode=all('manual' in r for r in rows)
        headings=(['صف Excel','الطالب']+list(IMPORT_SECTIONS) if self.manual_mode else
                  ['صف Excel','الطالب','شهرة الأم','البلد','العنوان','الهاتف','نوع المستند','رقم الوثيقة','تاريخ الانتهاء'])
        headings.insert(0,'استرداد');self.select_column=0
        headings.append('نتيجة الاستيراد')
        self.result_column=len(headings)-1
        self.table=QTableWidget(len(rows),len(headings))
        self.table.setLayoutDirection(Qt.RightToLeft)
        self.table.setHorizontalHeaderLabels(headings)
        self.table.horizontalHeader().setLayoutDirection(Qt.RightToLeft)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
        self.table.horizontalHeaderItem(self.select_column).setToolTip('أزل الإشارة لتخطّي هذا الطالب في التعبئة والحفظ والمراجعة. الاختيار محلي لهذه النافذة.')
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True);self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideRight)
        self.table.setMinimumHeight(210)
        self.table.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Expanding)
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setMinimumSectionSize(60)
        for i,row in enumerate(rows):
            values=row['values'];address=row['address']
            texts=[', '.join(map(str,row.get('excel_rows',[row['excel_row']]))),' '.join(values[k] for k in ('field-firstName','field-middleName','field-lastName')),
                   str(row.get('mother_surname','')),address.get('البلد',''),
                   ' / '.join(str(address.get(k,'')) for k in ('المحافظة','القضاء','المنطقة')),str(row['phone'])]
            card=row.get('identity_card',{})
            texts.extend(str(card.get(k,'') or '') for k in ('type','number','expiry'))
            if self.manual_mode:texts=texts[:2]+[section_summary(row,title) for title in IMPORT_SECTIONS]
            texts.append('بانتظار الاستيراد')
            texts.insert(0,'')
            for j,text in enumerate(texts):
                item=QTableWidgetItem(text);item.setToolTip(text)
                item.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
                if j==self.select_column:
                    item.setFlags(Qt.ItemIsUserCheckable|Qt.ItemIsEnabled|Qt.ItemIsSelectable)
                    item.setCheckState(Qt.Checked)
                    item.setToolTip('مؤشّر عليه: يُسترد. أزل الإشارة لتخطّيه في هذه النافذة.')
                self.table.setItem(i,j,item)
        for column in range(len(headings)):
            self.table.setColumnWidth(column,64 if column==0 else 74 if column==1 else 220 if column==2 else 190)
        self.table.setColumnWidth(self.result_column,300)
        self.table.horizontalHeader().moveSection(self.result_column,3)
        self.table.verticalHeader().setDefaultSectionSize(max(34,self.table.fontMetrics().height()+12))
        layout.addWidget(self.table,1)
        instruction='أزل إشارة استرداد عمّن تريد تخطّيه، ثم اختر إجراء الاستيراد.'
        self.status=QLabel(f'جاهز لاستيراد {len(rows)} طالباً من Excel. '+instruction)
        self.status.setTextFormat(Qt.PlainText);self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.status.setObjectName('detailStatus');layout.addWidget(self.status)
        self.buttons=[self.grade_combo]
        if self.manual_mode:
            self.single_group=QGroupBox('الطالب المحدّد في الجدول')
            self.single_grid=QGridLayout(self.single_group)
            self.single_grid.setContentsMargins(10,20,10,10);self.single_grid.setSpacing(8)
            self.manual_sections=QComboBox()
            self.manual_sections.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            self.manual_sections.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            self.manual_sections.setMinimumContentsLength(12)
            for title in IMPORT_SECTIONS:
                if title=='الأقارب':
                    self.manual_sections.addItem(DETAIL_SECTION_LABELS['personal'],'personal')
                else:
                    self.manual_sections.addItem(title,'manual_save:'+title)
            self.manual_sections.addItem(DETAIL_SECTION_LABELS['previous_school_type'],'previous_school_type')
            self.manual_sections.setToolTip('اختر القسم للطالب المحدّد. حالة التسجيل للقراءة؛ الإرسال له زر مستقل.')
            self.manual_save_button=QPushButton('تعبئة وحفظ القسم المحدد')
            self.manual_save_button.clicked.connect(self.start_section)
            self.manual_save_button.setObjectName('detailSecondary')
            self.buttons.extend([self.manual_sections,self.manual_save_button])
            self.manual_sections.currentIndexChanged.connect(self.section_changed)
            self.review_button=QPushButton('إرسال الطالب المحدد للمراجعة')
            self.review_button.clicked.connect(lambda:self.start_selected('review_send'))
            self.review_button.setObjectName('detailSecondary')
            self.buttons.append(self.review_button);layout.addWidget(self.single_group)
        self.batch_group=QGroupBox('استيراد الطلاب المؤشّر عليهم ضمن الصف المختار')
        self.selected_sections=None
        self.section_choices=('personal','previous_school_type','address')+(
            ('manual_save:الهواتف','manual_save:البريد الإلكتروني','manual_save:بطاقات التعريف','manual_save:المستندات')
            if self.manual_mode else ('phone','identity_card'))
        self.choose_sections_button=QPushButton('اختيار الأقسام — كل الأقسام')
        self.choose_sections_button.clicked.connect(self.choose_sections)
        self.buttons.append(self.choose_sections_button)
        layout.addWidget(self.choose_sections_button)
        self.batch_grid=QGridLayout(self.batch_group)
        self.batch_grid.setContentsMargins(10,20,10,10);self.batch_grid.setSpacing(8)
        self.import_review_button=QPushButton('استيراد الداتا المفصّلة مع إرسال الطالب للمراجعة')
        self.import_review_button.clicked.connect(lambda:self.start_batch(True))
        self.import_button=QPushButton('استيراد الداتا المفصّلة بدون إرسال الطالب للمراجعة')
        self.import_button.clicked.connect(lambda:self.start_batch(False))
        self.buttons.extend([self.import_review_button,self.import_button])
        layout.addWidget(self.batch_group)
        self.open_student_button=QPushButton('استرداد من سجل التلميذ المفتوح')
        self.open_student_button.clicked.connect(lambda:self.start_batch(False,use_open_student=True))
        self.open_student_button.setToolTip('افتح سجل التلميذ على المعلومات الشخصية في متصفح SIMS، وحدّد صفه وحده في الجدول.')
        self.buttons.append(self.open_student_button)
        layout.addWidget(self.open_student_button)
        for button in self.buttons:
            if isinstance(button,QPushButton):
                button.setAutoDefault(False)
                button.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
                button.setToolTip(button.text())
        footer=QHBoxLayout()
        self.stop_button=QPushButton('إيقاف بعد الطالب الحالي')
        self.stop_button.setObjectName('detailStop');self.stop_button.setAutoDefault(False)
        self.stop_button.clicked.connect(self.stop_batch);self.stop_button.hide();footer.addWidget(self.stop_button)
        self.continue_student_button=QPushButton('كمّل نفس التلميذ')
        self.continue_student_button.setToolTip('بعد مراجعة القسم وحفظه على SIMS، تابع الأقسام التالية لهذا التلميذ.')
        self.continue_student_button.clicked.connect(lambda:self.resume_batch(same_student=True))
        self.skip_student_button=QPushButton('تخطّي التلميذ ومتابعة')
        self.skip_student_button.clicked.connect(lambda:self.resume_batch(same_student=False))
        for button in (self.continue_student_button,self.skip_student_button):
            button.setAutoDefault(False);button.hide();footer.addWidget(button)
        footer.addStretch()
        self.close_button=QPushButton('إغلاق');self.close_button.setObjectName('detailSecondary')
        self.close_button.setAutoDefault(False);self.close_button.setMinimumWidth(90)
        self.close_button.clicked.connect(self.reject);footer.addWidget(self.close_button);outer.addLayout(footer)
        controller.student_result.connect(self.result);controller.event.connect(self.session)
        if hasattr(controller,'detail_diagnostic'):controller.detail_diagnostic.connect(self.receive_diagnostic)
        self.finished.connect(self.detach)
        # Explicit direction/alignment also covers native Windows combo labels,
        # whose noneditable text may otherwise ignore the inherited RTL state.
        for widget in (self.body,self.body_scroll,self.table.viewport()):widget.setLayoutDirection(Qt.RightToLeft)
        for combo in [self.grade_combo]+([self.manual_sections] if self.manual_mode else []):
            combo.setLayoutDirection(Qt.RightToLeft);combo.view().setLayoutDirection(Qt.RightToLeft)
            combo.setItemDelegate(QStyledItemDelegate(combo))
            for index in range(combo.count()):combo.setItemData(index,Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute,Qt.TextAlignmentRole)
            if hasattr(combo,'setLabelDrawingMode'):combo.setLabelDrawingMode(QComboBox.LabelDrawingMode.UseDelegate)
        self.table.itemChanged.connect(self.selection_changed)
        self.grade_combo.currentIndexChanged.connect(self.grade_changed)
        if rows:self.table.setCurrentCell(0,0)
        self.reflow_actions(1100)
        self.resize(1180,780)
        self.section_changed()

    def show_help(self,visible):
        self.help_scroll.setVisible(visible)
        self.help_button.setArrowType(Qt.DownArrow if visible else Qt.LeftArrow)

    def reflow_actions(self,width):
        columns=3 if width>=980 else 2 if width>=700 else 1
        if columns==self._action_columns:return
        self._action_columns=columns
        grids=[self.batch_grid]+([self.single_grid] if self.manual_mode else [])
        for grid in grids:
            while grid.count():grid.takeAt(0)
            for column in range(3):grid.setColumnStretch(column,0)
        if self.manual_mode:
            if columns==3:
                for column,widget in enumerate((self.manual_sections,self.manual_save_button,self.review_button)):
                    self.single_grid.addWidget(widget,0,column);self.single_grid.setColumnStretch(column,1)
            elif columns==2:
                self.single_grid.addWidget(self.manual_sections,0,0,1,2)
                self.single_grid.addWidget(self.manual_save_button,1,0)
                self.single_grid.addWidget(self.review_button,1,1)
                for column in range(2):self.single_grid.setColumnStretch(column,1)
            else:
                for row,widget in enumerate((self.manual_sections,self.manual_save_button,self.review_button)):
                    self.single_grid.addWidget(widget,row,0)
                self.single_grid.setColumnStretch(0,1)
        for index,button in enumerate((self.import_button,self.import_review_button)):
            # Compact labels keep both explicit choices readable side by side
            # on smaller screens; the full action remains in the tooltip.
            button.setText(('استيراد وحفظ بدون إرسال للمراجعة' if index==0 else 'استيراد وحفظ وإرسال للمراجعة')
                           if columns==2 else button.toolTip())
            self.batch_grid.addWidget(button,0 if columns>=2 else index,index if columns>=2 else 0)
            self.batch_grid.setColumnStretch(index if columns>=2 else 0,1)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        if hasattr(self,'batch_grid'):self.reflow_actions(self.width()-48)

    def showEvent(self,event):
        super().showEvent(event)
        if not self._fitted:
            self._fitted=True
            QTimer.singleShot(0,self.fit_screen)
            if self.windowHandle():self.windowHandle().screenChanged.connect(self.fit_screen)

    def fit_screen(self,*args):
        screen=self.screen()
        if screen is None:return
        area=screen.availableGeometry()
        frame=self.frameGeometry()
        frame_width=frame.width()-self.width();frame_height=frame.height()-self.height()
        self.resize(min(1180,max(1,area.width()-24-frame_width)),
                    min(780,max(1,area.height()-24-frame_height)))
        frame=self.frameGeometry()
        frame.moveCenter(area.center());self.move(frame.topLeft())

    def grade_changed(self,*args):
        if self.scope_request or self.single_pending or self.batch.active or self.batch.pending:return
        grade=self.grade_combo.currentData()
        visible=[]
        for i,row in enumerate(self.rows):
            show=in_grade(row,grade);self.table.setRowHidden(i,not show)
            if show:visible.append(i)
        self.table.clearSelection();self.table.setCurrentCell(visible[0] if visible else -1,0)
        scope=grade or 'كل الصفوف'
        request=uuid.uuid4().hex
        self.scope_request=(request,grade)
        self.set_running(True)
        self.status.setText(f'جارٍ تطبيق فلتر الصف على الموقع: {scope}…')
        if not self.controller.fill_details({'search_grade':grade},'scope_grade',request):
            self.result(request,'detail_account','')

    def checked_indices(self):
        return [i for i in range(len(self.rows)) if not self.table.isRowHidden(i) and
                self.table.item(i,self.select_column).checkState()==Qt.Checked]

    def selection_changed(self,item):
        if item.column()!=self.select_column or self.scope_request or self.single_pending or self.batch.active or self.batch.pending:return
        self.status.setText(f'مؤشّر عليهم للاسترداد: {len(self.checked_indices())} طالباً ضمن الصف المختار. الطلاب غير المؤشّر عليهم يُتخطّون.')
        self.update_resume_buttons()

    def section_changed(self,*args):
        if self.manual_mode and not self.batch.active and not self.single_pending:
            self.manual_save_button.setEnabled(self.manual_sections.currentData()!='manual_save:حالة التسجيل')

    def start_section(self):
        if self.manual_mode:self.start_selected(self.manual_sections.currentData())

    def start_selected(self,section):
        if self.scope_request or self.single_pending or self.batch.active or self.batch.pending:return
        index=self.table.currentRow()
        if index<0 or not self.manual_mode or self.table.isRowHidden(index):return
        if self.table.item(index,self.select_column).checkState()!=Qt.Checked:
            self.status.setText('هذا الطالب غير مؤشّر عليه للاسترداد. فعّل خانة استرداد بجانبه قبل تعبئته أو إرساله للمراجعة.');return
        if section=='manual_save:حالة التسجيل':return
        request=uuid.uuid4().hex
        self.single_pending=(request,index)
        self.set_running(True)
        action='إرسال الطالب المحدد للمراجعة' if section=='review_send' else 'تعبئة وحفظ '+self.manual_sections.currentText()
        self.status.setText(f'جارٍ {action} — صف Excel {self.rows[index]["excel_row"]}…')
        row=scoped_record(self.rows[index],self.grade_combo.currentData())
        if not self.controller.fill_details(row,section,request):
            self.result(request,'detail_account','')

    def choose_sections(self):
        picker=QDialog(self)
        picker.setWindowTitle('اختيار الأقسام للاسترداد')
        picker.setLayoutDirection(Qt.RightToLeft)
        layout=QVBoxLayout(picker)
        boxes={}
        for key in self.section_choices:
            box=QCheckBox(DETAIL_SECTION_LABELS[key])
            box.setChecked(self.selected_sections is None or key in self.selected_sections)
            layout.addWidget(box)
            boxes[key]=box
        actions=QHBoxLayout()
        select_all=QPushButton('تحديد الكل')
        clear=QPushButton('إلغاء التحديد')
        apply=QPushButton('اعتماد')
        cancel=QPushButton('رجوع')
        def set_all(checked):
            for box in boxes.values():box.setChecked(checked)
        def update_apply():
            apply.setEnabled(any(box.isChecked() for box in boxes.values()))
        for box in boxes.values():box.toggled.connect(update_apply)
        select_all.clicked.connect(lambda:set_all(True))
        clear.clicked.connect(lambda:set_all(False))
        apply.clicked.connect(picker.accept)
        cancel.clicked.connect(picker.reject)
        for button in (select_all,clear,apply,cancel):actions.addWidget(button)
        layout.addLayout(actions)
        if picker.exec()!=QDialog.Accepted:return
        selected=tuple(key for key,box in boxes.items() if box.isChecked())
        if not selected:return
        self.selected_sections=None if selected==self.section_choices else selected
        summary='كل الأقسام' if self.selected_sections is None else '، '.join(DETAIL_SECTION_LABELS[key] for key in selected)
        self.choose_sections_button.setText('اختيار الأقسام — '+summary)
        self.choose_sections_button.setToolTip(summary)

    def start_batch(self,with_review,*,use_open_student=False):
        if self.scope_request or self.single_pending or self.batch.active or self.batch.pending:return
        selected=self.checked_indices()
        if not selected:
            self.status.setText('لم يبدأ الاستيراد. فعّل خانة استرداد لطالب واحد على الأقل ضمن الصف المختار.');return
        if use_open_student and len(selected)!=1:
            self.status.setText('حدّد صف تلميذ واحد، وافتح سجله على المعلومات الشخصية في SIMS.')
            return
        if not self.batch.start(with_review,self.grade_combo.currentData(),selected,
                                use_open_student=use_open_student,sections=self.selected_sections):return
        self.set_running(self.batch.active)
        if self.batch.active:self.dispatch_next()
        else:self.status.setText(self.batch_summary()+' لا يوجد تلاميذ مؤشّر عليهم بانتظار الاستيراد.')

    def set_running(self,running):
        for button in self.buttons+[self.close_button]:button.setEnabled(not running)
        self.table.setEnabled(not running)
        self.stop_button.setVisible(running and self.batch.active);self.stop_button.setEnabled(running and self.batch.active)
        self.update_resume_buttons(running)
        if not running:self.section_changed()

    def update_resume_buttons(self,running=False):
        available=(not running and self.batch.can_skip and self.grade_combo.currentData()==self.batch.grade
                   and not self.scope_request and not self.single_pending)
        self.skip_student_button.setVisible(available)
        self.continue_student_button.setVisible(bool(available and self.batch.resume_detail))
        self.continue_student_button.setEnabled(available and self.batch.index in self.checked_indices())

    def resume_batch(self,*,same_student):
        if self.scope_request or self.single_pending or self.grade_combo.currentData()!=self.batch.grade:return
        index=self.batch.index
        if not self.batch.resume(same_student=same_student,selected=self.checked_indices()):return
        if self.batch.index!=index:
            note='تمت المتابعة بعد مراجعة القسم يدوياً.' if same_student else 'تم تخطّي التلميذ بطلب المستخدم.'
            self.row_result(index,self.table.item(index,self.result_column).text()+'\n'+note)
        self.set_running(self.batch.active)
        if self.batch.active:self.dispatch_next()
        else:self.status.setText(self.batch_summary()+' انتهت الدفعة.')

    def batch_summary(self):
        skipped=sum(self.batch.eligible(i) for i in self.batch.skipped_for_run())
        return f'اكتمل {self.batch.done}/{self.batch.total}. للمراجعة أو تم تخطّيهم: {skipped}.'

    def row_result(self,index,text):
        item=QTableWidgetItem(text);item.setToolTip(text)
        item.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter|Qt.AlignAbsolute)
        self.table.setItem(index,self.result_column,item)

    def dispatch_next(self):
        if not self.batch.active:return
        request=self.batch.request()
        if request is None:return
        row,mode,request_id=request
        self.table.setCurrentCell(self.batch.index,0)
        self.row_result(self.batch.index,'جارٍ الاستيراد والحفظ…')
        action='مع الإرسال للمراجعة' if mode=='details_import_review' else 'بدون إرسال للمراجعة'
        scope=self.batch.grade or 'كل الصفوف'
        self.status.setText(f'جارٍ استيراد الطالب {self.batch.position}/{self.batch.total} — {scope} — صف Excel {row["excel_row"]} — {action}…')
        if not self.controller.fill_details(row,mode,request_id):
            self.result(request_id,'detail_account','')

    def stop_batch(self):
        self.batch.stop_after_current();self.stop_button.setEnabled(False)
        self.status.setText('سيكتمل الطالب الحالي حسب الخيار المختار ثم تتوقف العملية.')
        if not self.batch.pending:
            self.set_running(False);self.status.setText(f'توقفت العملية حسب طلبك. اكتمل {self.batch.done}/{self.batch.total}.')

    def receive_diagnostic(self,request,detail):
        pending=self.single_pending[0] if self.single_pending else self.batch.pending
        if request!=pending:return
        from identity_dates import clean_birth_detail
        cleaned=clean_birth_detail(detail)
        if cleaned or isinstance(detail,dict):self.birth_diagnostics[request]=cleaned or detail

    def result(self,request,event,field):
        if self.scope_request and request==self.scope_request[0]:
            grade=self.scope_request[1];self.scope_request=None
            self.set_running(False)
            if event=='detail_grade_ready':
                self.status.setText(f'تم تحديد {grade or "كل الصفوف"} على الموقع. مؤشّر عليهم للاسترداد: {len(self.checked_indices())}. اختر إجراء الاستيراد.')
            else:self.status.setText(self.result_text(event,field))
            return
        if self.single_pending and request==self.single_pending[0]:
            index=self.single_pending[1];self.single_pending=None
            self.set_running(False)
            text=self.result_text(event,field,self.birth_diagnostics.pop(request,{}))
            if event=='detail_no_data':text='القسم المحدد فارغ في Excel؛ لم تُضف بيانات ولم يُحفظ.'
            self.row_result(index,text);self.status.setText(text)
            return
        index=self.batch.index
        detail=self.birth_diagnostics.pop(request,{})
        if not self.batch.result(request,event,field,detail):return
        text=self.result_text(event,field,detail)
        if index in self.batch.skipped_for_run():
            text='انتهت متابعة الأقسام الباقية. راجع القسم اللي توقّف عليه الاستيراد في SIMS.'
        self.row_result(index,text)
        if self.batch.active:
            QTimer.singleShot(0,self.dispatch_next)
        else:
            self.set_running(False)
            prefix=self.batch_summary()+' '
            if self.batch.stopping:prefix+='توقفت العملية حسب طلبك. '
            if self.batch.can_skip:
                text+=' اضغط «تخطّي التلميذ ومتابعة» لتكمل الدفعة.'
                if self.batch.resume_detail:
                    section=DETAIL_SECTION_LABELS[self.batch.resume_detail['stopped_section']]
                    text+=f' راجع «{section}» واحفظه في SIMS، ثم اضغط «كمّل نفس التلميذ».'
            self.status.setText(prefix+text)

    def result_text(self,event,field,detail=None):
        text={
            'detail_birth_mismatch':'وُجد الاسم، لكن تاريخ الولادة مختلف. توقفت العملية قبل إدخال البيانات.',
            'detail_grade_trigger':'تعذّر تثبيت الصف في فلتر الموقع أو قراءة قيمته. راجع قائمة الصفوف ثم أعد الاختيار.',
            'detail_grade_options':'تعذّر العثور على الصف المطلوب أو استقرار قائمة الصفوف على الموقع. أعد اختياره.',
            'detail_grade_rows':'تعذّر التحقق من جدول الطلاب للصف المختار أو صفحات نتائجه. انتظر تحميل الموقع ثم أعد اختيار الصف.',
            'detail_roster_unstable':'جدول الطلاب أو عدد صفحاته ما استقرّ بعد محاولتين. لم يُفتح سجل الطالب ولم يبدأ الحفظ.',
            'detail_roster_columns':'تعذّر التعرّف على أعمدة جدول إدارة الطلاب. لم يُفتح سجل للتعديل.',
            'detail_roster_pagination':'تعذّر قراءة عدّاد صفحات جدول إدارة الطلاب. لم يُفتح سجل للتعديل.',
            'detail_grade_filters':'يوجد بحث أو فلتر إضافي على الموقع. امسح البحث وأعد باقي المرشحات إلى الجميع ثم اختر الصف مجدداً.',
            'detail_import_saved':'تم استيراد الداتا المفصّلة وحفظها بدون إرسال للمراجعة.',
            'detail_import_review_sent':'تم استيراد الداتا المفصّلة وحفظها وإرسال الطالب للمراجعة.',
            'detail_import_review_already':'حُفظت الداتا المفصّلة؛ الطالب مقدّم للمراجعة مسبقاً.',

            'detail_save_blocked':'زر الحفظ ما زال معطلاً. راجع الحقول المطلوبة في القسم؛ لم يُضغط الحفظ.',
            'detail_address_save_button':'تعبّأ العنوان، لكن تعذّر العثور على زر حفظ واحد في قسم عناوين السكن. لم يُضغط الحفظ.',
            'detail_address_confirm':'تم الضغط على حفظ العنوان، لكن نافذة التأكيد لم تطابق النموذج المتوقع. راجعها قبل إعادة المحاولة.',
            'detail_no_data':'لا توجد بيانات تفصيلية قابلة للاستيراد في هذا الصف؛ لم يُرسل الطالب للمراجعة.',
            'detail_review_sent':'تم الإرسال للمراجعة، وتأكد ظهور «مقدّم للمراجعة» في الموقع.',
            'detail_review_already':'الطالب مقدّم للمراجعة بالفعل؛ لم يُرسل مرة ثانية.',
            'detail_card_input':'اختر نوع المستند من أعمدة بطاقة التعريف في Excel، وأكمل رقم الوثيقة (أو رقم السجل السابق). تاريخ الانتهاء اختياري ويجب أن يكون تاريخاً صالحاً عند إدخاله.',
            'detail_card_disabled':'زر حفظ بطاقة التعريف ما زال معطلاً في الموقع. راجع الحقول أو رسالة التحقق الظاهرة؛ لم يتم الضغط على الحفظ.',
            'detail_filled':'فُتح سجل التلميذ وتعبّأ القسم. راجع البيانات ثم استخدم «حفظ القسم» في الموقع.',
            'detail_saved':'حُفظ القسم المحدد بنجاح.',
            'detail_all_saved':'حُفظت الأقسام المتاحة من ملف Excel بالتتابع بنجاح.',
            'detail_all_partial':'اكتملت الأقسام التي أمكن تعبئتها. بعض الأقسام موجودة سلفاً أو ناقصة في Excel وتُخطّيت دون استبدالها. راجع عمود شهرة الأم ونتيجة الموقع.',
            'detail_mother_missing':'شهرة الأم فارغة في صف Excel المحدد. عبّئ عمود «شهرة الأم (للمفصّل)» واحفظ الملف ثم أعد استيراده.',
            'detail_mother_field':'شهرة الأم وصلت من Excel، لكن لم أستطع تحديد خانة الشهرة وحدها داخل «الأقارب #2» الخاصة بالأم. ابعث HTML لهذا القسم مع عنوانه والخانة لضبطه.',
            'detail_save_unknown':'تم الضغط على حفظ القسم، لكن لم يصل تأكيد نجاح. راجع القسم المفتوح وما سبقه قبل إعادة المحاولة.',
            'detail_identity':'افتح التلميذ الصحيح على المعلومات الشخصية. الاسم واسم الأب والشهرة وتاريخ الولادة، والرقم الموحد إن وجد، يجب أن تطابق Excel.',
            'detail_not_found':'لم يُعثر على الاسم الكامل ضمن نطاق الصف المختار. لم تُدخل بيانات ولم يُوسّع البحث إلى باقي المدرسة.',
            'detail_ambiguous':'وُجد أكثر من سجل مطابق للاسم وتاريخ الولادة. راجع التلميذ يدوياً؛ لم يُدخل عنوان.',
            'detail_management':'تعذّرت قراءة قائمة الطلاب ضمن النطاق المختار. راجع خيار الصف وامسح البحث وأعد باقي المرشحات إلى «الجميع»، ثم أعد المحاولة.',
            'detail_existing':'توجد بيانات مختلفة في الموقع أو أكثر من سجل. توقّف الاستيراد عند الطالب؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_open_required':'افتح صفحة تعديل التلميذ على تبويب المعلومات الشخصية في SIMS، ثم اضغط «استرداد من سجل التلميذ المفتوح».',
            'detail_import_skipped_section':'تخطّى التطبيق تلقائياً الأقسام اللي فيها بيانات متعارضة وحفظ باقي الأقسام المتاحة. لم يُرسل الطالب للمراجعة.',
            'detail_options':'تعذّرت مطابقة خانة أو خيار أو مربع التأكيد بشكل وحيد. قد تكون بعض الخانات تعبّأت؛ راجع القسم المفتوح قبل المتابعة.',
            'detail_input':'أكمل بيانات القسم المختار في Excel: العنوان أو الهاتف أو شهرة الأم، ثم احفظ الملف وأعد استرداده.',
            'detail_school_not_found':'ما ظهر خيار مدرسة مطابق تماماً لرقم ECRD. ما اختار التطبيق أي مدرسة.',
            'detail_school_unconfirmed':'انضغط خيار المدرسة المطابق، لكن التطبيق ما قدر يتأكّد من الاسم المختار. ما ضغط حفظ.',
            'detail_document_image':'تعذّر إرفاق المستند في SIMS. راجع الملف وخانة رفع المرفق في بطاقة المستند.',
            'detail_account':'تغيّرت الصفحة أو جلسة الحساب. توقفت التعبئة.',
            'detail_busy':'توجد عملية أخرى قيد التنفيذ. انتظر انتهاءها.',
            'detail_failed':'توقفت التعبئة. راجع القسم المفتوح؛ قد توجد مسودة غير محفوظة.'
        }.get(event,'توقفت العملية. راجع القسم المفتوح.')
        from manual_sections import HEADERS
        from student_excel import ADDRESS_HEADERS
        from previous_academic import HEADERS as ACADEMIC_HEADERS
        if field in HEADERS or field in ADDRESS_HEADERS or field in (UID_LABEL,*ACADEMIC_HEADERS):text+='\nالخانة: '+field
        if event=='detail_birth_mismatch':
            from identity_dates import clean_birth_detail
            checked=clean_birth_detail(detail)
            if checked:
                from datetime import date
                text+='\nتاريخ Excel: '+date.fromisoformat(checked['expected_birth']).strftime('%Y/%m/%d')
                text+=' — تاريخ الموقع: '+date.fromisoformat(checked['observed_birth']).strftime('%Y/%m/%d')
        return text

    def session(self,event):
        if event in ('disconnected','cancelled','browser_closed','failed','timeout'):
            self.birth_diagnostics.clear()
            self.scope_request=None;self.single_pending=None;self.batch.disconnect();self.set_running(False)
            for button in self.buttons:button.setEnabled(False)
            self.status.setText('انتهت جلسة المتصفح. أغلق النافذة وأعد تسجيل الدخول.')

    def detach(self,*args):
        self.controller.student_result.disconnect(self.result);self.controller.event.disconnect(self.session)
        if hasattr(self.controller,'detail_diagnostic'):self.controller.detail_diagnostic.disconnect(self.receive_diagnostic)
        self.birth_diagnostics.clear()
        self.rows=[];self.batch.rows=[];self.table.clearContents()

    def reject(self):
        if self.scope_request or self.single_pending or self.batch.active or self.batch.pending:return
        super().reject()
