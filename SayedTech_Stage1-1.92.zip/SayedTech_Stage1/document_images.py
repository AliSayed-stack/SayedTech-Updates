"""Read files embedded in the Excel document attachment column."""
from io import BytesIO
import posixpath
from struct import error as StructError, unpack_from
from pathlib import Path
from uuid import uuid4
import xml.etree.ElementTree as ET

from student_excel import ExcelInputError, NS, REL
from student_workflow import column

IMAGE_HEADER = 'المستندات / صورة المستند'
IMAGE_KEY = 'document_image'
MAX_IMAGE_BYTES = 10_000_000
DRAWING_NS = {
    'xdr': 'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
}
REL_NS = REL.split('}')[0] + '}'


def related_part(z, part, reference, kind, directory):
    folder, name = posixpath.split(part)
    rels = ET.fromstring(z.read(posixpath.join(folder, '_rels', name + '.rels')))
    matches = [r for r in rels if r.get('Id') == reference and reference]
    if len(matches) == 1:
        rel = matches[0]
        target = rel.get('Target', '')
        if rel.get('TargetMode', 'Internal') == 'Internal' and rel.get('Type') == REL_NS[1:-1] + '/' + kind:
            resolved = posixpath.normpath(target.lstrip('/') if target.startswith('/') else posixpath.join(folder, target))
            if posixpath.dirname(resolved) == directory and '\\' not in resolved and resolved in z.namelist():
                return resolved
    raise ExcelInputError('تعذّر قراءة مرفق مضمن في ملف Excel.')


def image_type(data):
    if data.startswith(b'\x89PNG\r\n\x1a\n'):
        return '.png', 'image/png'
    if data.startswith(b'\xff\xd8\xff'):
        return '.jpg', 'image/jpeg'
    raise ValueError('image format')


def attachment_extension(data):
    return '.pdf' if data.startswith(b'%PDF-') else image_type(data)[0]


def embedded_pdf(data):
    """Extract PDF bytes without opening or activating the Excel object."""
    if not data.startswith(b'%PDF-'):
        from olefile import OleFileIO
        with OleFileIO(BytesIO(data)) as ole:
            if ole.exists('CONTENTS'):
                data = ole.openstream('CONTENTS').read()
            else:
                native = ole.openstream('\x01Ole10Native').read()
                offset = native.index(b'\0', 6) + 1  # Filename
                offset = native.index(b'\0', offset) + 1  # Source path
                offset = native.index(b'\0', offset + 8) + 1  # Temporary path
                size, = unpack_from('<I', native, offset)
                data = native[offset + 4:offset + 4 + size]
                if len(data) != size:
                    raise ValueError('incomplete embedded file')
    if len(data) > MAX_IMAGE_BYTES or not data.startswith(b'%PDF-'):
        raise ValueError('expected PDF')
    return data


def anchor_row(start, image_column, selected_rows):
    if start is None:
        return None
    for namespace in (DRAWING_NS['xdr'], NS['m']):
        x = start.findtext(f'{{{namespace}}}col')
        y = start.findtext(f'{{{namespace}}}row')
        if x is None or y is None:
            continue
        index, row = int(x), int(y) + 1
        if not 0 <= index < 16384:
            raise ExcelInputError('موضع مرفق غير صالح في ملف Excel.')
        if column(index + 1) == image_column and row in selected_rows:
            return row
        return None
    return None


def read_document_images(z, image_column, selected_rows, directory):
    book = ET.fromstring(z.read('xl/workbook.xml'))
    sheet = next(s for s in book.findall('m:sheets/m:sheet', NS) if s.get('name') == 'الطلاب')
    part = related_part(z, 'xl/workbook.xml', sheet.get(REL), 'worksheet', 'xl/worksheets')
    sheet_xml = ET.fromstring(z.read(part))
    pictures = {}
    extracted = {}

    def save_attachment(row, media, *, pdf=False):
        if row in pictures:
            raise ExcelInputError(f'الصف {row} فيه أكثر من مرفق. ضع مرفقاً واحداً لكل مستند.')
        if directory is None:
            raise ExcelInputError('افتح الملف من زر استرداد أعمدة الأقسام اليدوية.')
        if media not in extracted:
            if z.getinfo(media).file_size > MAX_IMAGE_BYTES + (1_000_000 if pdf else 0):
                raise ExcelInputError(f'الصف {row}: الحد الأقصى للمرفق 10 ميغابايت.')
            data = z.read(media)
            try:
                if pdf:
                    data = embedded_pdf(data)
                suffix = '.pdf' if pdf else image_type(data)[0]
            except (OSError, ValueError, IndexError, StructError):
                message = 'أدرج ملف PDF مضمناً من دون ربطه بالملف الأصلي.' if pdf else 'استعمل صورة JPG أو PNG.'
                raise ExcelInputError(f'الصف {row}: {message}') from None
            path = Path(directory) / (uuid4().hex + suffix)
            path.write_bytes(data)
            extracted[media] = str(path)
        pictures[row] = extracted[media]

    selected_cells = {f'{image_column}{row}' for row in selected_rows}
    for cell in sheet_xml.findall('m:sheetData/m:row/m:c', NS):
        if cell.get('r') in selected_cells and (cell.get('vm') or cell.find('m:f', NS) is not None):
            raise ExcelInputError('أدرج صورة المستند باستخدام «وضع فوق الخلايا» في Excel.')
    for drawing in sheet_xml.findall('m:drawing', NS):
        drawing_part = related_part(z, part, drawing.get(REL), 'drawing', 'xl/drawings')
        for anchor in ET.fromstring(z.read(drawing_part)):
            picture = anchor.find('xdr:pic', DRAWING_NS)
            if picture is None:
                continue
            row = anchor_row(anchor.find('xdr:from', DRAWING_NS), image_column, selected_rows)
            if row is None:
                continue
            blip = picture.find('xdr:blipFill/a:blip', DRAWING_NS)
            media = related_part(z, drawing_part, blip.get(REL_NS + 'embed') if blip is not None else None,
                                 'image', 'xl/media')
            save_attachment(row, media)
    for obj in sheet_xml.findall('.//m:oleObject', NS):
        start = obj.find('m:objectPr/m:anchor/m:from', NS)
        row = anchor_row(start, image_column, selected_rows)
        if row is not None:
            media = related_part(z, part, obj.get(REL), 'oleObject', 'xl/embeddings')
            save_attachment(row, media, pdf=True)
    return pictures
