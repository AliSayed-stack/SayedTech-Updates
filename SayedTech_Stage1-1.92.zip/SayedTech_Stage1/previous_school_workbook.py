"""Set the previous-school default in a separate copy of a student workbook."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

from document_images import related_part
from previous_academic import HEADERS as ACADEMIC_HEADERS, DROPDOWNS, CURRENT_GRADE_LABEL, workbook_defaults, should_apply_default
from registration_workbook import _write
from student_excel import ADDRESS_STATUS_HEADER, BY_ID, NS, REL, ExcelInputError
from student_excel import is_third_kindergarten
from student_unified import ENTRY_KIND, _insert_translations
from student_workflow import column, workbook_rows


def column_index(letter):
    number=0
    for character in letter:
        number=number*26+ord(character)-64
    return number


def extend_range(xml,tag,old,new):
    pattern=rb'(<(?:[\w.-]+:)?'+tag+rb'\b[^>]*?\bref=["\'][A-Z]+\d+:)'+old.encode()+rb'(\d+["\'])'
    return re.sub(pattern,lambda match:match[1]+new.encode()+match[2],xml,count=1)


def extend_table(xml,letter,header):
    table=ET.fromstring(xml)
    old=column(column_index(letter)-1)
    expected=re.fullmatch(r'[A-Z]+\d+:'+old+r'\d+',table.get('ref',''))
    if not expected:
        raise ExcelInputError('تعذّر توسيع جدول الطلاب؛ فتحفظ النسخة الأصلية كما هي.')
    pattern=rb'(<(?P<tag>(?:[\w.-]+:)?tableColumns)\b[^>]*>)(.*?)(</(?P=tag)\s*>)'
    def add(match):
        cols=table.find('m:tableColumns',NS)
        next_id=max(int(cell.get('id')) for cell in cols)+1
        tag=match['tag'][:-len(b'tableColumns')]+b'tableColumn'
        start=re.sub(rb'\bcount=["\']\d+["\']',f'count="{len(cols)+1}"'.encode(),match[1],count=1)
        added=f' id="{next_id}" name="{header}"/>'.encode()
        return start+match[3]+b'<'+tag+added+match[4]
    xml,count=re.subn(pattern,add,xml,count=1,flags=re.DOTALL)
    if count!=1:raise ExcelInputError('تعذّر توسيع أعمدة جدول الطلاب.')
    return extend_range(extend_range(xml,b'table',old,letter),b'autoFilter',old,letter)


def add_type_dropdown(xml,letter,last,options):
    sheet=ET.fromstring(xml)
    choices='"'+','.join(options.values())+'"'
    for validation in sheet.findall('m:dataValidations/m:dataValidation',NS):
        if (validation.get('type')=='list' and validation.findtext('m:formula1',namespaces=NS)==choices
                and any((match:=re.fullmatch(letter+r'2:'+letter+r'(\d+)',ref)) and int(match[1])>=last
                        for ref in validation.get('sqref','').split())):
            return xml
    prefix=re.search(rb'<(?P<ns>(?:[\w.-]+:)?)worksheet\b',xml)['ns']
    tag=lambda name:prefix+name
    node=(b'<'+tag(b'dataValidation')+f' type="list" allowBlank="1" showErrorMessage="1" sqref="{letter}2:{letter}{last}">'.encode()
          +b'<'+tag(b'formula1')+b'>'+choices.encode()+b'</'+tag(b'formula1')+b'></'+tag(b'dataValidation')+b'>')
    group=tag(b'dataValidations')
    pattern=rb'(<'+group+rb'\b[^>]*>)(.*?)(</'+group+rb'\s*>)'
    current=sheet.find('m:dataValidations',NS)
    if current is not None:
        def add(match):
            node_pattern=rb'<'+tag(b'dataValidation')+rb'\b(?P<attrs>[^>]*?)(?:/\s*>|>.*?</'+tag(b'dataValidation')+rb'\s*>)'
            removed=0
            def old_rule(rule):
                nonlocal removed
                sqref=re.search(rb'\bsqref=["\']([^"\']+)["\']',rule['attrs'])
                refs=sqref[1].decode().split() if sqref else []
                if refs and all(re.fullmatch(letter+r'\d+(?::'+letter+r'\d+)?',ref) for ref in refs):
                    removed+=1
                    return b''
                return rule[0]
            body=re.sub(node_pattern,old_rule,match[2],flags=re.DOTALL)
            start=re.sub(rb'\s+count=["\']\d+["\']',b'',match[1][:-1])
            return start+f' count="{len(current)+1-removed}">'.encode()+body+node+match[3]
        xml,count=re.subn(pattern,add,xml,count=1,flags=re.DOTALL)
        if count!=1:raise ExcelInputError('تعذّر إضافة قائمة نوع المدرسة في Excel.')
        return xml
    next_node=re.search(rb'</'+tag(b'worksheet')+rb'\s*>|<'+prefix+rb'(?:hyperlinks|printOptions|pageMargins|pageSetup|headerFooter|rowBreaks|colBreaks|customProperties|cellWatches|ignoredErrors|smartTags|drawing|legacyDrawing|legacyDrawingHF|picture|oleObjects|controls|webPublishItems|tableParts|extLst)\b',xml)
    if next_node is None:raise ExcelInputError('تعذّر تحديد مكان قائمة Excel.')
    position=next_node.start()
    return xml[:position]+b'<'+group+b' count="1">'+node+b'</'+group+b'>'+xml[position:]


def add_previous_school_type(source,destination):
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.suffix.lower()!='.xlsx':
        raise ExcelInputError('احفظ النتيجة باسم مختلف عن ملف Excel الأصلي.')
    try:
        if source.stat().st_size>64_000_000:raise ExcelInputError('ملف Excel كبير جداً.')
        with ZipFile(source) as book:
            if len(book.infolist())>1000 or sum(item.file_size for item in book.infolist())>128_000_000:
                raise ExcelInputError('ملف Excel كبير جداً.')
            rows=workbook_rows(book,'الطلاب',ignore_headers=(ADDRESS_STATUS_HEADER,))
            if not rows or rows[0][0]!=1 or rows[0][2]:
                raise ExcelInputError('عناوين ورقة الطلاب غير صالحة.')
            headers=rows[0][1]
            labels={label:letter for letter,label in headers.items() if label}
            required=[BY_ID[key]['label'] for key in ('field-firstName','field-middleName','field-lastName')]
            if len(labels)!=sum(bool(value) for value in headers.values()) or any(label not in labels for label in required):
                raise ExcelInputError('اختر ملف الطلاب المسحوب أو المدموج من SayedTech.')
            old=column(max(map(column_index,labels.values())))
            new_columns={}
            for label in ACADEMIC_HEADERS:
                if label not in labels:
                    new_columns[label]=column(column_index(old)+len(new_columns)+1)
            labels.update(new_columns)
            from registration_workbook import canonical_kind, EXISTING
            from student_scan import REPORT_SHEET, is_deleted
            workbook=ET.fromstring(book.read('xl/workbook.xml'))
            sheets={x.get('name'):x for x in workbook.findall('m:sheets/m:sheet',NS)}
            excluded=set()
            if REPORT_SHEET in sheets:
                report=workbook_rows(book,REPORT_SHEET,max_row=5020)
                report_columns={value:col for col,value in report[0][1].items()}
                for _,values,_ in report[1:]:
                    number=str(values.get(report_columns['صف Excel'],'')).removesuffix('.0')
                    if not number.isdecimal():continue
                    state=str(values.get(report_columns['حالة الفحص'],''))
                    status=values.get(report_columns['الحالة في النظام'],'')
                    if is_deleted({'status':status}) or state.startswith(('محذوف','نفس السجل المفتوح سابقاً')):
                        excluded.add(int(number))
            uid_column=labels.get(BY_ID['field-existingUniqueId']['label'])
            changes={}
            eligible=0
            for number,values,_ in rows[1:]:
                if number in excluded:continue
                if not values.get(uid_column) and not all(str(values.get(labels[label],'') or '').strip() for label in (required[0],required[-1])):
                    continue
                kind=values.get(labels.get(ENTRY_KIND),'')
                row={label:values.get(letter,'') for label,letter in labels.items()}
                if not is_third_kindergarten(row.get(CURRENT_GRADE_LABEL,'')) and kind and canonical_kind(kind)!=EXISTING:continue
                eligible+=1
                for label,value in workbook_defaults(row).items():
                    if value in ('',None):continue
                    letter=labels[label]
                    if should_apply_default(row,label):
                        changes[number,letter]=str(value)
            if not eligible:raise ExcelInputError('ما في صفوف طلاب مؤهّلة لتعبئة النوع.')
            count=len({number for number,_ in changes})
            for label,letter in new_columns.items():
                changes[1,letter]=label
            sheet=sheets['الطلاب']
            part=related_part(book,'xl/workbook.xml',sheet.get(REL),'worksheet','xl/worksheets')
            parts={name:book.read(name) for name in book.namelist()}
            if new_columns:
                for node in ET.fromstring(parts[part]).findall('m:tableParts/m:tablePart',NS):
                    table=related_part(book,part,node.get(REL),'table','xl/tables')
                    for label,letter in new_columns.items():
                        parts[table]=extend_table(parts[table],letter,label)
                end=next(reversed(new_columns.values()))
                parts[part]=extend_range(extend_range(parts[part],b'dimension',old,end),b'autoFilter',old,end)
            parts[part]=_insert_translations(parts[part],changes)
            last=max(501,max(number for number,_,_ in rows))
            for label,options in DROPDOWNS.items():
                parts[part]=add_type_dropdown(parts[part],labels[label],last,options)
            ET.fromstring(parts[part])
        _write(parts,destination)
        return count
    except ExcelInputError:
        raise
    except (OSError,ValueError,KeyError,IndexError,TypeError,AttributeError,StopIteration,ET.ParseError,BadZipFile):
        raise ExcelInputError('تعذّر تجهيز نسخة Excel. اختر ملف طلاب صالحاً ومجلداً قابلاً للكتابة.') from None
