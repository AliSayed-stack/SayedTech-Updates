import threading
import unittest
from unittest.mock import patch
from detailed_batch import DetailedImportBatch
from detailed_import import DetailError,fill_details
from test_detailed_import import Page,Element


class BatchQueueTests(unittest.TestCase):
    def test_resume_same_pupil_uses_only_remaining_sections_without_review(self):
        batch=DetailedImportBatch([{'excel_row':2},{'excel_row':4},{'excel_row':8}])
        batch.start(True,selected=[0,2])
        _,_,request=batch.request()
        batch.result(request,'detail_options',detail={
            'stopped_section':'previous_school_type','remaining_sections':['phone']})
        self.assertTrue(batch.resume(same_student=True,selected=[0,1,2]))
        row,mode,request=batch.request()
        self.assertEqual((row['excel_row'],row['selected_detail_sections'],mode),(2,['phone'],'details_import'))
        batch.result(request,'detail_import_saved')
        row,mode,request=batch.request()
        self.assertEqual((row['excel_row'],mode),(8,'details_import_review'))
        self.assertEqual(batch.done,0)
        self.assertEqual(batch.skipped_for_run(),{0})

    def test_skip_retains_failure_and_never_skips_session_errors(self):
        batch=DetailedImportBatch([{'excel_row':2},{'excel_row':8}]);batch.start(False)
        batch.result(batch.request()[2],'detail_save_unknown')
        self.assertFalse(batch.resume(same_student=True,selected=[0,1]))
        self.assertTrue(batch.resume(same_student=False,selected=[0,1]))
        self.assertEqual(batch.request()[0]['excel_row'],8)
        batch.result(batch.pending,'detail_account')
        self.assertFalse(batch.resume(same_student=False,selected=[0,1]))
        self.assertEqual(batch.done,0)

    def test_section_scope_applies_to_selected_students_and_keeps_completion_separate(self):
        batch=DetailedImportBatch([{'excel_row':2},{'excel_row':3},{'excel_row':4}])
        batch.start(False,selected=[0,2],sections=['address'])
        row,_,request=batch.request()
        self.assertEqual((row['excel_row'],row['selected_detail_sections']),(2,['address']))
        batch.result(request,'detail_no_data')
        row,_,request=batch.request()
        self.assertEqual(row['excel_row'],4)
        batch.result(request,'detail_import_saved')
        self.assertFalse(batch.active)
        batch.start(False,selected=[0,2],sections=['personal'])
        self.assertEqual(batch.request()[0]['excel_row'],2)

    def test_checkbox_snapshot_skips_unchecked_rows_in_both_modes_and_counts_only_selection(self):
        for review,event in ((False,'detail_import_saved'),(True,'detail_import_review_sent')):
            batch=DetailedImportBatch([1,2,3,4]);selected=[1,3]
            batch.start(review,selected=selected)
            selected.append(0) # Changing the caller's list cannot add a pupil mid-run.
            self.assertEqual((batch.total,batch.position),(2,1))
            first,_,request=batch.request();self.assertEqual(first,2)
            batch.result(request,event)
            second,_,request=batch.request();self.assertEqual(second,4)
            self.assertEqual(batch.position,2)
            batch.result(request,event)
            self.assertFalse(batch.active);self.assertEqual(batch.done,2)
            batch.start(review,selected=[0,1,3])
            self.assertEqual((batch.done,batch.total),(2,3))
            self.assertEqual(batch.request()[0],1)

    def test_empty_checkbox_selection_does_not_dispatch(self):
        batch=DetailedImportBatch([1,2]);batch.start(False,selected=[])
        self.assertIsNone(batch.request());self.assertEqual(batch.total,0)

    def test_serial_rows_and_review_mode_are_explicit(self):
        for review,event in ((False,'detail_import_saved'),(True,'detail_import_review_sent')):
            batch=DetailedImportBatch([{'excel_row':2},{'excel_row':8}])
            self.assertTrue(batch.start(review))
            row,mode,request=batch.request()
            self.assertEqual(row['excel_row'],2)
            self.assertEqual(mode,'details_import_review' if review else 'details_import')
            self.assertIsNone(batch.request())
            self.assertFalse(batch.start(not review))
            self.assertFalse(batch.result('stale',event))
            self.assertEqual(batch.index,0)
            self.assertTrue(batch.result(request,event))
            row,mode,next_request=batch.request()
            self.assertEqual(row['excel_row'],8)
            self.assertNotEqual(request,next_request)
            batch.result(next_request,event)
            self.assertFalse(batch.active);self.assertEqual(batch.done,2)

    def test_failure_stops_next_pupil_and_retry_skips_successful_rows(self):
        batch=DetailedImportBatch([1,2,3]);batch.start(True)
        batch.result(batch.request()[2],'detail_import_review_sent')
        failed=batch.request()[2]
        batch.result(failed,'detail_options','الهواتف / رقم الهاتف')
        self.assertFalse(batch.active);self.assertIsNone(batch.request())
        self.assertEqual(batch.field,'الهواتف / رقم الهاتف');self.assertEqual(batch.done,1)
        batch.start(True)
        self.assertEqual(batch.request()[0],2)

    def test_stop_waits_for_current_pupil_and_can_resume(self):
        batch=DetailedImportBatch([1,2]);batch.start(False)
        request=batch.request()[2];batch.stop_after_current()
        self.assertTrue(batch.active)
        batch.result(request,'detail_import_saved')
        self.assertFalse(batch.active);self.assertEqual(batch.done,1)
        batch.start(False);self.assertEqual(batch.request()[0],2)

    def test_stop_between_rows_and_disconnection_ignore_late_results(self):
        batch=DetailedImportBatch([1,2]);batch.start(False)
        batch.result(batch.request()[2],'detail_import_saved');batch.stop_after_current()
        self.assertIsNone(batch.request())
        batch.start(False);request=batch.request()[2];batch.disconnect()
        self.assertFalse(batch.result(request,'detail_import_saved'))
        self.assertEqual(batch.done,1)

    def test_switching_to_review_still_processes_rows_saved_without_review(self):
        batch=DetailedImportBatch([1]);batch.start(False)
        batch.result(batch.request()[2],'detail_import_saved')
        batch.start(True);self.assertEqual(batch.request()[0],1)
        batch.result(batch.pending,'detail_import_review_already')
        batch.start(False);self.assertIsNone(batch.request())
        self.assertFalse(batch.active)


class DetailedWorkflowTests(unittest.TestCase):
    def row(self,page):
        return {'values':page.values.copy(),'address':{},'manual':{
            'الهواتف / رقم الهاتف':'03123456',
            'البريد الإلكتروني / البريد الإلكتروني':'test@example.test',
            'شهرة الأم':'شهرة اختبار',
            'بطاقات التعريف / نوع المستند':'هوية',
            'المستندات / نوع المستند':'بطاقة هوية',
            'حالة التسجيل / الحالة الحالية':'قيد الانتظار',
            'حالة التسجيل / ملاحظة (اختياري)':'ملاحظة اختبار'}}

    def invoke(self,page,row,review=False,cancelled=None,username='school@te.mehe.school'):
        with patch('detailed_import.time.monotonic',side_effect=lambda:page.clock):
            return fill_details(page,row,'details_import_review' if review else 'details_import',username,cancelled or threading.Event())

    def test_all_manual_sections_save_before_review_for_both_shifts(self):
        for username in ('school@te.mehe.school','school@te.pm.mehe.school'):
            for review in (False,True):
                page=Page();row=self.row(page);row['address']=dict(page.choices)
                navigate=page.goto
                def restore_personal(url,**kwargs):
                    navigate(url,**kwargs);page.values.update(row['values'])
                page.goto=restore_personal
                actions=[]
                def entered(page,row,title,guard):
                    guard();actions.append(('fill',title))
                    # Personal controls unmount after leaving the personal tab;
                    # the next fresh visit must restore and verify them.
                    page.values.pop('field-firstName',None)
                    return 'detail_filled'
                def saved(page,title,guard):guard();actions.append(('save',title));return 'detail_saved'
                def sent(page,row,guard):guard();actions.append(('review',''));return 'detail_review_sent'
                with patch('manual_sections.fill_manual_section',side_effect=entered),patch('manual_save.save_manual',side_effect=saved),patch('manual_save.send_review',side_effect=sent) as send:
                    self.assertEqual(self.invoke(page,row,review,username=username),'detail_import_review_sent' if review else 'detail_import_saved')
                expected=['الهواتف','البريد الإلكتروني','بطاقات التعريف','المستندات']
                self.assertEqual([title for action,title in actions if action=='fill'],expected)
                self.assertEqual(actions[:8],[(action,title) for title in expected for action in ('fill','save')])
                self.assertEqual(send.call_count,int(review))
                if review:self.assertEqual(actions[-1],('review',''))
                self.assertIn(('click','حفظ القسم'),page.actions)
                self.assertEqual(sum(action=='goto' for action,_ in page.actions),5+int(review))

    def test_failed_or_unconfirmed_save_prevents_later_sections_and_review(self):
        for outcome in ('error','unknown'):
            page=Page();row=self.row(page);saved=[]
            def save(page,title,guard):
                saved.append(title)
                if title=='البريد الإلكتروني':
                    if outcome=='error':raise DetailError('detail_save_blocked')
                    return 'detail_save_unknown'
                return 'detail_saved'
            with patch('manual_sections.fill_manual_section',return_value='detail_filled'),patch('manual_save.save_manual',side_effect=save),patch('manual_save.send_review') as send:
                with self.assertRaises(DetailError) as error:self.invoke(page,row,True)
                send.assert_not_called()
            if outcome=='error':
                self.assertEqual(error.exception.detail,{
                    'stopped_section':'manual_save:البريد الإلكتروني',
                    'remaining_sections':['manual_save:بطاقات التعريف','manual_save:المستندات']})
            else:self.assertIsNone(error.exception.detail)
            self.assertEqual(saved,['الهواتف','البريد الإلكتروني'])

    def test_empty_and_display_only_record_never_adds_saves_or_sends(self):
        page=Page();row=self.row(page);row['manual']={'حالة التسجيل / الحالة الحالية':'قيد الانتظار'}
        with patch('manual_sections.fill_manual_section') as fill,patch('manual_save.send_review') as send:
            self.assertEqual(self.invoke(page,row,True),'detail_no_data')
            fill.assert_not_called();send.assert_not_called()
        self.assertEqual(page.actions,[])

    def test_wrong_identity_fails_before_any_write(self):
        page=Page();row=self.row(page);row['values']['field-birthDate']='2014-01-02'
        with patch('manual_sections.fill_manual_section') as fill,patch('manual_save.send_review') as send,self.assertRaises(DetailError) as error:
            self.invoke(page,row,True)
        self.assertEqual(error.exception.code,'detail_birth_mismatch');fill.assert_not_called();send.assert_not_called()

    def test_cancellation_or_student_navigation_prevents_review(self):
        for change in ('cancel','url'):
            page=Page();row=self.row(page);row['manual']={'الهواتف / رقم الهاتف':'03123456'};cancelled=threading.Event()
            def saved(*args):
                if change=='cancel':cancelled.set()
                else:page.url+='/other-student'
                return 'detail_saved'
            with patch('manual_sections.fill_manual_section',return_value='detail_filled'),patch('manual_save.save_manual',side_effect=saved),patch('manual_save.send_review') as send,self.assertRaises(DetailError):
                self.invoke(page,row,True,cancelled)
            send.assert_not_called()

    def test_existing_matching_address_is_reused_and_conflicting_address_is_skipped(self):
        for conflict in (False,True):
            page=Page();page.existing=True;row=self.row(page)
            row['manual']={};row['address']=dict(page.choices,الشارع='شارع اختبار')
            for label in page.choices:page.values[label]='test'
            page.values['الشارع']='شارع مختلف' if conflict else 'شارع اختبار'
            if conflict:
                self.assertEqual(self.invoke(page,row),'detail_import_skipped_section')
                self.assertEqual(page.values['الشارع'],'شارع مختلف')
                self.assertNotIn(('click','حفظ القسم'),page.actions)
            else:self.assertEqual(self.invoke(page,row),'detail_import_saved')
            self.assertNotIn(('click','إضافة'),page.actions)

    def test_legacy_excel_format_uses_existing_address_phone_and_mother_paths(self):
        page=Page();row={'values':page.values.copy(),'address':dict(page.choices),'phone':'03123456','mother_surname':'شهرة اختبار'}
        self.assertEqual(self.invoke(page,row),'detail_import_saved')
        self.assertEqual(page.actions.count(('click','تأكيد')),3)

    def test_already_sent_status_is_not_reported_as_a_second_submission(self):
        page=Page();row=self.row(page)
        with patch('manual_sections.fill_manual_section',return_value='detail_filled'),patch('manual_save.save_manual',return_value='detail_saved'),patch('manual_save.send_review',return_value='detail_review_already'):
            self.assertEqual(self.invoke(page,row,True),'detail_import_review_already')


if __name__=='__main__':unittest.main()
