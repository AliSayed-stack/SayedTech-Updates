"""Choose a local school database and export an explicitly unselected reference."""
from pathlib import Path
import threading
import zipfile

from PySide6.QtCore import QThread, Signal, Qt, QUrl, QSettings
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QFileDialog, QProgressBar, QWidget, QCheckBox)
import core
from nsldb_reference import export_database, ReferenceError, TARGET_YEAR

MESSAGES = {
    'input': 'اختر ملف NSLDB بصيغة sdf موجوداً على جهازك.',
    'dependency': 'قارئ NSLDB غير متوفر. أغلق البرنامج وشغّل START_WINDOWS.bat لتحديث المتطلبات باستخدام Python 3.12 أو 3.13 بنظام 64 بت.',
    'password': 'تعذّر فتح هذه القاعدة باستخدام الملفات المدموجة. إذا كانت نسختكم مختلفة، اختر ملف MEHENSL.exe أو MDBL.dll الموجود عندكم ثم أعد المحاولة.',
    'program': 'تعذّرت قراءة ملف البرنامج القديم. اختر ملف MDBL.dll أو MEHENSL.exe أو ملف config الأصلي.',
    'format': 'تعذّرت قراءة قاعدة SQL CE. تأكد من الملف وكلمة السر ومن إغلاق البرنامج القديم قبل التصدير.',
    'schema': 'هذا الملف لا يطابق جداول NSLDB المطلوبة. لم يتم تصدير بيانات جزئية.',
    'count': 'عدد السجلات المقروءة لا يطابق القاعدة. لم يتم تصدير بيانات جزئية.',
    'identity': 'تعذّر ربط سجلات الطلاب بالأشخاص بشكل واضح. لم يتم تصدير بيانات جزئية.',
    'limit': 'الحد الحالي 5000 تسجيل طلاب وملف قاعدة بحجم 512 ميغابايت. لم يُقتطع جزء من البيانات.',
    'empty': 'لا توجد تسجيلات طلاب في هذه القاعدة.',
    'cell_limit': 'توجد قيمة نصية أطول من حد خلية Excel (32767 حرفاً). لم تُقصّ البيانات ولم يتم تصدير ملف جزئي.',
    'changed': 'تغيّر الملف أثناء نسخه. أغلق برنامج القاعدة القديم وأعد المحاولة.',
    'cancelled': 'أُلغي التصدير. لم يُستبدل ملف Excel السابق.',
    'output': 'اختر مكاناً متاحاً لحفظ ملف xlsx وأغلقه إذا كان مفتوحاً.',
    'mode': 'اختر تصديراً مبسّطاً أو مفصّلاً.',
    'year': 'السحب الحالي مخصص للعام \u200e2025–2026\u200e فقط.',
    'year_empty': 'لا توجد تسجيلات للعام \u200e2025–2026\u200e في هذه القاعدة.',
    'failed': 'تعذّر إكمال التصدير. لم تُرسل بيانات ولم يُعدّل ملف القاعدة الأصلي.'}


class ExportWorker(QThread):
    progress = Signal(str, int, int)

    def __init__(self, source, destination, password, program, parent, mode='detailed'):
        super().__init__(parent)
        self.source, self.destination = source, destination
        self.password, self.program = password, program
        self.mode = mode
        self.cancelled = threading.Event()
        self.result = None
        self.error = ''

    def run(self):
        try:
            self.result = export_database(self.source, self.destination, self.password,
                self.program, self.cancelled, self.progress.emit, mode=self.mode, academic_year=TARGET_YEAR)
        except ReferenceError as exc:
            self.error = exc.code
        except OSError:
            self.error = 'output'
        except Exception:
            self.error = 'failed'
        finally:
            self.password = ''


class NSLDBDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self.output = ''
        self.simple_output = ''
        self.detailed_output = ''
        self.settings=QSettings('SayedTech','SayedTech')
        school=core.read_school()
        shift=getattr(parent,'school_shift','morning') if parent else 'morning'
        self.workbook_key=f"student_workbook/{school.get('center','unknown')}/{shift}/2025-2026"
        self.setWindowTitle(f'Sayed tech {core.APP_VERSION} | NSLDB إلى Excel')
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(850, 560)
        layout = QVBoxLayout(self)
        intro = QLabel('بيانات الطلاب \u200e2025–2026\u200e — سحب ثم تحويل ثم تسجيل')
        layout.addWidget(intro)
        note = QLabel('1. اسحب كافة بيانات عام \u200e2025–2026\u200e بكل الحالات، مع الهاتف والتسلسل والإفادات وبقية بيانات القاعدة.\n'
            '2. جهّز الملف الموحد مرة واحدة. لاحقاً اضغط «استكمال ملف Excel السابق» واشتغل على الملف نفسه.\n'
            '3. في Excel: أول عمود «اختيار للاستيراد»؛ ضع 1 أو نعم للطلاب المطلوب تسجيلهم، و0 أو لا للبقية. '
            'أكمل النواقص واحفظ الملف نفسه. لإضافة طالب يدوياً، أضف صفاً وحدّد «طالب جديد»، أو «طالب موجود بمدرسة أخرى» إذا له سجل على النظام. '
            'بعد إدخال الاسم العربي، اضغط «ترجمة الأسماء الجديدة» ليملأ الملف خانات الإنجليزية الفارغة، ثم راجعها. '
            'اختر «تسجيل مبسّط» أو «استيراد مفصّل».\n\n'
            'السحب والتحويل محليان. يبقى ملف القاعدة والسحب الكامل كما هما. اختيار الطالب يعني انتسابه لمدرستك؛ '
            'المبسّط يسجّل صف القاعدة كطالب موجود، والصف اليدوي حسب طريقة التسجيل المختارة؛ المفصّل لاستكمال طالب محفوظ. حدّد 1 أو نعم للطلاب المقصودين بالعملية الحالية.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.source = QLineEdit()
        self.source.setReadOnly(True)
        self.source.setPlaceholderText('اختر NSLDB.sdf')
        self.pick_source = QPushButton('اختيار ملف NSLDB')
        self.pick_source.clicked.connect(self.choose_source)
        row = QHBoxLayout()
        row.addWidget(self.source, 1)
        row.addWidget(self.pick_source)
        layout.addLayout(row)
        layout.addWidget(QLabel('يقرأ التطبيق ملفات MEHENSL المدموجة تلقائياً. سنة السحب ثابتة: \u200e2025–2026\u200e.'))
        self.advanced_toggle = QCheckBox('اختيار نسخة أخرى من MEHENSL — عند الحاجة فقط')
        layout.addWidget(self.advanced_toggle)
        self.advanced = QWidget()
        advanced_layout = QVBoxLayout(self.advanced)
        advanced_layout.setContentsMargins(0, 0, 0, 0)
        advanced_layout.addWidget(QLabel('إذا كانت القاعدة محمية، اختر ملف MEHENSL الموجود عندكم أو أدخل كلمة سر القاعدة:'))
        self.program = QLineEdit()
        self.program.setReadOnly(True)
        self.program.setPlaceholderText('MDBL.dll أو MEHENSL.exe — اختياري')
        self.pick_program = QPushButton('اختيار البرنامج القديم')
        self.pick_program.clicked.connect(self.choose_program)
        row = QHBoxLayout()
        row.addWidget(self.program, 1)
        row.addWidget(self.pick_program)
        advanced_layout.addLayout(row)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setMaxLength(40)
        self.password.setPlaceholderText('كلمة سر قاعدة البيانات إن توفرت — لا تُحفظ')
        advanced_layout.addWidget(self.password)
        layout.addWidget(self.advanced)
        self.advanced.setVisible(False)
        self.advanced_toggle.toggled.connect(self.toggle_advanced)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        layout.addWidget(self.progress)
        self.status = QLabel('ابدأ بالسحب الكامل، ثم جهّز الملف الموحد. كل الطلاب غير مختارين افتراضياً.')
        self.status.setTextFormat(Qt.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        row = QHBoxLayout()
        self.export_button = QPushButton('1. سحب كافة بيانات \u200e2025–2026\u200e')
        self.export_button.clicked.connect(lambda: self.start())
        row.addWidget(self.export_button)
        self.convert_button = QPushButton('2. تجهيز ملف موحّد')
        self.convert_button.clicked.connect(self.convert)
        row.addWidget(self.convert_button)
        self.resume_button=QPushButton('استكمال ملف Excel السابق')
        self.resume_button.clicked.connect(self.choose_workbook)
        row.addWidget(self.resume_button)
        self.mother_column_button=QPushButton('إضافة عمود شهرة الأم لملف سابق')
        self.mother_column_button.clicked.connect(self.upgrade_mother_column)
        row.addWidget(self.mother_column_button)
        self.card_columns_button=QPushButton('إضافة أعمدة بطاقة التعريف لملف سابق')
        self.card_columns_button.clicked.connect(self.upgrade_card_columns)
        self.register_button = QPushButton('3. تسجيل مبسّط')
        self.register_button.clicked.connect(self.register)
        row.addWidget(self.register_button)
        layout.addLayout(row)
        layout.addWidget(self.card_columns_button)
        self.merge_site_button=QPushButton('سحب طلاب SIMS ودمجهم مع ملف NSLDB')
        self.merge_site_button.clicked.connect(self.merge_site)
        layout.addWidget(self.merge_site_button)
        row = QHBoxLayout()
        self.import_details_button=QPushButton('استيراد مفصّل')
        self.import_details_button.clicked.connect(self.import_details)
        row.addWidget(self.import_details_button)
        self.translate_button=QPushButton('ترجمة أسماء التلاميذ الجدد وتجهيز القيم الافتراضية')
        self.translate_button.clicked.connect(self.translate_names)
        row.addWidget(self.translate_button)
        self.cancel_button = QPushButton('إيقاف')
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancel)
        row.addWidget(self.cancel_button)
        self.open_button = QPushButton('فتح ملف Excel')
        self.open_button.setEnabled(False)
        self.open_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self.detailed_output or self.simple_output or self.output)))
        row.addWidget(self.open_button)
        self.close_button = QPushButton('إغلاق')
        self.close_button.clicked.connect(self.reject)
        row.addWidget(self.close_button)
        layout.addLayout(row)
        previous=self.settings.value(self.workbook_key,'',type=str)
        if previous and Path(previous).is_file():
            try:self.use_workbook(previous)
            except (OSError,ValueError,KeyError,zipfile.BadZipFile):pass

    def use_workbook(self,path):
        from student_unified import is_unified, UNIFIED_HEADERS, LAST_UNIFIED_HEADERS, SELECTION, MARKER, SITE_MERGE_MARKER, MATCH_COLUMN, unified_columns_match
        from nsldb_reference import REFERENCE_EXTRA, DETAILED_CHOICE
        from student_workflow import workbook_rows
        from student_excel import ExcelInputError
        with zipfile.ZipFile(path) as workbook:
            if not is_unified(workbook):raise ExcelInputError('اختر الملف الموحد الناتج عن البرنامج.')
            rows=workbook_rows(workbook,'الطلاب')
            headers=rows[0][1] if rows else {}
            standard=set(headers.values())
            marker={values.get('A'):values.get('B') for _,values,_ in workbook_rows(workbook,MARKER)}
            if marker.get(SITE_MERGE_MARKER)=='نعم':
                standard-=set((*REFERENCE_EXTRA[:2],DETAILED_CHOICE,MATCH_COLUMN))
            if headers.get('A')!=SELECTION or len(headers)!=len(set(headers.values())) or not unified_columns_match(
                    standard,(UNIFIED_HEADERS,LAST_UNIFIED_HEADERS)):
                raise ExcelInputError('عناوين الملف الموحد غير صالحة.')
        self.simple_output=self.detailed_output=path
        self.settings.setValue(self.workbook_key,path)
        self.open_button.setEnabled(True)
        self.status.setText('ملف العمل الحالي: '+path+' — افتحه وأكمل الخانات، ثم احفظه واختره للتسجيل أو الترجمة.')

    def choose_workbook(self):
        from student_excel import ExcelInputError
        path,_=QFileDialog.getOpenFileName(self,'استكمال ملف Excel الموحد',self.simple_output,'Excel (*.xlsx)')
        if not path:return
        try:self.use_workbook(path)
        except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
            self.status.setText(str(exc) if isinstance(exc,ExcelInputError) else 'تعذّر قراءة ملف Excel. اختر نسخة سليمة من الملف الموحد.')

    def upgrade_mother_column(self):
        from student_unified import add_mother_surname_column
        from student_excel import ExcelInputError
        source,_=QFileDialog.getOpenFileName(self,'اختر الملف الموحد السابق',self.simple_output,'Excel (*.xlsx)')
        if not source:return
        suggested=str(Path(source).with_name(Path(source).stem+'_mother_surname.xlsx'))
        destination,_=QFileDialog.getSaveFileName(self,'احفظ نسخة من ملفك مع عمود شهرة الأم',suggested,'Excel (*.xlsx)')
        if not destination:return
        if not destination.lower().endswith('.xlsx'):destination+='.xlsx'
        try:
            add_mother_surname_column(source,destination)
            self.use_workbook(destination)
        except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
            self.status.setText(str(exc) if isinstance(exc,ExcelInputError) else 'تعذّر تحديث الملف؛ بقي الملف الأصلي كما هو.')

    def upgrade_card_columns(self):
        from identity_workbook import add_identity_columns
        from student_excel import ExcelInputError
        source,_=QFileDialog.getOpenFileName(self,'اختر الملف الموحد السابق',self.simple_output,'Excel (*.xlsx)')
        if not source:return
        suggested=str(Path(source).with_name(Path(source).stem+'_identity_cards.xlsx'))
        destination,_=QFileDialog.getSaveFileName(self,'احفظ نسخة مع أعمدة بطاقة التعريف',suggested,'Excel (*.xlsx)')
        if not destination:return
        if not destination.lower().endswith('.xlsx'):destination+='.xlsx'
        try:
            add_identity_columns(source,destination)
            self.use_workbook(destination)
            self.status.setText('تم حفظ نسخة مع 3 أعمدة بعد السكن. اختر نوع المستند؛ نُسخ رقم الوثيقة من رقم السجل. تاريخ الانتهاء اختياري، والملف الأصلي محفوظ.')
        except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
            self.status.setText(str(exc) if isinstance(exc,ExcelInputError) else 'تعذّر تحديث الملف؛ بقي الأصل كما هو.')

    def choose_source(self):
        path, _ = QFileDialog.getOpenFileName(self, 'اختيار قاعدة بيانات الطلاب', '', 'SQL CE (*.sdf)')
        if path:
            self.source.setText(path)
            self.status.setText('اضغط سحب كافة بيانات \u200e2025–2026\u200e. لا تُستبعد أي حالة ضمن العام.')

    def choose_program(self):
        path, _ = QFileDialog.getOpenFileName(self, 'اختيار ملف البرنامج القديم لقراءة إعداد SDF',
                                             '', 'Legacy app (*.dll *.exe *.config)')
        if path:
            self.program.setText(path)

    def toggle_advanced(self, checked):
        self.advanced.setVisible(checked)
        if not checked:
            self.program.clear()
            self.password.clear()

    def set_pending(self, pending):
        for widget in (self.pick_source, self.pick_program, self.password, self.export_button, self.convert_button, self.resume_button, self.mother_column_button, self.card_columns_button, self.import_details_button, self.translate_button, self.register_button, self.merge_site_button, self.close_button, self.advanced_toggle):
            widget.setEnabled(not pending)
        self.cancel_button.setEnabled(pending)
        self.open_button.setEnabled(not pending and bool(self.detailed_output or self.simple_output or self.output))

    def start(self, mode='detailed'):
        if self.worker and self.worker.isRunning():
            return
        if not self.source.text():
            self.status.setText(MESSAGES['input'])
            return
        if mode != 'detailed':
            self.status.setText(MESSAGES['mode'])
            return
        path, _ = QFileDialog.getSaveFileName(self, 'حفظ كافة بيانات \u200e2025–2026\u200e', 'NSLDB_All_2025-2026.xlsx', 'Excel (*.xlsx)')
        if not path:
            return
        if not path.lower().endswith('.xlsx'):
            path += '.xlsx'
        self.output = ''
        password = self.password.text() if self.advanced_toggle.isChecked() else ''
        program = self.program.text() if self.advanced_toggle.isChecked() else ''
        self.worker = ExportWorker(self.source.text(), path, password, program, self, mode=mode)
        self.password.clear()
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.complete)
        self.set_pending(True)
        self.progress.setRange(0, 0)
        self.status.setText('جارٍ قراءة نسخة مؤقتة من القاعدة…')
        self.worker.start()

    def on_progress(self, stage, done, total):
        self.progress.setRange(0, total)
        self.progress.setValue(done)
        self.status.setText('جارٍ قراءة جداول الطلاب وربطها…' if stage == 'read' else
                            'جارٍ تجهيز Excel مع كل الصفوف غير مختارة…' if stage == 'export' else 'جارٍ فتح القاعدة…')

    def complete(self):
        if self.worker.error:
            self.status.setText(MESSAGES.get(self.worker.error, MESSAGES['failed']))
            if self.worker.error in {'password', 'program'}:
                self.advanced_toggle.setChecked(True)
            self.progress.setRange(0, 1)
            self.progress.setValue(0)
        else:
            result = self.worker.result
            self.output = self.worker.destination
            self.progress.setRange(0, result['records'])
            self.progress.setValue(result['records'])
            self.status.setText(f"تم حفظ {result['records']} تسجيل طلاب تخص {result['people']} شخصاً. "
                'عام \u200e2025–2026\u200e فقط، بكل الحالات. لا يوجد أي طالب مختار للتسجيل. الخطوة التالية: تجهيز ملف موحّد.')
        self.set_pending(False)

    def convert(self):
        from student_unified import convert_to_unified
        from student_excel import ExcelInputError
        source, _ = QFileDialog.getOpenFileName(self, 'اختر ملف السحب الكامل', self.output, 'Excel (*.xlsx)')
        if not source: return
        target, _ = QFileDialog.getSaveFileName(self, 'حفظ الملف الموحد للمبسّط والمفصّل', 'NSLDB_Students_2025-2026.xlsx', 'Excel (*.xlsx)')
        if not target: return
        if not target.lower().endswith('.xlsx'): target += '.xlsx'
        try:
            count = convert_to_unified(source, target)
        except ExcelInputError as exc:
            self.status.setText(str(exc)); return
        self.use_workbook(target)
        self.status.setText(f'تم تجهيز ملف واحد لـ{count} تسجيل، مع ترجمة الأسماء والقيم الافتراضية والعناوين والهواتف. عدّله واحفظه مرة واحدة؛ اختر نفس الملف للتسجيل المبسّط أو الاستيراد المفصّل. حدّد الطلاب في أول عمود لكل عملية.')

    def merge_site(self):
        parent=self.parent()
        if parent is None or not getattr(parent,'connected',False):
            self.status.setText('سجّل الدخول إلى SIMS أولاً.')
            return
        source,_=QFileDialog.getOpenFileName(self,'اختر ملف Excel المستخرج من NSLDB للدمج',self.detailed_output or self.output,'Excel (*.xlsx)')
        if not source:return
        from student_scan_dialog import StudentScanDialog
        StudentScanDialog(parent.login_controller,self,merge_source=source).exec()

    def import_details(self):
        from tempfile import TemporaryDirectory
        from detailed_import import read_details
        from detailed_dialog import DetailedImportDialog
        from student_excel import ExcelInputError
        parent=self.parent()
        if parent is None or not getattr(parent,'connected',False):
            self.status.setText('سجّل الدخول إلى النظام أولاً.');return
        path,_=QFileDialog.getOpenFileName(self,'اختر ملف الطلاب بعد تحديدهم للاسترداد المفصّل',self.detailed_output,'Excel (*.xlsx)')
        if not path:return
        with TemporaryDirectory(prefix='sayedtech-documents-') as directory:
            try:rows=read_details(path,image_directory=directory)
            except ExcelInputError as exc:self.status.setText(str(exc));return
            try:self.use_workbook(path)
            except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile):pass
            DetailedImportDialog(rows,parent.login_controller,parent).exec()

    def translate_names(self):
        from student_unified import translate_manual_names
        from student_excel import ExcelInputError
        path,_=QFileDialog.getOpenFileName(self,'اختر الملف الموحد بعد حفظ الأسماء وإغلاقه',self.simple_output,'Excel (*.xlsx)')
        if not path:return
        try:count=translate_manual_names(path)
        except (ExcelInputError,OSError,ValueError) as exc:
            self.status.setText(str(exc));return
        try:self.use_workbook(path)
        except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile):pass
        self.status.setText(f'تم تجهيز {count} خانة فارغة للأسماء الإنكليزية والقيم الافتراضية في الملف نفسه. افتحه وراجعها قبل التسجيل؛ القيم التي أدخلتها لم تتغير.')

    def register(self):
        from student_excel import read_students, ExcelInputError
        from student_dialog import StudentImportDialog
        parent = self.parent()
        if parent is None or not getattr(parent, 'connected', False):
            self.status.setText('سجّل الدخول إلى النظام أولاً.'); return
        path, _ = QFileDialog.getOpenFileName(self, 'اختر الملف الموحد بعد تحديد الطلاب للمبسّط وحفظه', self.simple_output, 'Excel (*.xlsx)')
        if not path: return
        try:
            rows = read_students(path, shift=getattr(parent,'school_shift','morning'))
        except ExcelInputError as exc:
            self.status.setText(str(exc)); return
        if not all(row.get('workflow') for row in rows):
            self.status.setText('استخدم الملف الناتج عن «تجهيز ملف موحّد» وحدّد الطلاب في أول عمود قبل التسجيل.'); return
        try:self.use_workbook(path)
        except (ExcelInputError,OSError,ValueError,KeyError,zipfile.BadZipFile):pass
        StudentImportDialog(rows, parent.login_controller, parent).exec()

    def cancel(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancelled.set()
            self.cancel_button.setEnabled(False)
            self.status.setText('جارٍ الإيقاف… انتظر انتهاء قراءة الجدول الحالي.')

    def reject(self):
        if self.worker and self.worker.isRunning():
            self.cancel()
            return
        self.password.clear()
        super().reject()

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.cancel()
            event.ignore()
        else:
            self.password.clear()
            super().closeEvent(event)
