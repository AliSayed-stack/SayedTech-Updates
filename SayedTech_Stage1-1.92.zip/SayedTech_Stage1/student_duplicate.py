"""Read-only school-roster check before a simple registration request."""
import uuid

from student_excel import validate_record, shift_for_username, first_invalid_field
from student_fill import StudentFillError
from student_scan import StudentBrowser, ScanError, canonical_uid, is_deleted, normalized

DUPLICATE_FAILURE_REASONS = {
    'filters_active': 'أعد فلاتر الصف والفرع واللغة والشعبة إلى «الجميع».',
    'search_active': 'امسح النص من خانة البحث في إدارة الطلاب.',
    'table_missing': 'جدول الطلاب ما ظهر خلال مهلة الانتظار.',
    'headers_changed': 'تعذّر التعرّف على أعمدة جدول الطلاب.',
    'pagination_missing': 'تعذّر العثور على عدّاد صفحات الطلاب.',
    'pagination_format': 'صيغة عدّاد الصفحات غير معروفة.',
    'page_size': 'تعذّر التعرّف على قائمة عدد الطلاب في الصفحة.',
    'page_not_changed': 'الجدول ما انتقل إلى الصفحة المطلوبة.',
    'count_changed': 'تغيّر عدد السجلات أثناء الجرد.',
    'row_count': 'عدد الصفوف الظاهرة ما طابق العدد المتوقع.',
    'rows_invalid': 'بعض صفوف جدول الطلاب ما أمكن قراءتها.',
    'status_missing': 'عمود حالة التسجيل غير متاح في الجدول.',
    'loading': 'الجدول ما استقر خلال مهلة الانتظار.',
    'grade_filter': 'تعذّر تحديد فلتر الصف في إدارة الطلاب.',
    'grade_options': 'تعذّر تحديد خيار جميع المستويات في فلتر الصف.',
    'unrecognized': 'تعذّر إكمال قراءة الجدول أو التنقّل بين صفحاته (ROSTER-READ).',
}


def _name(values):
    return tuple(normalized(values.get(key, '')) for key in
                 ('field-firstName', 'field-middleName', 'field-lastName'))


def _row_name(row):
    return tuple(normalized(row.get(key, '')) for key in ('first', 'middle', 'last'))


class DuplicateGuard:
    def __init__(self, browser_factory=StudentBrowser):
        self.browser_factory=browser_factory
        self.batch_id=None
        self.roster=[]
        self.browser=None

    def check(self, page, raw, username, cancelled, batch_id=None, account_session=None):
        data, errors=validate_record(raw,shift_for_username(username),registration=True)
        if errors: raise StudentFillError('student_invalid',first_invalid_field(errors))
        # A new batch (including each manual one-off request) rereads the live
        # roster. A confirmed save is added to the in-memory roster immediately.
        token=batch_id if isinstance(batch_id,str) and len(batch_id)==32 else uuid.uuid4().hex
        if self.batch_id!=token:
            self.batch_id=None
            try:
                browser=self.browser_factory(page,username,cancelled,account_session=account_session)
                try: roster=browser.inventory(lambda *_:None)
                except ScanError as exc:
                    if exc.code!='scan_empty':raise
                    state=browser.move(1)
                    if state['total']!=0:raise
                    roster=[]
            except ScanError as exc:
                if exc.code == 'scan_cancelled':
                    raise StudentFillError('student_cancelled') from exc
                if exc.code == 'scan_account_required':
                    raise StudentFillError('student_account_required') from exc
                reason = exc.reason if exc.reason in DUPLICATE_FAILURE_REASONS else 'unrecognized'
                raise StudentFillError('student_duplicate_check_failed', reason) from exc
            except Exception:
                raise StudentFillError('student_duplicate_check_failed', 'unrecognized') from None
            if any('status' not in row for row in roster):
                raise StudentFillError('student_duplicate_check_failed', 'status_missing')
            self.roster=roster
            self.browser=browser
            self.batch_id=token
        uid=canonical_uid(data.get('field-existingUniqueId',''))
        name=_name(data)
        if not all(name):raise StudentFillError('student_duplicate_review')
        candidates=[row for row in self.roster if not is_deleted(row) and
                    ((uid and row['uid']==uid) or _row_name(row)==name)]
        if not candidates:return 'clear'
        # A shared ID with a conflicting name, or the same name with a
        # conflicting nonblank ID, needs a person to resolve it.
        for row in candidates:
            if uid and row['uid']==uid and _row_name(row)!=name:
                raise StudentFillError('student_duplicate_review')
            if uid and row['uid'] and row['uid']!=uid and _row_name(row)==name:
                raise StudentFillError('student_duplicate_review')
        # The management table does not show birth dates. Open only plausible
        # rows to confirm the date, even when their unified IDs agree.
        for row in candidates:
            if _row_name(row)!=name:continue
            try: dob=row['birthDate'] if row.get('_saved') else self.browser.read_birth_date(row)
            except Exception:
                raise StudentFillError('student_duplicate_review') from None
            if not dob:raise StudentFillError('student_duplicate_review')
            if dob==data['field-birthDate']:return 'registered'
            # The same full name with a different date is not proof that the
            # roster row is a different person; stop for human review.
            raise StudentFillError('student_duplicate_review')
        return 'clear'

    def note_saved(self, data):
        self.roster.append({'uid':canonical_uid(data.get('field-existingUniqueId','')),
            'first':data['field-firstName'],'middle':data['field-middleName'],
            'last':data['field-lastName'],'status':'قيد الانتظار',
            'birthDate':data['field-birthDate'],'_saved':True})
